import { defineConfig, devices } from '@playwright/test';

export default defineConfig({
  testDir: './test/browser',
  outputDir: '.codex-tmp/playwright-results',
  timeout: 30_000,
  workers: 1,
  expect: { timeout: 10_000 },
  fullyParallel: false,
  forbidOnly: !!process.env.CI,
  retries: process.env.CI ? 1 : 0,
  reporter: process.env.CI ? [['github'], ['list']] : 'list',
  use: {
    baseURL: 'http://127.0.0.1:5193',
    trace: 'retain-on-failure',
    video: 'off',
  },
  projects: [{
    name: 'chromium',
    use: {
      ...devices['Desktop Chrome'],
      viewport: { width: 1280, height: 720 },
      // The full Chromium channel uses Chromium's new headless mode. The
      // default headless shell can lose its software WebGL context before the
      // production app receives any input; do not hide that condition.
      channel: process.env.CAVE9_BROWSER_CHANNEL || 'chromium',
    },
  }],
  webServer: {
    command: 'npm run build && npm run preview -- --host 127.0.0.1 --port 5193 --strictPort',
    url: 'http://127.0.0.1:5193',
    reuseExistingServer: false,
    timeout: 120_000,
  },
});
