# Cave9

A fast, minimalist **3D cave-runner** for the web and mobile, inspired by the
classic [cave9](https://github.com/bart9h/cave9) from **9Hells**
("SF-Cave goes 3D").

Fly **first-person** down a tight, organic, crystalline rock tube — no ship or
cockpit on screen, only a minimalist crosshair while you fly. You can't slow
down and gravity keeps pulling you down; all you have are two diagonal
thrusters. Skim the walls and lethal roots, blades and ribs for points, go deep,
crash, retry. Chase the distance.

On phones the game is **landscape-first**: in portrait it shows a rotate hint
rather than squashing the view; in landscape the invisible touch halves stay
inside the safe area and leave the tunnel unobstructed.

> Built with [Three.js](https://threejs.org) + [Vite](https://vitejs.dev).
> The fixed-step physics, controls and seed determinism descend from the original
> C sources (kept in [`_original/`](_original/)). The release generator is now
> route-first: a provably flyable line is built before the cave around it.

## Controls

| Input        | Action                                                            |
| ------------ | ----------------------------------------------------------------- |
| **Keyboard** | `←` / `A` = move left · `→` / `D` = move right · `↑` / `W` / `Space` = up · hold Up + Left/Right for a diagonal · `Esc` / `P` = pause · `Enter` = confirm |
| **Gamepad**  | Left stick / shoulders / triggers = thrusters · `A` = both · `Start` = pause |
| **Touch**    | Tap-and-hold the **left half** / **right half** of the screen     |

Two control schemes (Settings → *Control scheme*): **Two thrusters** (default)
or **One button** (any input fires both — easier).
Left + Right remains pure upward thrust. Holding Up together with one side is
accepted simultaneously and duty-cycled at the fixed 60 Hz physics rate between
both thrusters and the requested side, producing a stable diagonal trajectory.

After pausing, release and press gamepad Start again, or press A, to resume.
Touch has a visible pause control. Switching to portrait pauses an active run;
returning to landscape leaves an explicit Resume action.

## Runs, records and shared links

Free play uses the chosen control mode, thrust sensitivity and landmark setting.
Those rules are frozen for the run and its retries. Daily uses the UTC day,
two thrusters, normal thrust and enabled landmarks; retrying after midnight
retains the original day and seed. Daily does not overwrite personal settings.

Records are grouped by the exact rule profile. The result screen shows the
previous comparable seed best (or Daily best), distance, maximum speed, graze
and combo telemetry. Older local scores remain preserved through the legacy
storage API and are not silently presented as comparable ranked records.

Enter a signed, nonzero 32-bit seed on the menu, or copy a run link from the
result screen. A validated link retains its seed and rules, including its day
for Daily. It offers an explicit Start shared run action. Copy success or
failure is visible. First-run help can be skipped, and the initial motion
setting respects the system's reduced-motion preference.

## Quick start (no terminal, double-click)

Just want to play locally? Use the double-click starter — it checks Node.js,
installs dependencies if needed, builds the web version, serves it over a local
HTTP server and opens your browser automatically (never `file://`):

* **Windows** — double-click **`START_CAVE9.bat`** (or run `START_CAVE9.ps1`).
* **Linux / macOS** — `chmod +x start-cave9.sh` once, then `./start-cave9.sh`.

Requires [Node.js](https://nodejs.org) 20.19+ on the 20.x line, or 22.12+
(Node 22 is the CI target). Full walkthrough, stop
instructions and troubleshooting: [`QUICK_START.md`](QUICK_START.md).

## Quick start (development)

```bash
npm ci
npm run dev          # http://127.0.0.1:5173 (loopback only)
```

## Run the tests

```bash
npm test             # headless unit tests for the core logic
npm run test:clean   # npm ci, tests and build in an isolated source copy
npx playwright install chromium
npm run test:browser # production Chromium input/UI/storage regressions
npm run audit:seeds  # 50-seed fairness audit → SEED_AUDIT_REPORT.md
npm run capture      # deterministic screenshots → docs/screenshots/
npm run style        # reference-band descriptors + one contact sheet
npm run schematics   # assertable cross/longitudinal collision SVGs
npm run flight:record # per-frame headless telemetry JSON
npm run visual:relief-ab -- --run-id relief-check --chrome
```

Covers deterministic route and wall generation, Boolean-tube exclusion,
route-frame invariants, complete visible-surface collision, the 50-seed
10-km autopilot oracle, the crash/score loop, graze/combo risk-reward scoring,
settings, input, reduced motion and audio. See
[`TEST_EVIDENCE.md`](TEST_EVIDENCE.md) for the full evidence matrix and
screenshots, and [`SCORING_REPORT.md`](SCORING_REPORT.md) /
[`RUN_SUMMARY_REPORT.md`](RUN_SUMMARY_REPORT.md) /
[`GAME_FEEL_REPORT.md`](GAME_FEEL_REPORT.md) for the risk/reward design.

For form-language review without relying on a cockpit screenshot,
`npm run capture:orbit` records every landmark family from six external angles.
`npm run style` lays the full depth ladder out as a single SVG contact sheet.

### Performance evidence

`npm run perf:sim` profiles the production build at 1920×1080/DPR 1 on a
dedicated port. It applies separate 4× CPU throttling and SwiftShader bounds,
plus resource ceilings; the combined CPU+SwiftShader run is diagnostic only.
This is a reproducible proxy for the target envelope. **No GMKtec G3 Pro or
Intel UHD machine is available, so real target-hardware performance remains
untested and is not claimed.** See
[`BOOLEAN_TUBE_RELEASE.md`](BOOLEAN_TUBE_RELEASE.md) for the exact gate contract.

The previously recorded 25.3/33.7/25.8 ms SwiftShader release profile is
historical evidence for its own source fingerprint, not a pass for the current
geometry/material revision. A new full 30 s warm-up / 90 s sample / three-run
matrix is still required before the current build can claim a performance
release. The production hardware path enables normal+height relief with rock
detail; the software-GPU path disables that relief and uses its documented
fallback. Short diagnostics do not establish a release performance pass.

The [29 September diagnosis](docs/performance/A08_PERFORMANCE_2026-09-29.md)
corrects texture accounting to include all 53 array layers. R8 height uploads
reduce the measured texture estimate to 8,148,234 bytes, below the existing
8-MiB limit, with pixel-identical High captures. Performance quality uses
an internal ratio of `0.75 × min(devicePixelRatio, 1)`; High retains its cap of 2. At DPR 1,
the diagnostic room's SwiftShader p95 changed from 28.7 to 16.1 ms.
The moving Coiling case failed that historical short profile. The subsequent
V00–V08 work removed repeated Atlas/ring construction and passed an isolated
Coiling short run. Root/Crystal short timing limits and complete performance
acceptance remain open; the current evidence is in
[the visual-form run status](docs/planning/VISUAL_FORM_RUN_STATUS.md).

`npm run visual:relief-ab -- --run-id <id> --chrome` captures immutable 1280×720
before/after frames for both the general cave and Coiling maps, records WebGL
errors and verifies that the extra textures and shader define are absent in the
baseline. Set `PERF_SURFACE_RELIEF=0` for a diagnostic `perf:sim` comparison;
release evidence uses the production default, with relief requested and the
software-renderer fallback recorded explicitly.

## Build the static web version

```bash
npm run build        # outputs static files to dist/
npm run preview      # serve the production build locally (--host for LAN)
```

`dist/` is fully static and uses **relative paths**, so you can drop it on any
static host or a sub-path.

### Offline play and updates

The production build generates `dist/sw.js` from the final files and their
SHA-256 hashes. On HTTPS or localhost, a successful first online installation
caches the complete game for later offline starts. Development (`npm run dev`)
does not register a worker. Build-time previews and source textures are kept
under `docs/assets/` and excluded from the production download.

Each deployment path and build has a separate cache. An update is installed
only when every file matches its expected hash. Existing tabs keep their old
complete version, including public assets whose names have not changed. The
menu or result screen shows when an update is ready: **close all Cave9 tabs,
then reopen the game**. Reloading one tab while others remain open is not an
activation step. A running game is never automatically reloaded.

### Hosting options

The installable PWA is hosted at **[elheron.github.io/cave9-pwa](https://elheron.github.io/cave9-pwa/)**.
The separate [publication repository](https://github.com/ElHeron/cave9-pwa)
contains the production build, retained license notices and a matching source
download. GitHub Pages serves its `main` branch with HTTPS enforced.

To prepare another release on Windows, run:

```powershell
pwsh -NoProfile -File scripts/package-pwa.ps1
```

This produces `artifacts/pwa/cave9-pwa.zip` and a fresh upload directory.
The game and license notices are cached for offline use; the separate source
download is online-only. When committing the upload directory to the publication
repository, retain its `.nojekyll` and `.gitattributes` (`* -text`) files so
GitHub serves the exact bytes hashed by the offline worker.

* **GitHub Pages** — push `dist/` to a `gh-pages` branch, or build in CI and
  deploy the `dist/` artifact. (Relative `base: './'` makes project sub-paths
  like `user.github.io/cave9/` work out of the box.)
* **itch.io** — zip the contents of `dist/` (with `index.html` at the zip root)
  and upload as an HTML5 game.
* **Netlify / Vercel / any static host** — build command `npm run build`,
  publish directory `dist`.

## Mobile / Android

The game supports touch controls and is available both as a PWA and as a signed
Android app. The Android app bundles the game files for offline use from its
first launch, runs fullscreen in landscape, and pauses when sent to the
background. Android Back pauses play, returns from submenus, or closes the main
menu. Physical phone performance and controller hardware still need device testing.

### Option A — PWA (no store, fastest)
1. Host the `dist/` build over HTTPS.
2. Open it in Chrome on Android → menu → **Add to Home screen**.
3. Launches fullscreen with touch controls.

### Android APK

Download [Cave9 1.0.0 for Android](https://github.com/ElHeron/cave9-pwa/releases/download/android-v1.0.0/cave9-1.0.0.apk)
on your phone, open the downloaded APK, and allow installation from that browser
if Android asks. The app ID is `io.github.elheron.cave9`; it requires Android 7.0
(API 24) or later and an up-to-date Android System WebView with WebGL 2 support.
The [release page](https://github.com/ElHeron/cave9-pwa/releases/tag/android-v1.0.0)
also includes matching source and SHA-256 checksums.

The checked-in [Capacitor](https://capacitorjs.com/) Android project builds with
Node 22.12+ (or Node 24), JDK 21 and Android SDK 36. On Windows:

```powershell
npm ci
npm run android:build
# Optional debug APK and Play Store bundle:
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/build-android.ps1 -IncludeDebug -IncludeBundle
# Custom installed tool locations:
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/build-android.ps1 -SdkPath 'D:\Android\UE58Sdk' -JavaPath 'C:\Program Files\Android\Android Studio\jbr'
```

The build script runs release lint, verifies the APK signature, and writes the
APK, matching source archive, and checksums to `artifacts/android/`. It creates
a release signing key on the first build and reuses it for updates. Back up
`artifacts/android/signing/` securely: the key is needed to update existing
installations. This directory is ignored by Git and excluded from source archives.
Increment `versionCode` in `android/app/build.gradle` and `version` in
`package.json` before publishing an update.

> Tip: lock to landscape and lower *Render quality* to **Performance** in
> Settings on lower-end phones.

## Project layout

See [`ARCHITECTURE.md`](ARCHITECTURE.md) for the layer contract and
[`BOOLEAN_TUBE_RELEASE.md`](BOOLEAN_TUBE_RELEASE.md) for the current generator,
collision and measurement contract — start there before changing anything
structural.
[`MODERNIZATION_PLAN.md`](MODERNIZATION_PLAN.md) has the original analysis behind
the current browser-game direction. Short version:

```
src/core/      pure game logic (ported from C, framework-free, unit-tested)
src/app/       the frame: session runner, fixed-step ticker, settings bindings
src/render/    Three.js renderer, camera, landmark geometry
src/platform/  input, audio, save, settings
src/ui/        DOM menus, HUD, debug overlay, styles
src/main.js    composition root + app state machine
public/assets/ retained sounds/icon + generated runtime materials
_original/      the original cave9 C sources (preserved reference & credit)
```

## Credits & license

This project is inspired by the original GPLv3 cave9 and is published under
**GPL-3.0-or-later**. The original game remains a separate project by
**9Hells** and contributors. Retained original audio/reference files and all
third-party notices are documented in [`LICENSE_NOTES.md`](LICENSE_NOTES.md)
and [`licenses/`](licenses/); the current cave, formation and UI textures were
created for this project.
