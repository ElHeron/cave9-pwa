# Cave9 app icon

The final icon is **T4 · Tusche Pur**, selected by the user on 2026-10-02 with **5/5** in review round 3. The original artwork is kept intact in [assets/branding/cave9-tusche-pur.png](../../assets/branding/cave9-tusche-pur.png). It was generated with built-in Imagegen. The prompt and reference images are recorded in [the round-3 concepts](../reviews/icon-concepts-2026-10-02/round-3/concepts.json); the user's final ratings are saved in [icon-selection.json](icon-selection.json).

The packaging step resizes this exact artwork; it does not regenerate or retouch the design. With Python and Pillow installed, reproduce all shipped sizes from the repository root:

```powershell
python scripts/build-app-icons.py
```

Web assets are in `public/assets/`: the 64px favicon, 192px and 512px install icons, a 180px Apple touch icon, and a separate 512px maskable icon. The maskable version places the artwork at 80% scale on warm ivory. `icon.svg` retains the existing URL and embeds the 512px PNG; it is a raster-backed SVG, not a traced vector.

Android launcher images cover mdpi through xxxhdpi. Adaptive foregrounds use a 108dp canvas with the original square scaled to 64.8dp, preserving the rough silhouette inside the central safe area. Launcher, round launcher and splash references all use the selected artwork. The warm icon background is separate from the dark game/splash background.

Run `npm run build` for the PWA and `npm run android:prepare` to sync the web assets into the native project. Existing published PWA/APK releases need a separate release to receive these assets.
