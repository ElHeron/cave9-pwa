import { defineConfig } from 'vite';
import { writeFileSync, mkdirSync } from 'node:fs';
import { resolve } from 'node:path';

// Dev-only middleware: lets the running page persist a canvas/DOM capture to
// disk for screenshot evidence (POST /__shot?name=foo with a data URL body).
// Never registered in the production build.
function screenshotSaver() {
  return {
    name: 'cave9-screenshot-saver',
    apply: 'serve',
    configureServer(server) {
      server.middlewares.use('/__shot', (req, res) => {
        if (req.method !== 'POST') { res.statusCode = 405; res.end(); return; }
        const name = (new URL(req.url, 'http://x').searchParams.get('name') || 'shot')
          .replace(/[^a-z0-9_-]/gi, '');
        let body = '';
        req.on('data', (c) => { body += c; });
        req.on('end', () => {
          try {
            const b64 = body.replace(/^data:image\/\w+;base64,/, '');
            const dir = resolve(process.cwd(), 'docs/screenshots');
            mkdirSync(dir, { recursive: true });
            const ext = body.startsWith('data:image/png') ? 'png' : 'jpg';
            writeFileSync(resolve(dir, `${name}.${ext}`), Buffer.from(b64, 'base64'));
            res.statusCode = 200; res.end('ok');
          } catch (e) {
            res.statusCode = 500; res.end(String(e));
          }
        });
      });
    },
  };
}

// Cave9 web build.
// `base: './'` makes the build use relative asset paths so it can be hosted
// statically from any sub-path (GitHub Pages project sites, itch.io, Netlify, …).
export default defineConfig({
  base: './',
  plugins: [screenshotSaver()],
  build: {
    target: 'es2020',
    outDir: 'dist',
    assetsInlineLimit: 0,
    rollupOptions: {
      output: {
        // Three.js changes independently from Cave9's application code and is
        // large enough to dominate the entry chunk. Keeping it in a stable
        // vendor chunk removes the oversized-entry warning and lets browsers
        // cache the engine across application-only deployments.
        manualChunks(id) {
          if (id.includes('/node_modules/three/')) return 'three';
          return undefined;
        },
      },
    },
  },
  server: {
    host: '127.0.0.1',
    port: 5173,
  },
  preview: {
    host: '127.0.0.1',
  },
});
