import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { PNG } from 'pngjs';
import { writeUiMenuContactSheet } from './ui-menu-contact-sheet.mjs';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const SOURCE_DIR = path.join(ROOT, 'artifacts', 'ui-runtime-v2', 'sources');
const OUTPUT_DIR = path.join(ROOT, 'src', 'ui', 'textures', 'v2');
const CONTACT_SHEET = path.join(ROOT, 'artifacts', 'ui-runtime-v2', 'ui-menu-assets-v2-contact-sheet.png');

const SPECS = [
  { id: 'panel', source: 'panel-source.png', rect: [6, 6, 1242, 1242], size: [512, 512] },
  { id: 'button-neutral', source: 'buttons-source.png', rect: [55, 144, 673, 329], size: [384, 192] },
  { id: 'button-hover', source: 'buttons-source.png', rect: [806, 144, 672, 333], size: [384, 192] },
  { id: 'button-primary', source: 'buttons-source.png', rect: [56, 571, 672, 331], size: [384, 192] },
  { id: 'button-disabled', source: 'buttons-source.png', rect: [806, 571, 672, 331], size: [384, 192] },
  { id: 'toggle-off', source: 'micro-controls-source.png', rect: [69, 259, 514, 246], size: [256, 128] },
  { id: 'toggle-on', source: 'micro-controls-source.png', rect: [671, 259, 514, 247], size: [256, 128] },
  { id: 'slider-rail', source: 'slider-rail-alpha.png', rect: [119, 387, 1536, 121], size: [384, 48] },
  { id: 'slider-hinge', source: 'slider-hinge-alpha.png', rect: [273, 266, 707, 720], size: [128, 128] },
  { id: 'slider-lever', source: 'slider-lever-alpha.png', rect: [436, 339, 382, 568], size: [96, 128] },
  { id: 'divider', source: 'micro-controls-source.png', rect: [679, 816, 502, 76], size: [384, 64] },
  { id: 'button-danger', source: 'semantic-source.png', rect: [14, 183, 611, 401], size: [384, 192] },
  { id: 'crash-plate', source: 'semantic-source.png', rect: [645, 184, 583, 400], size: [384, 192] },
  { id: 'success-badge', source: 'semantic-source.png', rect: [14, 679, 621, 337], size: [384, 192] },
  { id: 'success-medallion', source: 'semantic-source.png', rect: [820, 679, 315, 338], size: [192, 192] },
];

function readPng(file) {
  if (!fs.existsSync(file)) throw new Error(`Missing UI source image: ${file}`);
  return PNG.sync.read(fs.readFileSync(file));
}

function cropNearest(source, rect, targetSize) {
  const [x0, y0, width, height] = rect;
  const [targetWidth, targetHeight] = targetSize;
  if (x0 < 0 || y0 < 0 || x0 + width > source.width || y0 + height > source.height) {
    throw new Error(`Crop ${rect.join(',')} exceeds ${source.width}x${source.height}`);
  }

  const out = new PNG({ width: targetWidth, height: targetHeight });
  for (let y = 0; y < targetHeight; y++) {
    const sourceY = y0 + Math.min(height - 1, Math.floor((y + 0.5) * height / targetHeight));
    for (let x = 0; x < targetWidth; x++) {
      const sourceX = x0 + Math.min(width - 1, Math.floor((x + 0.5) * width / targetWidth));
      const sourceOffset = (sourceY * source.width + sourceX) * 4;
      const targetOffset = (y * targetWidth + x) * 4;
      source.data.copy(out.data, targetOffset, sourceOffset, sourceOffset + 4);
    }
  }
  return out;
}

function fill(png, rgba) {
  for (let i = 0; i < png.data.length; i += 4) {
    png.data[i] = rgba[0];
    png.data[i + 1] = rgba[1];
    png.data[i + 2] = rgba[2];
    png.data[i + 3] = rgba[3];
  }
}

function clearExterior(png, threshold = 28) {
  const rowLeft = new Int32Array(png.height).fill(png.width);
  const rowRight = new Int32Array(png.height).fill(-1);
  const columnTop = new Int32Array(png.width).fill(png.height);
  const columnBottom = new Int32Array(png.width).fill(-1);

  for (let y = 0; y < png.height; y++) {
    for (let x = 0; x < png.width; x++) {
      const offset = (y * png.width + x) * 4;
      const visible = png.data[offset + 3] > 12
        && Math.max(png.data[offset], png.data[offset + 1], png.data[offset + 2]) > threshold;
      if (!visible) continue;
      rowLeft[y] = Math.min(rowLeft[y], x);
      rowRight[y] = Math.max(rowRight[y], x);
      columnTop[x] = Math.min(columnTop[x], y);
      columnBottom[x] = Math.max(columnBottom[x], y);
    }
  }

  for (let y = 0; y < png.height; y++) {
    for (let x = 0; x < png.width; x++) {
      const outsideRow = rowRight[y] < 0 || x < rowLeft[y] || x > rowRight[y];
      const outsideColumn = columnBottom[x] < 0 || y < columnTop[x] || y > columnBottom[x];
      if (outsideRow || outsideColumn) png.data[(y * png.width + x) * 4 + 3] = 0;
    }
  }
  return png;
}

fs.mkdirSync(OUTPUT_DIR, { recursive: true });
fs.rmSync(path.join(OUTPUT_DIR, 'slider.png'), { force: true });
const sourceCache = new Map();
const generated = new Map();

for (const spec of SPECS) {
  if (!sourceCache.has(spec.source)) {
    sourceCache.set(spec.source, readPng(path.join(SOURCE_DIR, spec.source)));
  }
  const output = clearExterior(cropNearest(sourceCache.get(spec.source), spec.rect, spec.size));
  const file = path.join(OUTPUT_DIR, `${spec.id}.png`);
  fs.writeFileSync(file, PNG.sync.write(output, { colorType: 6 }));
  generated.set(spec.id, output);
}

writeUiMenuContactSheet(CONTACT_SHEET, generated);

const totalBytes = SPECS.reduce((sum, spec) => {
  return sum + fs.statSync(path.join(OUTPUT_DIR, `${spec.id}.png`)).size;
}, 0);
console.log(`Built ${SPECS.length} UI assets (${totalBytes} bytes)`);
console.log(`Runtime: ${OUTPUT_DIR}`);
console.log(`Contact sheet: ${CONTACT_SHEET}`);
