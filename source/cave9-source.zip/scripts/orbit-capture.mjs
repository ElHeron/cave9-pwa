// Structural landmark review: each family from six external angles, plus one
// SVG contact sheet. This is deliberately not a gameplay screenshot gate.
import { spawn } from 'node:child_process';
import { mkdirSync, writeFileSync } from 'node:fs';
import { resolve, join, basename } from 'node:path';
import { chromium } from 'playwright';

const PORT = 5191;
const URL = `http://localhost:${PORT}/?capture=1`;
const OUT = resolve('docs/screenshots/orbit');
const FAMILIES = ['branching', 'crystal', 'coiling'];
const ANGLES = Array.from({ length: 6 }, (_, i) => i * Math.PI / 3);
mkdirSync(OUT, { recursive: true });

async function waitForServer() {
  const end = Date.now() + 30000;
  while (Date.now() < end) {
    try { if ((await fetch(URL)).ok) return; } catch { /* retry */ }
    await new Promise((r) => setTimeout(r, 150));
  }
  throw new Error('orbit capture server did not start');
}

const server = spawn(process.execPath,
  [resolve('node_modules/vite/bin/vite.js'), '--port', String(PORT), '--strictPort'],
  { cwd: process.cwd(), shell: false, stdio: 'ignore' });

let browser;
try {
  await waitForServer();
  browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 960, height: 540 }, deviceScaleFactor: 1 });
  const errors = [];
  page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
  page.on('pageerror', (e) => errors.push(e.message));
  await page.goto(URL, { waitUntil: 'load' });
  await page.waitForFunction(() => window.__cave9?.state && window.__cave9.state !== 'boot');

  const shots = [];
  for (const family of FAMILIES) for (let i = 0; i < ANGLES.length; i++) {
    const info = await page.evaluate((o) => window.__cave9.captureScenario(o), {
      seed: 2024, distance: 9010, place: true, family, orbitAngle: ANGLES[i],
      settings: { landmarks: true, rockDetail: true, motion: 0 },
    });
    for (let f = 0; f < 4; f++) await page.evaluate(() => new Promise((r) => requestAnimationFrame(r)));
    const file = join(OUT, `${family}-${i}.png`);
    const data = await page.evaluate(() => window.__cave9.renderer.canvas.toDataURL('image/png'));
    writeFileSync(file, Buffer.from(data.replace(/^data:image\/png;base64,/, ''), 'base64'));
    shots.push({ family, angle: i * 60, file: basename(file), pieces: info.landmarkPieces });
  }
  if (errors.length) throw new Error(`orbit capture console errors: ${errors.slice(0, 3).join(' | ')}`);

  const cellW = 320, cellH = 180, labelH = 28;
  const images = shots.map((s, i) => {
    const col = i % 6, row = Math.floor(i / 6);
    return `<g transform="translate(${col * cellW} ${row * (cellH + labelH)})">
      <image href="${basename(s.file)}" width="${cellW}" height="${cellH}" preserveAspectRatio="xMidYMid slice"/>
      <rect y="${cellH}" width="${cellW}" height="${labelH}" fill="#0b0e14"/>
      <text x="10" y="${cellH + 19}" fill="#dce7ff" font-family="monospace" font-size="14">${s.family} · ${s.angle}° · ${s.pieces} pieces</text>
    </g>`;
  }).join('\n');
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${cellW * 6}" height="${(cellH + labelH) * 3}" viewBox="0 0 ${cellW * 6} ${(cellH + labelH) * 3}">
    <rect width="100%" height="100%" fill="#080a0f"/>${images}</svg>`;
  writeFileSync(join(OUT, 'contact-sheet.svg'), svg);
  writeFileSync(join(OUT, 'manifest.json'), JSON.stringify({ seed: 2024, depth: 9010, shots }, null, 2) + '\n');
  console.log(`wrote ${shots.length} orbit views and ${join(OUT, 'contact-sheet.svg')}`);
} finally {
  if (browser) await browser.close();
  server.kill();
}
