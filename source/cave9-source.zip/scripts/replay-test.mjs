// Replay determinism CLI (Phase 4B, gate P1).
//
// Loads every committed replay fixture, runs each twice through the REAL
// Game.step path, and verifies:
//   1. the two runs are byte-identical (determinism), and
//   2. the run matches the recorded `expected` end-state (no drift).
// Prints a table and writes docs/measure/replay-report.json. Exits non-zero on
// any mismatch. The unit suite (test/replay.test.js) asserts the same contract;
// this script is the standalone, documented `npm run replay:test` entry point.

import { readFileSync, readdirSync, mkdirSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { runReplay } from '../src/core/Replay.js';

const FIX = resolve(process.cwd(), 'test/fixtures');
const OUT = resolve(process.cwd(), 'docs/measure');
mkdirSync(OUT, { recursive: true });

const FIELDS = ['pos', 'distance', 'score', 'grazeTime', 'bestCombo', 'maxSpeed', 'closest', 'alive', 'crashed'];

function eq(a, b) { return JSON.stringify(a) === JSON.stringify(b); }

const files = readdirSync(FIX).filter((f) => f.startsWith('replay-') && f.endsWith('.json')).sort();
if (files.length === 0) {
  console.error('no replay fixtures in test/fixtures/ — run: node scripts/make-replays.mjs');
  process.exit(1);
}

const rows = [];
let fail = 0;

for (const name of files) {
  const fx = JSON.parse(readFileSync(resolve(FIX, name), 'utf8'));
  const a = runReplay(fx);
  const b = runReplay(fx);

  const deterministic = eq(a.result, b.result);
  const mismatches = [];
  for (const f of FIELDS) {
    if (!eq(a.result[f], fx.expected[f])) mismatches.push(f);
  }
  const matchesExpected = mismatches.length === 0;
  const checkpointsMatch = eq(a.checkpoints, fx.expectedCheckpoints);
  if (!checkpointsMatch) mismatches.push('checkpoints');
  const ok = deterministic && matchesExpected && checkpointsMatch;
  if (!ok) fail++;

  rows.push({
    fixture: name, seed: fx.seed, steps: a.steps,
    baseline: fx._baseline || null,
    deterministic, matchesExpected, checkpointsMatch, mismatches,
    distance: a.result.distance, score: a.result.score,
    grazeTime: a.result.grazeTime, bestCombo: a.result.bestCombo,
    crashed: a.result.crashed,
  });
}

// ---- print ----------------------------------------------------------------
console.log('Cave9 — replay determinism (gate P1)\n');
console.log('fixture                | seed     | steps | dist(m)  | score | grazeT | combo | det | exp');
console.log('-----------------------|----------|-------|----------|-------|--------|-------|-----|----');
for (const r of rows) {
  console.log(
    `${r.fixture.padEnd(22)} | ${String(r.seed).padStart(8)} | ${String(r.steps).padStart(5)} | ` +
    `${String(r.distance).padStart(8)} | ${String(r.score).padStart(5)} | ${String(r.grazeTime).padStart(6)} | ` +
    `${String(r.bestCombo).padStart(5)} | ${(r.deterministic ? ' ok' : 'FAIL').padStart(3)} | ` +
    `${r.matchesExpected ? 'ok' : 'FAIL' + ' (' + r.mismatches.join(',') + ')'}`);
}

const report = { gate: 'P1', capturedAt: new Date().toISOString(), fixtures: rows, pass: fail === 0 };
writeFileSync(resolve(OUT, 'replay-report.json'), JSON.stringify(report, null, 2) + '\n');
console.log(`\n${fail === 0 ? 'PASS' : 'FAIL'} — ${rows.length} fixtures, ${fail} mismatch(es). ` +
  `Report: docs/measure/replay-report.json`);

process.exit(fail === 0 ? 0 : 1);
