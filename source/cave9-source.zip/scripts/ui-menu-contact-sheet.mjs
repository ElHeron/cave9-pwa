import fs from 'node:fs';
import path from 'node:path';
import { PNG } from 'pngjs';

export const UI_MENU_CONTACT_SHEET_SIZE = [1280, 1376];

function fillChecker(png) {
  const colors = [[13, 17, 24, 255], [29, 36, 47, 255]];
  const size = 24;
  for (let y = 0; y < png.height; y++) {
    for (let x = 0; x < png.width; x++) {
      const color = colors[(Math.floor(x / size) + Math.floor(y / size)) % 2];
      const offset = (y * png.width + x) * 4;
      png.data[offset] = color[0];
      png.data[offset + 1] = color[1];
      png.data[offset + 2] = color[2];
      png.data[offset + 3] = color[3];
    }
  }
}

function scaleNearest(source, width, height) {
  if (width === source.width && height === source.height) return source;
  const scaled = new PNG({ width, height });
  for (let y = 0; y < height; y++) {
    const sourceY = Math.min(source.height - 1, Math.floor((y + 0.5) * source.height / height));
    for (let x = 0; x < width; x++) {
      const sourceX = Math.min(source.width - 1, Math.floor((x + 0.5) * source.width / width));
      const sourceOffset = (sourceY * source.width + sourceX) * 4;
      source.data.copy(scaled.data, (y * width + x) * 4, sourceOffset, sourceOffset + 4);
    }
  }
  return scaled;
}

function blit(source, target, left, top, displayWidth = source.width, displayHeight = source.height) {
  const scaled = scaleNearest(source, displayWidth, displayHeight);
  for (let y = 0; y < scaled.height; y++) {
    for (let x = 0; x < scaled.width; x++) {
      const sourceOffset = (y * scaled.width + x) * 4;
      const targetOffset = ((top + y) * target.width + left + x) * 4;
      const alpha = scaled.data[sourceOffset + 3] / 255;
      const inverse = 1 - alpha;
      target.data[targetOffset] = Math.round(scaled.data[sourceOffset] * alpha + target.data[targetOffset] * inverse);
      target.data[targetOffset + 1] = Math.round(scaled.data[sourceOffset + 1] * alpha + target.data[targetOffset + 1] * inverse);
      target.data[targetOffset + 2] = Math.round(scaled.data[sourceOffset + 2] * alpha + target.data[targetOffset + 2] * inverse);
      target.data[targetOffset + 3] = 255;
    }
  }
}

/** Build the review contact sheet solely from shipped UI runtime PNGs. */
export function createUiMenuContactSheet(assets) {
  const get = (id) => {
    const asset = assets.get(id);
    if (!asset) throw new Error(`Missing runtime UI asset: ${id}`);
    return asset;
  };
  const [width, height] = UI_MENU_CONTACT_SHEET_SIZE;
  const sheet = new PNG({ width, height });
  fillChecker(sheet);

  blit(get('panel'), sheet, 32, 32, 448, 448);
  blit(get('button-neutral'), sheet, 520, 32, 336, 168);
  blit(get('button-hover'), sheet, 888, 32, 336, 168);
  blit(get('button-primary'), sheet, 520, 224, 336, 168);
  blit(get('button-disabled'), sheet, 888, 224, 336, 168);
  blit(get('toggle-off'), sheet, 32, 520, 256, 128);
  blit(get('toggle-on'), sheet, 320, 520, 256, 128);
  blit(get('slider-rail'), sheet, 624, 568, 480, 60);
  blit(get('slider-hinge'), sheet, 800, 512, 128, 128);
  blit(get('slider-lever'), sheet, 816, 512, 96, 128);
  blit(get('divider'), sheet, 32, 680, 576, 96);
  blit(get('button-danger'), sheet, 32, 824, 384, 192);
  blit(get('crash-plate'), sheet, 448, 824, 384, 192);
  blit(get('success-badge'), sheet, 32, 1056, 384, 192);
  blit(get('success-medallion'), sheet, 448, 1056, 192, 192);
  return sheet;
}

export function writeUiMenuContactSheet(file, assets) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, PNG.sync.write(createUiMenuContactSheet(assets), { colorType: 6 }));
}
