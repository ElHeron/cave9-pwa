#!/usr/bin/env node
import { spawnSync } from 'node:child_process';
import { mkdirSync, writeFileSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { PNG } from 'pngjs';

export const CAVE_MAP_SOURCE = 'public/assets/cave-wall-detail.webp';
export const CAVE_HEIGHT_OUTPUT = 'public/assets/cave-wall-height.png';
export const CAVE_NORMAL_OUTPUT = 'public/assets/cave-wall-normal.png';
export const CAVE_NORMAL_STRENGTH = 7.5;

const clamp = (v, lo = 0, hi = 1) => Math.max(lo, Math.min(hi, v));

function srgbToLinear(byte) {
  const v = byte / 255;
  return v <= 0.04045 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4;
}

// Reflect-101 matches a mirrored tile at the image edge: the first sample
// outside the image is the first sample inside it. It also gives the derived
// normal a zero cross-edge slope at the mirror seam.
function mirrorIndex(i, size) {
  if (size <= 1) return 0;
  const period = 2 * size - 2;
  let n = i % period;
  if (n < 0) n += period;
  return n < size ? n : period - n;
}

function gaussianKernel(radius, sigma) {
  const kernel = new Float64Array(radius * 2 + 1);
  let sum = 0;
  for (let i = -radius; i <= radius; i++) {
    const value = Math.exp(-(i * i) / (2 * sigma * sigma));
    kernel[i + radius] = value;
    sum += value;
  }
  for (let i = 0; i < kernel.length; i++) kernel[i] /= sum;
  return kernel;
}

function gaussianBlur(source, width, height, radius, sigma) {
  const kernel = gaussianKernel(radius, sigma);
  const horizontal = new Float64Array(source.length);
  const output = new Float64Array(source.length);
  for (let y = 0; y < height; y++) for (let x = 0; x < width; x++) {
    let sum = 0;
    for (let k = -radius; k <= radius; k++) {
      sum += source[y * width + mirrorIndex(x + k, width)] * kernel[k + radius];
    }
    horizontal[y * width + x] = sum;
  }
  for (let y = 0; y < height; y++) for (let x = 0; x < width; x++) {
    let sum = 0;
    for (let k = -radius; k <= radius; k++) {
      sum += horizontal[mirrorIndex(y + k, height) * width + x] * kernel[k + radius];
    }
    output[y * width + x] = sum;
  }
  return output;
}

function percentile(values, p) {
  const sorted = Float64Array.from(values).sort();
  return sorted[Math.min(sorted.length - 1, Math.max(0, Math.floor((sorted.length - 1) * p)))];
}

function rgbaPng(width, height, pixel, outputColorType = 6) {
  const png = new PNG({ width, height, colorType: 6 });
  for (let i = 0; i < width * height; i++) {
    const [r, g, b, a = 255] = pixel(i);
    const offset = i * 4;
    png.data[offset] = r;
    png.data[offset + 1] = g;
    png.data[offset + 2] = b;
    png.data[offset + 3] = a;
  }
  return PNG.sync.write(png, {
    colorType: outputColorType,
    inputColorType: 6,
    bitDepth: 8,
    deflateLevel: 9,
    deflateStrategy: 3,
  });
}

export function deriveCaveMaps(rgba, width, height, { normalStrength = CAVE_NORMAL_STRENGTH } = {}) {
  if (rgba.length !== width * height * 4) throw new Error('RGBA byte length does not match dimensions');
  const linearLuma = new Float64Array(width * height);
  for (let i = 0; i < linearLuma.length; i++) {
    const offset = i * 4;
    const r = srgbToLinear(rgba[offset]);
    const g = srgbToLinear(rgba[offset + 1]);
    const b = srgbToLinear(rgba[offset + 2]);
    linearLuma[i] = 0.2126 * r + 0.7152 * g + 0.0722 * b;
  }

  // Remove the source image's broad value bias while retaining both shallow
  // fissures and medium mineral undulations. The resulting map represents
  // detail displacement around a neutral surface, not absolute cave radius.
  const fineBase = gaussianBlur(linearLuma, width, height, 3, 1.45);
  const broadBase = gaussianBlur(linearLuma, width, height, 14, 6.0);
  const relief = new Float64Array(linearLuma.length);
  for (let i = 0; i < relief.length; i++) {
    const fine = linearLuma[i] - fineBase[i];
    const medium = fineBase[i] - broadBase[i];
    relief[i] = fine * 0.68 + medium * 0.92;
  }

  // Robust bounds prevent a handful of compression outliers from flattening
  // the useful relief range. Keep headroom at both ends for future packing.
  const low = percentile(relief, 0.01);
  const high = percentile(relief, 0.99);
  const span = Math.max(1e-9, high - low);
  const heights = new Float64Array(relief.length);
  for (let i = 0; i < relief.length; i++) {
    const normalized = clamp((relief[i] - low) / span);
    heights[i] = 0.04 + normalized * 0.92;
  }

  const heightPng = rgbaPng(width, height, (i) => {
    const h = Math.round(heights[i] * 255);
    return [h, h, h, 255];
  }, 0);

  const normalPng = rgbaPng(width, height, (i) => {
    const x = i % width;
    const y = Math.floor(i / width);
    const sample = (sx, sy) => heights[mirrorIndex(sy, height) * width + mirrorIndex(sx, width)];
    const left = sample(x - 1, y - 1) + 2 * sample(x - 1, y) + sample(x - 1, y + 1);
    const right = sample(x + 1, y - 1) + 2 * sample(x + 1, y) + sample(x + 1, y + 1);
    const up = sample(x - 1, y - 1) + 2 * sample(x, y - 1) + sample(x + 1, y - 1);
    const down = sample(x - 1, y + 1) + 2 * sample(x, y + 1) + sample(x + 1, y + 1);
    const dx = (right - left) * 0.125;
    const dyImage = (down - up) * 0.125;
    let nx = -dx * normalStrength;
    let ny = dyImage * normalStrength; // OpenGL +Y after Three's texture flip
    let nz = 1;
    const invLength = 1 / Math.hypot(nx, ny, nz);
    nx *= invLength;
    ny *= invLength;
    nz *= invLength;
    return [
      Math.round((nx * 0.5 + 0.5) * 255),
      Math.round((ny * 0.5 + 0.5) * 255),
      Math.round((nz * 0.5 + 0.5) * 255),
      255,
    ];
  }, 2);

  return { heightPng, normalPng, heights, bounds: { low, high }, normalStrength };
}

function decodeWebpWithFfmpeg(file) {
  const probe = spawnSync('ffprobe', [
    '-v', 'error', '-select_streams', 'v:0', '-show_entries', 'stream=width,height',
    '-of', 'csv=p=0:s=x', file,
  ], { encoding: 'utf8' });
  if (probe.status !== 0) throw new Error(`ffprobe failed: ${probe.stderr.trim()}`);
  const [width, height] = probe.stdout.trim().split('x').map(Number);
  if (!Number.isInteger(width) || !Number.isInteger(height)) throw new Error('invalid source dimensions');
  const decoded = spawnSync('ffmpeg', [
    '-v', 'error', '-i', file, '-f', 'rawvideo', '-pix_fmt', 'rgba', 'pipe:1',
  ], { encoding: null, maxBuffer: width * height * 4 + 1024 * 1024 });
  if (decoded.status !== 0) throw new Error(`ffmpeg failed: ${decoded.stderr.toString().trim()}`);
  if (decoded.stdout.length !== width * height * 4) throw new Error('ffmpeg returned unexpected RGBA length');
  return { rgba: decoded.stdout, width, height };
}

export function generateSurfaceMaps({
  source,
  heightOutput,
  normalOutput,
  normalStrength = CAVE_NORMAL_STRENGTH,
}) {
  const decoded = decodeWebpWithFfmpeg(source);
  const maps = deriveCaveMaps(decoded.rgba, decoded.width, decoded.height, { normalStrength });
  mkdirSync(dirname(heightOutput), { recursive: true });
  mkdirSync(dirname(normalOutput), { recursive: true });
  writeFileSync(heightOutput, maps.heightPng);
  writeFileSync(normalOutput, maps.normalPng);
  return {
    source, heightOutput, normalOutput,
    width: decoded.width, height: decoded.height,
    normalStrength: maps.normalStrength,
    reliefBounds: maps.bounds,
  };
}

export function generateCaveMaps({
  source = resolve(CAVE_MAP_SOURCE),
  heightOutput = resolve(CAVE_HEIGHT_OUTPUT),
  normalOutput = resolve(CAVE_NORMAL_OUTPUT),
} = {}) {
  return generateSurfaceMaps({ source, heightOutput, normalOutput });
}

const invokedPath = process.argv[1] ? pathToFileURL(resolve(process.argv[1])).href : null;
if (invokedPath === import.meta.url) {
  console.log(JSON.stringify(generateCaveMaps(), null, 2));
}
