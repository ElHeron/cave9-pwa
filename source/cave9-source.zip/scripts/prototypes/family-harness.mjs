import { mkdir, writeFile } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { prototypes, runPrototype } from './landmark-family-core.mjs';
import { crossSectionSvg, longitudinalSvg, silhouettesSvg } from './landmark-family-svg.mjs';

const here = dirname(fileURLToPath(import.meta.url));
const root = resolve(here, '..', '..');
const outputRoot = resolve(root, 'docs', 'measure', 'prototypes');

await mkdir(outputRoot, { recursive: true });
const summary = {
  schemaVersion: 1,
  purpose: 'Browser-, Canvas-, and THREE-free structural comparison of proposed landmark family generators.',
  referenceEvidence: {
    files: [
      'docs/reference/ChatGPT Image 7. Aug. 2026, 16_54_40.png',
      'docs/reference/ChatGPT Image 7. Aug. 2026, 16_55_03.png',
    ],
    structuralIdeas: [
      'continuous multi-start wall helix',
      'several axial overlap layers',
      'small central opening framed by cave mass',
      'small warm nests embedded in the mineral surface',
    ],
    excludedFromGeometryTarget: ['cockpit framing', 'speed streaks and edge particles'],
    handling: 'Images are supplemental manifest evidence with D1-D6 profiles; metricEnvelope=false keeps cockpit and speed streaks out of the cave-only release envelope.',
  },
  limitations: [
    'S6 ember irregularity is not evaluated because the harness intentionally has no materials, UVs, textures, or ember field.',
    'Orthographic S4 is an analytic interval-occupancy proxy, not a rendered pixel silhouette.',
    'Route frames and wall radii are deterministic curved/dynamic surrogates; production CaveTopology integration remains untested.',
    'GPU cost, final art direction, D1-D6, warning/audio behavior, and real gameplay collision are outside this isolated Core harness.',
  ],
  candidates: [],
  recommendations: {},
};

for (const spec of prototypes) {
  const first = runPrototype(spec);
  const second = runPrototype(spec);
  if (first.document.fingerprint !== second.document.fingerprint) throw new Error(`${spec.variant} is not deterministic`);
  const slug = `${spec.family}-${spec.variant.toLowerCase()}`;
  const directory = resolve(outputRoot, slug);
  await mkdir(directory, { recursive: true });
  await Promise.all([
    writeFile(resolve(directory, 'evidence.json'), `${JSON.stringify(first.document, null, 2)}\n`),
    writeFile(resolve(directory, 'cross-sections.svg'), crossSectionSvg(first.result, first.context)),
    writeFile(resolve(directory, 'longitudinal-section.svg'), longitudinalSvg(first.result, first.context)),
    writeFile(resolve(directory, 'silhouettes.svg'), silhouettesSvg(first.result)),
  ]);
  summary.candidates.push({
    family: spec.family,
    variant: spec.variant,
    name: first.result.name,
    recommendedByResearch: spec.recommended,
    metrics: first.metrics,
    fingerprint: first.document.fingerprint,
    files: {
      evidence: `${slug}/evidence.json`,
      crossSections: `${slug}/cross-sections.svg`,
      longitudinalSection: `${slug}/longitudinal-section.svg`,
      silhouettes: `${slug}/silhouettes.svg`,
    },
  });
}

for (const family of ['roots', 'blades', 'ribs']) {
  const candidates = summary.candidates.filter((candidate) => candidate.family === family);
  candidates.sort((a, b) => b.metrics.summary.structuralScore - a.metrics.summary.structuralScore);
  const selected = candidates[0];
  summary.recommendations[family] = {
    selected: selected.variant,
    reason: `${selected.metrics.summary.passed}/${selected.metrics.summary.evaluated} evaluable S-gates; axial span ${selected.metrics.summary.axialSpan} m; structural score ${selected.metrics.summary.structuralScore}.`,
    caveat: selected.variant === 'C3'
      ? 'Selection depends on proving the same interpolated shell margin in production wall triangles.'
      : 'Selection still needs a neutral production mesh/orbit check before visual acceptance.',
  };
}

await writeFile(resolve(outputRoot, 'summary.json'), `${JSON.stringify(summary, null, 2)}\n`);
console.log(`Wrote ${summary.candidates.length} deterministic family prototypes to ${outputRoot}`);
for (const [family, recommendation] of Object.entries(summary.recommendations)) {
  console.log(`${family}: ${recommendation.selected} — ${recommendation.reason}`);
}
