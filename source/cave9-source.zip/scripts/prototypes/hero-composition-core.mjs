// Isolated camera-composition experiment for the R2/B1/C3 landmark families.
//
// This module deliberately imports only the numeric prototype harness.  It has
// no THREE, Canvas, browser or production-runtime dependency.  Candidate
// geometry remains collision-authoritative: capsules are the visible surface,
// and plate polygons are bounded by their accompanying capsule.

import { prototypes, runPrototype } from './landmark-family-core.mjs';

const TAU = Math.PI * 2;
const WIDTH = 160;
const HEIGHT = 90;
const FOV_Y = 70 * Math.PI / 180;
const ASPECT = WIDTH / HEIGHT;

const clamp = (value, lo, hi) => Math.max(lo, Math.min(hi, value));
const lerp = (a, b, t) => a + (b - a) * t;
const round = (value, digits = 5) => Number(value.toFixed(digits));
const polar = (radius, azimuth, z) => ({ x: radius * Math.cos(azimuth), y: radius * Math.sin(azimuth), z });

function capsule(id, gid, a, b, radius, role, depthBand, wallContact = false) {
  return { id, gid, kind: 'capsule', a, b, radius, role, depthBand, wallContact };
}

function appendCapsuleChain(pieces, forms, {
  gid, nodes, radii, role, depthBand, wallContact = true,
}) {
  for (let i = 1; i < nodes.length; i++) {
    const radius = Array.isArray(radii) ? radii[i - 1] : radii;
    pieces.push(capsule(`${gid}-${i - 1}`, gid, nodes[i - 1], nodes[i], radius, role, depthBand, i === 1 && wallContact));
  }
  forms.push({ gid, role, tier: depthBand, nodes, wallContact });
}

function makeResult(family, variant, name, base, pieces, forms, diagnostics) {
  return {
    schemaVersion: 1,
    family,
    variant,
    name,
    context: base.result.context,
    pieces,
    collisionCapsules: pieces.flatMap((piece) => piece.kind === 'capsule'
      ? [piece]
      : piece.collisionCapsule ? [piece.collisionCapsule] : []),
    wallTriangles: [],
    shellChannels: [],
    forms,
    diagnostics,
  };
}

function buildRootsHero(base) {
  const { context } = base;
  const pieces = [];
  const forms = [];
  const depthBandCenters = [context.zStart + 23, context.zStart + 57, context.zStart + 92];
  const gaps = [-0.78, 1.82, -2.42];

  // Three irregular 280-degree arches. Each is one connected capsule chain
  // with both shoulders returning to the wall: no detached claws or rods.
  for (let band = 0; band < depthBandCenters.length; band++) {
    const z = depthBandCenters[band];
    const gapCenter = gaps[band];
    const arcStart = gapCenter + 0.70;
    const arcSpan = TAU - 1.40;
    const nodes = [];
    const radius = 5.18 + 0.30 * Math.sin(band * 1.9);
    const wallA = context.wallRadiusAt(z - 2.4, arcStart);
    nodes.push(polar(wallA - 0.56, arcStart, z - 2.4));
    for (let node = 0; node <= 13; node++) {
      const t = node / 13;
      const azimuth = arcStart + arcSpan * t;
      const organic = 0.22 * Math.sin(t * Math.PI * 3 + band * 1.3);
      nodes.push(polar(radius + organic, azimuth, z + 3.2 * Math.sin(Math.PI * t + band * 0.6)));
    }
    const endAz = arcStart + arcSpan;
    const wallB = context.wallRadiusAt(z + 2.1, endAz);
    nodes.push(polar(wallB - 0.50, endAz, z + 2.1));
    appendCapsuleChain(pieces, forms, {
      gid: `root-arch-${band}`,
      nodes,
      radii: Array.from({ length: nodes.length - 1 }, (_, i) => 0.62 + 0.16 * Math.sin((i + 1) / nodes.length * Math.PI)),
      role: 'hero-arch',
      depthBand: band,
    });
  }

  // The two longitudinal joins make the nested arches one wall-grown graph.
  for (let side = 0; side < 2; side++) {
    const nodes = [];
    for (let band = 0; band < depthBandCenters.length - 1; band++) {
      for (let step = 0; step <= 6; step++) {
        if (band && step === 0) continue;
        const t = step / 6;
        const z = lerp(depthBandCenters[band], depthBandCenters[band + 1], t);
        const az0 = gaps[band] + (side ? TAU - 0.70 : 0.70);
        const az1 = gaps[band + 1] + (side ? TAU - 0.70 : 0.70);
        const azimuth = lerp(az0, az1, t);
        // Sample the wall curve instead of joining two anchors with a chord;
        // the latter would cut through the protected central tube.
        nodes.push(polar(context.wallRadiusAt(z, azimuth) - 0.58, azimuth, z));
      }
    }
    appendCapsuleChain(pieces, forms, {
      gid: `root-spine-${side}`,
      nodes,
      radii: 0.55,
      role: 'wall-spine',
      depthBand: side,
    });
  }

  return makeResult('roots', 'R2-H', 'Nested Root Arch Braid', base, pieces, forms, {
    depthBandCenters,
    referenceSignals: { axialContinuity: true, connectedArches: true, wallIntegrated: true, isolatedClaws: false },
  });
}

function platePolygon(base, tip, azimuth, width, zSkew) {
  const tangent = { x: -Math.sin(azimuth), y: Math.cos(azimuth), z: 0 };
  const offset = (point, amount, dz = 0) => ({
    x: point.x + tangent.x * amount,
    y: point.y + tangent.y * amount,
    z: point.z + dz,
  });
  const middle = {
    x: lerp(base.x, tip.x, 0.58),
    y: lerp(base.y, tip.y, 0.58),
    z: lerp(base.z, tip.z, 0.58),
  };
  return [
    offset(base, width * 0.48, -zSkew),
    offset(base, -width * 0.44, zSkew),
    offset(middle, -width * 0.55, zSkew * 0.35),
    offset(tip, -width * 0.14),
    offset(tip, width * 0.11),
    offset(middle, width * 0.50, -zSkew * 0.30),
  ];
}

function buildBladesHero(base) {
  const { context } = base;
  const pieces = [];
  const forms = [];
  const depthBandCenters = [context.zStart + 17, context.zStart + 49, context.zEnd - 15];
  const bankTurns = [0, 0.47, 0.93];
  const plateCount = 8;

  // One broad polygon/capsule per spoke (24 total versus B1's 72 facets).
  // Tips stop farther from the protected tube, preserving a readable corridor.
  for (let bank = 0; bank < depthBandCenters.length; bank++) {
    const z = depthBandCenters[bank];
    for (let index = 0; index < plateCount; index++) {
      const azimuth = bankTurns[bank] + (index + 0.5) * TAU / plateCount;
      const baseRadius = context.wallRadiusAt(z, azimuth) - 0.38;
      const tipRadius = context.tubeRadiusAt(z) + 2.12 + 0.16 * ((index + bank) % 3);
      const basePoint = polar(baseRadius, azimuth, z + 1.2 * Math.sin(index * 1.7 + bank));
      const tipPoint = polar(tipRadius, azimuth, z + 2.2 * Math.sin(index * 0.9 + bank * 1.4));
      const width = 2.10 + 0.16 * ((index + 2 * bank) % 3);
      const vertices = platePolygon(basePoint, tipPoint, azimuth, width, 0.42 + 0.08 * (index % 2));
      const collisionRadius = width * 0.58 + 0.04;
      const gid = `b1h-plate-${bank}-${index}`;
      const collisionCapsule = capsule(`${gid}-cap`, gid, basePoint, tipPoint, collisionRadius, 'hero-plate', bank, true);
      pieces.push({
        id: gid,
        gid,
        kind: 'plate',
        role: 'hero-plate',
        depthBand: bank,
        vertices,
        collisionCapsule,
        wallContact: true,
      });
      forms.push({ gid, role: 'hero-plate', tier: bank, nodes: [basePoint, tipPoint], wallContact: true });
    }
  }

  return makeResult('blades', 'B1-H', 'Open Three-Bank Hero Iris', base, pieces, forms, {
    depthBandCenters,
    bankCount: 3,
    plateCount: pieces.length,
    referenceSignals: { axialLayers: true, radialIris: true, familyDistinct: true, openCorridor: true },
  });
}

function buildRibsHero(base) {
  const { context } = base;
  const pieces = [];
  const forms = [];
  const span = context.zEnd - context.zStart;
  const depthBandCenters = Array.from({ length: 5 }, (_, index) => context.zStart + 18 + index * (span - 36) / 4);

  // Five broad, staggered 300-degree arches recede along the axis. Their open
  // sectors rotate slowly enough to avoid a rigid ring grid, but the banks stay
  // discrete so this landmark does not duplicate the corridor's three-start
  // embedded coil. Every visible segment remains a collision capsule.
  for (let band = 0; band < depthBandCenters.length; band++) {
    const z = depthBandCenters[band];
    const gapCenter = -1.25 + band * 0.31;
    const arcStart = gapCenter + 0.50;
    const arcSpan = TAU - 1.00;
    const nodes = [];
    const radial = 5.45 + 0.18 * Math.sin(band * 1.2);
    nodes.push(polar(context.wallRadiusAt(z - 1.5, arcStart) - 0.68, arcStart, z - 1.5));
    for (let node = 0; node <= 15; node++) {
      const t = node / 15;
      const azimuth = arcStart + arcSpan * t;
      nodes.push(polar(radial, azimuth, z + 1.25 * Math.sin(Math.PI * t + band * 0.42)));
    }
    const endAz = arcStart + arcSpan;
    nodes.push(polar(context.wallRadiusAt(z + 1.5, endAz) - 0.68, endAz, z + 1.5));
    appendCapsuleChain(pieces, forms, {
      gid: `rib-arch-${band}`,
      nodes,
      radii: Array.from({ length: nodes.length - 1 }, (_, i) => 0.70 + 0.22 * Math.sin((i + 0.5) / (nodes.length - 1) * Math.PI) ** 2),
      role: 'vertebra-arch',
      depthBand: band,
    });
  }

  return makeResult('ribs', 'C3-H', 'Five-Bank Vertebra Arch Sequence', base, pieces, forms, {
    depthBandCenters,
    hubMaxima: 5,
    referenceSignals: { vertebraSequence: true, axialOverlap: true, integratedSurface: true, nestedArches: true, familyDistinctFromCorridorCoil: true },
  });
}

function project(point, radius, cameraZ, roll) {
  const depth = point.z - cameraZ;
  if (depth <= 0.5) return null;
  const c = Math.cos(roll), s = Math.sin(roll);
  const x = point.x * c - point.y * s;
  const y = point.x * s + point.y * c;
  const fy = 1 / Math.tan(FOV_Y / 2);
  return {
    x: x / depth * fy / ASPECT,
    y: y / depth * fy,
    r: radius / depth * fy,
    depth,
  };
}

const pixelX = (ndc) => (ndc * 0.5 + 0.5) * WIDTH;
const pixelY = (ndc) => (0.5 - ndc * 0.5) * HEIGHT;

function paintDisk(mask, projection) {
  const cx = pixelX(projection.x), cy = pixelY(projection.y);
  const radius = Math.max(0.55, projection.r * HEIGHT * 0.5);
  const x0 = clamp(Math.floor(cx - radius), 0, WIDTH - 1);
  const x1 = clamp(Math.ceil(cx + radius), 0, WIDTH - 1);
  const y0 = clamp(Math.floor(cy - radius), 0, HEIGHT - 1);
  const y1 = clamp(Math.ceil(cy + radius), 0, HEIGHT - 1);
  for (let y = y0; y <= y1; y++) for (let x = x0; x <= x1; x++) {
    if ((x + 0.5 - cx) ** 2 + (y + 0.5 - cy) ** 2 <= radius ** 2) mask[y * WIDTH + x] = 1;
  }
}

function edge(a, b, p) {
  return (p.x - a.x) * (b.y - a.y) - (p.y - a.y) * (b.x - a.x);
}

function paintTriangle(mask, a, b, c) {
  const points = [a, b, c].map((point) => ({ x: pixelX(point.x), y: pixelY(point.y) }));
  const x0 = clamp(Math.floor(Math.min(...points.map((p) => p.x))), 0, WIDTH - 1);
  const x1 = clamp(Math.ceil(Math.max(...points.map((p) => p.x))), 0, WIDTH - 1);
  const y0 = clamp(Math.floor(Math.min(...points.map((p) => p.y))), 0, HEIGHT - 1);
  const y1 = clamp(Math.ceil(Math.max(...points.map((p) => p.y))), 0, HEIGHT - 1);
  const sign = Math.sign(edge(points[0], points[1], points[2])) || 1;
  for (let y = y0; y <= y1; y++) for (let x = x0; x <= x1; x++) {
    const p = { x: x + 0.5, y: y + 0.5 };
    if (sign * edge(points[0], points[1], p) >= 0
      && sign * edge(points[1], points[2], p) >= 0
      && sign * edge(points[2], points[0], p) >= 0) mask[y * WIDTH + x] = 1;
  }
}

function nearestBand(result, z) {
  const bands = result.diagnostics.depthBandCenters ?? [];
  let best = 0;
  for (let i = 1; i < bands.length; i++) if (Math.abs(bands[i] - z) < Math.abs(bands[best] - z)) best = i;
  return best;
}

function pieceBand(result, piece) {
  if (Number.isInteger(piece.depthBand)) return piece.depthBand;
  if (Number.isInteger(piece.bank)) return piece.bank;
  if (Number.isInteger(piece.tier)) return piece.tier;
  const z = piece.kind === 'capsule'
    ? (piece.a.z + piece.b.z) * 0.5
    : piece.vertices.reduce((sum, point) => sum + point.z, 0) / piece.vertices.length;
  return nearestBand(result, z);
}

function rasterize(result, roll = 0) {
  const bandCount = Math.max(1, result.diagnostics.depthBandCenters?.length ?? 1);
  const bands = Array.from({ length: bandCount }, () => new Uint8Array(WIDTH * HEIGHT));
  const forms = new Map();
  const cameraZ = result.context.zStart - 18;
  const maskFor = (piece) => {
    const gid = piece.gid ?? piece.id;
    if (!forms.has(gid)) forms.set(gid, new Uint8Array(WIDTH * HEIGHT));
    return [bands[clamp(pieceBand(result, piece), 0, bandCount - 1)], forms.get(gid)];
  };

  for (const piece of result.pieces) {
    const targets = maskFor(piece);
    if (piece.kind === 'capsule') {
      const sampleCount = Math.max(5, Math.ceil(Math.hypot(piece.b.x - piece.a.x, piece.b.y - piece.a.y, piece.b.z - piece.a.z) * 2));
      for (let sample = 0; sample <= sampleCount; sample++) {
        const t = sample / sampleCount;
        const point = {
          x: lerp(piece.a.x, piece.b.x, t),
          y: lerp(piece.a.y, piece.b.y, t),
          z: lerp(piece.a.z, piece.b.z, t),
        };
        const projected = project(point, piece.radius, cameraZ, roll);
        if (projected) for (const target of targets) paintDisk(target, projected);
      }
    } else if (piece.kind === 'plate') {
      const projected = piece.vertices.map((point) => project(point, 0, cameraZ, roll));
      if (projected.every(Boolean)) for (let triangle = 1; triangle < projected.length - 1; triangle++) {
        for (const target of targets) paintTriangle(target, projected[0], projected[triangle], projected[triangle + 1]);
      }
    }
  }

  // C3 baseline uses authoritative wall triangles rather than pieces.
  for (const triangle of result.wallTriangles ?? []) {
    const z = triangle.vertices.reduce((sum, point) => sum + point.z, 0) / 3;
    const band = bands[nearestBand(result, z)];
    const projected = triangle.vertices.map((point) => project(point, 0, cameraZ, roll));
    if (projected.every(Boolean)) paintTriangle(band, ...projected);
  }

  return { bands, forms: [...forms.values()] };
}

function metricsForRaster(raster) {
  const union = new Uint8Array(WIDTH * HEIGHT);
  const overlap = new Uint8Array(WIDTH * HEIGHT);
  for (const band of raster.bands) for (let i = 0; i < union.length; i++) {
    if (band[i]) union[i] = 1;
    overlap[i] += band[i];
  }
  const occupied = union.reduce((sum, value) => sum + value, 0);
  let nearest = Infinity;
  let centreDiskPixels = 0;
  let centreDiskFree = 0;
  const quadrant = [0, 0, 0, 0];
  const sectors = new Uint8Array(24);
  for (let y = 0; y < HEIGHT; y++) for (let x = 0; x < WIDTH; x++) {
    const nx = (x + 0.5 - WIDTH / 2) / (HEIGHT / 2);
    const ny = (HEIGHT / 2 - y - 0.5) / (HEIGHT / 2);
    const radial = Math.hypot(nx, ny);
    const index = y * WIDTH + x;
    if (radial <= 0.28) {
      centreDiskPixels++;
      if (!union[index]) centreDiskFree++;
    }
    if (!union[index]) continue;
    nearest = Math.min(nearest, radial);
    quadrant[(x >= WIDTH / 2 ? 1 : 0) + (y >= HEIGHT / 2 ? 2 : 0)]++;
    if (radial >= 0.16 && radial <= 0.92) {
      const angle = (Math.atan2(ny, nx) + TAU) % TAU;
      sectors[Math.floor(angle / TAU * sectors.length)] = 1;
    }
  }
  const bandOccupancies = raster.bands.map((band) => band.reduce((sum, value) => sum + value, 0) / union.length);
  const formOccupancies = raster.forms.map((form) => form.reduce((sum, value) => sum + value, 0) / Math.max(1, occupied)).sort((a, b) => b - a);
  const occupiedOverlaps = overlap.filter((_, index) => union[index]);
  const qMax = Math.max(...quadrant);
  const nonEmptyBands = bandOccupancies.filter((value) => value > 0);
  return {
    occupancy: occupied / union.length,
    centreClearance: Number.isFinite(nearest) ? nearest : 2,
    centreDiskFree: centreDiskFree / centreDiskPixels,
    radialCoverage: sectors.reduce((sum, value) => sum + value, 0) / sectors.length,
    depthOverlap: occupiedOverlaps.reduce((sum, value) => sum + value, 0) / Math.max(1, occupiedOverlaps.length),
    depthBalance: nonEmptyBands.length > 1 ? Math.min(...nonEmptyBands) / Math.max(...nonEmptyBands) : 1,
    quadrantBalance: qMax ? Math.min(...quadrant) / qMax : 0,
    dominantFormShare: formOccupancies[0] ?? 0,
    bandOccupancies,
  };
}

export function measureHeroComposition(result) {
  const views = Array.from({ length: 6 }, (_, view) => metricsForRaster(rasterize(result, view * TAU / 6)));
  const scalar = (key, reducer) => reducer(views.map((view) => view[key]));
  const min = (values) => Math.min(...values);
  const max = (values) => Math.max(...values);
  const mean = (values) => values.reduce((sum, value) => sum + value, 0) / values.length;
  return {
    H1_occupancy: round(scalar('occupancy', mean)),
    H2_centreClearance: round(scalar('centreClearance', min)),
    H3_centreDiskFree: round(scalar('centreDiskFree', min)),
    H4_radialCoverage: round(scalar('radialCoverage', min)),
    H5_depthOverlap: round(scalar('depthOverlap', mean)),
    H6_depthBalance: round(scalar('depthBalance', min)),
    H7_quadrantBalance: round(scalar('quadrantBalance', min)),
    H8_dominantFormShare: round(scalar('dominantFormShare', max)),
    views: views.map((view, roll) => ({ roll: roll * 60, ...Object.fromEntries(Object.entries(view).map(([key, value]) => [key, Array.isArray(value) ? value.map((v) => round(v)) : round(value)])) })),
  };
}

export const heroTargets = {
  roots: {
    H1_occupancy: [0.008, 0.08], H2_centreClearance: [0.04, 0.16], H3_centreDiskFree: [0.58, 1],
    H4_radialCoverage: [0.75, 1], H5_depthOverlap: [1.05, 2.4], H6_depthBalance: [0.10, 0.35],
    H7_quadrantBalance: [0.42, 1], H8_dominantFormShare: [0, 0.70],
  },
  blades: {
    H1_occupancy: [0.010, 0.026], H2_centreClearance: [0.055, 0.18], H3_centreDiskFree: [0.70, 1],
    H4_radialCoverage: [0.70, 1], H5_depthOverlap: [1, 2.2], H6_depthBalance: [0.035, 0.25],
    H7_quadrantBalance: [0.55, 1], H8_dominantFormShare: [0, 0.24],
  },
  ribs: {
    H1_occupancy: [0.012, 0.05], H2_centreClearance: [0.03, 0.16], H3_centreDiskFree: [0.45, 1],
    H4_radialCoverage: [0.83, 1], H5_depthOverlap: [1.03, 2.4], H6_depthBalance: [0.09, 0.35],
    H7_quadrantBalance: [0.48, 1], H8_dominantFormShare: [0, 0.70],
  },
};

export function evaluateHeroTargets(family, metrics) {
  const target = heroTargets[family];
  const gates = Object.fromEntries(Object.entries(target).map(([key, [lo, hi]]) => [key, {
    value: metrics[key],
    range: [lo, hi],
    pass: metrics[key] >= lo && metrics[key] <= hi,
  }]));
  return {
    gates,
    passed: Object.values(gates).filter((gate) => gate.pass).length,
    evaluated: Object.keys(gates).length,
  };
}

export function minimumTubeMargin(result, context) {
  let margin = Infinity;
  for (const piece of result.collisionCapsules) {
    for (let sample = 0; sample <= 12; sample++) {
      const t = sample / 12;
      const x = lerp(piece.a.x, piece.b.x, t);
      const y = lerp(piece.a.y, piece.b.y, t);
      const z = lerp(piece.a.z, piece.b.z, t);
      margin = Math.min(margin, Math.hypot(x, y) - piece.radius - context.tubeRadiusAt(z));
    }
  }
  return round(margin);
}

export function buildHeroExperiment() {
  const baselineSpecs = ['R2', 'B1', 'C3'].map((variant) => prototypes.find((spec) => spec.variant === variant));
  const baselines = baselineSpecs.map((spec) => runPrototype(spec));
  const candidates = [buildRootsHero(baselines[0]), buildBladesHero(baselines[1]), buildRibsHero(baselines[2])];
  return baselines.map((baseline, index) => {
    const candidate = candidates[index];
    const before = measureHeroComposition(baseline.result);
    const after = measureHeroComposition(candidate);
    return {
      family: candidate.family,
      baseline: { variant: baseline.result.variant, metrics: before, target: evaluateHeroTargets(candidate.family, before) },
      candidate: {
        variant: candidate.variant,
        name: candidate.name,
        pieces: candidate.pieces.length,
        forms: candidate.forms.length,
        collisionCapsules: candidate.collisionCapsules.length,
        tubeMargin: minimumTubeMargin(candidate, baseline.context),
        metrics: after,
        target: evaluateHeroTargets(candidate.family, after),
      },
      result: candidate,
      context: baseline.context,
    };
  });
}

export const heroRasterSize = { width: WIDTH, height: HEIGHT, fovYDegrees: 70, aspect: ASPECT };
