import { createHash } from 'node:crypto';

const TAU = Math.PI * 2;
const VISIBLE_SPAN = 280;

function mulberry32(seed) {
  let state = seed >>> 0;
  return () => {
    state += 0x6d2b79f5;
    let t = state;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
const lerp = (a, b, t) => a + (b - a) * t;
const round = (v, digits = 5) => Number(v.toFixed(digits));
const polar = (radius, azimuth, z) => ({
  x: radius * Math.cos(azimuth),
  y: radius * Math.sin(azimuth),
  z,
});

function distancePointSegment(point, a, b) {
  const ab = { x: b.x - a.x, y: b.y - a.y, z: b.z - a.z };
  const ap = { x: point.x - a.x, y: point.y - a.y, z: point.z - a.z };
  const d = ab.x * ab.x + ab.y * ab.y + ab.z * ab.z;
  const t = d ? clamp((ap.x * ab.x + ap.y * ab.y + ap.z * ab.z) / d, 0, 1) : 0;
  return Math.hypot(point.x - (a.x + ab.x * t), point.y - (a.y + ab.y * t), point.z - (a.z + ab.z * t));
}

function capsule(id, gid, a, b, radius, role, wallContact = false) {
  return { id, gid, kind: 'capsule', a, b, radius, role, wallContact };
}

function baseContext(seed, zStart, zEnd) {
  return {
    seed,
    roomK: 9,
    zStart,
    zEnd,
    rng: mulberry32(seed),
    pathFrameAt(z) {
      return {
        center: { x: 0.28 * Math.sin(z / 83), y: 0.22 * Math.cos(z / 71), z },
        tangent: { x: 0.0034 * Math.cos(z / 83), y: -0.0031 * Math.sin(z / 71), z: 0.99999 },
        axisX: { x: 1, y: 0, z: -0.0034 * Math.cos(z / 83) },
        axisY: { x: 0, y: 1, z: 0.0031 * Math.sin(z / 71) },
      };
    },
    tubeRadiusAt(z) {
      return 3 + 0.08 * Math.sin(z / 47);
    },
    wallRadiusAt(z, azimuth) {
      return 8.35 + 0.28 * Math.sin(z / 31 + azimuth * 2) + 0.18 * Math.cos(z / 17 - azimuth * 3);
    },
    budgets: { pieces: 120, triangles: 12000, axial: VISIBLE_SPAN },
  };
}

function generateR2(context) {
  const pieces = [];
  const forms = [];
  const crawlerCount = 3;
  const nodesPerCrawler = 18;
  for (let crawler = 0; crawler < crawlerCount; crawler++) {
    const gid = `crawler-${crawler}`;
    const phase = crawler * TAU / crawlerCount + (context.rng() - 0.5) * 0.18;
    const nodes = [];
    for (let i = 0; i < nodesPerCrawler; i++) {
      const t = i / (nodesPerCrawler - 1);
      const z = lerp(context.zStart + 2, context.zEnd - 3, t);
      const azimuth = phase + 0.52 * Math.sin(t * Math.PI * 1.55 + crawler * 0.8);
      const wall = context.wallRadiusAt(z, azimuth);
      const radius = 0.38 + 0.16 * (1 - t);
      const radial = wall - 0.44 - radius;
      nodes.push(polar(radial, azimuth, z));
      if (i) pieces.push(capsule(`r2-${gid}-${i - 1}`, gid, nodes[i - 1], nodes[i], radius, 'hero-crawler', i <= 2));
    }
    forms.push({ gid, role: 'hero-crawler', tier: 0, nodes, wallContact: true });
  }

  const clawSpecs = [
    { crawler: 0, at: 12, dz: 19, turn: 0.42 },
    { crawler: 0, at: 14, dz: 13, turn: -0.58 },
    { crawler: 1, at: 11, dz: 23, turn: -0.47 },
    { crawler: 2, at: 13, dz: 17, turn: 0.55 },
  ];
  for (let claw = 0; claw < clawSpecs.length; claw++) {
    const spec = clawSpecs[claw];
    const parent = forms[spec.crawler].nodes[spec.at];
    const startAz = Math.atan2(parent.y, parent.x);
    const startR = Math.hypot(parent.x, parent.y);
    const gid = `claw-${claw}`;
    const nodes = [parent];
    for (let i = 1; i <= 6; i++) {
      const t = i / 6;
      const z = parent.z + spec.dz * t;
      const radius = 0.38 - 0.18 * t;
      const targetR = context.tubeRadiusAt(z) + radius + 0.22;
      nodes.push(polar(lerp(startR, targetR, t * t), startAz + spec.turn * Math.sin(Math.PI * t), z));
      pieces.push(capsule(`r2-${gid}-${i - 1}`, gid, nodes[i - 1], nodes[i], radius, 'claw', false));
    }
    forms.push({ gid, role: 'claw', tier: 1, nodes, wallContact: true, junction: `crawler-${spec.crawler}` });
  }

  return familyResult('roots', 'R2', 'Wall-Crawling Fork Braid', context, pieces, forms, [], {
    depthBandCenters: [8994, 9022, 9050, 9078, 9106], crawlerCount, forkCount: clawSpecs.length,
    referenceSignals: { axialContinuity: true, forkedClaws: true, wallIntegrated: true },
  });
}

function generateR1(context) {
  const pieces = [];
  const forms = [];
  for (let arm = 0; arm < 4; arm++) {
    const gid = `reach-${arm}`;
    const nodes = [];
    const phase = arm * TAU / 4 + 0.13 * Math.sin(context.seed + arm);
    for (let i = 0; i < 15; i++) {
      const t = i / 14;
      const z = lerp(context.zStart + 17, context.zEnd - 18, t);
      const az = phase + 0.28 * Math.sin(t * Math.PI);
      const radius = 0.48 - 0.2 * t;
      const radial = lerp(context.wallRadiusAt(z, az) - radius - 0.2, context.tubeRadiusAt(z) + radius + 0.25, t * t);
      nodes.push(polar(radial, az, z));
      if (i) pieces.push(capsule(`r1-${gid}-${i - 1}`, gid, nodes[i - 1], nodes[i], radius, 'forked-reach', i <= 2));
    }
    forms.push({ gid, role: 'forked-reach', tier: 0, nodes, wallContact: true });
  }
  return familyResult('roots', 'R1', 'Forked Reach Graph', context, pieces, forms, [], {
    depthBandCenters: [9010, 9038, 9066, 9094], crawlerCount: 0, forkCount: 4,
    referenceSignals: { axialContinuity: false, forkedClaws: true, wallIntegrated: true },
  });
}

function plateGeometry(context, variant, bank, index, facets, z, azimuth, length, width) {
  const wall = context.wallRadiusAt(z, azimuth);
  const radialBase = wall - 0.35;
  const radialTip = context.tubeRadiusAt(z) + 0.82;
  const gid = `${variant.toLowerCase()}-plate-${bank}-${index}`;
  const centerZ = z + 0.4 * Math.sin(index * 1.7 + bank);
  const pieces = [];
  for (let facet = 0; facet < facets; facet++) {
    const across = facets === 1 ? 0 : facet / (facets - 1) - 0.5;
    const facetAz = azimuth + across * width / ((radialBase + radialTip) * 0.5);
    const stagger = across * length * 0.12;
    const base = polar(radialBase, facetAz, centerZ - length * 0.5 + stagger);
    const tip = polar(radialTip, facetAz, centerZ + length * 0.5 - stagger);
    const tangent = { x: -Math.sin(facetAz), y: Math.cos(facetAz), z: 0 };
    const halfWidth = width / facets * (0.48 + 0.08 * ((index + facet) % 3));
    const offset = (point, amount) => ({ x: point.x + tangent.x * amount, y: point.y + tangent.y * amount, z: point.z });
    const middle = { x: (base.x + tip.x) * 0.5, y: (base.y + tip.y) * 0.5, z: (base.z + tip.z) * 0.5 + 0.12 * Math.sin(index + facet) };
    const vertices = [
      offset(base, halfWidth), offset(base, -halfWidth * 0.78),
      offset(middle, -halfWidth * 1.06), offset(tip, -halfWidth * 0.28),
      offset(tip, halfWidth * 0.22), offset(middle, halfWidth * 0.91),
    ];
    const maxDistance = Math.max(...vertices.map((point) => distancePointSegment(point, base, tip)));
    const colliderRadius = maxDistance + 0.015;
    pieces.push({
      id: `${gid}-facet-${facet}`, gid, kind: 'plate', role: 'hero-plate', vertices,
      collisionCapsule: capsule(`${gid}-cap-${facet}`, gid, base, tip, colliderRadius, 'hero-plate', true),
      wallContact: true,
    });
  }
  return {
    gid, pieces,
    form: {
      gid, role: 'hero-plate', tier: bank,
      nodes: [pieces[0].collisionCapsule.a, pieces.at(-1).collisionCapsule.b], wallContact: true,
    },
    azimuth,
  };
}

function generateB1(context) {
  const pieces = [];
  const forms = [];
  const bankZ = [context.zStart + 12, (context.zStart + context.zEnd) / 2, context.zEnd - 12];
  const azimuths = [];
  for (let bank = 0; bank < 3; bank++) {
    const opening = bank * 0.27 + 0.035 * Math.sin(context.seed + bank);
    for (let plate = 0; plate < 8; plate++) {
      const az = opening + (plate + 0.5) * TAU / 8;
      const result = plateGeometry(context, 'B1', bank, plate, 3, bankZ[bank], az, 10 + (plate % 4) * 2.1, 1.2 + (plate % 3) * 0.24);
      pieces.push(...result.pieces);
      forms.push(result.form);
      azimuths.push(az);
    }
  }
  return familyResult('blades', 'B1', 'Three-Bank Axial Iris', context, pieces, forms, [], {
    depthBandCenters: bankZ, bankCount: 3, plateCount: forms.length, azimuths,
    referenceSignals: { axialLayers: true, radialIris: true, familyDistinct: true },
  });
}

function generateB2(context) {
  const pieces = [];
  const forms = [];
  const fronts = 5;
  const bandCenters = [];
  const azimuths = [];
  for (let front = 0; front < fronts; front++) {
    const z = lerp(context.zStart + 14, context.zEnd - 14, front / (fronts - 1));
    bandCenters.push(z);
    const baseAz = front * 1.11;
    for (let plate = 0; plate < 7; plate++) {
      const az = baseAz + (plate - 3) * 0.25;
      const result = plateGeometry(context, 'B2', front, plate, 2, z, az, 8 + (plate % 3) * 2, 1.0 + (plate % 2) * 0.3);
      pieces.push(...result.pieces);
      forms.push(result.form);
      azimuths.push(az);
    }
  }
  return familyResult('blades', 'B2', 'Shared Fracture Fronts', context, pieces, forms, [], {
    depthBandCenters: bandCenters, bankCount: fronts, plateCount: forms.length, azimuths,
    referenceSignals: { axialLayers: true, radialIris: false, familyDistinct: true },
  });
}

function shellGrid(context, channels) {
  const rings = [];
  const triangles = [];
  for (let z = context.zStart; z <= context.zEnd + 1e-6; z += 2) {
    const vertices = [];
    for (let sector = 0; sector < 32; sector++) {
      const az = sector * TAU / 32;
      const baseRadius = context.wallRadiusAt(z, az);
      let requested = 0;
      for (const channel of channels) {
        const phase = channel.phaseAt(z);
        const delta = Math.atan2(Math.sin(az - phase), Math.cos(az - phase));
        const halfWidth = channel.halfWidthAt(z);
        const angular = Math.abs(delta) < halfWidth ? 0.5 + 0.5 * Math.cos(Math.PI * delta / halfWidth) : 0;
        requested += channel.inwardAt(z) * angular;
      }
      // Vertex clamp leaves enough reserve for the chord between adjacent sectors.
      const tubeLimit = context.tubeRadiusAt(z) + 0.18;
      const radius = Math.max(tubeLimit, baseRadius - requested);
      vertices.push({ ...polar(radius, az, z), baseRadius, radius, requested, azimuth: az });
    }
    rings.push({ z, vertices });
  }
  for (let ring = 0; ring < rings.length - 1; ring++) {
    for (let sector = 0; sector < 32; sector++) {
      const next = (sector + 1) % 32;
      const a = rings[ring].vertices[sector];
      const b = rings[ring + 1].vertices[sector];
      const c = rings[ring + 1].vertices[next];
      const d = rings[ring].vertices[next];
      triangles.push({ id: `wall-${ring}-${sector}-a`, vertices: [a, b, c] });
      triangles.push({ id: `wall-${ring}-${sector}-b`, vertices: [a, c, d] });
    }
  }
  return { rings, triangles };
}

function generateC3(context) {
  const span = context.zEnd - context.zStart;
  const channel = {
    id: 'shell-channel-main', z0: context.zStart, z1: context.zEnd, profile: 'cosine',
    phaseAt: (z) => 0.4 + (z - context.zStart) * TAU / 128,
    halfWidthAt: (z) => 0.48 + 0.11 * Math.sin((z - context.zStart) * TAU * 6 / span) ** 2,
    inwardAt: (z) => 3.4 + 1.6 * (0.5 + 0.5 * Math.cos((z - context.zStart) * TAU * 6 / span)),
  };
  const companion = {
    id: 'shell-channel-companion', z0: context.zStart, z1: context.zEnd, profile: 'cosine',
    phaseAt: (z) => channel.phaseAt(z) + Math.PI,
    halfWidthAt: (z) => 0.34 + 0.07 * Math.sin((z - context.zStart) * TAU * 5 / span) ** 2,
    inwardAt: (z) => 0.72 + 0.52 * (0.5 + 0.5 * Math.cos((z - context.zStart) * TAU * 5 / span + 0.8)),
  };
  const channels = [channel, companion];
  const grid = shellGrid(context, channels);
  const forms = channels.map((candidate, tier) => ({
    gid: candidate.id, role: 'shell-channel', tier, wallContact: true,
    nodes: grid.rings.map((ring) => {
      const phase = candidate.phaseAt(ring.z);
      const radial = context.wallRadiusAt(ring.z, phase) - candidate.inwardAt(ring.z);
      return polar(radial, phase, ring.z);
    }),
  }));
  const depthBandCenters = Array.from({ length: 7 }, (_, i) => context.zStart + i * span / 6);
  return familyResult('ribs', 'C3', 'Shell-Channel Helix Vertebra', context, [], forms, channels, {
    depthBandCenters,
    hubMaxima: 6, extraDrawCalls: 0, shellRings: grid.rings, wallTriangles: grid.triangles,
    azimuths: depthBandCenters.flatMap((z) => [channel.phaseAt(z), companion.phaseAt(z)]),
    referenceSignals: { continuousWallHelix: true, axialOverlap: true, integratedSurface: true, smallCentralOpening: true },
  });
}

function generateC1(context) {
  const pieces = [];
  const forms = [];
  const backboneNodes = [];
  for (let i = 0; i < 37; i++) {
    const t = i / 36;
    const z = lerp(context.zStart, context.zEnd, t);
    const az = 0.25 + t * TAU * 1.2;
    const radial = context.wallRadiusAt(z, az) - 1.1;
    backboneNodes.push(polar(radial, az, z));
    if (i) pieces.push(capsule(`c1-backbone-${i - 1}`, 'backbone', backboneNodes[i - 1], backboneNodes[i], 0.46, 'backbone', i <= 2));
  }
  forms.push({ gid: 'backbone', role: 'backbone', tier: 0, nodes: backboneNodes, wallContact: true });
  for (let rib = 0; rib < 6; rib++) {
    const gid = `vertebra-${rib}`;
    const z = context.zStart + 12 + rib * (context.zEnd - context.zStart - 24) / 5;
    const startAz = 0.25 + (z - context.zStart) / (context.zEnd - context.zStart) * TAU * 1.2;
    const nodes = [];
    for (let i = 0; i <= 8; i++) {
      const az = startAz + i / 8 * Math.PI * 1.45;
      const radial = context.wallRadiusAt(z, az) - 0.75;
      nodes.push(polar(radial, az, z + 1.8 * Math.sin(i / 8 * Math.PI)));
      if (i) pieces.push(capsule(`c1-${gid}-${i - 1}`, gid, nodes[i - 1], nodes[i], 0.6, 'vertebra', i === 1));
    }
    forms.push({ gid, role: 'vertebra', tier: 1, nodes, wallContact: true, junction: 'backbone' });
  }
  return familyResult('ribs', 'C1', 'Helix Backbone with Vertebrae', context, pieces, forms, [], {
    depthBandCenters: forms.slice(1).map((form) => form.nodes[0].z), hubMaxima: 6, extraDrawCalls: 1,
    referenceSignals: { continuousWallHelix: false, axialOverlap: true, integratedSurface: false, smallCentralOpening: true },
  });
}

function familyResult(family, variant, name, context, pieces, forms, shellChannels, diagnostics) {
  const { wallTriangles = [], ...publicDiagnostics } = diagnostics;
  const collisionCapsules = pieces.flatMap((piece) => piece.kind === 'capsule'
    ? [piece]
    : piece.collisionCapsule ? [piece.collisionCapsule] : []);
  return {
    schemaVersion: 1,
    family, variant, name,
    context: { seed: context.seed, roomK: context.roomK, zStart: context.zStart, zEnd: context.zEnd },
    pieces, collisionCapsules, wallTriangles, shellChannels: shellChannels.map(({ phaseAt, halfWidthAt, inwardAt, ...channel }) => ({
      ...channel,
      samples: Array.from({ length: 9 }, (_, i) => {
        const z = lerp(channel.z0, channel.z1, i / 8);
        return { z, phase: phaseAt(z), halfWidth: halfWidthAt(z), inward: inwardAt(z) };
      }),
    })),
    forms, diagnostics: publicDiagnostics,
  };
}

function largestAzimuthGap(result) {
  const values = result.diagnostics.azimuths?.slice()
    ?? result.forms.map((form) => Math.atan2(form.nodes[0].y, form.nodes[0].x));
  const angles = [...new Set(values.map((value) => (value % TAU + TAU) % TAU).map((value) => round(value, 4)))].sort((a, b) => a - b);
  if (angles.length < 2) return 360;
  let gap = 0;
  for (let i = 0; i < angles.length; i++) {
    const next = i === angles.length - 1 ? angles[0] + TAU : angles[i + 1];
    gap = Math.max(gap, next - angles[i]);
  }
  return gap * 180 / Math.PI;
}

function visibleSamples(result) {
  const samples = [];
  for (const piece of [...result.pieces, ...result.wallTriangles]) {
    if (piece.kind === 'capsule') {
      for (let i = 0; i <= 4; i++) {
        const t = i / 4;
        samples.push({
          x: lerp(piece.a.x, piece.b.x, t), y: lerp(piece.a.y, piece.b.y, t), z: lerp(piece.a.z, piece.b.z, t),
          radius: piece.radius, authority: 'capsule', id: piece.id,
        });
      }
    } else if (piece.kind === 'plate') {
      samples.push(...piece.vertices.map((point) => ({ ...point, radius: 0, authority: 'plate', id: piece.id, capsule: piece.collisionCapsule })));
      for (let i = 0; i <= 4; i++) {
        const t = i / 4;
        samples.push({
          x: lerp(piece.collisionCapsule.a.x, piece.collisionCapsule.b.x, t),
          y: lerp(piece.collisionCapsule.a.y, piece.collisionCapsule.b.y, t),
          z: lerp(piece.collisionCapsule.a.z, piece.collisionCapsule.b.z, t),
          radius: piece.collisionCapsule.radius,
          authority: 'plate-capsule', id: piece.collisionCapsule.id,
        });
      }
    } else if (piece.vertices) {
      const [a, b, c] = piece.vertices;
      const barycentric = [
        [1, 0, 0], [0, 1, 0], [0, 0, 1],
        [0.5, 0.5, 0], [0.5, 0, 0.5], [0, 0.5, 0.5],
        [1 / 3, 1 / 3, 1 / 3],
      ];
      samples.push(...barycentric.map(([wa, wb, wc]) => ({
        x: a.x * wa + b.x * wb + c.x * wc,
        y: a.y * wa + b.y * wb + c.y * wc,
        z: a.z * wa + b.z * wb + c.z * wc,
        radius: 0, authority: 'wall-triangle', id: piece.id,
      })));
    }
  }
  return samples;
}

function orbitStability(result) {
  const samples = visibleSamples(result);
  const occupancies = [];
  for (let view = 0; view < 6; view++) {
    const angle = view * TAU / 6;
    const projected = samples.map((point) => ({ u: -point.x * Math.sin(angle) + point.y * Math.cos(angle), z: point.z, r: point.radius }));
    const zMin = Math.min(...projected.map((p) => p.z));
    const zMax = Math.max(...projected.map((p) => p.z));
    const uMin = Math.min(...projected.map((p) => p.u - p.r));
    const uMax = Math.max(...projected.map((p) => p.u + p.r));
    const binCount = 48;
    let filled = 0;
    for (let bin = 0; bin < binCount; bin++) {
      const z = lerp(zMin, zMax, (bin + 0.5) / binCount);
      const intervals = projected
        .filter((p) => Math.abs(p.z - z) <= Math.max(2.5, (zMax - zMin) / binCount))
        .map((p) => [p.u - Math.max(p.r, 0.12), p.u + Math.max(p.r, 0.12)])
        .sort((a, b) => a[0] - b[0]);
      let covered = 0;
      let cursor = -Infinity;
      for (const [a, b] of intervals) {
        if (b <= cursor) continue;
        covered += b - Math.max(a, cursor);
        cursor = b;
      }
      filled += covered / Math.max(0.01, uMax - uMin);
    }
    occupancies.push(filled / binCount);
  }
  const min = Math.min(...occupancies);
  const max = Math.max(...occupancies);
  return { value: max ? min / max : 0, occupancies: occupancies.map((v) => round(v)) };
}

function capsuleCoverage(result) {
  const plateVertices = result.pieces.filter((piece) => piece.kind === 'plate').flatMap((piece) => piece.vertices.map((point) => ({ point, capsule: piece.collisionCapsule })));
  if (!plateVertices.length) return {
    value: 1,
    checked: result.wallTriangles.length || result.pieces.length,
    authority: result.shellChannels.length ? 'wall triangles are visible and colliding authority' : 'capsule sweep is visible and colliding authority',
  };
  const covered = plateVertices.filter(({ point, capsule: cap }) => distancePointSegment(point, cap.a, cap.b) <= cap.radius + 1e-8).length;
  return { value: covered / plateVertices.length, checked: plateVertices.length, authority: 'plate vertices against authoritative capsules' };
}

function tubeMargin(result, context) {
  let margin = Infinity;
  for (const point of visibleSamples(result)) {
    const radial = Math.hypot(point.x, point.y) - point.radius;
    margin = Math.min(margin, radial - context.tubeRadiusAt(point.z));
  }
  return margin;
}

function gateFor(family, key, value) {
  if (key === 'S1') return value >= ({ roots: 0.29, blades: 0.21, ribs: 0.43 })[family];
  if (key === 'S2') return value >= 3;
  if (key === 'S3') {
    const [lo, hi] = ({ roots: [40, 120], blades: [0, 35], ribs: [25, 90] })[family];
    return value >= lo && value <= hi;
  }
  if (key === 'S4') return value >= (family === 'blades' ? 0.3 : 0.45);
  if (key === 'S5' || key === 'S7') return value === 1;
  if (key === 'S8') return value >= (family === 'ribs' ? 0.12 : 0.15);
  return null;
}

export function measureFamily(result, context) {
  const samples = visibleSamples(result);
  const zValues = samples.map((point) => point.z);
  const span = Math.max(...zValues) - Math.min(...zValues);
  const s4 = orbitStability(result);
  const s7 = capsuleCoverage(result);
  const contacts = result.forms.filter((form) => form.wallContact).length / Math.max(1, result.forms.length);
  const values = {
    S1: { name: 'axialOccupancy', value: span / VISIBLE_SPAN, unit: 'ratio' },
    S2: { name: 'depthBands', value: result.diagnostics.depthBandCenters.length, unit: 'count' },
    S3: { name: 'azimuthGap', value: largestAzimuthGap(result), unit: 'degrees' },
    S4: { name: 'orbitStability', value: s4.value, unit: 'min/max', views: s4.occupancies },
    S5: { name: 'wallContact', value: contacts, unit: 'ratio' },
    S6: { name: 'emberIrregularity', status: 'notEvaluated', reason: 'Core prototype intentionally has no material, UV, texture, or ember field.' },
    S7: { name: 'surfaceCoverage', value: s7.value, unit: 'ratio', checked: s7.checked, authority: s7.authority },
    S8: { name: 'tubeMargin', value: tubeMargin(result, context), unit: 'metres' },
  };
  for (const [key, metric] of Object.entries(values)) {
    if ('value' in metric) {
      metric.value = round(metric.value);
      metric.pass = gateFor(result.family, key, metric.value);
    }
  }
  const evaluated = Object.values(values).filter((metric) => metric.pass !== undefined);
  const passCount = evaluated.filter((metric) => metric.pass).length;
  const referenceSignals = Object.values(result.diagnostics.referenceSignals ?? {});
  const referenceFit = referenceSignals.filter(Boolean).length / Math.max(1, referenceSignals.length);
  return {
    ...values,
    summary: {
      evaluated: evaluated.length,
      passed: passCount,
      coreGatePass: passCount === evaluated.length,
      pieceCount: result.pieces.length,
      triangleCount: result.wallTriangles.length,
      formCount: result.forms.length,
      capsuleCount: result.collisionCapsules.length,
      shellChannelCount: result.shellChannels.length,
      axialSpan: round(span),
      referenceFit: round(referenceFit),
      structuralScore: round(passCount / evaluated.length * 70 + Math.min(span, VISIBLE_SPAN) / VISIBLE_SPAN * 10 + referenceFit * 20),
    },
  };
}

function serializable(result, metrics) {
  const cleaned = JSON.parse(JSON.stringify(result, (key, value) => {
    if (key === 'shellRings') return undefined;
    return typeof value === 'number' ? round(value) : value;
  }));
  cleaned.metrics = metrics;
  cleaned.fingerprint = fingerprint(cleaned);
  return cleaned;
}

export function fingerprint(value) {
  return createHash('sha256').update(JSON.stringify(value)).digest('hex');
}

export const prototypes = [
  { family: 'roots', variant: 'R2', seed: 2024, zStart: 8990, zEnd: 9110, generate: generateR2, recommended: true },
  { family: 'roots', variant: 'R1', seed: 2024, zStart: 8990, zEnd: 9110, generate: generateR1, recommended: false },
  { family: 'blades', variant: 'B1', seed: 256, zStart: 9000, zEnd: 9100, generate: generateB1, recommended: true },
  { family: 'blades', variant: 'B2', seed: 256, zStart: 9000, zEnd: 9100, generate: generateB2, recommended: false },
  { family: 'ribs', variant: 'C3', seed: 2024, zStart: 8970, zEnd: 9130, generate: generateC3, recommended: true },
  { family: 'ribs', variant: 'C1', seed: 2024, zStart: 8970, zEnd: 9130, generate: generateC1, recommended: false },
];

export function runPrototype(spec) {
  const context = baseContext(spec.seed, spec.zStart, spec.zEnd);
  const result = spec.generate(context);
  const metrics = measureFamily(result, context);
  return { context, result, metrics, document: serializable(result, metrics) };
}

export function escapeXml(value) {
  return String(value).replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;').replaceAll('"', '&quot;');
}
