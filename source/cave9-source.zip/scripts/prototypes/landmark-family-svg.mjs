import { escapeXml } from './landmark-family-core.mjs';

const TAU = Math.PI * 2;
const f = (v) => Number(v).toFixed(2);
const polarRadius = (p) => Math.hypot(p.x, p.y);

function shellAt(result, context, z, count = 32) {
  const ring = result.diagnostics.shellRings?.reduce((best, candidate) => Math.abs(candidate.z - z) < Math.abs(best.z - z) ? candidate : best, result.diagnostics.shellRings[0]);
  if (ring) return ring.vertices;
  return Array.from({ length: count }, (_, sector) => {
    const azimuth = sector * TAU / count;
    return { ...(() => {
      const radius = context.wallRadiusAt(z, azimuth);
      return { x: radius * Math.cos(azimuth), y: radius * Math.sin(azimuth), z, radius };
    })(), azimuth };
  });
}

function header(title, width, height, result) {
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}" role="img" aria-labelledby="title desc" data-family="${result.family}" data-variant="${result.variant}">
<title id="title">${escapeXml(title)}</title><desc id="desc">Deterministic vector evidence. Dark line: visible surface. Red: boolean tube. Orange: collision authority.</desc>
<style>text{font:12px system-ui;fill:#cbd5e1}.label{font-weight:700;fill:#fff}.wall{fill:none;stroke:#64748b;stroke-width:1.2}.tube{fill:#21080b;stroke:#fb7185;stroke-width:1.5}.surface{fill:none;stroke:#e2e8f0;stroke-width:1.5}.collision{fill:none;stroke:#f59e0b;stroke-width:1;stroke-dasharray:3 2}.grid{stroke:#243244;stroke-width:.7}.muted{fill:#94a3b8}.panel{fill:#0b1220;stroke:#334155}</style>
<rect width="100%" height="100%" fill="#070b13"/>`;
}

export function crossSectionSvg(result, context) {
  const zs = [result.context.zStart + 20, (result.context.zStart + result.context.zEnd) / 2, result.context.zEnd - 20];
  const width = 960;
  const height = 350;
  let svg = header(`${result.variant} cross sections`, width, height, result);
  zs.forEach((z, panel) => {
    const cx = 160 + panel * 320;
    const cy = 175;
    const scale = 14;
    svg += `<g id="section-${panel}" data-z="${f(z)}"><rect class="panel" x="${panel * 320 + 8}" y="24" width="304" height="310" rx="8"/><text class="label" x="${panel * 320 + 20}" y="46">z ${f(z)} m</text>`;
    const wall = shellAt(result, context, z);
    const wallPath = wall.map((p, i) => `${i ? 'L' : 'M'}${f(cx + p.x * scale)} ${f(cy - p.y * scale)}`).join(' ') + ' Z';
    svg += `<path class="wall" d="${wallPath}"/><circle class="tube" cx="${cx}" cy="${cy}" r="${f(context.tubeRadiusAt(z) * scale)}"/>`;
    for (const piece of result.pieces) {
      if (piece.kind === 'capsule') {
        const zMin = Math.min(piece.a.z, piece.b.z) - piece.radius;
        const zMax = Math.max(piece.a.z, piece.b.z) + piece.radius;
        if (z < zMin || z > zMax) continue;
        const t = Math.abs(piece.b.z - piece.a.z) < 1e-6 ? 0.5 : Math.max(0, Math.min(1, (z - piece.a.z) / (piece.b.z - piece.a.z)));
        const x = piece.a.x + (piece.b.x - piece.a.x) * t;
        const y = piece.a.y + (piece.b.y - piece.a.y) * t;
        svg += `<circle class="collision" data-piece="${piece.id}" cx="${f(cx + x * scale)}" cy="${f(cy - y * scale)}" r="${f(piece.radius * scale)}"/>`;
      } else if (piece.kind === 'plate') {
        if (!piece.vertices.some((p) => Math.abs(p.z - z) < 6)) continue;
        const points = piece.vertices.map((p) => `${f(cx + p.x * scale)},${f(cy - p.y * scale)}`).join(' ');
        svg += `<polygon class="surface" data-piece="${piece.id}" points="${points}"/>`;
      }
    }
    svg += '</g>';
  });
  return `${svg}</svg>\n`;
}

export function longitudinalSvg(result, context) {
  const width = 1000;
  const height = 440;
  const x0 = 58;
  const x1 = 975;
  const cy = 220;
  const sy = 19;
  const sx = (x1 - x0) / (result.context.zEnd - result.context.zStart);
  const px = (z) => x0 + (z - result.context.zStart) * sx;
  let svg = header(`${result.variant} longitudinal section`, width, height, result);
  svg += `<g id="envelopes"><line class="grid" x1="${x0}" y1="${cy}" x2="${x1}" y2="${cy}"/>`;
  const samples = Array.from({ length: 81 }, (_, i) => lerp(result.context.zStart, result.context.zEnd, i / 80));
  const wallTop = samples.map((z, i) => `${i ? 'L' : 'M'}${f(px(z))} ${f(cy - context.wallRadiusAt(z, 0) * sy)}`).join(' ');
  const wallBottom = samples.map((z, i) => `${i ? 'L' : 'M'}${f(px(z))} ${f(cy + context.wallRadiusAt(z, Math.PI) * sy)}`).join(' ');
  const tubeTop = samples.map((z, i) => `${i ? 'L' : 'M'}${f(px(z))} ${f(cy - context.tubeRadiusAt(z) * sy)}`).join(' ');
  const tubeBottom = samples.map((z, i) => `${i ? 'L' : 'M'}${f(px(z))} ${f(cy + context.tubeRadiusAt(z) * sy)}`).join(' ');
  svg += `<path class="wall" d="${wallTop}"/><path class="wall" d="${wallBottom}"/><path class="tube" d="${tubeTop}"/><path class="tube" d="${tubeBottom}"/></g>`;
  for (const form of result.forms) {
    const path = form.nodes.map((p, i) => `${i ? 'L' : 'M'}${f(px(p.z))} ${f(cy - polarRadius(p) * Math.cos(Math.atan2(p.y, p.x)) * sy)}`).join(' ');
    svg += `<path class="surface" id="form-${form.gid}" data-role="${form.role}" d="${path}"/>`;
  }
  svg += `<text class="label" x="58" y="28">${escapeXml(result.variant)} — ${escapeXml(result.name)}</text><text class="muted" x="58" y="420">z horizontal · signed projected radius vertical · red = dynamic tube</text>`;
  return `${svg}</svg>\n`;
}

export function silhouettesSvg(result) {
  const width = 1080;
  const height = 570;
  const panelW = 350;
  const panelH = 250;
  const allPoints = result.forms.flatMap((form) => form.nodes);
  const zMin = Math.min(...allPoints.map((p) => p.z));
  const zMax = Math.max(...allPoints.map((p) => p.z));
  let svg = header(`${result.variant} six-angle vector silhouettes`, width, height, result);
  for (let view = 0; view < 6; view++) {
    const angle = view * TAU / 6;
    const col = view % 3;
    const row = Math.floor(view / 3);
    const left = 10 + col * 355;
    const top = 32 + row * 265;
    const project = (point) => ({
      x: left + 18 + (point.z - zMin) / Math.max(1, zMax - zMin) * (panelW - 36),
      y: top + panelH / 2 - (-point.x * Math.sin(angle) + point.y * Math.cos(angle)) * 13,
    });
    svg += `<g id="view-${view}" data-angle="${view * 60}"><rect class="panel" x="${left}" y="${top}" width="${panelW}" height="${panelH}" rx="8"/><text class="label" x="${left + 12}" y="${top + 20}">${view * 60}°</text>`;
    for (const form of result.forms) {
      const path = form.nodes.map((p, i) => {
        const q = project(p);
        return `${i ? 'L' : 'M'}${f(q.x)} ${f(q.y)}`;
      }).join(' ');
      svg += `<path class="surface" data-form="${form.gid}" d="${path}"/>`;
    }
    svg += '</g>';
  }
  return `${svg}</svg>\n`;
}

function lerp(a, b, t) { return a + (b - a) * t; }
