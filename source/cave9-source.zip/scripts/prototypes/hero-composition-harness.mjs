import { mkdir, writeFile } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { buildHeroExperiment, heroRasterSize, heroTargets } from './hero-composition-core.mjs';

const here = dirname(fileURLToPath(import.meta.url));
const root = resolve(here, '..', '..');
const out = resolve(root, 'docs', 'measure', 'prototypes', 'hero-composition-experiment.json');
const experiments = buildHeroExperiment();

const report = {
  schemaVersion: 1,
  purpose: 'Isolated perspective-screen-space comparison for the hero camera; no production runtime or renderer changes.',
  camera: {
    projection: 'analytic perspective along +z',
    cameraOffsetBeforeRoom: 18,
    ...heroRasterSize,
    robustness: 'minimum/maximum over six 60-degree camera-roll samples',
  },
  targets: heroTargets,
  metricDefinitions: {
    H1_occupancy: 'fraction of the 16:9 hero frame covered by landmark silhouette',
    H2_centreClearance: 'minimum free radius around image centre, normalized by half frame height',
    H3_centreDiskFree: 'free fraction inside a radius-0.28 central disk',
    H4_radialCoverage: 'fraction of 24 angular sectors hit in the hero annulus',
    H5_depthOverlap: 'mean number of axial banks contributing at occupied pixels',
    H6_depthBalance: 'smallest/largest projected bank occupancy',
    H7_quadrantBalance: 'smallest/largest quadrant mass',
    H8_dominantFormShare: 'largest single connected form occupancy divided by union occupancy',
  },
  evidenceBasis: [
    'blade-iris: radial dark plates around a visibly lighter corridor',
    'claw-reach and arch-sweep: frame-scale organic mass organized as connected arches, not detached prongs',
    'rib-rings: repeated concentric arches over several axial layers',
    'runtime orbit manifest: R2 76, B1 71 and C3 96 pieces; side-orbit views do not measure hero-camera composition',
    'the standard corridor already owns the continuous embedded three-start coil; C3 must remain a discrete vertebra/ring landmark',
  ],
  runtimeAudit: {
    orbitMethod: 'scripts/orbit-capture.mjs places an external orbit camera at six angles; it is useful for topology, but cannot accept/reject the forward hero silhouette.',
    roots: {
      current: 'Three 17-node longitudinal crawlers plus four forked two-prong claws (76 pieces in the orbit manifest).',
      observedRisk: 'The six side views read as three separate narrow wall strands; no large connected arch encloses the flight corridor.',
    },
    blades: {
      current: 'Three banks of 21-25 plates, each with only a 14-19 degree azimuth gap; 71 pieces in the sampled orbit.',
      observedRisk: 'The existing tests intentionally require tip surfaces within 0.37 m of the Boolean tube, which guarantees a very small projected opening when three banks overlap.',
    },
    ribs: {
      current: 'Two continuous 48-segment capsule helices (96 pieces in the orbit manifest), used as a bounded substitute for the C3 shell-channel prototype.',
      observedRisk: 'The side orbit reads as two intertwined cords; the concentric vertebra/ring hierarchy from rib-rings and arch-sweep is not present in the hero projection contract.',
    },
  },
  caveats: [
    'The mask is geometric and material-free; it does not replace rendered D1-D6 profiling.',
    'Targets are acceptance bands for composition experiments, not claims of pixel identity with a reference photograph.',
    'C3 baseline rasterizes the shell-channel wall triangles while C3-H uses capsule arches; its H1/H3 delta demonstrates composition direction, not a like-for-like percentage improvement.',
    'The candidates are prototype-only and have not been integrated into production CaveTopology or runtime capture.',
  ],
  experiments: experiments.map(({ result, context, ...entry }) => entry),
  recommendation: {
    roots: 'Replace isolated fork emphasis with 3 nested 280-degree arches joined by two wall spines.',
    blades: 'Keep three rotated banks, but use 8 broad plates per bank and terminate tips 2.12-2.44 m outside the protected tube.',
    ribs: 'Use five discrete staggered 300-degree vertebra arches over the axial span; do not add another continuous helix beside the corridor coil.',
  },
};

await mkdir(dirname(out), { recursive: true });
await writeFile(out, `${JSON.stringify(report, null, 2)}\n`);
console.log(`Wrote hero-composition experiment to ${out}`);
for (const experiment of report.experiments) {
  console.log(`${experiment.family}: ${experiment.baseline.variant} ${experiment.baseline.target.passed}/8 -> ${experiment.candidate.variant} ${experiment.candidate.target.passed}/8, tube margin ${experiment.candidate.tubeMargin} m`);
}
