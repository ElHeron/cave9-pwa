// Deterministic, offline hero-camera/reference composition report.
// Uses existing PNGs only: no Vite server, browser, scene graph, or depth buffer.

import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { basename, join, resolve } from 'node:path';
import { composition, compositionDistance, loadFrame } from './lib/frame-metrics.mjs';

const ROOT = process.cwd();
const REF_DIR = resolve(ROOT, 'docs/reference');
const SHOT_DIR = resolve(ROOT, 'docs/screenshots/style');
const OUT_DIR = resolve(ROOT, 'docs/measure');
const manifest = JSON.parse(readFileSync(join(REF_DIR, 'manifest.json'), 'utf8'));
const style = JSON.parse(readFileSync(join(OUT_DIR, 'style-report.json'), 'utf8'));

function describeComposition(file) {
  const projected = composition(loadFrame(file));
  return {
    file,
    D7_centralOpening: projected.centralOpening,
    D8_angularSilhouette: projected.angularSilhouette,
    D9_quadrantMass: projected.quadrantMass,
    D10_dominantForms: projected.dominantForms,
    D11_tipDistance: projected.tipDistance,
    D12_projectedOcclusion: projected.projectedOcclusion,
  };
}

const refs = manifest.frames.map((entry) => {
  const file = join(REF_DIR, entry.file);
  if (!existsSync(file)) throw new Error(`missing reference frame: ${file}`);
  return { ...describeComposition(file), name: entry.file, families: entry.families || [], roles: entry.roles || [], metricEnvelope: entry.metricEnvelope !== false };
});

const captures = style.ladder.flatMap((entry) => {
  if (!entry.family) return [];
  const file = join(SHOT_DIR, `d${entry.depth}-s${entry.seed}.png`);
  if (!existsSync(file)) return [];
  return [{ ...describeComposition(file), name: basename(file), family: entry.family, depth: entry.depth, seed: entry.seed, judged: entry.judged }];
});

if (!captures.length) throw new Error('no existing hero captures found; run npm run style once');

function compact(d) {
  return {
    name: d.name,
    family: d.family,
    families: d.families,
    roles: d.roles,
    metricEnvelope: d.metricEnvelope,
    D7_centralOpening: d.D7_centralOpening,
    D8_angularSilhouette: d.D8_angularSilhouette,
    D9_quadrantMass: d.D9_quadrantMass,
    D10_dominantForms: d.D10_dominantForms,
    D11_tipDistance: d.D11_tipDistance,
    D12_projectedOcclusion: d.D12_projectedOcclusion,
  };
}

const families = [...new Set(refs.flatMap((d) => d.families))].sort();
const COMPOSITION_AXES = {
  D7_openingRatio: (d) => d.D7_centralOpening.areaRatio,
  D8_angularEntropy: (d) => d.D8_angularSilhouette.entropy,
  D9_quadrantImbalance: (d) => d.D9_quadrantMass.imbalance,
  D10_dominantTop3: (d) => d.D10_dominantForms.top3Share,
  D11_tipMedian: (d) => d.D11_tipDistance.median,
  D12_occlusionLayers: (d) => d.D12_projectedOcclusion.meanCrossings,
};
function compositionEnvelope(frames) {
  if (!frames.length) return null;
  return Object.fromEntries(Object.entries(COMPOSITION_AXES).map(([axis, get]) => {
    const values = frames.map(get);
    return [axis, { min: Math.min(...values), max: Math.max(...values), mean: values.reduce((s, v) => s + v, 0) / values.length }];
  }));
}
const familyTargets = {};
for (const family of families) {
  const familyRefs = refs.filter((d) => d.families.includes(family));
  const primary = familyRefs.filter((d) => d.metricEnvelope);
  familyTargets[family] = {
    primaryFrames: primary.map((d) => d.name),
    supplementalFrames: familyRefs.filter((d) => !d.metricEnvelope).map((d) => d.name),
    primaryEnvelope: compositionEnvelope(primary),
    supplementalEnvelope: familyRefs.some((d) => !d.metricEnvelope)
      ? compositionEnvelope(familyRefs.filter((d) => !d.metricEnvelope)) : null,
  };
}

const hero = captures.map((capture) => {
  const primary = refs.filter((ref) => ref.metricEnvelope && ref.families.includes(capture.family));
  const supplemental = refs.filter((ref) => !ref.metricEnvelope && ref.families.includes(capture.family));
  const comparisons = primary.map((ref) => ({ reference: ref.name, ...compositionDistance(capture, ref) }))
    .sort((a, b) => b.similarity - a.similarity);
  return {
    depth: capture.depth, seed: capture.seed, family: capture.family, judged: capture.judged,
    frame: capture.name,
    composition: compact(capture),
    primaryComparisons: comparisons,
    bestPrimaryMatch: comparisons[0] || null,
    supplementalComparisons: supplemental.map((ref) => ({ reference: ref.name, ...compositionDistance(capture, ref) })),
    envelopeAuthority: 'primary-only',
  };
});

const report = {
  schemaVersion: 1,
  generatedBy: 'scripts/composition-report.mjs',
  invariant: 'Every descriptor is computed from one PNG with the same canonical polar-image logic. Supplemental references are evidence-only and cannot widen primaryEnvelope.',
  axes: Object.keys(COMPOSITION_AXES),
  globalPrimaryEnvelope: compositionEnvelope(refs.filter((d) => d.metricEnvelope)),
  familyTargets,
  references: refs.map(compact),
  heroCaptures: hero,
};

function silhouettePoints(profile, cx, cy, radius) {
  return profile.map((r, i) => {
    const angle = (i + 0.5) * Math.PI * 2 / profile.length;
    return `${(cx + Math.cos(angle) * r * radius).toFixed(1)},${(cy + Math.sin(angle) * r * radius).toFixed(1)}`;
  }).join(' ');
}

function svgSheet() {
  const rows = [...refs.map((d) => ({ kind: d.metricEnvelope ? 'primary ref' : 'supplemental', d })),
    ...captures.map((d) => ({ kind: 'hero capture', d }))];
  const rowH = 116, width = 1040, height = 42 + rows.length * rowH;
  const body = rows.map(({ kind, d }, i) => {
    const y = 42 + i * rowH;
    const profile = d.D7_centralOpening.radialProfile;
    const match = hero.find((h) => h.frame === d.name)?.bestPrimaryMatch;
    return `<g data-kind="${kind}" data-frame="${d.name}" transform="translate(0 ${y})">
      <rect x="10" y="4" width="1020" height="106" rx="8" fill="${kind === 'hero capture' ? '#111d2c' : '#10151e'}" stroke="#2b3b50"/>
      <text x="26" y="30" class="name">${kind} · ${d.name}</text>
      <text x="26" y="54">${d.family || d.families.join(', ')}${match ? ` · best ${match.reference} · ${match.similarity}%` : ''}</text>
      <text x="26" y="79">opening ${d.D7_centralOpening.areaRatio.toFixed(3)} · tip ${d.D11_tipDistance.median.toFixed(3)} · layers ${d.D12_projectedOcclusion.meanCrossings.toFixed(2)}</text>
      <polygon points="${silhouettePoints(profile, 780, 57, 48)}" fill="#070a0e" stroke="#74b9ff" stroke-width="1.5"/>
      ${d.D9_quadrantMass.shares.map((v, q) => `<rect x="850" y="${18 + q * 20}" width="${Math.round(v * 580)}" height="12" fill="#7dd3fc"/><text x="992" y="${28 + q * 20}" text-anchor="end">Q${q + 1} ${v.toFixed(3)}</text>`).join('')}
    </g>`;
  }).join('');
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}" role="img" aria-labelledby="title desc">
  <title id="title">Cave9 projected composition evidence</title><desc id="desc">Primary and supplemental references plus deterministic hero captures, all measured with one single-frame polar silhouette model.</desc>
  <style>text{font:13px ui-monospace,monospace;fill:#aebdd0}.name{font-weight:700;fill:#f4f8ff}</style><rect width="100%" height="100%" fill="#070a0f"/><text x="18" y="27" class="name">Projected composition · D7–D12 · primary envelope only</text>${body}</svg>\n`;
}

mkdirSync(OUT_DIR, { recursive: true });
writeFileSync(join(OUT_DIR, 'composition-report.json'), `${JSON.stringify(report, null, 2)}\n`);
writeFileSync(join(OUT_DIR, 'composition-report.svg'), svgSheet());

console.log('\nProjected composition: hero camera → primary family references\n');
for (const row of hero) {
  const match = row.bestPrimaryMatch;
  console.log(`${row.frame.padEnd(20)} ${row.family.padEnd(10)} ${match ? `${String(match.similarity).padStart(6)}%  ${match.reference}` : 'no primary family reference'}`);
}
console.log(`\n› wrote ${join(OUT_DIR, 'composition-report.json')}`);
console.log(`› wrote ${join(OUT_DIR, 'composition-report.svg')}\n`);
