export const RELEASE_SCENARIOS = Object.freeze([
  Object.freeze({ name: 'corridor', seed: 4096, distance: 500 }),
  Object.freeze({ name: 'room', seed: 256, distance: 9010 }),
  Object.freeze({ name: 'deep-stair', seed: 2024, distance: 15600 }),
]);
export const RELEASE_FAMILIES = Object.freeze(['off', 'branching', 'crystal', 'coiling']);
export const RELEASE_MODES = Object.freeze(['static', 'flythrough']);
export const RELEASE_VIEWPORT = Object.freeze({ width: 1920, height: 1080, dpr: 1 });

function sameEntries(actual, expected) {
  return Array.isArray(actual) && actual.length === expected.length
    && actual.every((entry, index) => entry === expected[index]);
}

// Only the exact, unfiltered production matrix may be called release evidence.
// Diagnostic flags are still accepted by the runner but cannot produce a pass.
export function releaseEvidenceContractPass(options) {
  return options.releaseRequested === true
    && options.warmupSeconds === 30 && options.sampleSeconds === 90
    && options.repetitions === 3 && options.flySpanMeters === 1200
    && sameEntries(options.families, RELEASE_FAMILIES)
    && sameEntries(options.modes, RELEASE_MODES)
    && Array.isArray(options.scenarios) && options.scenarios.length === RELEASE_SCENARIOS.length
    && options.scenarios.every((scenario, index) =>
      scenario.name === RELEASE_SCENARIOS[index].name
      && scenario.seed === RELEASE_SCENARIOS[index].seed
      && scenario.distance === RELEASE_SCENARIOS[index].distance)
    && options.scenarioFilterRequested !== true
    && options.checkpointOverrideRequested !== true
    && options.pairSweep !== true
    && options.rockDetail === true && options.surfaceRelief === true
    && options.landmarks === true && options.cave === true
    && options.quality === 2
    && options.viewport?.width === RELEASE_VIEWPORT.width
    && options.viewport?.height === RELEASE_VIEWPORT.height
    && options.viewport?.dpr === RELEASE_VIEWPORT.dpr;
}

export function perfScenarioContractPass(scenario) {
  const loaded = scenario.loadedSnapshot;
  const active = Array.isArray(loaded?.family?.active) ? loaded.family.active : [];
  const familyPass = scenario.family === 'off'
    ? loaded?.scenario?.settings?.landmarks === false && active.length === 0
    : scenario.family === 'auto'
      ? loaded?.family?.requested === 'auto'
      : loaded?.family?.requested === scenario.family
        && active.length <= 1 && active.every((family) => family === scenario.family);
  const flythroughPass = scenario.mode !== 'flythrough'
    || (Number.isFinite(scenario.flyTo) && scenario.endDistance >= scenario.flyTo);
  return scenario.captureApi === 'window.__cave9.visual.loadScenario+step+inspect'
    && loaded?.version === 'VisualSnapshotV1' && familyPass && flythroughPass;
}

export function coilingRimPolicyPass(scenario, softwareRenderer) {
  const capabilities = scenario?.loadedSnapshot?.renderCapabilities;
  const activeFamilies = scenario?.loadedSnapshot?.family?.active;
  const coilingVisible = Array.isArray(activeFamilies) && activeFamilies.includes('coiling');
  // Hardware keeps the constant-cost crest branch compiled once so entering a
  // room cannot hitch. Software omits it until a live C3 ring exists. A forced
  // family request in an ordinary corridor is not itself a visible C3 shell.
  const expectedActive = softwareRenderer ? coilingVisible : true;
  return capabilities?.coilingRimActive === expectedActive
    && capabilities?.coilingRimSoftwareFallback === false;
}

export function textureBudgetMetrics(resourceSnapshots = []) {
  let maxTextureDimension = 0;
  let maxEstimatedTextureBytes = 0;
  for (const snapshot of resourceSnapshots) {
    maxEstimatedTextureBytes = Math.max(
      maxEstimatedTextureBytes,
      Number(snapshot?.estimatedTextureBytes) || 0,
    );
    for (const texture of snapshot?.textures || []) {
      maxTextureDimension = Math.max(
        maxTextureDimension,
        Number(texture?.width) || 0,
        Number(texture?.height) || 0,
      );
    }
  }
  return { maxTextureDimension, maxEstimatedTextureBytes };
}

// WebGL2 array textures have a fixed layer count at every mip level. The
// report records format/type so a one-channel height map is not charged as RGBA.
export function textureStorageBytes(texture) {
  const width = Math.max(0, Math.trunc(Number(texture?.width) || 0));
  const height = Math.max(0, Math.trunc(Number(texture?.height) || 0));
  const layers = Math.max(1, Math.trunc(Number(texture?.layers) || 1));
  if (!width || !height) return 0;
  const channels = ({ 1023: 4, 1028: 1, 1030: 2 })[texture.format] ?? 4;
  const bytesPerChannel = texture.type === 1009 ? 1 : 4;
  let mipWidth = width, mipHeight = height, pixels = 0;
  while (true) {
    pixels += mipWidth * mipHeight * layers;
    if (!texture.generateMipmaps || (mipWidth === 1 && mipHeight === 1)) break;
    mipWidth = Math.max(1, Math.floor(mipWidth / 2));
    mipHeight = Math.max(1, Math.floor(mipHeight / 2));
  }
  return pixels * channels * bytesPerChannel;
}

export function withTextureStorageEstimate(snapshot) {
  const textures = (snapshot?.textures || []).map((texture) => ({
    ...texture, estimatedStorageBytes: textureStorageBytes(texture),
  }));
  return { ...snapshot, textures,
    estimatedTextureBytes: textures.reduce((sum, texture) => sum + texture.estimatedStorageBytes, 0) };
}
