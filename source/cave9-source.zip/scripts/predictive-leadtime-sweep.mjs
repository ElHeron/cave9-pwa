// Reproducible operating-point selection for predictive warning. Thresholds
// are declared before results are read: retain useful event coverage, cap false
// alarms, then choose the longest mean lead in that admissible band.
import { readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { spawnSync } from 'node:child_process';
import { T_LEAD } from '../src/core/Predictive.js';

const maxSteps = Number(process.argv[2]) || 4000;
const candidates = [0.20, 0.30, 0.40, 0.50];
const policy = {
  eventsLedPctMin: 30,
  falseAlarmRateMax: 0.12,
  objective: 'maximum mean lead seconds among admissible candidates',
};
const reportFile = resolve('docs/measure/predictive-leadtime.json');

function measure(tLead) {
  const run = spawnSync(process.execPath,
    ['scripts/predictive-leadtime.mjs', String(maxSteps), String(tLead)], {
      cwd: process.cwd(), encoding: 'utf8', windowsHide: true, timeout: 180_000,
    });
  if (run.status !== 0) throw new Error(run.stderr || run.stdout || `lead-time run failed for ${tLead}`);
  const { summary } = JSON.parse(readFileSync(reportFile, 'utf8'));
  return {
    tLead,
    events: summary.reactiveHighEvents,
    eventsLedPct: summary.eventsLedPct,
    meanLeadSeconds: summary.leadSeconds.mean,
    medianLeadSeconds: summary.leadSeconds.median,
    p90LeadSeconds: summary.leadSeconds.p90,
    falseAlarmRate: summary.falseAlarmRate,
  };
}

const results = candidates.map(measure);
const admissible = results.filter((result) =>
  result.eventsLedPct >= policy.eventsLedPctMin
  && result.falseAlarmRate <= policy.falseAlarmRateMax);
const selected = [...admissible].sort((a, b) =>
  b.meanLeadSeconds - a.meanLeadSeconds || a.falseAlarmRate - b.falseAlarmRate)[0] || null;
const pass = selected?.tLead === T_LEAD;

// Leave the detailed single-point report at the shipped operating point.
measure(T_LEAD);

const report = {
  capturedAt: new Date().toISOString(),
  panel: { seeds: 50, controllers: 3, maxSteps },
  policy,
  candidates: results,
  selected,
  shippedTLead: T_LEAD,
  pass,
};
writeFileSync(resolve('docs/measure/predictive-leadtime-sweep.json'),
  JSON.stringify(report, null, 2) + '\n');
for (const row of results) {
  console.log(`${row.tLead.toFixed(2)}s  led ${row.eventsLedPct.toFixed(1)}%  `
    + `mean ${row.meanLeadSeconds.toFixed(3)}s  false ${(row.falseAlarmRate * 100).toFixed(1)}%`);
}
console.log(`${pass ? 'PASS' : 'FAIL'} — selected ${selected?.tLead ?? 'none'}s, shipped ${T_LEAD}s`);
if (!pass) process.exitCode = 1;
