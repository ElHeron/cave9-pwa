// Small, deterministic mutation gate for the load-bearing core contracts.
// This is intentionally narrower than a coverage report: each mutant changes a
// real decision, then the relevant tests must reject the resulting program.

import { cpSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import { spawnSync } from 'node:child_process';

const mutants = [
  {
    id: 'tube-loses-one-hull-radius', file: 'src/core/FlightPath.js',
    from: 'export const TUBE_MIN_RADIUS = 2 * SHIP_RADIUS;',
    to: 'export const TUBE_MIN_RADIUS = 1 * SHIP_RADIUS;',
    tests: ['test/flightpath.test.js'],
  },
  {
    id: 'sight-no-longer-follows-speed', file: 'src/core/Difficulty.js',
    from: 'export const SIGHT_FLOOR_MUL = 1.30;',
    to: 'export const SIGHT_FLOOR_MUL = 1.00;',
    tests: ['test/difficulty.test.js'],
  },
  {
    id: 'outside-ring-probes-are-ignored', file: 'src/core/CollisionSystem.js',
    from: 'probeInside.some((inside) => !inside) || clearance <= 0',
    to: 'false || clearance <= 0',
    tests: ['test/collision.test.js'],
  },
  {
    id: 'wall-rng-skips-a-state', file: 'src/core/RNG.js',
    from: 'let v = (this.randval + 1) | 0;',
    to: 'let v = (this.randval + 2) | 0;',
    tests: ['test/generator-stream.test.js'],
  },
  {
    id: 'ring-midpoint-tie-break-drifts', file: 'src/core/SurfaceQuery.js',
    from: 'if (lowerGap < upperGap) return lower;',
    to: 'if (lowerGap <= upperGap) return lower;',
    tests: ['test/generator-stream.test.js'],
  },
];

function runTests(cwd, tests) {
  return spawnSync(process.execPath, ['--test', ...tests], {
    cwd, encoding: 'utf8', windowsHide: true, timeout: 120_000,
  });
}

const root = process.cwd();
const allTests = [...new Set(mutants.flatMap((mutant) => mutant.tests))];
const baseline = runTests(root, allTests);
if (baseline.status !== 0) {
  process.stderr.write(baseline.stdout || '');
  process.stderr.write(baseline.stderr || '');
  throw new Error('Mutation baseline is not green; refusing to score mutants.');
}

const workspace = mkdtempSync(join(tmpdir(), 'cave9-mutation-'));
const results = [];
try {
  cpSync(resolve('src'), join(workspace, 'src'), { recursive: true });
  cpSync(resolve('test'), join(workspace, 'test'), { recursive: true });
  cpSync(resolve('scripts'), join(workspace, 'scripts'), { recursive: true });
  cpSync(resolve('docs'), join(workspace, 'docs'), { recursive: true });
  cpSync(resolve('package.json'), join(workspace, 'package.json'));

  for (const mutant of mutants) {
    const file = join(workspace, mutant.file);
    const original = readFileSync(file, 'utf8');
    const occurrences = original.split(mutant.from).length - 1;
    if (occurrences !== 1) throw new Error(`${mutant.id}: expected one mutation target, found ${occurrences}`);
    writeFileSync(file, original.replace(mutant.from, mutant.to));
    const run = runTests(workspace, mutant.tests);
    const killed = run.status !== 0;
    results.push({ id: mutant.id, killed, tests: mutant.tests });
    writeFileSync(file, original);
    console.log(`${killed ? 'KILLED' : 'SURVIVED'}  ${mutant.id}`);
  }
} finally {
  rmSync(workspace, { recursive: true, force: true });
}

const killed = results.filter((result) => result.killed).length;
const score = killed / results.length;
console.log(`Mutation score: ${(score * 100).toFixed(1)}% (${killed}/${results.length})`);
if (score < 1) process.exitCode = 1;
