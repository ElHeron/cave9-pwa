// Edge-energy / local-contrast metrics (Phase 4B, gate P2).
//
// luminance.mjs answers "how bright / how dark is the centre hole?". This module
// answers the complementary question the fidelity roadmap needs: "how much
// visible SURFACE DETAIL is on the near/mid walls?" — the objective signal a
// future bump/normal-map or SSAO change must move (up for detail) WITHOUT
// brightening the centre (readability, guarded by luminance.mjs).
//
// Two metrics, both over luminance Y (Rec.709, reused from luminance.mjs):
//   * edge energy  = mean Sobel gradient magnitude. More high-frequency surface
//                    relief → higher edge energy.
//   * local contrast = mean per-window standard deviation (windowed RMS contrast).
//
// Regions (a first-person tube: the dark hole is central, walls are peripheral):
//   * full   — whole frame.
//   * wall   — the OUTER frame (everything outside the central third) ≈ near walls.
//   * mid    — the ring between the central third and the central two-thirds
//              ≈ mid-distance walls.
// Region geometry is fixed and documented so the numbers are comparable across
// images and across runs. This is a pure analysis helper — it changes nothing
// the game renders.
//
// Usage:  node scripts/edge.mjs <image> [<image> ...]
// Library: import { edgeMetrics } from './edge.mjs'

import { extname } from 'node:path';
import { pathToFileURL } from 'node:url';
import { decodeImage, pixelLuminance } from './luminance.mjs';

// Build a Float64 luminance plane (0..1) from a decoded RGBA image.
function lumaPlane(img) {
  const { width, height, data } = img;
  const Y = new Float64Array(width * height);
  for (let i = 0, p = 0; i < Y.length; i++, p += 4) {
    Y[i] = pixelLuminance(data[p], data[p + 1], data[p + 2]);
  }
  return Y;
}

// Region predicate: which band a pixel (x,y) belongs to. Central third on each
// axis = "hole"; the inner-third box is excluded from wall/mid.
function regionMask(width, height) {
  const x0 = width / 3, x1 = width * 2 / 3;
  const y0 = height / 3, y1 = height * 2 / 3;
  const x0b = width / 6, x1b = width * 5 / 6;
  const y0b = height / 6, y1b = height * 5 / 6;
  return {
    inHole: (x, y) => x >= x0 && x < x1 && y >= y0 && y < y1,
    // wall = outside the central third (periphery)
    inWall: (x, y) => !(x >= x0 && x < x1 && y >= y0 && y < y1),
    // mid = between the central third and the central two-thirds (a ring)
    inMid: (x, y) => (x >= x0b && x < x1b && y >= y0b && y < y1b) &&
                     !(x >= x0 && x < x1 && y >= y0 && y < y1),
  };
}

// Sobel gradient magnitude at interior pixel (x,y) on the luminance plane.
function sobelMag(Y, width, height, x, y) {
  const at = (xx, yy) => Y[yy * width + xx];
  const gx =
    -at(x - 1, y - 1) - 2 * at(x - 1, y) - at(x - 1, y + 1) +
     at(x + 1, y - 1) + 2 * at(x + 1, y) + at(x + 1, y + 1);
  const gy =
    -at(x - 1, y - 1) - 2 * at(x, y - 1) - at(x + 1, y - 1) +
     at(x - 1, y + 1) + 2 * at(x, y + 1) + at(x + 1, y + 1);
  return Math.hypot(gx, gy);
}

// Mean over a region with a per-pixel value function; returns {mean, count}.
function regionMean(width, height, pred, valueAt) {
  let sum = 0, n = 0;
  for (let y = 1; y < height - 1; y++) {
    for (let x = 1; x < width - 1; x++) {
      if (!pred(x, y)) continue;
      sum += valueAt(x, y);
      n++;
    }
  }
  return { mean: n ? sum / n : 0, count: n };
}

// Windowed local-contrast (std of luminance in a w×w window) averaged over a
// region. Sampled on a stride so it stays fast on 1280×720 frames.
function localContrast(Y, width, height, pred, win = 7, stride = 4) {
  const half = win >> 1;
  let sum = 0, n = 0;
  for (let y = half; y < height - half; y += stride) {
    for (let x = half; x < width - half; x += stride) {
      if (!pred(x, y)) continue;
      let s = 0, s2 = 0, c = 0;
      for (let dy = -half; dy <= half; dy++) {
        for (let dx = -half; dx <= half; dx++) {
          const v = Y[(y + dy) * width + (x + dx)];
          s += v; s2 += v * v; c++;
        }
      }
      const mean = s / c;
      const varr = Math.max(0, s2 / c - mean * mean);
      sum += Math.sqrt(varr);
      n++;
    }
  }
  return { mean: n ? sum / n : 0, count: n };
}

export function edgeMetrics(file) {
  const img = decodeImage(file);
  const { width, height } = img;
  const Y = lumaPlane(img);
  const R = regionMask(width, height);

  const edge = (pred) => regionMean(width, height, pred, (x, y) => sobelMag(Y, width, height, x, y)).mean;
  const contrast = (pred) => localContrast(Y, width, height, pred).mean;

  const round = (x) => +x.toFixed(5);
  return {
    file, width, height,
    edgeEnergy: {
      full: round(edge(() => true)),
      wall: round(edge(R.inWall)),
      mid: round(edge(R.inMid)),
    },
    localContrast: {
      full: round(contrast(() => true)),
      wall: round(contrast(R.inWall)),
      mid: round(contrast(R.inMid)),
    },
  };
}

function fmt(n) { return n.toFixed(5); }
export function printEdge(m) {
  console.log(`\n${m.file}  (${m.width}x${m.height})`);
  console.log(`  edge   full=${fmt(m.edgeEnergy.full)} wall=${fmt(m.edgeEnergy.wall)} mid=${fmt(m.edgeEnergy.mid)}`);
  console.log(`  contr  full=${fmt(m.localContrast.full)} wall=${fmt(m.localContrast.wall)} mid=${fmt(m.localContrast.mid)}`);
}

// CLI entry
if (import.meta.url === pathToFileURL(process.argv[1]).href) {
  const files = process.argv.slice(2).filter((f) => ['.png', '.jpg', '.jpeg'].includes(extname(f).toLowerCase()));
  if (files.length === 0) {
    console.error('usage: node scripts/edge.mjs <image> [<image> ...]');
    process.exit(1);
  }
  const out = [];
  for (const f of files) { const m = edgeMetrics(f); printEdge(m); out.push(m); }
  console.log('\nJSON ' + JSON.stringify(out));
}
