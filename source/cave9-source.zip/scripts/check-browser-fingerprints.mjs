import { deepStrictEqual } from 'node:assert';
import { chromium, firefox, webkit } from '@playwright/test';
import { expectedGeneratorFingerprintReport } from '../src/core/GeneratorFingerprint.js';
import { withViteServer } from './visual/vite-server.mjs';

const requested = process.argv.slice(2).filter((value) => !value.startsWith('--'));
const names = requested.length ? requested : ['chromium', 'firefox', 'webkit'];
const engines = { chromium, firefox, webkit };

for (const name of names) {
  if (!engines[name]) throw new Error(`Unknown browser engine: ${name}`);
}

await withViteServer(async ({ url }) => {
  for (const name of names) {
    const browser = await engines[name].launch({ headless: true });
    try {
      const page = await browser.newPage();
      await page.goto(url, { waitUntil: 'domcontentloaded' });
      const actual = await page.evaluate(async () => {
        const module = await import('/src/core/GeneratorFingerprint.js');
        return module.generatorFingerprintReport();
      });
      deepStrictEqual(actual, expectedGeneratorFingerprintReport());
      console.log(`PASS — ${name} matches the canonical generator fingerprints.`);
    } finally {
      await browser.close();
    }
  }
});
