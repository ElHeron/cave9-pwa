import { deepStrictEqual } from 'node:assert';
import {
  expectedGeneratorFingerprintReport,
  generatorFingerprintReport,
} from '../src/core/GeneratorFingerprint.js';

const actual = generatorFingerprintReport();
deepStrictEqual(actual, expectedGeneratorFingerprintReport());
console.log(JSON.stringify({ runtime: `node ${process.version}`, platform: process.platform, actual }, null, 2));
console.log('PASS — canonical generator fingerprints match.');
