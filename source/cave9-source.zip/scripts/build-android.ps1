param(
    [string]$SdkPath = $env:ANDROID_HOME,
    [string]$JavaPath = $env:JAVA_HOME,
    [switch]$IncludeDebug,
    [switch]$IncludeBundle
)
$ErrorActionPreference = 'Stop'
$projectRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
Set-Location -LiteralPath $projectRoot
if (-not $SdkPath) {
    foreach ($candidate in @($env:ANDROID_SDK_ROOT, (Join-Path $env:LOCALAPPDATA 'Android\Sdk'), 'D:\Android\UE58Sdk')) {
        if ($candidate -and (Test-Path (Join-Path $candidate 'platforms\android-36'))) { $SdkPath = $candidate; break }
    }
}
if (-not $JavaPath -or -not (Test-Path (Join-Path $JavaPath 'bin\javac.exe'))) {
    $JavaPath = 'C:\Program Files\Android\Android Studio\jbr'
}
if (-not $SdkPath -or -not (Test-Path (Join-Path $SdkPath 'platforms\android-36'))) { throw 'Android SDK 36 is required. Pass -SdkPath.' }
if (-not (Test-Path (Join-Path $JavaPath 'bin\javac.exe'))) { throw 'JDK 21 is required. Pass -JavaPath.' }
$env:JAVA_HOME = [IO.Path]::GetFullPath($JavaPath)
$env:ANDROID_HOME = [IO.Path]::GetFullPath($SdkPath)
$env:PATH = "$env:JAVA_HOME\bin;$env:PATH"
$outputDir = Join-Path $projectRoot 'artifacts\android'
$signingDir = Join-Path $outputDir 'signing'
New-Item -ItemType Directory -Path $signingDir -Force | Out-Null
$credentialsFile = Join-Path $signingDir 'release-key.json'
$keyFile = Join-Path $signingDir 'cave9-release.p12'
if (-not (Test-Path $credentialsFile)) {
    if (Test-Path $keyFile) { throw 'Existing signing key has no credentials file. Restore its credentials before building.' }
    $randomBytes = New-Object byte[] 32
    $rng = [Security.Cryptography.RandomNumberGenerator]::Create()
    try { $rng.GetBytes($randomBytes) } finally { $rng.Dispose() }
    $password = [Convert]::ToBase64String($randomBytes)
    @{ alias = 'cave9'; password = $password } | ConvertTo-Json | Set-Content -LiteralPath $credentialsFile -Encoding UTF8
}
$credentials = Get-Content -LiteralPath $credentialsFile -Raw | ConvertFrom-Json
$env:CAVE9_KEYSTORE_PATH = $keyFile
$env:CAVE9_KEYSTORE_PASSWORD = $credentials.password
$env:CAVE9_KEY_ALIAS = $credentials.alias
$env:CAVE9_KEY_PASSWORD = $credentials.password
try {
    if (-not (Test-Path $keyFile)) {
        & (Join-Path $env:JAVA_HOME 'bin\keytool.exe') -genkeypair -keystore $keyFile -storetype PKCS12 -alias $env:CAVE9_KEY_ALIAS -keyalg RSA -keysize 3072 -validity 10000 -dname 'CN=Cave9, OU=Games, O=ElHeron' -storepass:env CAVE9_KEYSTORE_PASSWORD -keypass:env CAVE9_KEY_PASSWORD
        if ($LASTEXITCODE -ne 0) { throw 'Signing key generation failed.' }
    }
    $sdkProperty = $env:ANDROID_HOME.Replace('\', '/').Replace(':', '\:')
    "sdk.dir=$sdkProperty" | Set-Content android\local.properties -Encoding ASCII
    & npm.cmd run android:prepare
    if ($LASTEXITCODE -ne 0) { throw 'Android asset preparation failed.' }
    $gradleTasks = @('assembleRelease', 'lintRelease')
    if ($IncludeDebug) { $gradleTasks += 'assembleDebug' }
    if ($IncludeBundle) { $gradleTasks += 'bundleRelease' }
    Push-Location android
    try {
        & .\gradlew.bat --no-daemon @gradleTasks
        if ($LASTEXITCODE -ne 0) { throw 'Android build or lint failed.' }
    } finally { Pop-Location }
    $version = (Get-Content package.json -Raw | ConvertFrom-Json).version
    $apkFile = Join-Path $outputDir "cave9-$version.apk"
    Copy-Item android\app\build\outputs\apk\release\app-release.apk $apkFile -Force
    & (Join-Path $env:ANDROID_HOME 'build-tools\36.0.0\apksigner.bat') verify --verbose --print-certs $apkFile
    if ($LASTEXITCODE -ne 0) { throw 'APK signature verification failed.' }
    if ($IncludeDebug) { Copy-Item android\app\build\outputs\apk\debug\app-debug.apk (Join-Path $outputDir "cave9-$version-debug.apk") -Force }
    if ($IncludeBundle) { Copy-Item android\app\build\outputs\bundle\release\app-release.aab (Join-Path $outputDir "cave9-$version.aab") -Force }
    & node scripts/package-android-source.mjs
    if ($LASTEXITCODE -ne 0) { throw 'Android source packaging failed.' }
    Write-Host "Signed Android APK: $apkFile"
    $apkHasher = [Security.Cryptography.SHA256]::Create()
    $apkStream = [IO.File]::OpenRead($apkFile)
    try {
        $apkHash = [BitConverter]::ToString($apkHasher.ComputeHash($apkStream)).Replace('-', '').ToLowerInvariant()
        Write-Host "SHA-256: $apkHash"
    } finally {
        $apkStream.Dispose()
        $apkHasher.Dispose()
    }
} finally {
    Remove-Item Env:\CAVE9_KEYSTORE_PASSWORD, Env:\CAVE9_KEY_PASSWORD -ErrorAction SilentlyContinue
    $password = $null
    $credentials = $null
}
