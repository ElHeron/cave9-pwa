"""Package the selected T4 artwork without regenerating or retouching the design.
Requires Pillow. Run: python scripts/build-app-icons.py
"""
import base64
import json
from pathlib import Path
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parent.parent
SOURCE = ROOT / "assets/branding/cave9-tusche-pur.png"
WEB = ROOT / "public/assets"
ANDROID = ROOT / "android/app/src/main/res"
IVORY = "#faf4e3"
with Image.open(SOURCE) as source:
    source.load()
    assert source.width == source.height
    original = source.convert("RGB")

def sized(pixels, inset=1):
    canvas = Image.new("RGB", (pixels, pixels), IVORY)
    art_size = round(pixels * inset)
    artwork = original.resize((art_size, art_size), Image.Resampling.LANCZOS)
    canvas.paste(artwork, ((pixels-art_size)//2, (pixels-art_size)//2))
    return canvas

for filename, pixels in [("icon.png",64), ("icon-192.png",192), ("icon-512.png",512), ("apple-touch-icon.png",180)]:
    sized(pixels).save(WEB / filename, optimize=True)
# Keep the entire rough circular silhouette inside the 80% maskable safe diameter.
sized(512, .8).save(WEB / "icon-maskable-512.png", optimize=True)
# Preserve the existing SVG URL with a self-contained raster-backed SVG.
embedded = base64.b64encode((WEB / "icon-512.png").read_bytes()).decode("ascii")
(WEB / "icon.svg").write_text(
    '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" role="img" aria-labelledby="title">\n'
    '  <title id="title">Cave9 — Tusche Pur</title>\n'
    f'  <image width="512" height="512" href="data:image/png;base64,{embedded}"/>\n'
    '</svg>\n', encoding="utf-8")
# 108dp adaptive canvas: artwork spans 64.8dp, safely within the central 66dp.
for density, scale in [("mdpi",1), ("hdpi",1.5), ("xhdpi",2), ("xxhdpi",3), ("xxxhdpi",4)]:
    folder = ANDROID / f"mipmap-{density}"
    folder.mkdir(parents=True, exist_ok=True)
    legacy_size = round(48*scale)
    icon = sized(legacy_size)
    icon.save(folder / "ic_launcher.png", optimize=True)
    round_icon = icon.convert("RGBA")
    mask = Image.new("L", (legacy_size, legacy_size), 0)
    ImageDraw.Draw(mask).ellipse((0,0,legacy_size-1,legacy_size-1), fill=255)
    round_icon.putalpha(mask)
    round_icon.save(folder / "ic_launcher_round.png", optimize=True)
    sized(round(108*scale), .6).save(folder / "ic_launcher_foreground.png", optimize=True)
print(json.dumps({"selected":"T4 · Tusche Pur","source":str(SOURCE),"web":5,"svg":"embedded PNG","android_density_sets":5}, ensure_ascii=False))
