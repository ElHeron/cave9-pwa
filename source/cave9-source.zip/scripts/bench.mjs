// Frame-time bench (Phase 4B, gate P2).
//
// Headless, deterministic timing for regression DETECTION — not absolute
// hardware truth. Headless timing is noisy, so thresholds (if used) are wide and
// advisory; the value is comparing the same machine before/after a change.
//
// Two benches:
//   A) sim      — N fixed steps of the real core loop (carve + move + collision +
//                 score) across a few seeds. The CPU cost of a simulated frame.
//   B) geometry — the renderer's per-frame CPU geometry work, isolated: rewrite a
//                 THREE BufferGeometry's positions from a real cave then
//                 computeVertexNormals — measured WITH and WITHOUT the extra
//                 computeBoundingSphere() the current renderer also calls every
//                 frame (the FIDELITY_ROADMAP L1 "dead cost" target). No WebGL
//                 context is created; this is pure CPU geometry math.
//
// Writes docs/measure/bench-metrics.json. Run: node scripts/bench.mjs [--steps N]

import { mkdirSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { BufferGeometry, BufferAttribute } from 'three';
import { Game } from '../src/core/Game.js';
import { caveGeomChanged, caveGeomKey } from '../src/render/Renderer.js';
import { landmarksInView } from '../src/core/Landmarks.js';
import { SECTOR_COUNT, SEGMENT_COUNT, FOG_END, TWO_BUTTONS } from '../src/core/constants.js';

const args = process.argv.slice(2);
const argN = (flag, def) => {
  const i = args.indexOf(flag);
  return i >= 0 && args[i + 1] ? Number(args[i + 1]) : def;
};
const STEPS = argN('--steps', 20000);
const SEEDS = [1, 424242, 4096];
const GEO_ITERS = argN('--geo-iters', 4000);
const VERTS = SEGMENT_COUNT * SECTOR_COUNT;

const now = () => Number(process.hrtime.bigint()) / 1e6; // ms

function median(xs) {
  const s = [...xs].sort((a, b) => a - b);
  const m = s.length >> 1;
  return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2;
}

// ---- Bench A: core simulation ---------------------------------------------
function benchSim() {
  const per = [];
  let totalSteps = 0;
  for (const seed of SEEDS) {
    const g = new Game();
    g.start({ seed, mode: TWO_BUTTONS });
    // warm up a little so JIT settles, then time the run (autopilot so it flies
    // a realistic path; restart on crash to keep stepping)
    for (let i = 0; i < 200; i++) { g.autopilot(); if (g.step()) g.start({ seed, mode: TWO_BUTTONS }); }

    const t0 = now();
    let steps = 0;
    for (let i = 0; i < STEPS; i++) {
      g.autopilot();
      if (g.step()) g.start({ seed, mode: TWO_BUTTONS });
      steps++;
    }
    const ms = now() - t0;
    per.push({ seed, steps, ms: +ms.toFixed(2), msPer1k: +(ms / steps * 1000).toFixed(4), stepsPerSec: Math.round(steps / (ms / 1000)) });
    totalSteps += steps;
  }
  const msPer1k = median(per.map((p) => p.msPer1k));
  return { steps: STEPS, seeds: SEEDS, perSeed: per, medianMsPer1k: +msPer1k.toFixed(4), medianStepsPerSec: Math.round(1e6 / msPer1k) };
}

// ---- Bench B: renderer per-frame geometry cost -----------------------------
function benchGeometry() {
  // Build a representative cave to source real vertex positions.
  const g = new Game();
  g.start({ seed: 424242, mode: TWO_BUTTONS });
  for (let i = 0; i < 1200; i++) { g.autopilot(); if (g.step()) break; }

  const geo = new BufferGeometry();
  const positions = new Float32Array(VERTS * 3);
  geo.setAttribute('position', new BufferAttribute(positions, 3));
  const idx = [];
  const at = (s, j) => s * SECTOR_COUNT + j;
  for (let s = 0; s < SEGMENT_COUNT - 1; s++) {
    for (let j = 0; j < SECTOR_COUNT; j++) {
      const j1 = (j + 1) % SECTOR_COUNT;
      idx.push(at(s, j), at(s + 1, j), at(s, j1), at(s, j1), at(s + 1, j), at(s + 1, j1));
    }
  }
  geo.setIndex(idx);

  const fill = () => {
    let p = 0;
    for (let s = 0; s < SEGMENT_COUNT; s++) {
      const buf = (g.cave.i + s) % SEGMENT_COUNT;
      const ring = g.cave.segs[buf];
      for (let j = 0; j < SECTOR_COUNT; j++) {
        positions[p++] = ring[j][0]; positions[p++] = ring[j][1]; positions[p++] = ring[j][2];
      }
    }
    geo.attributes.position.needsUpdate = true;
  };

  const time = (withBounding) => {
    // warm up
    for (let i = 0; i < 200; i++) { fill(); geo.computeVertexNormals(); if (withBounding) geo.computeBoundingSphere(); }
    const t0 = now();
    for (let i = 0; i < GEO_ITERS; i++) {
      fill();
      geo.computeVertexNormals();
      if (withBounding) geo.computeBoundingSphere();
    }
    return (now() - t0) / GEO_ITERS;
  };

  const normalsOnly = time(false);
  const normalsPlusBounding = time(true);
  return {
    verts: VERTS, iters: GEO_ITERS,
    msPerFrame_normalsOnly: +normalsOnly.toFixed(5),
    msPerFrame_normalsPlusBounding: +normalsPlusBounding.toFixed(5),
    boundingSphereOverheadMs: +(normalsPlusBounding - normalsOnly).toFixed(5),
  };
}

// ---- Bench C: render-cadence (how often the cave geometry actually changes) -
// At the live ~60 fps cadence (≈1 sim step per render frame) the cave only
// carves a new ring every few frames, so the Phase-4C skip avoids the
// position-rewrite + computeVertexNormals on the rest. This measures that ratio
// using the SAME pure predicate the renderer uses (caveGeomChanged), so the
// "effective per-frame geometry cost" before/after is grounded in a real flight.
function benchCadence() {
  const seeds = [1, 424242, 4096];
  const framesPerSeed = 6000;
  let frames = 0, rebuilds = 0;
  for (const seed of seeds) {
    const g = new Game();
    g.start({ seed, mode: TWO_BUTTONS });
    let key = null;
    for (let f = 0; f < framesPerSeed; f++) {
      g.autopilot();
      if (g.step()) { g.start({ seed, mode: TWO_BUTTONS }); key = null; } // restart → forces a rebuild
      frames++;
      if (caveGeomChanged(key, g.cave)) { rebuilds++; key = caveGeomKey(g.cave); }
    }
  }
  return {
    frames, rebuilds,
    rebuildFraction: +(rebuilds / frames).toFixed(4),
    skipFraction: +(1 - rebuilds / frames).toFixed(4),
  };
}

// ---- Bench D: landmark query cost (Phase 4G / M2) --------------------------
// The per-frame CPU cost of the visible-landmarks feature is one pure
// landmarksInView() scan (Landmarks.js) + repositioning ≤4 pooled meshes. This
// times the scan at a room depth (worst case: a landmark actually in view), so
// the M2 frame-time impact is documented, not asserted by hand.
function benchLandmarks() {
  const g = new Game();
  g.start({ seed: 256, mode: TWO_BUTTONS }); // survives past the first room
  while (g.player.pos[2] - g.player.start < 1975) { g.autopilot(); if (g.step()) break; }
  const range = FOG_END * 1.3;
  const iters = 200000;
  // warm up
  for (let i = 0; i < 2000; i++) landmarksInView(g.cave, g.player.pos[2], range, g.seed);
  const t0 = now();
  let count = 0, pieces = 0;
  for (let i = 0; i < iters; i++) {
    const cs = landmarksInView(g.cave, g.player.pos[2], range, g.seed);
    count = cs.length;
    pieces = cs.reduce((a, c) => a + c.pieces.length, 0);
  }
  const msPerCall = (now() - t0) / iters;
  return { iters, inViewCount: count, pieceCount: pieces, msPerCall: +msPerCall.toFixed(6) };
}

const sim = benchSim();
const geometry = benchGeometry();
const cadence = benchCadence();
const landmarks = benchLandmarks();

// Effective per-frame geometry cost (ms): before this phase every frame did
// normals + boundingSphere; after, only rebuild frames do normals (no bounding).
const effBefore = +(geometry.msPerFrame_normalsPlusBounding).toFixed(5);
const effAfter = +(geometry.msPerFrame_normalsOnly * cadence.rebuildFraction).toFixed(5);
geometry.effectivePerFrameMs = { before: effBefore, after: effAfter, rebuildFraction: cadence.rebuildFraction };

console.log('Cave9 — frame-time bench (gate P2)  [regression detection, not absolute hardware truth]\n');
console.log('Sim:');
for (const p of sim.perSeed) console.log(`  seed ${String(p.seed).padStart(7)}: ${p.msPer1k} ms/1k steps  (${p.stepsPerSec.toLocaleString()} steps/s)`);
console.log(`  median: ${sim.medianMsPer1k} ms/1k steps  (~${sim.medianStepsPerSec.toLocaleString()} steps/s)\n`);
console.log('Geometry (per simulated frame, no WebGL context):');
console.log(`  computeVertexNormals only:          ${geometry.msPerFrame_normalsOnly} ms`);
console.log(`  + computeBoundingSphere:            ${geometry.msPerFrame_normalsPlusBounding} ms`);
console.log(`  boundingSphere overhead (L1 target): ${geometry.boundingSphereOverheadMs} ms/frame\n`);
console.log('Render cadence (live ~60 fps, 1 step/frame):');
console.log(`  geometry rebuilds: ${cadence.rebuilds}/${cadence.frames} frames  ` +
  `(${(cadence.rebuildFraction * 100).toFixed(1)}% rebuild, ${(cadence.skipFraction * 100).toFixed(1)}% skipped)`);
console.log(`  effective geometry cost/frame: before ${effBefore} ms  →  after ${effAfter} ms`);
console.log('\nLandmarks (Phase 4G / M2) — per-frame query at a room depth:');
console.log(`  landmarksInView: ${landmarks.msPerCall} ms/call  (${landmarks.inViewCount} comp, ${landmarks.pieceCount} pieces)`);

const OUT = resolve(process.cwd(), 'docs/measure');
mkdirSync(OUT, { recursive: true });
const report = { gate: 'P2-bench', capturedAt: new Date().toISOString(), node: process.version, sim, geometry, cadence, landmarks };
writeFileSync(resolve(OUT, 'bench-metrics.json'), JSON.stringify(report, null, 2) + '\n');
console.log('\nReport: docs/measure/bench-metrics.json');

// Record-only by default: headless timing is machine-dependent, so an absolute
// pass/fail ceiling would be fragile. Regression detection comes from comparing
// the committed bench-metrics.json on the SAME machine before/after a change.
// A ceiling is enforced ONLY when --max-ms-per-1k is explicitly passed (CI on a
// known runner can opt in). Keep any such ceiling generous (3–5× the recorded
// median) so it trips only on a gross regression, never on normal variance.
const ceilIdx = args.indexOf('--max-ms-per-1k');
if (ceilIdx >= 0 && args[ceilIdx + 1]) {
  const ceiling = Number(args[ceilIdx + 1]);
  if (sim.medianMsPer1k > ceiling) {
    console.error(`\nFAIL — sim ${sim.medianMsPer1k} ms/1k exceeds ceiling ${ceiling} ms/1k`);
    process.exit(1);
  }
  console.log(`\nPASS — sim ${sim.medianMsPer1k} ms/1k within ceiling ${ceiling} ms/1k`);
} else {
  console.log(`\nRecorded (no ceiling). For a regression gate pass e.g. --max-ms-per-1k ${(sim.medianMsPer1k * 3).toFixed(1)}`);
}
