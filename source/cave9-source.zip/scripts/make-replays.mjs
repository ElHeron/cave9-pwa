// Replay fixture generator (Phase 4B, gate P1).
//
// Produces the committed replay fixtures used by test/replay.test.js and
// scripts/replay-test.mjs:
//
//   test/fixtures/replay-normal.json  — the deterministic autopilot, a normal
//                                        clean flight (no wall scraping).
//   test/fixtures/replay-graze.json   — an ORGANIC grazing flight: a wall-rider
//                                        controller that deliberately flies close
//                                        to a wall so the real scoring system
//                                        accrues graze time (and, where the cave
//                                        allows, a real combo). NOTHING is
//                                        injected — only the input track is
//                                        recorded, then replayed through the real
//                                        Game.step path.
//
// The graze track is found by a small deterministic search over the seed panel
// and a few lateral-offset gains, picking the run with the most real graze time.
// Each fixture stores the seed, mode, the RLE input track, AND the recorded
// expected end-state, so the test can prove "replay reproduces the recording".
//
// Run:  node scripts/make-replays.mjs   (writes the two fixtures)
// To update only expectations after a diagnosed simulation correction, retain
// the original input tracks with --refresh-expected --reason "...".

import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { resolve } from 'node:path';
import { parseArgs } from 'node:util';
import { recordReplay, runReplay } from '../src/core/Replay.js';
import { TWO_BUTTONS, SHIP_RADIUS, THRUST, GRAVITY } from '../src/core/constants.js';
import { pathAt, pathDerivativesAt, pathFrameAt, tubeRadiusAt } from '../src/core/FlightPath.js';
import { speedMul } from '../src/core/Difficulty.js';
import { SEED_PANEL } from './seed-panel.mjs';

const OUT = resolve(process.cwd(), 'test/fixtures');
const { values: options } = parseArgs({ options: {
  'refresh-expected': { type: 'boolean', default: false },
  reason: { type: 'string' },
} });
if (options['refresh-expected']) {
  if (!options.reason?.trim()) throw new Error('--refresh-expected requires a documented --reason');
  const updates = ['replay-normal.json', 'replay-graze.json'].map((name) => {
    const file = resolve(OUT, name);
    const fixture = JSON.parse(readFileSync(file, 'utf8'));
    const { result, checkpoints, steps } = runReplay(fixture);
    const inputSha256 = createHash('sha256').update(JSON.stringify(fixture.frames)).digest('hex');
    fixture.expected = result;
    fixture.expectedCheckpoints = checkpoints;
    fixture._baseline.expectationRefresh = {
      recordedAt: new Date().toISOString().slice(0, 10),
      reason: options.reason.trim(),
      inputSha256,
      preserved: 'Original seed, mode, checkpoint interval and recorded input track.',
    };
    return { file, fixture, steps, inputSha256 };
  });
  for (const { file, fixture, steps, inputSha256 } of updates) {
    writeFileSync(file, JSON.stringify(fixture, null, 2) + '\n');
    console.log(`refreshed expectations: ${file} (${steps} steps, input SHA-256 ${inputSha256})`);
  }
  process.exit(0);
}
if (options.reason !== undefined) throw new Error('--reason requires --refresh-expected');
mkdirSync(OUT, { recursive: true });

// A wall-rider controller factory: same idea as the built-in autopilot (aim for
// a point a few rings ahead with a PD law on the two thrusters), but the target
// is pushed laterally toward a wall by `bias` so the ship rides close to the
// rock and the scoring system registers real grazes. Purely an input generator —
// the physics, collision and graze accrual are the unmodified core.
function wallRider(bias) {
  return (g) => {
    const p = g.player;
    const depth = p.pos[2] - p.start;
    const ref = pathAt(g.seed, depth);
    const derivatives = pathDerivativesAt(g.seed, depth);
    const frame = pathFrameAt(g.seed, depth);
    // Ease away from the centre so the binary-thruster controller does not
    // turn the initial offset request into an artificial launch transient.
    const rampT = Math.max(0, Math.min(1, depth / 180));
    const ramp = rampT * rampT * (3 - 2 * rampT);
    const offset = ramp * bias * (tubeRadiusAt(depth) - SHIP_RADIUS);
    const tx = ref.x + frame.right.x * offset;
    const ty = ref.y + frame.right.y * offset;
    const vz = p.vel[2];
    const forceScale = speedMul(depth);
    const ex = tx - p.pos[0], ey = ty - p.pos[1];
    const evx = derivatives.dx * vz - p.vel[0];
    const evy = derivatives.dy * vz - p.vel[1];
    const wantedX = derivatives.ddx * vz * vz + ex * 9.0 + evx * 5.4;
    const wantedY = derivatives.ddy * vz * vz + ey * 9.0 + evy * 5.4;
    const actions = [
      [false, false, 0, -GRAVITY * forceScale],
      [true, false, -THRUST * forceScale, 0],
      [false, true, THRUST * forceScale, 0],
      [true, true, 0, (THRUST - GRAVITY) * forceScale],
    ];
    let best = actions[0], bestCost = Infinity;
    for (const action of actions) {
      const dx = (action[2] - wantedX) / (THRUST * forceScale);
      const dy = (action[3] - wantedY) / (GRAVITY * forceScale);
      const cost = dx * dx + 1.35 * dy * dy;
      if (cost < bestCost) { best = action; bestCost = cost; }
    }
    p.lefton = best[0];
    p.righton = best[1];
  };
}

function writeFixture(name, replay, result, checkpoints, meta) {
  const file = resolve(OUT, name);
  const doc = {
    _comment: meta,
    _baseline: {
      recordedAt: '2026-08-09',
      reason: 'Authorised route-first Boolean-tube generator with an exact 2 m ring lattice, ring-stable wall RNG, asymptotic route, shared discrete speed/gravity/thrust plateaus and deeper wall-embedded standard-corridor coil at its reference-led 97 m pitch.',
      coverage: 'Early fixed-step input path through about 900 m; room shells and runtime families are pinned by dedicated generator/reference-family tests.',
    },
    ...replay,
    expectedCheckpoints: checkpoints,
    expected: result,
  };
  writeFileSync(file, JSON.stringify(doc, null, 2) + '\n');
  return file;
}

// ---- normal flight (autopilot) --------------------------------------------
const NORMAL_SEED = 424242;
{
  const rec = recordReplay({ seed: NORMAL_SEED, mode: TWO_BUTTONS, maxSteps: 1800 });
  // sanity: replaying the recorded track must reproduce the recorded end-state
  const rep = runReplay(rec.replay);
  const ok = JSON.stringify(rep.result) === JSON.stringify(rec.result);
  const file = writeFixture('replay-normal.json', rec.replay, rec.result, rec.checkpoints,
    'Phase 4B P1 fixture — deterministic autopilot, normal clean flight. ' +
    'Generated by scripts/make-replays.mjs; do not edit by hand.');
  console.log(`normal:  seed ${NORMAL_SEED}  steps ${rec.steps}  ` +
    `dist ${rec.result.distance}m  score ${rec.result.score}  ` +
    `grazeT ${rec.result.grazeTime}s  bestCombo ${rec.result.bestCombo}  ` +
    `crashed ${rec.result.crashed}  round-trip ${ok ? 'OK' : 'MISMATCH'}`);
  console.log(`  -> ${file}`);
  if (!ok) process.exitCode = 1;
}

// ---- organic graze flight (search) ----------------------------------------
{
  const biases = [0.58, 0.64, 0.7, 0.76, 0.82];
  let best = null;
  for (const seed of SEED_PANEL) {
    for (const bias of biases) {
      const rec = recordReplay({ seed, mode: TWO_BUTTONS, maxSteps: 1800, controller: wallRider(bias) });
      const g = rec.result.grazeTime || 0;
      if (g > 0 && (!best || g > best.rec.result.grazeTime ||
          (g === best.rec.result.grazeTime && rec.result.bestCombo > best.rec.result.bestCombo))) {
        // prefer the longest real graze time; tie-break on real combo level
        if (!best || rec.result.bestCombo > best.rec.result.bestCombo || g > best.rec.result.grazeTime) {
          best = { seed, bias, rec };
        }
      }
    }
  }

  if (!best) {
    console.error('graze: no grazing track found — leaving previous fixture untouched');
    process.exitCode = 1;
  } else {
    const { seed, bias, rec } = best;
    const rep = runReplay(rec.replay);
    const ok = JSON.stringify(rep.result) === JSON.stringify(rec.result);
    const file = writeFixture('replay-graze.json', rec.replay, rec.result, rec.checkpoints,
      `Phase 4B P1 fixture — ORGANIC graze flight (wall-rider bias ${bias}). ` +
      'Real graze time accrued by the unmodified scoring system; nothing injected. ' +
      'Generated by scripts/make-replays.mjs; do not edit by hand.');
    console.log(`graze:   seed ${seed}  bias ${bias}  steps ${rec.steps}  ` +
      `dist ${rec.result.distance}m  score ${rec.result.score}  ` +
      `grazeT ${rec.result.grazeTime}s  bestCombo ${rec.result.bestCombo}  ` +
      `crashed ${rec.result.crashed}  round-trip ${ok ? 'OK' : 'MISMATCH'}`);
    console.log(`  -> ${file}`);
    if (!ok) process.exitCode = 1;
  }
}
