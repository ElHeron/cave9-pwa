// Deterministic screenshot harness (Phase 3A).
//
// Spins up the Vite dev server, drives the real app via window.__cave9, and
// saves:
//   * the required full-page composites (minimal overlay + canvas):
//       default / bright / reduced-motion / danger-near-wall /
//       debug-overlay / death-summary -> docs/screenshots/*-fullpage.png
//   * identical-frame canvas-only before/after pairs (readability OFF vs ON)
//       for the three lighting scenarios -> docs/screenshots/phase3a/*.png
//
// Every gameplay frame is produced by app.captureScenario({seed, distance,
// settings, scenario}) so before/after use the SAME seed, distance, camera and
// frame. Luminance metrics are computed over every saved image and written to
// docs/screenshots/phase3a/metrics.json.
//
// Headless note: headless Chromium intermittently returns a blank (transparent
// or pure-white) frame for page.screenshot / toDataURL right after a WebGL
// render. We therefore VERIFY every saved image and re-capture until it is a
// real, non-blank frame (see captureVerified). Determinism is unaffected: the
// CAPTURE-state loop re-renders the exact same byte-stable frame each tick.
//
// Run:  node scripts/capture.mjs

import { spawn } from 'node:child_process';
import { mkdirSync, writeFileSync, readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { chromium } from 'playwright';
import { PNG } from 'pngjs';
import { luminanceMetrics } from './luminance.mjs';
import { edgeMetrics } from './edge.mjs';

const PORT = 5188;
const URL = `http://localhost:${PORT}/?capture=1`;
const SEED = 424242;
// A shallow clean frame preserves the original-look baseline before the visual
// morph and speed-only regime begin.
const DISTANCE = 700;
const VIEWPORT = { width: 1280, height: 720 }; // landscape-first

const OUT = resolve(process.cwd(), 'docs/screenshots');
const OUT3A = resolve(OUT, 'phase3a');
const OUT4D = resolve(OUT, 'phase4d');
const OUT4G = resolve(OUT, 'phase4g');
mkdirSync(OUT3A, { recursive: true });
mkdirSync(OUT4D, { recursive: true });
mkdirSync(OUT4G, { recursive: true });

// Landmark capture (Phase 4G.2): rooms only exist from z≈2050 m, so the landmark
// art shots use seeds whose autopilot survives past the first room, framed from
// just before the room plane. One family per seed (see the landmark block below).

function waitForServer(url, timeoutMs = 30000) {
  const start = Date.now();
  return new Promise((res, rej) => {
    const tick = async () => {
      try {
        const r = await fetch(url);
        if (r.ok) return res();
      } catch { /* not up yet */ }
      if (Date.now() - start > timeoutMs) return rej(new Error('server timeout'));
      setTimeout(tick, 250);
    };
    tick();
  });
}

// Wait for the CAPTURE-state loop to re-render the held frame a few times so
// the live WebGL canvas is present for the compositor / toDataURL in headless.
async function settle(page, frames = 3) {
  for (let i = 0; i < frames; i++) {
    await page.evaluate(() => new Promise((r) => requestAnimationFrame(() => r())));
  }
}

// Fraction of pixels that are fully transparent or pure white — the signature
// of a blank headless capture (real Cave9 frames are dark rock, never that).
function blankFraction(file) {
  const png = PNG.sync.read(readFileSync(file));
  const d = png.data;
  const n = png.width * png.height;
  let bad = 0;
  for (let i = 0; i < n; i++) {
    const r = d[i * 4], g = d[i * 4 + 1], b = d[i * 4 + 2], a = d[i * 4 + 3];
    if (a === 0 || (r === 255 && g === 255 && b === 255)) bad++;
  }
  return bad / n;
}

// Save via `take`, verify it is not a blank frame, and retry with extra settle
// frames until it is real (or give up loudly after a few tries).
async function captureVerified(page, file, take, tries = 6) {
  for (let t = 0; t < tries; t++) {
    await settle(page, 3 + t);
    await take(file);
    if (blankFraction(file) < 0.4) return;
  }
  throw new Error(`capture stayed blank after ${tries} tries: ${file}`);
}

const screenshotTake = (page) => (file) => page.screenshot({ path: file });
const canvasTake = (page) => async (file) => {
  const url = await page.evaluate(() => window.__cave9.renderer.canvas.toDataURL('image/png'));
  writeFileSync(file, Buffer.from(url.replace(/^data:image\/png;base64,/, ''), 'base64'));
};

async function main() {
  console.log('› starting vite dev server on', PORT);
  const server = spawn(process.execPath,
    [resolve('node_modules/vite/bin/vite.js'), '--port', String(PORT), '--strictPort'], {
    cwd: process.cwd(), shell: false, stdio: 'ignore',
  });

  const consoleErrors = [];
  let browser;
  try {
    await waitForServer(URL);
    browser = await chromium.launch({ channel: 'chromium' });
    const page = await browser.newPage({ viewport: VIEWPORT, deviceScaleFactor: 1 });
    page.on('console', (m) => { if (m.type() === 'error') consoleErrors.push(m.text()); });
    page.on('pageerror', (e) => consoleErrors.push('pageerror: ' + e.message));

    await page.goto(URL, { waitUntil: 'load' });
    await page.waitForFunction(
      () => window.__cave9 && window.__cave9.state && window.__cave9.state !== 'boot',
      { timeout: 30000 });

    const shot = screenshotTake(page);
    const canvas = canvasTake(page);
    const metrics = [];
    const record = (label, file, kind, info) => {
      const m = luminanceMetrics(file);
      // Phase 4B (gate P2): also carry edge-energy / local-contrast so every
      // captured frame records its near/mid-wall surface-detail level alongside
      // luminance. Pure analysis — nothing in the render path changes.
      const e = edgeMetrics(file);
      metrics.push({
        label, kind, file: file.replace(process.cwd() + '\\', '').replace(/\\/g, '/'),
        info, ...m, edgeEnergy: e.edgeEnergy, localContrast: e.localContrast,
      });
    };

    const fly = (settings, scenario = 'play') => page.evaluate(
      (o) => window.__cave9.captureScenario(o),
      { seed: SEED, distance: DISTANCE, settings, scenario });
    // full-control variant (own seed + distance) for the landmark scenarios
    const flyOpts = (opts) => page.evaluate(
      (o) => window.__cave9.captureScenario(o), opts);

    // ---- three lighting scenarios: full-page + identical-frame canvas pair ---
    const lighting = [
      { label: 'default', settings: { brightness: 1.0, motion: 1.0 } },
      { label: 'bright', settings: { brightness: 1.5, motion: 1.0 } },
      { label: 'reduced-motion', settings: { brightness: 1.0, motion: 0.0 } },
    ];

    for (const sc of lighting) {
      const info = await fly({ ...sc.settings, readability: true });
      console.log(`  ${sc.label}: dist=${info.distanceReached}m speed=${info.speed} warn=${info.warnLevel}`);

      const full = resolve(OUT, `${sc.label}-fullpage.png`);
      await captureVerified(page, full, shot);
      record(sc.label, full, 'fullpage-improved', info);

      const canvasImp = resolve(OUT3A, `canvas-${sc.label}-improved.png`);
      await captureVerified(page, canvasImp, canvas);
      record(sc.label, canvasImp, 'canvas-improved', info);

      // baseline (Phase 2 look) at the IDENTICAL frame — readability OFF
      const binfo = await fly({ ...sc.settings, readability: false });
      const canvasBase = resolve(OUT3A, `canvas-${sc.label}-baseline.png`);
      await captureVerified(page, canvasBase, canvas);
      record(sc.label, canvasBase, 'canvas-baseline', binfo);
    }

    // ---- Phase 4D: rock micro-relief (L2) — off/on pair + named fullpages ----
    // Identical-frame canvas pair isolating ONLY the normal map (rock detail
    // off vs on, readability + brightness + motion held constant). This is the
    // before/after + quality-off-vs-on evidence the L2 metrics compare.
    {
      const off = await fly({ brightness: 1.0, motion: 1.0, readability: true, rockDetail: false });
      const cOff = resolve(OUT4D, 'canvas-rockdetail-off.png');
      await captureVerified(page, cOff, canvas);
      record('rockdetail-off', cOff, 'canvas-rockdetail-off', off);

      const on = await fly({ brightness: 1.0, motion: 1.0, readability: true, rockDetail: true });
      const cOn = resolve(OUT4D, 'canvas-rockdetail-on.png');
      await captureVerified(page, cOn, canvas);
      record('rockdetail-on', cOn, 'canvas-rockdetail-on', on);
      console.log(`  rock-detail: off→on (same frame, dist=${on.distanceReached}m, rockDetail=${on.rockDetail})`);

      // named full-page composites (rock detail ON = shipped default)
      const full = resolve(OUT, 'rock-detail-default-fullpage.png');
      await captureVerified(page, full, shot);
      record('rock-detail-default', full, 'fullpage-improved', on);

      const binfo = await fly({ brightness: 1.5, motion: 1.0, readability: true, rockDetail: true });
      const fullB = resolve(OUT, 'rock-detail-bright-fullpage.png');
      await captureVerified(page, fullB, shot);
      record('rock-detail-bright', fullB, 'fullpage-improved', binfo);

      const dinfo = await fly({ brightness: 1.0, motion: 1.0, readability: true, rockDetail: true }, 'danger');
      const fullD = resolve(OUT, 'rock-detail-danger-fullpage.png');
      await captureVerified(page, fullD, shot);
      record('rock-detail-danger', fullD, 'fullpage-improved', dinfo);
    }

    // ---- danger near wall ---------------------------------------------------
    {
      const info = await fly({ brightness: 1.0, motion: 1.0, readability: true }, 'danger');
      console.log(`  danger: warn=${info.warnLevel} clearance=${info.clearance}`);
      const full = resolve(OUT, 'danger-near-wall-fullpage.png');
      await captureVerified(page, full, shot);
      record('danger-near-wall', full, 'fullpage-improved', info);
    }

    // ---- reduced-motion danger (warning info retained without animation) ----
    {
      const info = await fly({ brightness: 1.0, motion: 0.0, readability: true }, 'danger');
      console.log(`  reduced-motion danger: warn=${info.warnLevel} motion=${info.motion}`);
      const full = resolve(OUT, 'reduced-motion-danger-fullpage.png');
      await captureVerified(page, full, shot);
      record('reduced-motion-danger', full, 'fullpage-improved', info);
    }

    // ---- debug overlay ------------------------------------------------------
    {
      const info = await fly({ brightness: 1.0, motion: 1.0, readability: true });
      await page.evaluate(() => {
        window.__cave9.debug.toggle(true);
        window.__cave9.debug.update(window.__cave9.game);
      });
      const full = resolve(OUT, 'debug-overlay-fullpage.png');
      await captureVerified(page, full, shot);
      record('debug-overlay', full, 'fullpage-improved', info);
      await page.evaluate(() => window.__cave9.debug.toggle(false));
    }

    // ---- predictive warning (Phase 4F / M1) ---------------------------------
    // A real autopilot frame where the HEADING leads into a wall: the predictive
    // warning has engaged (HUD vignette + headlight tint) while the reactive
    // proximity is still lower. Proves the warning leads, additively, on a frame
    // that is not yet a reactive-danger frame.
    {
      const info = await fly({ brightness: 1.0, motion: 1.0, readability: true }, 'predictive');
      console.log(`  predictive: reactive=${info.reactiveWarn} predictive=${info.predictiveWarn} final=${info.finalWarn} lead=${info.leadDist}m`);
      const full = resolve(OUT, 'predictive-warning-fullpage.png');
      await captureVerified(page, full, shot);
      record('predictive-warning', full, 'fullpage-improved', info);

      // same scenario with the debug overlay on, so reactive/pred/final/lead read
      const dbg = await page.evaluate(() => {
        const app = window.__cave9, g = app.game;
        app.debug.toggle(true);
        // The frame's single warning state (core/WarnState.js), computed once by
        // the session and remembered on it — the overlay shows these exact values.
        const w = app.session.lastWarn;
        app.debug.update(g, w);
        return w ? { reactive: +w.reactive.toFixed(3),
          predictive: +w.predictive.toFixed(3), final: +w.final.toFixed(3) } : null;
      });
      console.log(`  predictive-debug: ${JSON.stringify(dbg)}`);
      const fullD = resolve(OUT, 'predictive-warning-debug-fullpage.png');
      await captureVerified(page, fullD, shot);
      record('predictive-warning-debug', fullD, 'fullpage-improved', { ...info, ...dbg });
      await page.evaluate(() => window.__cave9.debug.toggle(false));
    }

    // ---- landmark GEOMETRY LANGUAGE rebuild (Phase 4I.2) --------------------
    // 4I had the right safety skeleton but rendered every piece as a scaled
    // primitive → rods/bars/boxes/spikes. 4I.2 grows REAL organic geometry on the
    // same deterministic skeleton: curved tapered tubes (branching), oval cave
    // ribs (coiling) and faceted obsidian shard clusters (crystal), with baked
    // vertex-colour gradients + wall root pads. Render-only, deterministic decor.
    // Seeds landing each family at the first room: branching=99, crystal=2024,
    // coiling=256.
    {
      const lmSettings = { brightness: 1.2, motion: 1.0, readability: true, landmarks: true };
      const fam = [
        { name: 'branching', seed: 99, dist: 2010 },
        { name: 'crystal', seed: 2024, dist: 2018 },
        { name: 'coiling', seed: 256, dist: 2004 },
      ];
      for (const f of fam) {
        const info = await flyOpts({ seed: f.seed, distance: f.dist, settings: lmSettings });
        console.log(`  landmark-geometry2-${f.name}: type=${info.landmarkType} pieces=${info.landmarkPieces} nearest=${info.nearestLandmark}m`);
        const full = resolve(OUT, `landmark-geometry2-${f.name}-fullpage.png`);
        await captureVerified(page, full, shot);
        record(`landmark-geometry2-${f.name}`, full, 'fullpage-improved', info);
      }

      // depth cue: a family seen from far → small, reads as depth into the cave
      const depth = await flyOpts({ seed: 99, distance: 1945, settings: lmSettings });
      console.log(`  landmark-geometry2-depthcue: type=${depth.landmarkType} nearest=${depth.nearestLandmark}m`);
      const fullDepth = resolve(OUT, 'landmark-geometry2-depthcue-fullpage.png');
      await captureVerified(page, fullDepth, shot);
      record('landmark-geometry2-depthcue', fullDepth, 'fullpage-improved', depth);

      // identical-frame off-vs-on canvas pair (only the formation differs)
      const onInfo = await flyOpts({ seed: 99, distance: 2010, settings: lmSettings });
      const cOn = resolve(OUT4G, 'landmark-geometry2-on.png');
      await captureVerified(page, cOn, canvas);
      record('landmark-geometry2-on', cOn, 'canvas-landmark-on', onInfo);
      const offInfo = await flyOpts({ seed: 99, distance: 2010, settings: { ...lmSettings, landmarks: false } });
      const cOff = resolve(OUT4G, 'landmark-geometry2-off.png');
      await captureVerified(page, cOff, canvas);
      record('landmark-geometry2-off', cOff, 'canvas-landmark-off', offInfo);
      console.log(`  landmark-geometry2 off→on (same frame, dist=2010m, pieces=${onInfo.landmarkPieces})`);

      // debug overlay on the branching frame (type + count + pieces + nearest-z)
      const dbgInfo = await flyOpts({ seed: 99, distance: 2010, settings: lmSettings });
      await page.evaluate(() => {
        window.__cave9.debug.toggle(true);
        window.__cave9.debug.update(window.__cave9.game);
      });
      const fullDbg = resolve(OUT, 'landmark-geometry2-debug-fullpage.png');
      await captureVerified(page, fullDbg, shot);
      record('landmark-geometry2-debug', fullDbg, 'fullpage-improved', dbgInfo);
      await page.evaluate(() => window.__cave9.debug.toggle(false));
    }

    // ---- death / run summary ------------------------------------------------
    {
      const info = await fly({ brightness: 1.0, motion: 1.0, readability: true }, 'danger');
      await page.evaluate(() => {
        const app = window.__cave9, g = app.game;
        app.menu.setFlightOverlayVisible(false);
        app.menu.showDeath({
          score: g.scoreValue(), newBest: true,
          context: {
            seed: g.seed, daily: false, dailyKey: null,
            rules: { controlMode: g.mode, thrustScale: g.player.thrustScale, landmarks: g.landmarksEnabled },
          },
          previousBest: Math.max(0, g.scoreValue() - 100),
          telemetry: {
            distance: g.score.distance, maxSpeed: g.score.maxSpeed,
            grazeTime: g.score.grazeTime, bestComboMultiplier: g.score.comboMultiplier,
          },
        });
      });
      const summary = resolve(OUT, 'death-summary-fullpage.png');
      await settle(page, 4);
      await shot(summary);
      record('death-summary', summary, 'fullpage-improved', info);
    }

    // ---- daily seed menu ----------------------------------------------------
    {
      const info = await fly({ brightness: 1.0, motion: 1.0, readability: true });
      const dl = await page.evaluate(() => {
        // seed a local "today's best" so the menu shows a real loaded value
        const key = new Date().toISOString().slice(0, 10);
        localStorage.setItem(`cave9.ranked.v1.daily.${key}.r1-m2-t1-l1`, '4200');
        window.__cave9.toMenu(); // refreshes daily info from local storage
        // keep the idle attract-demo from hijacking the menu before the shot
        window.__cave9.lastInteract = performance.now();
        return {
          best: document.getElementById('menu-daily-best').textContent,
          seed: document.getElementById('menu-daily-seed').textContent,
        };
      });
      console.log(`  daily: best=${dl.best} seed=${dl.seed}`);
      const full = resolve(OUT, 'daily-seed-menu-fullpage.png');
      await settle(page, 4);
      await shot(full);
      record('daily-seed-menu', full, 'fullpage-improved', { ...info, ...dl });
    }

    // ---- debug overlay with scoring metrics ---------------------------------
    {
      const info = await fly({ brightness: 1.0, motion: 1.0, readability: true }, 'danger');
      const dbg = await page.evaluate(() => {
        const app = window.__cave9, g = app.game;
        // a representative combo so the new overlay rows are all populated
        g.score.combo = 2;
        g.score.comboMultiplier = 2.0;
        app.menu.setFlightOverlayVisible(true);
        app.debug.toggle(true);
        app.debug.update(g);
        return {
          grazeActive: g.score.grazeActive, combo: g.score.combo,
          closest: +g.score.closest.toFixed(2), maxDanger: +g.score.maxDanger.toFixed(2),
        };
      });
      console.log(`  debug-scoring: graze=${dbg.grazeActive} combo=${dbg.combo} closest=${dbg.closest} maxDanger=${dbg.maxDanger}`);
      const full = resolve(OUT, 'debug-overlay-scoring-fullpage.png');
      await captureVerified(page, full, shot);
      record('debug-overlay-scoring', full, 'fullpage-improved', { ...info, ...dbg });
      await page.evaluate(() => window.__cave9.debug.toggle(false));
    }

    writeFileSync(resolve(OUT3A, 'metrics.json'),
      JSON.stringify({ seed: SEED, distance: DISTANCE, viewport: VIEWPORT, capturedAt: new Date().toISOString(), consoleErrors, metrics }, null, 2));

    console.log(`\n› saved ${metrics.length} images + metrics.json`);
    console.log('› console errors during capture:', consoleErrors.length);
    if (consoleErrors.length) console.log(consoleErrors.join('\n'));

    await browser.close();
  } finally {
    if (browser) try { await browser.close(); } catch {}
    server.kill();
  }
}

main().catch((e) => { console.error(e); process.exit(1); });
