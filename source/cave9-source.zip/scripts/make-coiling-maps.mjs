#!/usr/bin/env node
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { generateSurfaceMaps } from './make-cave-maps.mjs';

// This deterministic source is only needed to regenerate the shipped normal
// and height maps. Keep it outside public/ so the browser never downloads it.
export const COILING_MAP_SOURCE = 'docs/assets/coiling-rock-detail.webp';
export const COILING_HEIGHT_OUTPUT = 'public/assets/coiling-rock-height.png';
export const COILING_NORMAL_OUTPUT = 'public/assets/coiling-rock-normal.png';
export const COILING_NORMAL_STRENGTH = 6.0;

export function generateCoilingMaps({
  source = resolve(COILING_MAP_SOURCE),
  heightOutput = resolve(COILING_HEIGHT_OUTPUT),
  normalOutput = resolve(COILING_NORMAL_OUTPUT),
} = {}) {
  return generateSurfaceMaps({
    source,
    heightOutput,
    normalOutput,
    normalStrength: COILING_NORMAL_STRENGTH,
  });
}

const invokedPath = process.argv[1] ? pathToFileURL(resolve(process.argv[1])).href : null;
if (invokedPath === import.meta.url) {
  console.log(JSON.stringify(generateCoilingMaps(), null, 2));
}
