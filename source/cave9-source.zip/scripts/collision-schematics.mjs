// Convert the 3D collision truth into assertable SVGs: one route-local
// cross-section and one whole-run longitudinal section.
import { mkdirSync, writeFileSync } from 'node:fs';
import { resolve, join } from 'node:path';
import { Game } from '../src/core/Game.js';
import { collision } from '../src/core/CollisionSystem.js';
import { pathAt, pathFrameAt, tubeRadiusAt } from '../src/core/FlightPath.js';
import { roomZ } from '../src/core/Landmarks.js';
import { ROOM_LEN, ROOM_SPACING, ROOM_START, SECTOR_COUNT, SHIP_RADIUS } from '../src/core/constants.js';

const OUT = resolve('docs/measure/schematics');
const SEED = Number(process.argv[2]) || 2024;
const DEPTH = Number(process.argv[3]) || 9050;
mkdirSync(OUT, { recursive: true });

function carveTo(game, depth, lead = 180) {
  game.cave.generateThrough(depth + lead);
}

function project(frame, p) {
  const dx = p[0] - frame.center.x, dy = p[1] - frame.center.y, dz = p[2] - frame.center.z;
  return [dx * frame.right.x + dy * frame.right.y + dz * frame.right.z,
    dx * frame.up.x + dy * frame.up.y + dz * frame.up.z];
}

const game = new Game().start({ seed: SEED, mode: 2 });
game.landmarkFamilyOverride = 'coiling';
carveTo(game, DEPTH);
const route = pathAt(SEED, DEPTH);
game.player.pos[0] = route.x; game.player.pos[1] = route.y; game.player.pos[2] = DEPTH;
const comps = game.landmarkCache.landmarksInView(game.cave, DEPTH, 140, SEED, 140,
  game.landmarkFamilyOverride);
const wallClearance = collision(game.cave, game.player, []);
const surfaceClearance = collision(game.cave, game.player, comps);

let ringIndex = 0, ringGap = Infinity;
for (let i = 0; i < game.cave.centers.length; i++) {
  const gap = Math.abs(game.cave.centers[i][2] - DEPTH);
  if (gap < ringGap) { ringGap = gap; ringIndex = i; }
}
const frame = game.cave.frames[ringIndex];
const ring = game.cave.segs[ringIndex].map((v) => project(frame, v));
const extent = Math.max(8, ...ring.map(([x, y]) => Math.hypot(x, y)));
const W = 900, H = 900, scale = 360 / extent, cx = W / 2, cy = H / 2;
const pt = ([x, y]) => `${(cx + x * scale).toFixed(1)},${(cy - y * scale).toFixed(1)}`;
const pieceColors = { limb: '#7fb98b', blade: '#879cff', rib: '#c18bff' };
const pieceSvg = comps.flatMap((c) => c.pieces).map((p) => {
  const c = project(frame, [p.cx, p.cy, p.cz]);
  const dx = p.dx * frame.right.x + p.dy * frame.right.y + p.dz * frame.right.z;
  const dy = p.dx * frame.up.x + p.dy * frame.up.y + p.dz * frame.up.z;
  const hl = p.length / 2;
  return `<line x1="${cx + (c[0] - dx * hl) * scale}" y1="${cy - (c[1] - dy * hl) * scale}" x2="${cx + (c[0] + dx * hl) * scale}" y2="${cy - (c[1] + dy * hl) * scale}" stroke="${pieceColors[p.shape] || '#bbb'}" stroke-opacity=".44" stroke-width="${Math.max(1, p.radius * 2 * scale)}" stroke-linecap="round"/>`;
}).join('');
const tube = tubeRadiusAt(DEPTH, SEED);
const probeSvg = [[-1, 0], [0, 1], [1, 0], [0, -1]].map(([x, y], i) =>
  `<circle cx="${cx + x * SHIP_RADIUS * scale}" cy="${cy - y * SHIP_RADIUS * scale}" r="5" fill="#66ffbb"/><text x="${cx + x * SHIP_RADIUS * scale + 8}" y="${cy - y * SHIP_RADIUS * scale - 8}" fill="#bfffee" font-family="monospace" font-size="13">P${i + 1}</text>`).join('');
const crossSvg = `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}"><rect width="100%" height="100%" fill="#080b11"/><text x="24" y="34" fill="#edf3ff" font-family="monospace" font-size="20">Cave9 cross-section · seed ${SEED} · ${DEPTH}m</text><polygon points="${ring.map(pt).join(' ')}" fill="#1c2532" stroke="#a8b5ca" stroke-width="2"/>${pieceSvg}<circle cx="${cx}" cy="${cy}" r="${tube * scale}" fill="none" stroke="#36d6ff" stroke-width="3" stroke-dasharray="10 7"/><circle cx="${cx}" cy="${cy}" r="${SHIP_RADIUS * scale}" fill="#ffcc66" fill-opacity=".25" stroke="#ffcc66" stroke-width="3"/>${probeSvg}<g fill="#cbd6e8" font-family="monospace" font-size="15"><text x="24" y="${H - 88}">nearest visible surface: ${surfaceClearance.toFixed(3)}m · wall only: ${wallClearance.toFixed(3)}m</text><text x="24" y="${H - 64}">boolean tube: ${tube.toFixed(3)}m · ship radius: ${SHIP_RADIUS.toFixed(3)}m</text><text x="24" y="${H - 40}">ring vertices: ${ring.length} · pieces: ${comps.reduce((n, c) => n + c.pieces.length, 0)}</text><text x="24" y="${H - 16}">family forced: coiling · capsule width is drawn to scale</text></g></svg>`;
writeFileSync(join(OUT, 'cross-section.svg'), crossSvg);

// Whole-run view: fly the real oracle, record signed route-local error, and
// retain each room's piece spans while its ring is live.
const flight = new Game().start({ seed: SEED, mode: 2 });
const samples = [];
const landmarkSpans = new Map();
const maxDepth = 10000;
while (flight.player.pos[2] < maxDepth && flight.phase === 'running') {
  flight.autopilot(); flight.step();
  for (const c of flight.landmarkCompositions) {
    if (landmarkSpans.has(c.k)) continue;
    const minZ = Math.min(...c.pieces.map((p) => p.cz - Math.abs(p.dz) * p.length / 2 - p.radius));
    const maxZ = Math.max(...c.pieces.map((p) => p.cz + Math.abs(p.dz) * p.length / 2 + p.radius));
    landmarkSpans.set(c.k, { k: c.k, typeName: c.typeName, minZ, maxZ, pieces: c.pieces.length });
  }
  if ((samples.length === 0) || flight.player.pos[2] - samples.at(-1).z >= 20) {
    const z = flight.player.pos[2], f = pathFrameAt(SEED, z), p = flight.player.pos;
    const dx = p[0] - f.center.x, dy = p[1] - f.center.y, dz = p[2] - f.center.z;
    const rightError = dx * f.right.x + dy * f.right.y + dz * f.right.z;
    const upError = dx * f.up.x + dy * f.up.y + dz * f.up.z;
    samples.push({ z, radialError: Math.hypot(rightError, upError) });
  }
}
const LW = 1400, LH = 700, mid = 350, xAt = (z) => 60 + z / maxDepth * (LW - 100);
const rScale = 28;
const upper = [], lower = [];
for (let z = 0; z <= maxDepth; z += 25) {
  const r = tubeRadiusAt(z, SEED);
  upper.push(`${xAt(z).toFixed(1)},${(mid - r * rScale).toFixed(1)}`);
  lower.push(`${xAt(z).toFixed(1)},${(mid + r * rScale).toFixed(1)}`);
}
const rooms = [];
for (let k = Math.ceil(ROOM_START / ROOM_SPACING); roomZ(k) <= maxDepth; k++) {
  const z = roomZ(k), x = xAt(z - ROOM_LEN / 2), width = xAt(z + ROOM_LEN / 2) - x;
  rooms.push(`<rect x="${x}" y="70" width="${width}" height="560" fill="#624a88" fill-opacity=".16"/><text x="${x + 3}" y="88" fill="#bda6e6" font-family="monospace" font-size="11">room ${k}</text>`);
}
const familyColors = { branching: '#7fb98b', crystal: '#879cff', coiling: '#c18bff' };
const spanSvg = [...landmarkSpans.values()].sort((a, b) => a.k - b.k).map((s, i) => {
  const y = 112 + (i % 3) * 20;
  const x1 = xAt(Math.max(0, s.minZ)), x2 = xAt(Math.min(maxDepth, s.maxZ));
  return `<line x1="${x1.toFixed(1)}" y1="${y}" x2="${x2.toFixed(1)}" y2="${y}" stroke="${familyColors[s.typeName] || '#ddd'}" stroke-width="7" stroke-linecap="round"/><text x="${x1.toFixed(1)}" y="${y - 6}" fill="${familyColors[s.typeName] || '#ddd'}" font-family="monospace" font-size="10">${s.typeName} · ${s.pieces}</text>`;
}).join('');
const flown = samples.map((s) => `${xAt(s.z).toFixed(1)},${(mid - s.radialError * rScale).toFixed(1)}`).join(' ');
const maxTrackingError = Math.max(...samples.map((s) => s.radialError));
const longSvg = `<svg xmlns="http://www.w3.org/2000/svg" width="${LW}" height="${LH}" viewBox="0 0 ${LW} ${LH}"><rect width="100%" height="100%" fill="#080b11"/><text x="24" y="34" fill="#edf3ff" font-family="monospace" font-size="20">Cave9 longitudinal section · seed ${SEED} · real autopilot</text>${rooms.join('')}<polygon points="${upper.concat([...lower].reverse()).join(' ')}" fill="#18303a" fill-opacity=".7" stroke="none"/>${spanSvg}<polyline points="${upper.join(' ')}" fill="none" stroke="#36d6ff" stroke-width="2"/><polyline points="${lower.join(' ')}" fill="none" stroke="#36d6ff" stroke-width="2"/><line x1="60" y1="${mid}" x2="${LW - 40}" y2="${mid}" stroke="#637087" stroke-dasharray="5 5"/><polyline points="${flown}" fill="none" stroke="#ffcc66" stroke-width="2"/><g fill="#cbd6e8" font-family="monospace" font-size="14"><text x="24" y="${LH - 45}">cyan: Boolean-tube · amber: radial flight error · coloured bars: landmark z-spans</text><text x="24" y="${LH - 22}">reached ${flight.player.pos[2].toFixed(1)}m · crashed ${flight.phase === 'dead'} · max radial error ${maxTrackingError.toFixed(3)}m</text></g></svg>`;
writeFileSync(join(OUT, 'longitudinal-section.svg'), longSvg);

const evidence = {
  seed: SEED, depth: DEPTH, ringVertices: ring.length, tubeRadius: tube,
  wallClearance, surfaceClearance,
  probesInside: [...game.player.probeInside], landmarkPieces: comps.reduce((n, c) => n + c.pieces.length, 0),
  longitudinalLandmarkSpans: [...landmarkSpans.values()],
  flightDepth: flight.player.pos[2], flightCrashed: flight.phase === 'dead',
  maxTrackingError,
};
if (evidence.ringVertices !== SECTOR_COUNT || !(evidence.surfaceClearance > 0) ||
    evidence.probesInside.some((v) => !v) || evidence.longitudinalLandmarkSpans.length === 0 ||
    evidence.flightCrashed) {
  throw new Error(`schematic invariant failed: ${JSON.stringify(evidence)}`);
}
writeFileSync(join(OUT, 'evidence.json'), JSON.stringify(evidence, null, 2) + '\n');
console.log(`wrote collision schematics to ${OUT}`);
