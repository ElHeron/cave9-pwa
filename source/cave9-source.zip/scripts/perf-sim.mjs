// Simulated target-boundary profile.  This is deliberately a proxy, never a
// claim about hardware that is not present: one pass throttles CPU, another
// uses SwiftShader as a conservative GPU boundary.
import { chromium } from '@playwright/test';
import { spawn } from 'node:child_process';
import { mkdirSync, writeFileSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import * as THREE from 'three';
import { gitProvenance, runtimeFingerprint } from './visual/provenance.mjs';
import {
  coilingRimPolicyPass, perfScenarioContractPass, textureBudgetMetrics,
  releaseEvidenceContractPass, RELEASE_SCENARIOS, RELEASE_VIEWPORT,
  withTextureStorageEstimate,
} from './perf-scenario-contract.mjs';
import { applyCaveMineral } from '../src/render/materials/caveMineral.js';
import { drawingBufferSize, effectiveRenderPixelRatio } from '../src/render/renderResolution.js';

const PORT = 5199;
const URL = `http://localhost:${PORT}/?visualLab=1&capture=1&perf=1`;
const args = process.argv.slice(2);
const rawValue = (flag, fallback) => {
  const i = args.indexOf(flag);
  return i >= 0 && args[i + 1] ? args[i + 1] : fallback;
};
const value = (flag, fallback) => {
  const raw = rawValue(flag, null);
  return raw == null ? fallback : Number(raw);
};
const WARMUP_S = value('--warmup', Number(process.env.PERF_WARMUP) || 30);
const SAMPLE_S = value('--seconds', Number(process.env.PERF_SECONDS) || 90);
const ROCK_DETAIL = process.env.PERF_ROCK_DETAIL !== '0';
const SURFACE_RELIEF = process.env.PERF_SURFACE_RELIEF !== '0';
const QUALITY = value('--quality', Number(process.env.PERF_QUALITY) || 2);
const VIEWPORT = {
  width: value('--width', Number(process.env.PERF_WIDTH) || RELEASE_VIEWPORT.width),
  height: value('--height', Number(process.env.PERF_HEIGHT) || RELEASE_VIEWPORT.height),
  dpr: value('--dpr', Number(process.env.PERF_DPR) || RELEASE_VIEWPORT.dpr),
};
if (![1, 2].includes(QUALITY) || !Number.isInteger(VIEWPORT.width)
  || !Number.isInteger(VIEWPORT.height) || VIEWPORT.width < 1
  || VIEWPORT.height < 1 || !(VIEWPORT.dpr > 0 && VIEWPORT.dpr <= 4)) {
  throw new Error('invalid diagnostic quality or viewport');
}

function compiledMineralFragmentHasFbm() {
  const material = new THREE.MeshStandardMaterial();
  applyCaveMineral(material);
  const shader = {
    uniforms: {},
    vertexShader: '#include <common>\n#include <begin_vertex>',
    fragmentShader: [
      '#include <common>', '#include <normal_fragment_maps>',
      '#include <emissivemap_fragment>', '#include <dithering_fragment>',
    ].join('\n'),
  };
  material.onBeforeCompile(shader);
  material.dispose();
  return shader.fragmentShader.includes('lmFbm2(');
}
const LANDMARKS = process.env.PERF_LANDMARKS !== '0';
const CAVE = process.env.PERF_CAVE !== '0';
const RELEASE = args.includes('--release');
const BROWSER_CHANNEL = args.includes('--chrome') ? 'chrome' : 'chromium';
const REPETITIONS = Math.max(1, Math.trunc(value('--repetitions', Number(process.env.PERF_REPETITIONS) || 1)));
const FLY_SPAN = Math.max(1, value('--fly-span', Number(process.env.PERF_FLY_SPAN) || 1200));
const list = (value, fallback) => String(value ?? fallback).split(',').map((entry) => entry.trim()).filter(Boolean);
const requestedFamilies = list(rawValue('--families', process.env.PERF_FAMILIES || 'auto'));
const requestedModes = list(rawValue('--mode', process.env.PERF_MODE || 'static'))
  .flatMap((mode) => mode === 'both' ? ['static', 'flythrough'] : [mode]);
const allowedFamilies = new Set(['off', 'auto', 'branching', 'crystal', 'coiling']);
const allowedModes = new Set(['static', 'flythrough']);
for (const family of requestedFamilies) if (!allowedFamilies.has(family)) throw new Error(`unknown family ${family}`);
for (const mode of requestedModes) if (!allowedModes.has(mode)) throw new Error(`unknown mode ${mode}`);
const PAIR_FROM = Number(process.env.PERF_PAIR_FROM);
const PAIR_COUNT = Number(process.env.PERF_PAIR_COUNT);
const PAIR_SWEEP = Number.isInteger(PAIR_FROM) && Number.isInteger(PAIR_COUNT);
const DEFAULT_SCENARIOS = RELEASE_SCENARIOS;
const checkpointOverrideRequested = args.includes('--checkpoints') || !!process.env.PERF_CHECKPOINTS;
const scenarioFilterRequested = !!process.env.PERF_SCENARIO;
const requestedCheckpoints = list(rawValue('--checkpoints', process.env.PERF_CHECKPOINTS || ''), '')
  .map(Number).filter(Number.isFinite);
const BASE_SCENARIOS = requestedCheckpoints.length
  ? requestedCheckpoints.map((distance) => ({ name: `depth-${distance}`, seed: 2024, distance }))
  : DEFAULT_SCENARIOS;
// Local profiler diagnosis can isolate one scenario; the release command has
// no PERF_SCENARIO and therefore always measures the complete three-part set.
const FILTERED_SCENARIOS = process.env.PERF_SCENARIO
  ? BASE_SCENARIOS.filter((s) => s.name === process.env.PERF_SCENARIO)
  : BASE_SCENARIOS;
const SCENARIOS = FILTERED_SCENARIOS.flatMap((scenario) => requestedFamilies.flatMap((family) =>
  requestedModes.flatMap((mode) => Array.from({ length: REPETITIONS }, (_, repetition) => ({
    ...scenario, family, mode, repetition: repetition + 1,
    name: `${scenario.name}-${family}-${mode}-r${repetition + 1}`,
    flyTo: mode === 'flythrough' ? scenario.distance + FLY_SPAN : null,
  })))));
if (!SCENARIOS.length) throw new Error(`unknown PERF_SCENARIO ${process.env.PERF_SCENARIO}`);
const EVIDENCE_VALID = releaseEvidenceContractPass({
  releaseRequested: RELEASE, warmupSeconds: WARMUP_S, sampleSeconds: SAMPLE_S,
  repetitions: REPETITIONS, flySpanMeters: FLY_SPAN,
  families: requestedFamilies, modes: requestedModes, scenarios: FILTERED_SCENARIOS,
  scenarioFilterRequested, checkpointOverrideRequested, pairSweep: PAIR_SWEEP,
  rockDetail: ROCK_DETAIL, surfaceRelief: SURFACE_RELIEF, landmarks: LANDMARKS,
  cave: CAVE, quality: QUALITY, viewport: VIEWPORT,
});
const LIMITS = Object.freeze({
  cpuP95Ms: 4,
  swiftshaderP95Ms: 36,
  swiftshaderP99Ms: 38,
  swiftshaderMinRollingFps: 28,
  drawCalls: 3,
  triangles: 12000,
  heapMB: 256,
  landmarkGeometryRooms: 4,
  textureDimension: 2048,
  textureBytes: 8 * 1024 * 1024,
  compositionCacheRooms: 6,
  landmarkGeometryBytes: 1024 * 1024,
});

const percentile = (xs, p) => {
  const a = [...xs].sort((x, y) => x - y);
  return a[Math.min(a.length - 1, Math.floor((a.length - 1) * p))] || 0;
};

async function waitForServer() {
  const end = Date.now() + 30000;
  while (Date.now() < end) {
    try { if ((await fetch(URL)).ok) return; } catch { /* retry */ }
    await new Promise((r) => setTimeout(r, 150));
  }
  throw new Error('preview server did not start');
}

async function sample(page, seconds, finishGpu, mode = 'static', flyTo = null) {
  return page.evaluate(async ({ duration, finishGpu, mode, flyTo }) => {
    const workMs = [];
    const cadenceMs = [];
    const app = window.__cave9;
    const renderer = window.__cave9.renderer;
    const gl = renderer.renderer.getContext();
    const readback = new Uint8Array(4);
    const resources = () => {
      const textures = new Map();
      const geometries = new Map();
      const materials = new Set();
      let geometryBytes = 0;
      const addTexture = (texture, key) => {
        if (!texture?.isTexture || textures.has(texture.uuid)) return;
        const image = texture.image;
        const width = image?.width || 0, height = image?.height || 0;
        textures.set(texture.uuid, { key, width, height,
          layers: image?.depth || 1, format: texture.format, type: texture.type,
          generateMipmaps: texture.generateMipmaps });
      };
      renderer.scene.traverse((object) => {
        if (object.geometry?.uuid && !geometries.has(object.geometry.uuid)) {
          const geometry = object.geometry;
          let bytes = geometry.index?.array?.byteLength || 0;
          for (const attribute of Object.values(geometry.attributes || {})) bytes += attribute?.array?.byteLength || 0;
          geometries.set(geometry.uuid, bytes);
          geometryBytes += bytes;
        }
        const list = Array.isArray(object.material) ? object.material : object.material ? [object.material] : [];
        for (const material of list) {
          materials.add(material.uuid);
          for (const key of Object.keys(material)) {
            addTexture(material[key], key);
          }
        }
      });
      addTexture(renderer.caveTexture, 'caveDetailMap');
      addTexture(renderer.caveSurfaceTexture, 'caveSurfaceArray');
      for (const [profile, pair] of renderer._surfaceReliefAssets || []) {
        addTexture(pair.normal, `${profile}ReliefNormal`);
        addTexture(pair.height, `${profile}ReliefHeight`);
      }
      addTexture(renderer.landmarkLayer?.rockMat?.map, 'landmarkGrainMap');
      addTexture(renderer.landmarkLayer?.grainTex, 'retainedLandmarkGrain');
      addTexture(renderer.landmarkLayer?.emberMask, 'landmarkEmberMask');
      const gameCache = app.game?.landmarkCache;
      return {
        landmarkGpuRooms: renderer.landmarkLayer?.built?.size ?? null,
        landmarkGpuKeys: [...(renderer.landmarkLayer?.built?.keys?.() || [])],
        compositionCacheRooms: gameCache?.size ?? null,
        compositionHits: gameCache?.hits ?? null,
        compositionMisses: gameCache?.misses ?? null,
        compositionCache: gameCache?.resourceMetrics?.() ?? null,
        landmarkGpuCache: renderer.landmarkLayer?.resourceMetrics?.() ?? null,
        rendererAssetPrewarm: { ...(renderer.assetMetrics || {}) },
        renderCapabilities: renderer.renderCapabilities?.() ?? null,
        caveGeometryRevision: renderer._geomKey ? {
          i: renderer._geomKey.i,
          capacity: renderer._geomKey.capacity,
          z: renderer._geomKey.z,
        } : null,
        geometryObjects: geometries.size,
        geometryBytes,
        materialCount: materials.size,
        textures: [...textures.values()],
        estimatedTextureBytes: 0, // calculated from format, layers and mips in Node
        rendererMemory: { ...renderer.renderer.info.memory },
        shaderPrograms: renderer.renderer.info.programs?.length ?? null,
        instrumentation: { ...(window.__cave9PerfMetrics || {}) },
        textureReadiness: {
          caveDetail: !!(renderer.caveTexture?.image?.width && renderer.caveFacet?.detailMap?.value === renderer.caveTexture),
          landmarkGrain: !!(renderer.landmarkLayer?.grainTex
            || renderer.landmarkLayer?.rockMat?.map)?.image?.width,
          landmarkGrainActive: !!renderer.landmarkLayer?.rockMat?.map?.image?.width,
          emberMask: !!renderer.landmarkLayer?.emberMask?.image?.width,
          surfaceRelief: !renderer.surfaceRelief || !!(
            renderer.caveFacet?.reliefNormalMap?.value?.image?.width
            && renderer.caveFacet?.reliefHeightMap?.value?.image?.width),
        },
      };
    };
    const resourceStart = resources();
    const heapStart = performance.memory?.usedJSHeapSize ?? null;
    let peakCalls = 0, peakTriangles = 0;
    const started = performance.now();
    do {
      const frameStarted = performance.now();
      const before = performance.now();
      if (mode === 'flythrough') app.visual.step(1);
      else app._holdFrame();
      gl.flush();
      const cpuWork = performance.now() - before;
      if (finishGpu) {
        // Headless compositors may discard an unchanged, never-presented
        // framebuffer. One-pixel readback forces full raster completion without
        // folding screenshot encoding or a fullscreen copy into the frame cost.
        gl.readPixels(gl.drawingBufferWidth >> 1, gl.drawingBufferHeight >> 1,
          1, 1, gl.RGBA, gl.UNSIGNED_BYTE, readback);
      }
      gl.finish(); // drain exactly one frame; never let the command queue grow
      // GPU pass includes completed wall work. CPU pass records submission only;
      // its finish is deliberately outside `cpuWork` to keep the gates separate.
      const work = finishGpu ? performance.now() - before : cpuWork;
      workMs.push(work);
      // `gl.finish()` above drains exactly one complete frame, so this cadence
      // is real end-to-end throughput without rAF or background-timer policy.
      cadenceMs.push(performance.now() - frameStarted);
      // A flythrough can finish after the formation has left the camera. The
      // last frame then contains only the cave and is not the resource peak.
      // Read Three's existing counters outside the timed work; no GL query or
      // scene traversal is needed to retain every submitted frame's maximum.
      peakCalls = Math.max(peakCalls, renderer.renderer.info.render.calls);
      peakTriangles = Math.max(peakTriangles, renderer.renderer.info.render.triangles);
    } while (performance.now() - started < duration * 1000
      && (mode !== 'flythrough' || app.visual.inspect().distance < flyTo));

    const info = renderer.renderer.info;
    const glError = gl.getError();
    const heap = performance.memory?.usedJSHeapSize ?? null;
    const resourceEnd = resources();
    const maxTextureDimension = Math.max(0, ...resourceEnd.textures.flatMap(
      (texture) => [texture.width || 0, texture.height || 0]));
    const visual = app.visual.inspect();
    return { workMs, cadenceMs, heap, calls: peakCalls, triangles: peakTriangles,
      endCalls: info.render.calls, endTriangles: info.render.triangles, glError,
      timerQuery: false, contextLost: gl.isContextLost(),
      drawingBuffer: [gl.drawingBufferWidth, gl.drawingBufferHeight],
      effectivePixelRatio: renderer.renderer.getPixelRatio(),
      qualityCap: renderer.maxPixelRatio,
      cacheStart: resourceStart.landmarkGpuRooms, cacheEnd: renderer.landmarkLayer.built.size, heapStart,
      textures: info.memory.textures, maxTextureDimension,
      resourceStart, resourceEnd,
      endDistance: visual.distance, crashed: visual.positioning?.crashed ?? false,
      activeFamily: visual.family?.active ?? [], requestedFamily: visual.family?.requested ?? null };
  }, { duration: seconds, finishGpu, mode, flyTo });
}

function summarize(raw) {
  raw.resourceStart = withTextureStorageEstimate(raw.resourceStart);
  raw.resourceEnd = withTextureStorageEstimate(raw.resourceEnd);
  const totalCadenceMs = raw.cadenceMs.reduce((a, b) => a + b, 0);
  let minRollingFps = Infinity;
  for (let i = 0, j = 0, sum = 0; i < raw.cadenceMs.length; i++) {
    sum += raw.cadenceMs[i];
    while (sum > 5000 && j < i) sum -= raw.cadenceMs[j++];
    if (sum >= 4500) minRollingFps = Math.min(minRollingFps, (i - j + 1) / sum * 1000);
  }
  return {
    frames: raw.workMs.length,
    averageFps: +(raw.workMs.length / totalCadenceMs * 1000).toFixed(2),
    minRollingFps: +(Number.isFinite(minRollingFps) ? minRollingFps
      : raw.workMs.length / Math.max(1, totalCadenceMs) * 1000).toFixed(2),
    p50Ms: +percentile(raw.workMs, 0.50).toFixed(2),
    p95Ms: +percentile(raw.workMs, 0.95).toFixed(2),
    p99Ms: +percentile(raw.workMs, 0.99).toFixed(2),
    heapMB: raw.heap == null ? null : +(raw.heap / 1048576).toFixed(1),
    heapGrowthMB: raw.heap == null || raw.heapStart == null ? null
      : +((raw.heap - raw.heapStart) / 1048576).toFixed(1),
    drawCalls: raw.calls, triangles: raw.triangles,
    endDrawCalls: raw.endCalls, endTriangles: raw.endTriangles,
    landmarkCacheRooms: raw.cacheEnd,
    landmarkCacheGrowth: raw.cacheEnd - raw.cacheStart,
    webglError: raw.glError,
    timerQuery: raw.timerQuery,
    contextLost: raw.contextLost,
    drawingBuffer: raw.drawingBuffer,
    effectivePixelRatio: raw.effectivePixelRatio,
    qualityCap: raw.qualityCap,
    textures: raw.textures,
    maxTextureDimension: raw.maxTextureDimension,
    firstFrameMs: +(raw.workMs[0] || 0).toFixed(2),
    endDistance: raw.endDistance,
    crashed: raw.crashed,
    requestedFamily: raw.requestedFamily,
    activeFamily: raw.activeFamily,
    resources: {
      measurement: 'scene traversal plus renderer/cache counters; upload time is represented by first-frame cost, not claimed as a GPU timer',
      start: raw.resourceStart,
      end: raw.resourceEnd,
      geometryByteGrowth: raw.resourceEnd.geometryBytes - raw.resourceStart.geometryBytes,
      estimatedTextureByteGrowth: raw.resourceEnd.estimatedTextureBytes - raw.resourceStart.estimatedTextureBytes,
      compositionHitDelta: raw.resourceEnd.compositionHits - raw.resourceStart.compositionHits,
      compositionMissDelta: raw.resourceEnd.compositionMisses - raw.resourceStart.compositionMisses,
      meshBuildDelta: raw.resourceEnd.landmarkGpuKeys.filter((key) => !raw.resourceStart.landmarkGpuKeys.includes(key)).length,
      measuredCompositionBuilds: raw.resourceEnd.instrumentation.compositionBuilds - raw.resourceStart.instrumentation.compositionBuilds,
      measuredCompositionBuildMs: +(raw.resourceEnd.instrumentation.compositionBuildMs
        - raw.resourceStart.instrumentation.compositionBuildMs).toFixed(3),
      measuredMeshBuilds: raw.resourceEnd.instrumentation.meshBuilds - raw.resourceStart.instrumentation.meshBuilds,
      measuredMeshBuildMs: +(raw.resourceEnd.instrumentation.meshBuildMs
        - raw.resourceStart.instrumentation.meshBuildMs).toFixed(3),
      measuredEvictions: raw.resourceEnd.instrumentation.evictions - raw.resourceStart.instrumentation.evictions,
      cpuCacheEvictionDelta: (raw.resourceEnd.compositionCache?.evictions ?? 0)
        - (raw.resourceStart.compositionCache?.evictions ?? 0),
      gpuCacheEvictionDelta: (raw.resourceEnd.landmarkGpuCache?.evictions ?? 0)
        - (raw.resourceStart.landmarkGpuCache?.evictions ?? 0),
      gpuRevisionReplacementDelta: (raw.resourceEnd.landmarkGpuCache?.revisionReplacements ?? 0)
        - (raw.resourceStart.landmarkGpuCache?.revisionReplacements ?? 0),
      gpuDisposedGeometryDelta: (raw.resourceEnd.landmarkGpuCache?.disposedGeometries ?? 0)
        - (raw.resourceStart.landmarkGpuCache?.disposedGeometries ?? 0),
      gpuPrewarmBuildDelta: (raw.resourceEnd.landmarkGpuCache?.prewarmBuilds ?? 0)
        - (raw.resourceStart.landmarkGpuCache?.prewarmBuilds ?? 0),
      gpuColdVisibleBuildDelta: (raw.resourceEnd.landmarkGpuCache?.coldVisibleBuilds ?? 0)
        - (raw.resourceStart.landmarkGpuCache?.coldVisibleBuilds ?? 0),
      gpuPrewarmActivationDelta: (raw.resourceEnd.landmarkGpuCache?.prewarmActivations ?? 0)
        - (raw.resourceStart.landmarkGpuCache?.prewarmActivations ?? 0),
      gpuProgramPrewarmDelta: (raw.resourceEnd.landmarkGpuCache?.programPrewarms ?? 0)
        - (raw.resourceStart.landmarkGpuCache?.programPrewarms ?? 0),
      gpuProgramPrewarmFailureDelta: (raw.resourceEnd.landmarkGpuCache?.programPrewarmFailures ?? 0)
        - (raw.resourceStart.landmarkGpuCache?.programPrewarmFailures ?? 0),
      gpuCacheOverBudget: raw.resourceEnd.landmarkGpuCache?.overBudget ?? null,
      uploadWarmupProxyMs: +(raw.workMs[0] || 0).toFixed(2),
      textureReadiness: raw.resourceEnd.textureReadiness,
    },
  };
}

async function runScenario(name, s, { cpuRate = 1, swiftshader = false } = {}) {
  const launchArgs = swiftshader
    ? ['--use-angle=swiftshader', '--enable-unsafe-swiftshader']
    : ['--use-angle=d3d11', '--enable-gpu', '--ignore-gpu-blocklist', '--disable-software-rasterizer'];
  const browser = await chromium.launch({
    headless: true,
    channel: BROWSER_CHANNEL,
    args: launchArgs,
  });
  try {
    const page = await browser.newPage({
      viewport: { width: VIEWPORT.width, height: VIEWPORT.height },
      deviceScaleFactor: VIEWPORT.dpr,
    });
    const browserInfo = { name: BROWSER_CHANNEL === 'chrome' ? 'Chrome' : 'Chromium',
      channel: BROWSER_CHANNEL, version: browser.version() };
    const errors = [];
    page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
    page.on('pageerror', (e) => errors.push(e.message));
    const cdp = await page.context().newCDPSession(page);
    if (cpuRate !== 1) await cdp.send('Emulation.setCPUThrottlingRate', { rate: cpuRate });
    await page.goto(URL, { waitUntil: 'load' });
    await page.waitForFunction(() => window.__cave9?.visual?.loadScenario && window.__cave9?.state !== 'boot');
    await page.evaluate(() => {
      const app = window.__cave9;
      const cache = app.game.landmarkCache;
      const layer = app.renderer.landmarkLayer;
      const metrics = window.__cave9PerfMetrics = {
        compositionCalls: 0, compositionBuilds: 0, compositionBuildMs: 0,
        meshBuilds: 0, meshBuildMs: 0, evictions: 0,
      };
      const compositionAt = cache.compositionAt.bind(cache);
      cache.compositionAt = (...callArgs) => {
        const misses = cache.misses;
        const started = performance.now();
        const result = compositionAt(...callArgs);
        metrics.compositionCalls++;
        if (cache.misses > misses) {
          metrics.compositionBuilds++;
          metrics.compositionBuildMs += performance.now() - started;
        }
        return result;
      };
      const buildGroup = layer._buildGroup.bind(layer);
      layer._buildGroup = (...callArgs) => {
        const started = performance.now();
        const result = buildGroup(...callArgs);
        metrics.meshBuilds++;
        metrics.meshBuildMs += performance.now() - started;
        return result;
      };
      const evict = layer._evict.bind(layer);
      layer._evict = (...callArgs) => { metrics.evictions++; return evict(...callArgs); };
    });
    const gpu = await page.evaluate(() => {
      const gl = window.__cave9.renderer.renderer.getContext();
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      return {
        vendor: ext ? gl.getParameter(ext.UNMASKED_VENDOR_WEBGL) : gl.getParameter(gl.VENDOR),
        renderer: ext ? gl.getParameter(ext.UNMASKED_RENDERER_WEBGL) : gl.getParameter(gl.RENDERER),
      };
    });
    const runtime = await page.evaluate(() => ({ userAgent: navigator.userAgent, platform: navigator.platform }));
    console.log(`[perf:sim] ${name}/${s.name}: load VisualScenarioV1 at ${s.distance}m`);
    const loaded = await page.evaluate((o) => {
      const snapshot = window.__cave9.visual.loadScenario({
        version: 'VisualScenarioV1', seed: o.seed, distance: o.distance,
        placement: 'place', control: 'autopilot', paused: true,
        family: o.family, camera: 'hero', viewport: o.viewport,
        settings: {
          motion: 1, landmarks: o.landmarks && o.family !== 'off', rockDetail: o.rockDetail,
          surfaceRelief: o.surfaceRelief,
          cave: o.cave, readability: true, wireframe: false, landmarkMesh: true,
          collisionCapsules: false, booleanTube: false, playerHull: false, frames: false,
          fog: true, material: true, light: true, brightness: 1, fov: 45,
        },
      });
      return { snapshot, api: 'window.__cave9.visual.loadScenario+step+inspect' };
    }, { ...s, viewport: VIEWPORT, landmarks: LANDMARKS, rockDetail: ROCK_DETAIL,
      surfaceRelief: SURFACE_RELIEF, cave: CAVE });
    await page.evaluate((quality) => window.__cave9.renderer.setQuality(quality), QUALITY);
    if (SURFACE_RELIEF) {
      await page.evaluate(async () => {
        await window.__cave9.renderer.surfaceReliefReady();
        window.__cave9.visual.step(0);
      });
    }
    if (PAIR_SWEEP) {
      await page.evaluate(({ from, count }) => {
        const renderer = window.__cave9.renderer;
        renderer._updateCaveDrawRange = () => {
          renderer.caveGeo.setDrawRange(from * 32 * 6, count * 32 * 6);
        };
      }, { from: PAIR_FROM, count: PAIR_COUNT });
    }
    console.log(`[perf:sim] ${name}/${s.name}: warm-up ${WARMUP_S}s`);
    const warmup = summarize(await sample(page, WARMUP_S, swiftshader, 'static', null));
    if (s.mode === 'flythrough') {
      await page.evaluate((o) => window.__cave9.visual.loadScenario({
        version: 'VisualScenarioV1', seed: o.seed, distance: o.distance,
        placement: 'place', control: 'autopilot', paused: true,
        family: o.family,
        camera: 'hero', viewport: o.viewport,
        settings: { motion: 1, landmarks: o.landmarks && o.family !== 'off', rockDetail: o.rockDetail,
          surfaceRelief: o.surfaceRelief,
          cave: o.cave, readability: true, wireframe: false, landmarkMesh: true,
          collisionCapsules: false, booleanTube: false, playerHull: false, frames: false,
          fog: true, material: true, light: true, brightness: 1, fov: 45 },
      }), { ...s, viewport: VIEWPORT, landmarks: LANDMARKS, rockDetail: ROCK_DETAIL,
        surfaceRelief: SURFACE_RELIEF, cave: CAVE });
      await page.evaluate((quality) => window.__cave9.renderer.setQuality(quality), QUALITY);
      if (SURFACE_RELIEF) await page.evaluate(async () => {
        await window.__cave9.renderer.surfaceReliefReady();
        window.__cave9.visual.step(0);
      });
    }
    console.log(`[perf:sim] ${name}/${s.name}: sample ${SAMPLE_S}s`);
    const scenario = { ...s, captureApi: loaded.api, loadedSnapshot: loaded.snapshot,
      warmup, ...summarize(await sample(page, SAMPLE_S, swiftshader, s.mode, s.flyTo)) };
    console.log(`[perf:sim] ${name}/${s.name}: done`);
    return { browser: { ...browserInfo, ...runtime }, gpu, errors, scenario };
  } finally {
    await browser.close();
  }
}

async function runPass(name, options = {}) {
  const results = [];
  // A fresh browser per scenario prevents long-running timer-query/driver state
  // from one scene contaminating the next. Each 90-second sample still proves
  // its own cache stability; aggregate resource maxima cover the complete pass.
  for (const s of SCENARIOS) results.push(await runScenario(name, s, options));
  return {
    name, cpuRate: options.cpuRate ?? 1, swiftshader: !!options.swiftshader,
    browser: results[0].browser, gpu: results[0].gpu,
    errors: results.flatMap((r) => r.errors),
    scenarios: results.map((r) => r.scenario),
  };
}

function aggregateCases(scenarios) {
  const groups = new Map();
  for (const scenario of scenarios) {
    const key = `${scenario.seed}:${scenario.distance}:${scenario.family}:${scenario.mode}`;
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(scenario);
  }
  return [...groups.entries()].map(([key, runs]) => ({
    key,
    seed: runs[0].seed,
    distance: runs[0].distance,
    family: runs[0].family,
    mode: runs[0].mode,
    repetitions: runs.length,
    medianP95Ms: +percentile(runs.map((run) => run.p95Ms), 0.5).toFixed(2),
    worstP95Ms: +Math.max(...runs.map((run) => run.p95Ms)).toFixed(2),
    worstP99Ms: +Math.max(...runs.map((run) => run.p99Ms)).toFixed(2),
    minimumRollingFps: +Math.min(...runs.map((run) => run.minRollingFps)).toFixed(2),
    maximumTransitionFrameMs: +Math.max(...runs.map((run) => run.firstFrameMs)).toFixed(2),
    crashes: runs.filter((run) => run.crashed).length,
  }));
}

const server = spawn(process.execPath,
  [resolve('node_modules/vite/bin/vite.js'), 'preview', '--port', String(PORT), '--strictPort'], {
  cwd: process.cwd(), shell: false, stdio: 'ignore',
});
try {
  await waitForServer();
  const cpu = await runPass('cpu-4x', { cpuRate: 4 });
  const gpu = await runPass('swiftshader', { swiftshader: true });
  const diagnostic = await runPass('cpu-4x-swiftshader', { cpuRate: 4, swiftshader: true });
  // The deliberately over-constrained combined pass is evidence only. Keep it
  // out of every release aggregate as well as the timing gates.
  const releaseScenarios = [...cpu.scenarios, ...gpu.scenarios];
  const fragmentHasFbm = compiledMineralFragmentHasFbm();
  const textureBudget = textureBudgetMetrics(releaseScenarios.map((s) => s.resources.end));
  const resources = {
    fragmentHasFbm,
    maxDrawCalls: Math.max(...releaseScenarios.map((s) => s.drawCalls)),
    maxTriangles: Math.max(...releaseScenarios.map((s) => s.triangles)),
    maxHeapMB: Math.max(0, ...releaseScenarios.map((s) => s.heapMB || 0)),
    maxCacheRooms: Math.max(...releaseScenarios.map((s) => s.landmarkCacheRooms)),
    maxCacheGrowth: Math.max(...releaseScenarios.map((s) => s.landmarkCacheGrowth)),
    maxCompositionCacheRooms: Math.max(0, ...releaseScenarios.map(
      (s) => s.resources.end.compositionCache?.rooms ?? 0)),
    maxConfiguredCompositionCacheRooms: Math.max(0, ...releaseScenarios.map(
      (s) => s.resources.end.compositionCache?.maxRooms ?? Infinity)),
    maxLandmarkGeometryBytes: Math.max(0, ...releaseScenarios.map(
      (s) => s.resources.end.landmarkGpuCache?.geometryBytes ?? 0)),
    maxPeakLandmarkGeometryBytes: Math.max(0, ...releaseScenarios.map(
      (s) => s.resources.end.landmarkGpuCache?.peakGeometryBytes ?? 0)),
    anyLandmarkCacheOverBudget: releaseScenarios.some(
      (s) => s.resources.end.landmarkGpuCache?.overBudget !== false),
    ...textureBudget,
    maxTextures: Math.max(...releaseScenarios.map((s) => s.textures)),
    anyAssetPrewarmFailure: releaseScenarios.some((s) => {
      const metrics = s.resources.end.rendererAssetPrewarm ?? {};
      return (metrics.texturePrewarmFailures ?? 0) > 0
        || (metrics.caveProgramPrewarmFailures ?? 0) > 0
        || (metrics.landmarkProgramPrewarmFailures ?? 0) > 0
        || (metrics.reliefLoadFailures ?? 0) > 0;
    }),
  };
  const noWebglErrors = releaseScenarios.every((s) => s.webglError === 0);
  const gpuIdentity = (pass) => `${pass.gpu.vendor || ''} ${pass.gpu.renderer || ''}`;
  const cpuUsesHardwareGpu = !!cpu.gpu.renderer && !/swiftshader/i.test(gpuIdentity(cpu));
  const gpuUsesSwiftShader = /swiftshader/i.test(gpuIdentity(gpu));
  const hardwareRockDetailActive = !ROCK_DETAIL || cpu.scenarios.every((s) =>
    s.loadedSnapshot?.renderCapabilities?.rockDetailRequested === true
    && s.loadedSnapshot?.renderCapabilities?.rockFacetActive === true
    && s.loadedSnapshot?.renderCapabilities?.rockFacetSoftwareFallback === false
    && s.loadedSnapshot?.renderCapabilities?.rockDetailSampleActive === true
    && s.loadedSnapshot?.renderCapabilities?.rockDetailSoftwareFallback === false);
  const softwareRockDetailFallback = !ROCK_DETAIL || gpu.scenarios.every((s) =>
    s.loadedSnapshot?.renderCapabilities?.rockDetailRequested === true
    && s.loadedSnapshot?.renderCapabilities?.rockFacetActive === false
    && s.loadedSnapshot?.renderCapabilities?.rockFacetSoftwareFallback === true
    && s.loadedSnapshot?.renderCapabilities?.rockDetailSampleActive === false
    && s.loadedSnapshot?.renderCapabilities?.rockDetailSoftwareFallback === true);
  const hardwareLandmarkMaterialActive = cpu.scenarios.every((s) =>
    s.loadedSnapshot?.renderCapabilities?.landmarkMineralActive === true
    && s.loadedSnapshot?.renderCapabilities?.landmarkRimActive === true
    && s.loadedSnapshot?.renderCapabilities?.landmarkSoftwareFallback === false
    && s.loadedSnapshot?.renderCapabilities?.landmarkLightingModel === 'standard');
  const softwareLandmarkMaterialFallback = gpu.scenarios.every((s) =>
    s.loadedSnapshot?.renderCapabilities?.landmarkMineralActive === false
    && s.loadedSnapshot?.renderCapabilities?.landmarkRimActive === true
    && s.loadedSnapshot?.renderCapabilities?.landmarkSoftwareFallback === true
    && s.loadedSnapshot?.renderCapabilities?.landmarkLightingModel === 'lambert');
  const surfaceReliefPolicy = !SURFACE_RELIEF || (
    cpu.scenarios.every((s) =>
      s.loadedSnapshot?.renderCapabilities?.surfaceReliefRequested === true
      && s.loadedSnapshot?.renderCapabilities?.surfaceReliefActive === true
      && ['cave', 'coiling'].includes(
        s.loadedSnapshot?.renderCapabilities?.surfaceReliefProfile)
      && s.loadedSnapshot?.renderCapabilities?.surfaceReliefSoftwareFallback === false)
    && gpu.scenarios.every((s) =>
      s.loadedSnapshot?.renderCapabilities?.surfaceReliefRequested === true
      && s.loadedSnapshot?.renderCapabilities?.surfaceReliefActive === false
      && s.loadedSnapshot?.renderCapabilities?.surfaceReliefProfile === null
      && s.loadedSnapshot?.renderCapabilities?.surfaceReliefSoftwareFallback === true));
  const coilingRimPolicy = cpu.scenarios.every((s) => coilingRimPolicyPass(s, false))
    && gpu.scenarios.every((s) => coilingRimPolicyPass(s, true));
  const gateResults = {
    cpuUsesHardwareGpu,
    gpuUsesSwiftShader,
    rockDetailPolicy: hardwareRockDetailActive && softwareRockDetailFallback,
    surfaceReliefPolicy,
    landmarkMaterialPolicy: hardwareLandmarkMaterialActive && softwareLandmarkMaterialFallback,
    coilingRimPolicy,
    scenarioContract: SCENARIOS.length === FILTERED_SCENARIOS.length * requestedFamilies.length
      * requestedModes.length * REPETITIONS
      && cpu.scenarios.length === SCENARIOS.length && gpu.scenarios.length === SCENARIOS.length
      && releaseScenarios.every(perfScenarioContractPass)
      && releaseScenarios.every((s) => s.qualityCap === QUALITY
        && s.effectivePixelRatio === effectiveRenderPixelRatio(VIEWPORT.dpr, QUALITY)
        && s.drawingBuffer[0] === drawingBufferSize(VIEWPORT.width, VIEWPORT.height,
          s.effectivePixelRatio)[0]
        && s.drawingBuffer[1] === drawingBufferSize(VIEWPORT.width, VIEWPORT.height,
          s.effectivePixelRatio)[1]),
    cpu: cpuUsesHardwareGpu && cpu.errors.length === 0 && cpu.scenarios.every((s) => !s.contextLost && s.webglError === 0 &&
      !s.crashed && s.drawCalls > 0 && s.p95Ms <= LIMITS.cpuP95Ms),
    gpu: gpuUsesSwiftShader && gpu.errors.length === 0 && gpu.scenarios.every((s) => s.webglError === 0 &&
      !s.contextLost && !s.crashed && s.drawCalls > 0 && s.p95Ms <= LIMITS.swiftshaderP95Ms
      && s.p99Ms <= LIMITS.swiftshaderP99Ms &&
      s.minRollingFps >= LIMITS.swiftshaderMinRollingFps),
    resources: noWebglErrors && !fragmentHasFbm
      && hardwareRockDetailActive && softwareRockDetailFallback
      && surfaceReliefPolicy
      && hardwareLandmarkMaterialActive && softwareLandmarkMaterialFallback
      && coilingRimPolicy &&
      resources.maxDrawCalls <= LIMITS.drawCalls && resources.maxTriangles <= LIMITS.triangles &&
      resources.maxHeapMB <= LIMITS.heapMB && resources.maxCacheRooms <= LIMITS.landmarkGeometryRooms
      && resources.maxCompositionCacheRooms <= LIMITS.compositionCacheRooms
      && resources.maxConfiguredCompositionCacheRooms <= LIMITS.compositionCacheRooms
      && resources.maxLandmarkGeometryBytes <= LIMITS.landmarkGeometryBytes
      && resources.maxPeakLandmarkGeometryBytes <= LIMITS.landmarkGeometryBytes
      && !resources.anyLandmarkCacheOverBudget
      && !resources.anyAssetPrewarmFailure
      && resources.maxTextureDimension <= LIMITS.textureDimension
      && resources.maxEstimatedTextureBytes <= LIMITS.textureBytes,
  };
  const pass = gateResults.scenarioContract && gateResults.cpu && gateResults.gpu && gateResults.resources;
  const sourceProvenance = {
    git: await gitProvenance(process.cwd()),
    runtime: runtimeFingerprint(process.cwd()),
  };
  const report = {
    capturedAt: new Date().toISOString(),
    evidenceValid: EVIDENCE_VALID,
    verdict: EVIDENCE_VALID ? (pass ? 'pass' : 'fail') : 'diagnostic',
    claim: 'simulated target boundaries only; real GMKtec hardware untested',
    viewport: [VIEWPORT.width, VIEWPORT.height], dpr: VIEWPORT.dpr,
    quality: QUALITY, warmupSeconds: WARMUP_S, sampleSeconds: SAMPLE_S,
    rockDetail: ROCK_DETAIL,
    surfaceRelief: SURFACE_RELIEF,
    landmarks: LANDMARKS,
    cave: CAVE,
    pairSweep: PAIR_SWEEP ? { from: PAIR_FROM, count: PAIR_COUNT } : null,
    contract: {
      releaseRequested: RELEASE,
      families: requestedFamilies,
      modes: requestedModes,
      checkpoints: BASE_SCENARIOS.map(({ name, seed, distance }) => ({ name, seed, distance })),
      scenarioFilterRequested, checkpointOverrideRequested,
      repetitions: REPETITIONS,
      flySpanMeters: FLY_SPAN,
      captureApi: 'window.__cave9.visual.loadScenario+step+inspect',
    },
    source: sourceProvenance,
    limits: LIMITS, gateResults,
    cpu: { ...cpu, caseAggregates: aggregateCases(cpu.scenarios) },
    gpu: { ...gpu, caseAggregates: aggregateCases(gpu.scenarios) },
    diagnostic: { ...diagnostic, caseAggregates: aggregateCases(diagnostic.scenarios), releaseGate: false }, resources,
  };
  const stamp = report.capturedAt.replace(/[-:]/g, '').replace(/\.\d{3}Z$/, 'Z');
  const requestedOutput = rawValue('--output', process.env.PERF_OUTPUT || '');
  const outputFile = requestedOutput
    ? resolve(requestedOutput)
    : resolve('artifacts/perf-sim', `${stamp}-${sourceProvenance.git.shortCommit}`, 'report.json');
  mkdirSync(dirname(outputFile), { recursive: true });
  writeFileSync(outputFile, JSON.stringify(report, null, 2) + '\n');
  console.log(`[perf:sim] report ${outputFile}`);
  console.log(JSON.stringify({ verdict: report.verdict, evidenceValid: report.evidenceValid,
    gateResults: report.gateResults,
    cpuCases: report.cpu.caseAggregates,
    gpuCases: report.gpu.caseAggregates }, null, 2));
  if (EVIDENCE_VALID && !pass) process.exitCode = 1;
} finally {
  server.kill();
}
