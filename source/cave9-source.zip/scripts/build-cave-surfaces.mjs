/**
 * Builds the runtime colour texture transport sheet for Cave9.
 *
 * The sheet deliberately contains unpadded 128px cells. At runtime every cell
 * becomes one DataArrayTexture layer, so mipmaps can never bleed between tiles.
 */
import { existsSync, readFileSync, writeFileSync, mkdirSync, statSync } from 'node:fs';
import { dirname, relative, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { PNG } from 'pngjs';

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const ASSET_DIR = resolve(ROOT, 'public/assets');
const PREVIEW_DIR = resolve(ROOT, 'docs/assets');
const CONTACT_SHEET = resolve(PREVIEW_DIR, 'cave-surfaces-contact-sheet.png');
const TUNNEL_MANIFEST = resolve(ROOT, 'artifacts/texture-concepts/tunnel-positional-v1-v8/manifest.json');
const FAMILY_MANIFEST = resolve(ROOT, 'artifacts/texture-concepts/layered-families/manifest.json');
const CELL = 128;
const COLUMNS = 8;
const ROWS = 7;
const LAYER_COUNT = 53;

const TUNNEL_ORDER = ['neutral', 'floor', 'sideWall', 'ceiling'];
const FAMILY_ORDER = ['layerA', 'layerB', 'layerC', 'lava', 'floor', 'sideWall', 'ceiling'];

function srgbToLinear(value) {
  const srgb = value / 255;
  return srgb <= 0.04045 ? srgb / 12.92 : ((srgb + 0.055) / 1.055) ** 2.4;
}

function meanLinear(png) {
  const sum = [0, 0, 0];
  const pixelCount = png.width * png.height;
  for (let offset = 0; offset < png.data.length; offset += 4) {
    const alpha = png.data[offset + 3] / 255;
    sum[0] += srgbToLinear(png.data[offset]) * alpha;
    sum[1] += srgbToLinear(png.data[offset + 1]) * alpha;
    sum[2] += srgbToLinear(png.data[offset + 2]) * alpha;
  }
  return sum.map((channel) => Number((channel / pixelCount).toFixed(8)));
}

function paletteSize(png) {
  const colors = new Set();
  for (let offset = 0; offset < png.data.length; offset += 4) {
    colors.add(`${png.data[offset]},${png.data[offset + 1]},${png.data[offset + 2]},${png.data[offset + 3]}`);
  }
  return colors.size;
}

function assertSeamless(png, source) {
  for (let y = 0; y < png.height; y++) {
    const left = y * png.width * 4;
    const right = left + (png.width - 1) * 4;
    for (let channel = 0; channel < 4; channel++) {
      if (png.data[left + channel] !== png.data[right + channel]) {
        throw new Error(`${source}: horizontal edge mismatch at row ${y}, channel ${channel}`);
      }
    }
  }
  for (let x = 0; x < png.width; x++) {
    const top = x * 4;
    const bottom = ((png.height - 1) * png.width + x) * 4;
    for (let channel = 0; channel < 4; channel++) {
      if (png.data[top + channel] !== png.data[bottom + channel]) {
        throw new Error(`${source}: vertical edge mismatch at column ${x}, channel ${channel}`);
      }
    }
  }
}

function meanLinearRegion(png, x, y, width, height) {
  const sum = [0, 0, 0];
  for (let row = y; row < y + height; row++) {
    for (let column = x; column < x + width; column++) {
      const offset = (row * png.width + column) * 4;
      const alpha = png.data[offset + 3] / 255;
      sum[0] += srgbToLinear(png.data[offset]) * alpha;
      sum[1] += srgbToLinear(png.data[offset + 1]) * alpha;
      sum[2] += srgbToLinear(png.data[offset + 2]) * alpha;
    }
  }
  return sum.map((channel) => Number((channel / (width * height)).toFixed(8)));
}

function assertRuntimeManifest(manifest) {
  if (manifest.version !== 'CaveSurfaceRuntimeV1') throw new Error('Unexpected cave surface runtime manifest version');
  if (manifest.width !== CELL || manifest.height !== CELL || manifest.layerCount !== LAYER_COUNT
    || manifest.columns !== COLUMNS || manifest.rows !== ROWS || !Array.isArray(manifest.layers)
    || manifest.layers.length !== LAYER_COUNT) throw new Error('Invalid cave surface runtime manifest layout');
  const ids = new Set();
  for (const [index, layer] of manifest.layers.entries()) {
    if (layer.index !== index || typeof layer.id !== 'string' || ids.has(layer.id)) {
      throw new Error(`Invalid cave surface layer at index ${index}`);
    }
    ids.add(layer.id);
    const expectedX = (index % COLUMNS) * CELL;
    const expectedY = Math.floor(index / COLUMNS) * CELL;
    if (layer.atlas?.x !== expectedX || layer.atlas?.y !== expectedY
      || layer.atlas?.width !== CELL || layer.atlas?.height !== CELL) {
      throw new Error(`${layer.id}: invalid atlas cell`);
    }
    if (!Array.isArray(layer.meanLinear) || !layer.meanLinear.every((value) => Number.isFinite(value) && value >= 0 && value <= 1)) {
      throw new Error(`${layer.id}: invalid linear colour mean`);
    }
  }
}

// A clean checkout contains the delivered atlas and manifest plus this checked-in
// documentation preview, but deliberately not the large concept-art source tree.
// Check mode therefore validates the shipped contract directly. Generation still
// consumes those optional art sources, preserving the authoring workflow.
export function checkCaveSurfaces() {
  const manifestPath = resolve(ASSET_DIR, 'cave-surfaces.manifest.json');
  if (!existsSync(manifestPath)) throw new Error('Missing committed cave surface runtime manifest');
  const manifest = JSON.parse(readFileSync(manifestPath, 'utf8'));
  assertRuntimeManifest(manifest);

  const sourcePath = resolve(ASSET_DIR, manifest.sourceImage);
  const contactPath = CONTACT_SHEET;
  if (!existsSync(sourcePath) || !existsSync(contactPath)) throw new Error('Missing committed cave surface runtime or preview image');
  const source = PNG.sync.read(readFileSync(sourcePath));
  const contact = PNG.sync.read(readFileSync(contactPath));
  const expectedWidth = CELL * COLUMNS;
  const expectedHeight = CELL * ROWS;
  if (source.width !== expectedWidth || source.height !== expectedHeight
    || contact.width !== expectedWidth || contact.height !== expectedHeight) {
    throw new Error('Invalid cave surface transport image dimensions');
  }
  for (const layer of manifest.layers) {
    const { x, y, width, height } = layer.atlas;
    const tile = new PNG({ width, height, colorType: 6 });
    PNG.bitblt(source, tile, x, y, width, height, 0, 0);
    assertSeamless(tile, layer.id);
    const actualMean = meanLinearRegion(source, x, y, width, height);
    if (JSON.stringify(actualMean) !== JSON.stringify(layer.meanLinear)) {
      throw new Error(`${layer.id}: runtime colour mean differs from manifest`);
    }
    for (let row = 0; row < height; row++) {
      for (let column = 0; column < width; column++) {
        const offset = ((y + row) * source.width + x + column) * 4;
        for (let channel = 0; channel < 4; channel++) {
          if (source.data[offset + channel] !== contact.data[offset + channel]) {
            throw new Error(`${layer.id}: contact sheet differs from runtime transport at ${column},${row}`);
          }
        }
      }
    }
  }
  return manifest;
}

// Concept sources are visually tileable, but a few have one-pixel anti-aliased
// edge deltas. Array layers need bit-exact edges for repeat sampling, so the
// runtime copy locks the final row/column to the first row/column without
// changing the source artwork or introducing palette colours.
function seamLock(source) {
  const png = new PNG({ width: source.width, height: source.height, colorType: 6 });
  source.data.copy(png.data);
  for (let y = 0; y < png.height; y++) {
    const from = y * png.width * 4;
    const to = from + (png.width - 1) * 4;
    png.data.copy(png.data, to, from, from + 4);
  }
  for (let x = 0; x < png.width; x++) {
    const from = x * 4;
    const to = ((png.height - 1) * png.width + x) * 4;
    png.data.copy(png.data, to, from, from + 4);
  }
  return png;
}

function makeLayer({ id, family = null, variant = null, role, source, directional, transforms }) {
  return { id, family, variant, role, source, directional, transforms };
}

function layerDefinitions() {
  const tunnel = JSON.parse(readFileSync(TUNNEL_MANIFEST, 'utf8'));
  const families = JSON.parse(readFileSync(FAMILY_MANIFEST, 'utf8'));
  const tunnelDir = dirname(TUNNEL_MANIFEST);
  const familyDir = dirname(FAMILY_MANIFEST);
  const layers = [];

  for (const [manifestVariant, entries] of Object.entries(tunnel.variants)) {
    const variant = manifestVariant.match(/^v\d+/)?.[0];
    if (!variant) throw new Error(`Cannot derive stable variant id from ${manifestVariant}`);
    const directional = ['v2', 'v6', 'v7'].includes(variant);
    const transforms = directional ? ['mirrorX', 'rotate180'] : ['mirrorX', 'mirrorY', 'rotate90', 'rotate180', 'rotate270'];
    for (const role of TUNNEL_ORDER) {
      layers.push(makeLayer({
        id: `tunnel.${variant}.${role}`,
        variant,
        role,
        source: resolve(tunnelDir, entries[role]),
        directional,
        transforms,
      }));
    }
  }

  for (const familyName of ['branching', 'crystal', 'coiling']) {
    const family = families.families[familyName];
    if (!family) throw new Error(`Missing family ${familyName}`);
    const sourceByRole = {
      layerA: family.layers[0],
      layerB: family.layers[1],
      layerC: family.layers[2],
      lava: family.floor,
      floor: family.positionalSurfaces.floor,
      sideWall: family.positionalSurfaces.sideWall,
      ceiling: family.positionalSurfaces.ceiling,
    };
    for (const role of FAMILY_ORDER) {
      const directional = role.startsWith('layer');
      layers.push(makeLayer({
        id: `family.${familyName}.${role}`,
        family: familyName,
        role,
        source: resolve(familyDir, sourceByRole[role]),
        directional,
        transforms: directional ? ['mirrorX', 'rotate180'] : ['mirrorX', 'mirrorY', 'rotate90', 'rotate180', 'rotate270'],
      }));
    }
  }
  if (layers.length !== LAYER_COUNT) throw new Error(`Expected ${LAYER_COUNT} layers, got ${layers.length}`);
  return layers;
}

export function buildCaveSurfaces({ checkOnly = false } = {}) {
  if (checkOnly) return checkCaveSurfaces();
  const layers = layerDefinitions();
  const sheet = new PNG({ width: CELL * COLUMNS, height: CELL * ROWS, colorType: 6 });
  const contact = new PNG({ width: CELL * COLUMNS, height: CELL * ROWS, colorType: 6 });
  sheet.data.fill(0);
  // A subtle opaque backing makes the intentionally unused three contact cells explicit.
  for (let offset = 0; offset < contact.data.length; offset += 4) {
    contact.data[offset] = 9; contact.data[offset + 1] = 12; contact.data[offset + 2] = 18; contact.data[offset + 3] = 255;
  }

  const manifestLayers = layers.map((layer, index) => {
    if (!statSync(layer.source).isFile()) throw new Error(`Missing layer source ${layer.source}`);
    const sourcePng = PNG.sync.read(readFileSync(layer.source));
    if (sourcePng.width !== CELL || sourcePng.height !== CELL) throw new Error(`${layer.source}: expected ${CELL}x${CELL}, got ${sourcePng.width}x${sourcePng.height}`);
    const colors = paletteSize(sourcePng);
    if (colors > 12) throw new Error(`${layer.source}: palette has ${colors} colors, expected at most 12`);
    const png = seamLock(sourcePng);
    assertSeamless(png, layer.source);
    const x = (index % COLUMNS) * CELL;
    const y = Math.floor(index / COLUMNS) * CELL;
    PNG.bitblt(png, sheet, 0, 0, CELL, CELL, x, y);
    PNG.bitblt(png, contact, 0, 0, CELL, CELL, x, y);
    return {
      id: layer.id,
      index,
      family: layer.family,
      variant: layer.variant,
      role: layer.role,
      meanLinear: meanLinear(png),
      directional: layer.directional,
      transforms: layer.transforms,
      source: relative(ROOT, layer.source).replaceAll('\\', '/'),
      atlas: { x, y, width: CELL, height: CELL },
    };
  });
  const ids = new Set(manifestLayers.map(({ id }) => id));
  if (ids.size !== LAYER_COUNT || manifestLayers.some((layer, index) => layer.index !== index)) throw new Error('Layer ids or indices are not unique and contiguous');

  const manifest = {
    version: 'CaveSurfaceRuntimeV1',
    width: CELL,
    height: CELL,
    layerCount: LAYER_COUNT,
    columns: COLUMNS,
    rows: ROWS,
    sourceImage: 'cave-surfaces-source.png',
    layers: manifestLayers,
  };

  if (!checkOnly) {
    mkdirSync(ASSET_DIR, { recursive: true });
    mkdirSync(PREVIEW_DIR, { recursive: true });
    writeFileSync(resolve(ASSET_DIR, manifest.sourceImage), PNG.sync.write(sheet));
    writeFileSync(CONTACT_SHEET, PNG.sync.write(contact));
    writeFileSync(resolve(ASSET_DIR, 'cave-surfaces.manifest.json'), `${JSON.stringify(manifest, null, 2)}\n`);
  }
  return manifest;
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const manifest = buildCaveSurfaces({ checkOnly: process.argv.includes('--check') });
  console.log(`Validated ${manifest.layerCount} Cave9 surface layers (${manifest.columns}x${manifest.rows}).`);
}
