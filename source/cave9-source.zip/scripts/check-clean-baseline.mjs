import { execFileSync, spawnSync } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const OMITTED_TOP_LEVEL = new Set(['.codex-tmp', '.git', 'artifacts', 'dist', 'node_modules']);
const dryRun = process.argv.includes('--dry-run');

function trackedAndRelevantNewFiles() {
  const output = execFileSync('git', ['ls-files', '--cached', '--others', '--exclude-standard', '-z'], {
    cwd: ROOT,
    encoding: 'buffer',
  });
  return output.toString('utf8').split('\0').filter(Boolean).filter((relative) => {
    const parts = relative.replaceAll('\\', '/').split('/');
    return !OMITTED_TOP_LEVEL.has(parts[0]);
  });
}

function copyWorkingTree(destination, files) {
  for (const relative of files) {
    const source = path.resolve(ROOT, relative);
    const target = path.resolve(destination, relative);
    if (!source.startsWith(`${ROOT}${path.sep}`) || !target.startsWith(`${destination}${path.sep}`)) {
      throw new Error(`Refusing to copy a path outside the check roots: ${relative}`);
    }
    // `git ls-files --cached` also reports a tracked file removed from the
    // working tree but not yet staged. The isolated copy must reflect that
    // current deletion instead of failing while trying to copy it.
    if (!fs.existsSync(source)) continue;
    fs.mkdirSync(path.dirname(target), { recursive: true });
    fs.copyFileSync(source, target);
  }
}

function run(command, args, cwd) {
  const result = spawnSync(command, args, { cwd, shell: process.platform === 'win32', stdio: 'inherit' });
  if (result.error) throw result.error;
  if (result.status !== 0) throw new Error(`${command} ${args.join(' ')} failed with exit code ${result.status}`);
}

const files = trackedAndRelevantNewFiles();
const checkRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'cave9-clean-baseline-'));
const resolvedCheckRoot = path.resolve(checkRoot);
const resolvedTempRoot = path.resolve(os.tmpdir());

try {
  copyWorkingTree(checkRoot, files);
  console.log(`Copied ${files.length} current source files to ${checkRoot}`);
  console.log('Excluded top-level directories: .codex-tmp, .git, artifacts, dist, node_modules');
  if (!dryRun) {
    const npm = process.platform === 'win32' ? 'npm.cmd' : 'npm';
    run(npm, ['ci'], checkRoot);
    run(npm, ['test'], checkRoot);
    run(npm, ['run', 'build'], checkRoot);
  }
} finally {
  const validTemporaryTarget = resolvedCheckRoot.startsWith(`${resolvedTempRoot}${path.sep}`)
    && path.basename(resolvedCheckRoot).startsWith('cave9-clean-baseline-');
  if (!validTemporaryTarget) throw new Error(`Refusing to remove unexpected check directory: ${resolvedCheckRoot}`);
  fs.rmSync(resolvedCheckRoot, { recursive: true, force: true });
}
