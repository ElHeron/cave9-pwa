// npm run style — how far the game currently is from the reference, per axis.
//
// This is the loop the landmark work was missing. Every other gate answers "did
// this change what was there before?"; this one answers "is this closer to what
// we want?", by computing the SAME descriptors on captures that ref-profile.mjs
// computes on the reference frames.
//
// Captures a DEPTH LADDER rather than a single frame, because the target is a
// morph: shallow depths should still look like the original cave9 and only deep
// ones should approach the reference (see LANDMARK_STRATEGY.md). A change that
// helps at 2000 m and wrecks 250 m is a regression, and one frame hides that.
//
// Reads docs/measure/reference-target.json — run `npm run ref:profile` first.

import { spawn } from 'node:child_process';
import { mkdirSync, writeFileSync, readFileSync, existsSync } from 'node:fs';
import { resolve, join, basename } from 'node:path';
import { chromium } from 'playwright';
import { describe, AXES, axisValue } from './lib/frame-metrics.mjs';
import { styleAt, STYLE_FULL } from '../src/core/Difficulty.js';
import { fileSha256, gitProvenance, runtimeFingerprint } from './visual/provenance.mjs';

const PORT = 5189; // distinct from capture.mjs (5188) so both can run
const OUT = resolve(process.cwd(), 'docs/measure');
const SHOTS = resolve(process.cwd(), 'docs/screenshots/style');
const TARGET = join(OUT, 'reference-target.json');
const TOOL = resolve('scripts/style-report.mjs');

function provenance() {
  return { runtime: runtimeFingerprint(), toolSha256: fileSha256(TOOL) };
}

async function renderState(page) {
  return page.evaluate(() => {
    const renderer = window.__cave9?.renderer;
    const gl = renderer?.renderer?.getContext?.();
    const renderCaps = renderer?.renderCapabilities?.() ?? null;
    let gpuRenderer = null, gpuVendor = null, gpuVersion = null, rendererSource = null;
    if (gl) {
      try {
        const debug = gl.getExtension('WEBGL_debug_renderer_info');
        gpuRenderer = gl.getParameter(debug?.UNMASKED_RENDERER_WEBGL ?? gl.RENDERER);
        gpuVendor = gl.getParameter(debug?.UNMASKED_VENDOR_WEBGL ?? gl.VENDOR);
        gpuVersion = gl.getParameter(gl.VERSION);
        rendererSource = debug ? 'WEBGL_debug_renderer_info' : 'GL_RENDERER';
      } catch { /* restricted WebGL identity remains unknown */ }
    }
    return {
      gpu: { renderer: gpuRenderer, vendor: gpuVendor, version: gpuVersion,
        rendererSource, contextLost: gl?.isContextLost?.() ?? null },
      renderCaps,
      arrayActive: renderer?.surfaceMaterialActive ?? null,
    };
  });
}

// The ladder spans the whole morph, not just one depth: the anchor before any
// room exists, an early room that is meant to still look original, mid-morph,
// and two fully-morphed chambers.
// Early rungs are genuinely flown and keep the capture crash guard exercised.
// Deeper visual rungs use exact placement: the autopilot now survives them, but
// style comparison needs the same room-relative camera depth on every run.
//
// Rooms sit at 50 + 1000k, so a rung is placed just before one (40 m out).
// A rung between two rooms has no formation in frame at all — 9500 m did, and
// every landmark descriptor read as if the formations had vanished.
const LADDER = [
  { depth: 250, seed: 4096, note: 'before any room — the original anchor' },
  { depth: 2010, seed: 4096, note: 'first room, near-original by design' },
  { depth: 4010, seed: 256, note: 'morph beginning — still flown' },
  { depth: 6010, seed: 2024, place: true, note: 'mid-morph' },
  { depth: 9000, seed: 2024, place: true, note: 'full reference, coiling approach' },
  { depth: 9000, seed: 256, place: true, note: 'full reference, crystal approach' },
];

// A rung is judged against the reference envelope only once the morph has
// actually arrived. Measuring the 250 m anchor against the reference is a
// category error — it is SUPPOSED to look like the original, and scoring it as a
// miss would push tuning in exactly the wrong direction.
const JUDGE_FROM_STYLE = 0.85;

function waitForServer(url, timeoutMs = 60000) {
  const start = Date.now();
  return new Promise((res, rej) => {
    const tick = async () => {
      try { if ((await fetch(url)).ok) return res(); } catch { /* not up */ }
      if (Date.now() - start > timeoutMs) return rej(new Error('server timeout'));
      setTimeout(tick, 250);
    };
    tick();
  });
}

async function main() {
  if (!existsSync(TARGET)) {
    console.error('No reference target. Run `npm run ref:profile` first.');
    process.exit(1);
  }
  const target = JSON.parse(readFileSync(TARGET, 'utf8'));
  const sourceBefore = provenance();
  const gitBefore = await gitProvenance();
  mkdirSync(SHOTS, { recursive: true });
  mkdirSync(OUT, { recursive: true });

  const server = spawn(process.execPath,
    [resolve('node_modules/vite/bin/vite.js'), '--port', String(PORT), '--strictPort'],
    { stdio: 'ignore', shell: false });
  let browser;
  let browserVersion = null;
  const rows = [];

  try {
    browser = await chromium.launch({ channel: 'chromium' });
    browserVersion = browser.version();
    await waitForServer(`http://localhost:${PORT}/`);
    const page = await browser.newPage({ viewport: { width: 1280, height: 720 } });
    const errors = [];
    page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
    page.on('pageerror', (e) => errors.push(e.message));
    await page.goto(`http://localhost:${PORT}/?capture=1`);
    await page.waitForFunction(
      () => window.__cave9 && window.__cave9.state && window.__cave9.state !== 'boot',
      { timeout: 30000 });
    await page.evaluate(() => window.__cave9.renderer.load());

    for (const step of LADDER) {
      const info = await page.evaluate(
        (o) => window.__cave9.captureScenario(o),
        { seed: step.seed, distance: step.depth, place: !!step.place, settings: { landmarks: true } });
      // Headless Chromium hands back a stale or empty buffer until the CAPTURE
      // loop has re-rendered the held frame a few times, and the first shot of a
      // session needs the most. Without this the early rungs come back pure
      // black and every descriptor reads 0.000 — which looks like a real result.
      const file = join(SHOTS, `d${step.depth}-s${step.seed}.png`);
      let d = null;
      for (let attempt = 0; attempt < 6; attempt++) {
        for (let i = 0; i < 3 + attempt * 3; i++) {
          await page.evaluate(() => new Promise((r) => requestAnimationFrame(() => r())));
        }
        const url = await page.evaluate(() => window.__cave9.renderer.canvas.toDataURL('image/png'));
        writeFileSync(file, Buffer.from(url.replace(/^data:image\/png;base64,/, ''), 'base64'));
        d = describe(file);
        if (d.D3_tone.median > 0.002) break; // a real Cave9 frame is never flat black
      }
      if (d.D3_tone.median <= 0.002) {
        throw new Error(`capture stayed blank at ${step.depth} m / seed ${step.seed}`);
      }
      // captureScenario stops flying when the autopilot crashes, so a rung whose
      // seed cannot survive to its depth silently measures the CRASH frame — the
      // ship pressed against a wall, which reads as a bright, detailed picture
      // and quietly poisons the whole axis. Fail loudly instead.
      if (!step.place && info.distanceReached < step.depth * 0.97) {
        throw new Error(
          `seed ${step.seed} only reached ${info.distanceReached} m of ${step.depth} m ` +
          '— pick a seed whose autopilot survives that deep, or the rung measures a crash frame');
      }
      const state = await renderState(page);
      const style = styleAt(step.depth);
      rows.push({ ...step, file, style, judged: style >= JUDGE_FROM_STYLE,
        reached: info.distanceReached, family: info.landmarkType, described: d,
        renderState: { browserVersion, ...state } });
    }
    if (errors.length) throw new Error(
      `${errors.length} capture console/page error(s): ${errors.slice(0, 3).join(' | ')}`);
  } finally {
    if (browser) await browser.close();
    server.kill();
  }

  const sourceAfter = provenance();
  const gitAfter = await gitProvenance();
  report(rows, target, { browser: { channel: 'chromium', version: browserVersion },
    sourceBefore, sourceAfter, gitBefore, gitAfter,
    runtimeStable: sourceBefore.runtime.source.sha256 === sourceAfter.runtime.source.sha256
      && sourceBefore.runtime.assets.sha256 === sourceAfter.runtime.assets.sha256
      && sourceBefore.toolSha256 === sourceAfter.toolSha256,
    gitNote: 'Git after-state includes screenshots written under docs/screenshots/style; style-report.json is written after this snapshot.' });
}

function report(rows, target, captureProvenance) {
  const env = target.envelope;
  const releaseAxes = new Set([
    'D1_figureGround', 'D2_centreOverEdge', 'D3_median', 'D3_brightTail',
    'D4_radialAlignment', 'D5_edgeDensity', 'D6_blobs',
  ]);
  const pad = (s, n) => String(s).padEnd(n);
  const fmt = (v, axis) => (axis === 'D6_blobs' ? String(Math.round(v)) : v.toFixed(3));

  console.log('\nStyle distance to the reference envelope\n');
  console.log(pad('axis', 22), pad('target', 18), rows.map((r) => pad(`${r.depth}m/${r.seed}`, 13)).join(''), 'verdict');

  const results = {};
  for (const axis of AXES) {
    const e = env[axis];
    const cells = [], misses = [];
    for (const r of rows) {
      const v = axisValue(r.described, axis);
      const inside = v >= e.min && v <= e.max;
      // Factor off, not distance normalised by the envelope's own width. The
      // width version let a wide band (D1 spans 0.194–0.838) report a 40x
      // shortfall as "near". "How many times off" is scale-free and matches how
      // a miss is actually read.
      const bound = v < e.min ? e.min : e.max;
      // Floor the denominator at the axis's own smallest meaningful step, or a
      // count of zero reports as a 80000x miss instead of "there are none".
      const floor = axis === 'D6_blobs' ? 1 : 0.01;
      const hi = Math.max(Math.abs(v), Math.abs(bound), floor);
      const lo = Math.max(Math.min(Math.abs(v), Math.abs(bound)), floor);
      const dist = inside ? 0 : hi / lo - 1;
      // rungs still travelling toward the reference are shown but not scored
      cells.push(pad(`${fmt(v, axis)}${inside ? ' ok' : r.judged ? '' : ' ·'}`, 13));
      if (r.judged) misses.push(dist);
    }
    const worst = misses.length ? Math.max(...misses) : 0;
    const verdict = worst === 0 ? 'ok'
      : worst < 0.3 ? 'near' : worst < 2 ? 'off' : `far ${(worst + 1).toFixed(1)}x`;
    results[axis] = {
      envelope: e,
      values: rows.map((r) => ({ depth: r.depth, seed: r.seed, judged: r.judged, value: axisValue(r.described, axis) })),
      worst, verdict,
    };
    console.log(pad(axis, 22), pad(`${fmt(e.min, axis)} – ${fmt(e.max, axis)}`, 18), cells.join(''), verdict);
  }

  // 'far' carries its factor ("far 5.2x"), so match by prefix — an exact
  // comparison silently reported the worst axes as fine.
  const failures = Object.entries(results)
    .filter(([axis, r]) => releaseAxes.has(axis) && r.verdict !== 'ok')
    .sort((a, b) => b[1].worst - a[1].worst);
  const diagnostics = Object.entries(results)
    .filter(([axis, r]) => !releaseAxes.has(axis) && r.verdict !== 'ok')
    .sort((a, b) => b[1].worst - a[1].worst);
  const judgedRungs = rows.filter((r) => r.judged).length;
  if (!judgedRungs) {
    // Printing "all axes ok" when nothing was scored would be the worst possible
    // output: a green light produced by measuring nothing at all.
    const deepest = Math.max(...rows.map((r) => r.style));
    console.log(
      `\nNOT JUDGED — no rung reaches the reference. The deepest style on the ladder` +
      `\nis ${deepest.toFixed(2)} of 1.00, because the deterministic autopilot cannot survive` +
      `\npast ~4100 m while the morph completes at ${STYLE_FULL} m. The columns above are` +
      `\na trend, not a verdict.` +
      `\n\nTo close this: give captureScenario a way to PLACE the ship at a depth` +
      `\ninstead of flying to it. Carving the generator forward and setting z is` +
      `\nenough — a style measurement does not need a legitimately-flown frame.`);
  } else {
    console.log(failures.length
      ? `\n${failures.length} release axis/axes need work: ${failures.map(([a]) => a).join(', ')}`
      : '\nAll D1–D6 release axes inside the reference envelope.');
    if (diagnostics.length) {
      console.log(`Diagnostic D7–D12 misses (reported, not release-gating until family-specific bands exist): ${diagnostics.map(([a]) => a).join(', ')}`);
    }
    if (failures.length) process.exitCode = 1;
  }

  const outFile = join(OUT, 'style-report.json');
  writeFileSync(outFile, JSON.stringify({
    capturedAt: new Date().toISOString(),
    captureProvenance,
    ladder: rows.map((r) => ({
      depth: r.depth, seed: r.seed, note: r.note, style: r.style, judged: r.judged, reached: r.reached, family: r.family,
      renderState: r.renderState,
      ...Object.fromEntries(AXES.map((a) => [a, axisValue(r.described, a)])),
      D7_centralOpening: r.described.D7_centralOpening,
      D8_angularSilhouette: r.described.D8_angularSilhouette,
      D9_quadrantMass: r.described.D9_quadrantMass,
      D10_dominantForms: r.described.D10_dominantForms,
      D11_tipDistance: r.described.D11_tipDistance,
      D12_projectedOcclusion: r.described.D12_projectedOcclusion,
    })),
    axes: results,
    releaseGate: {
      axes: [...releaseAxes],
      pass: failures.length === 0,
      failures: failures.map(([axis]) => axis),
    },
    compositionDiagnostics: {
      releaseGating: false,
      reason: 'D7-D12 use a global multi-family envelope; family-specific acceptance bands are not yet frozen.',
      misses: diagnostics.map(([axis]) => axis),
    },
  }, null, 2));
  const cellW = 426, cellH = 240, labelH = 42, cols = 3;
  const sheet = rows.map((r, i) => {
    const x = (i % cols) * cellW, y = Math.floor(i / cols) * (cellH + labelH);
    const d1 = axisValue(r.described, 'D1_figureGround').toFixed(3);
    const d3 = axisValue(r.described, 'D3_median').toFixed(3);
    const d5 = axisValue(r.described, 'D5_edgeDensity').toFixed(3);
    return `<g transform="translate(${x} ${y})"><image href="${basename(r.file)}" width="${cellW}" height="${cellH}" preserveAspectRatio="xMidYMid slice"/><rect y="${cellH}" width="${cellW}" height="${labelH}" fill="#090c12"/><text x="9" y="${cellH + 17}" fill="#e5edff" font-family="monospace" font-size="13">${r.depth}m · seed ${r.seed} · ${r.family || 'corridor'}</text><text x="9" y="${cellH + 34}" fill="#9eabc4" font-family="monospace" font-size="12">D1 ${d1} · D3 ${d3} · D5 ${d5}</text></g>`;
  }).join('');
  const sheetRows = Math.ceil(rows.length / cols);
  writeFileSync(join(SHOTS, 'contact-sheet.svg'), `<svg xmlns="http://www.w3.org/2000/svg" width="${cellW * cols}" height="${(cellH + labelH) * sheetRows}" viewBox="0 0 ${cellW * cols} ${(cellH + labelH) * sheetRows}"><rect width="100%" height="100%" fill="#05070b"/>${sheet}</svg>`);
  console.log(`\n› wrote ${outFile}\n`);
}

main().catch((e) => { console.error(e); process.exit(1); });
