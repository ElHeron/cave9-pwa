// Predictive-warning lead-time measurement (Phase 4F / M1).
//
// Flies the deterministic controllers (the built-in autopilot + the wall-rider
// used for the graze fixture) over the shared 50-seed panel, sampling the
// REACTIVE warning (ScoreSystem.warnLevel) and the PREDICTIVE warning
// (predictiveWarn, a pure look-ahead probe) on every frame. It then measures:
//
//   * lead-time: for each rising edge where the reactive warning crosses the
//     HIGH danger threshold, how many frames/seconds earlier did the predictive
//     warning already reach HIGH (within a look-back window)?
//   * false-alarm rate: of all frames where the predictive warning is HIGH, what
//     fraction are NOT confirmed by the reactive warning reaching HIGH within the
//     look-ahead horizon (i.e. the player turned away — informative, not impending).
//
// Nothing here changes the simulation: predictiveWarn never touches the sim, and
// the controllers are the same deterministic ones the fixtures use. Pure
// measurement. Writes docs/measure/predictive-leadtime.json and prints a summary.
//
//   node scripts/predictive-leadtime.mjs            # default panel
//   node scripts/predictive-leadtime.mjs 5000       # maxSteps override

import { mkdirSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { Game, DT } from '../src/core/Game.js';
import { predictiveWarn, T_LEAD } from '../src/core/Predictive.js';
import { TWO_BUTTONS, SEGMENT_COUNT } from '../src/core/constants.js';
import { tubeRadiusAt } from '../src/core/FlightPath.js';
import { SEED_PANEL } from './seed-panel.mjs';

const args = process.argv.slice(2).filter((a) => !a.startsWith('--'));
const GATE = process.argv.includes('--gate');
const MAX_STEPS = Number(args[0]) || 4000;
// optional t_lead sweep override (seconds); defaults to the shipped T_LEAD
const TLEAD = Number(args[1]) || T_LEAD;

const HIGH = 0.78;          // "high danger" — matches the danger capture threshold
const LOOKBACK = 90;        // frames (1.5 s) to look back for a preceding predictive lead
const CONFIRM = 36;         // frames (0.6 s) a predictive-HIGH frame has to be confirmed

// The wall-rider controller (a copy of scripts/make-replays.mjs' generator): aim a
// few rings ahead but bias the target toward the +x wall so the ship rides close
// to the rock and produces real high-danger approaches. Pure input generator.
function wallRider(bias) {
  return (g) => {
    const p = g.player;
    const centers = g.cave.centers;
    const z = p.pos[2];
    const targetZ = z + 12;
    let c = null, bestD = Infinity;
    for (let k = 0; k < SEGMENT_COUNT; k++) {
      const cc = centers[k];
      if (cc[2] <= z) continue;
      const d = Math.abs(cc[2] - targetZ);
      if (d < bestD) { bestD = d; c = cc; }
    }
    if (!c) { g.autopilot(); return; }
    const radius = g.player.radius > 0 ? tubeRadiusAt(z - p.start, g.seed) : 10;
    const ax = c[0] + bias * radius;
    const ex = ax - p.pos[0];
    const ey = c[1] - p.pos[1];
    const cx = ex * 1.8 - p.vel[0] * 1.2;
    const cy = ey * 1.8 - p.vel[1] * 1.2;
    let left = false, right = false;
    if (cx > 1.0) right = true;
    else if (cx < -1.0) left = true;
    if (cy > 1.2) left = right = true;
    else if (cy < -1.5) left = right = false;
    else if (cy > -0.3) { if (!left && !right) { if (ex < 0) left = true; else right = true; } }
    p.lefton = left;
    p.righton = right;
  };
}

// Fly one seed with one controller, returning per-frame [reactive, predictive].
function flightTrace(seed, controller) {
  const g = new Game();
  g.start({ mode: TWO_BUTTONS, seed });
  const trace = [];
  for (let i = 0; i < MAX_STEPS; i++) {
    controller(g);
    const reactive = g.score.warnLevel || 0;       // BEFORE step: current proximity
    const pred = predictiveWarn(g.cave, g.player, TLEAD).warn;
    trace.push([reactive, pred]);
    if (g.step()) break;
  }
  return trace;
}

const controllers = [
  { name: 'autopilot', make: () => (g) => g.autopilot() },
  { name: 'wallrider-0.70', make: () => wallRider(0.70) },
  { name: 'wallrider-0.80', make: () => wallRider(0.80) },
];

const leads = [];          // lead in frames per reactive-HIGH event
let events = 0, ledEvents = 0;
let predHighFrames = 0, predFalseFrames = 0;
let totalFrames = 0;
const perSeed = [];

for (const seed of SEED_PANEL) {
  let seedEvents = 0, seedLed = 0, seedLeadSum = 0, seedMaxLead = 0;
  for (const ctl of controllers) {
    const trace = flightTrace(seed, ctl.make());
    totalFrames += trace.length;

    for (let f = 0; f < trace.length; f++) {
      const [reactive, pred] = trace[f];

      // reactive rising edge into HIGH = a danger "event"
      const prevReactive = f > 0 ? trace[f - 1][0] : 0;
      if (reactive >= HIGH && prevReactive < HIGH) {
        events++; seedEvents++;
        // earliest frame in the look-back window where predictive was already HIGH
        let lead = 0;
        for (let g2 = f - 1; g2 >= Math.max(0, f - LOOKBACK); g2--) {
          if (trace[g2][1] >= HIGH) lead = f - g2; else break;
        }
        if (lead > 0) { ledEvents++; seedLed++; leads.push(lead); seedLeadSum += lead; }
        if (lead > seedMaxLead) seedMaxLead = lead;
      }

      // false-alarm bookkeeping over predictive-HIGH frames
      if (pred >= HIGH) {
        predHighFrames++;
        let confirmed = false;
        for (let g2 = f; g2 <= Math.min(trace.length - 1, f + CONFIRM); g2++) {
          if (trace[g2][0] >= HIGH) { confirmed = true; break; }
        }
        if (!confirmed) predFalseFrames++;
      }
    }
  }
  perSeed.push({ seed, events: seedEvents, led: seedLed,
    avgLeadFrames: seedEvents ? +(seedLeadSum / Math.max(1, seedLed)).toFixed(1) : 0,
    maxLeadFrames: seedMaxLead });
}

leads.sort((a, b) => a - b);
const sum = leads.reduce((a, b) => a + b, 0);
const mean = leads.length ? sum / leads.length : 0;
const median = leads.length ? leads[Math.floor(leads.length / 2)] : 0;
const p90 = leads.length ? leads[Math.floor(leads.length * 0.9)] : 0;
const max = leads.length ? leads[leads.length - 1] : 0;
const falseRate = predHighFrames ? predFalseFrames / predHighFrames : 0;

const summary = {
  tLead: TLEAD,
  panelSeeds: SEED_PANEL.length,
  controllers: controllers.map((c) => c.name),
  maxSteps: MAX_STEPS,
  highThreshold: HIGH,
  lookbackFrames: LOOKBACK,
  confirmFrames: CONFIRM,
  dt: DT,
  totalFrames,
  reactiveHighEvents: events,
  eventsLed: ledEvents,
  eventsLedPct: events ? +(100 * ledEvents / events).toFixed(1) : 0,
  leadFrames: { mean: +mean.toFixed(2), median, p90, max },
  leadSeconds: { mean: +(mean * DT).toFixed(3), median: +(median * DT).toFixed(3),
    p90: +(p90 * DT).toFixed(3), max: +(max * DT).toFixed(3) },
  predictiveHighFrames: predHighFrames,
  predictiveFalseFrames: predFalseFrames,
  falseAlarmRate: +falseRate.toFixed(4),
};

const gate = {
  thresholds: {
    eventsLedPctMin: 30,
    meanLeadSecondsMin: 0.18,
    falseAlarmRateMax: 0.15,
  },
  checks: {
    eventsLed: summary.eventsLedPct >= 30,
    usefulMeanLead: summary.leadSeconds.mean >= 0.18,
    falseAlarms: summary.falseAlarmRate <= 0.15,
  },
};
gate.pass = Object.values(gate.checks).every(Boolean);

const OUT = resolve(process.cwd(), 'docs/measure');
mkdirSync(OUT, { recursive: true });
writeFileSync(resolve(OUT, 'predictive-leadtime.json'),
  JSON.stringify({ capturedAt: new Date().toISOString(), summary, gate, perSeed }, null, 2) + '\n');

console.log('Cave9 — predictive warning lead-time (Phase 4F / M1)\n');
console.log(`panel: ${SEED_PANEL.length} seeds × ${controllers.length} controllers, ${MAX_STEPS} steps cap`);
console.log(`HIGH threshold: warn ≥ ${HIGH}   look-back: ${LOOKBACK}f   confirm: ${CONFIRM}f   DT: ${DT.toFixed(4)}s\n`);
console.log(`reactive-HIGH events:    ${events}`);
console.log(`  led by predictive:     ${ledEvents}  (${summary.eventsLedPct}%)`);
console.log(`lead-time (frames):      mean ${summary.leadFrames.mean}  median ${median}  p90 ${p90}  max ${max}`);
console.log(`lead-time (seconds):     mean ${summary.leadSeconds.mean}s  median ${summary.leadSeconds.median}s  p90 ${summary.leadSeconds.p90}s  max ${summary.leadSeconds.max}s`);
console.log(`\npredictive-HIGH frames:  ${predHighFrames}`);
console.log(`  unconfirmed (false):   ${predFalseFrames}  (${(falseRate * 100).toFixed(2)}%)`);
if (GATE) console.log(`\n${gate.pass ? 'PASS' : 'FAIL'} — predictive-warning operating gate`);
console.log(`\n› wrote docs/measure/predictive-leadtime.json`);
if (GATE && !gate.pass) process.exitCode = 1;
