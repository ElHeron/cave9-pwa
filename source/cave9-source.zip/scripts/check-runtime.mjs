// Keep the double-click starters aligned with package.json's Node engine range.
const [major, minor] = process.versions.node.split('.').map(Number);
const supported = (major === 20 && minor >= 19) ||
  (major === 22 && minor >= 12) || major > 22;

if (!supported) {
  console.error(`[FEHLER] Node.js ${process.versions.node} wird nicht unterstuetzt.`);
  console.error('Cave9 benoetigt Node.js 20.19+ (20er Reihe) oder 22.12+ (22er Reihe und neuer).');
  console.error('Bitte eine aktuelle LTS-Version von https://nodejs.org installieren.');
  process.exitCode = 1;
}
