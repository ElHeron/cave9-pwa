// Edge-energy / local-contrast collector (Phase 4B, gate P2).
//
// Runs scripts/edge.mjs over the frozen baseline canvas set and writes
// docs/measure/edge-metrics.json — the committed reference "detail level" of the
// near/mid walls. A future fidelity change (bump/normal map, SSAO) re-runs
// `npm run capture` then this collector over the new canvases; edge energy must
// rise (more surface detail) while luminance.mjs shows the centre hole is NOT
// brighter (readability preserved). Pure analysis — renders nothing.
//
// Run: node scripts/measure-edges.mjs [<dir>]   ( = npm run edges )

import { readdirSync, existsSync, mkdirSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { edgeMetrics, printEdge } from './edge.mjs';

const ROOT = process.cwd();
const dir = resolve(ROOT, process.argv[2] || 'docs/screenshots/baseline');
const OUT = resolve(ROOT, 'docs/measure');
mkdirSync(OUT, { recursive: true });

if (!existsSync(dir)) {
  console.error(`image dir not found: ${dir}`);
  process.exit(1);
}

const files = readdirSync(dir).filter((f) => f.endsWith('.png')).sort();
if (files.length === 0) { console.error(`no PNGs in ${dir}`); process.exit(1); }

console.log(`Cave9 — edge-energy / local-contrast (gate P2)\nsource: ${dir.replace(ROOT + '\\', '').replace(/\\/g, '/')}`);
const metrics = [];
for (const f of files) {
  const m = edgeMetrics(resolve(dir, f));
  m.file = f; // store the short name
  printEdge({ ...m, file: f });
  metrics.push(m);
}

const report = { gate: 'P2-edges', capturedAt: new Date().toISOString(), source: dir, metrics };
writeFileSync(resolve(OUT, 'edge-metrics.json'), JSON.stringify(report, null, 2) + '\n');
console.log(`\nReport: docs/measure/edge-metrics.json  (${metrics.length} images)`);
