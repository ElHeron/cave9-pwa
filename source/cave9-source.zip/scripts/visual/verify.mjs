import { parseArgs, resolveRunDir } from './manifest.mjs';
import { verifyRun } from './verification.mjs';

const args = parseArgs(process.argv.slice(2));
const root = process.cwd();
const runDir = resolveRunDir(root, args.run || args.positional[0]);
const manifest = await verifyRun({ root, runDir });
console.log(JSON.stringify({ runId: manifest.runId, status: manifest.status,
  automated: manifest.automated.status, staleReasons: manifest.verification.staleReasons }, null, 2));
if (manifest.status === 'fail' || manifest.status === 'stale') process.exitCode = 1;
