import { existsSync, mkdirSync, writeFileSync } from 'node:fs';
import { relative, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { chromium } from 'playwright';
import { ROOM_LEN, ROOM_SPACING } from '../../src/core/constants.js';
import { evaluateFrame, inspectPng, inspectPngDifference } from './image-checks.mjs';
import { parseArgs, writeManifest } from './manifest.mjs';
import { gitProvenance, makeRunId, runtimeFingerprint } from './provenance.mjs';
import {
  FAMILY_FORM_API,
  FAMILY_FORM_BASE_DEPTH,
  FAMILY_FORM_FAMILIES,
  FAMILY_FORM_M1_M2_FAMILIES,
  familyFormHeroDifferenceCheck,
  familyFormFramingCheck,
  familyFormSuiteDefinition,
  familyFormTemplates,
  resolvedFamilyOffControlScenario,
  resolvedFamilyScenario,
} from './family-form-config.mjs';
import { writeFamilyFormReport } from './family-form-report.mjs';
import { verifyFamilyFormRun } from './family-form-verification.mjs';
import { withViteServer } from './vite-server.mjs';

const root = process.cwd();

function createRunDirectory(runDir) {
  if (existsSync(runDir)) throw new Error(`refusing to overwrite existing family-form run: ${runDir}`);
  const frames = resolve(runDir, 'frames');
  mkdirSync(frames, { recursive: true });
  return frames;
}

const visualSettings = Object.freeze({
  fov: 45, brightness: 1, motion: 0, landmarks: true, readability: true, rockDetail: true,
  cave: true, wireframe: false, landmarkMesh: true, collisionCapsules: false,
  booleanTube: false, playerHull: false, frames: false, fog: true, material: true, light: true,
});

async function settle(page, frames = 4) {
  for (let i = 0; i < frames; i++) {
    await page.evaluate(() => new Promise((resolvePromise) => requestAnimationFrame(resolvePromise)));
  }
}

async function resolveVisibleFamilyGeometry(page, spec) {
  return page.evaluate(async ({ spec, baseDepth, settings, roomLength, roomSpacing }) => {
    const visual = window.__cave9?.visual;
    const app = window.__cave9;
    if (typeof visual?.loadScenario !== 'function' || typeof visual?.snapshot !== 'function') {
      throw new Error('VisualScenarioV1 API is required; no legacy fallback is permitted');
    }
    visual.loadScenario({
      version: 'VisualScenarioV1', name: `resolve-${spec.family}`, seed: spec.seed,
      distance: spec.family === 'coiling' ? baseDepth + 70 : baseDepth,
      placement: 'place', family: spec.family, camera: 'hero', paused: true,
      viewport: { width: 1280, height: 720, dpr: 1 }, settings,
    });
    await app.renderer.load();
    visual.step(0);
    await app.renderer.surfaceReliefReady();
    const snapshot = visual.step(0);
    if (snapshot?.version !== 'VisualSnapshotV1' || snapshot.family?.requested !== spec.family
      || !snapshot.family?.active?.includes(spec.family)) {
      throw new Error(`missing or wrong forced composition while resolving ${spec.family}`);
    }
    const compositions = visual.runner.visibleCompositions().filter((comp) => comp.typeName === spec.family);
    if (compositions.length !== 1) {
      throw new Error(`expected exactly one active ${spec.family} composition, found ${compositions.length}`);
    }
    const composition = compositions[0];
    if (spec.family === 'coiling') {
      const roomStart = composition.k * roomSpacing;
      const roomEnd = roomStart + roomLength;
      const bounds = { minX: Infinity, minY: Infinity, minZ: Infinity,
        maxX: -Infinity, maxY: -Infinity, maxZ: -Infinity, vertexCount: 0 };
      for (const ring of app.game.cave.segs) for (const point of ring) {
        const [x, y, z] = point;
        if (z < roomStart || z > roomEnd) continue;
        bounds.minX = Math.min(bounds.minX, x); bounds.maxX = Math.max(bounds.maxX, x);
        bounds.minY = Math.min(bounds.minY, y); bounds.maxY = Math.max(bounds.maxY, y);
        bounds.minZ = Math.min(bounds.minZ, z); bounds.maxZ = Math.max(bounds.maxZ, z);
        bounds.vertexCount++;
      }
      if (!bounds.vertexCount) throw new Error('coiling has no live CaveStream room rings');
      return {
        family: spec.family, seed: spec.seed, resolvedAtDepth: snapshot.distance,
        compositionCount: compositions.length, compositionRoom: composition.k,
        compositionCenterDepth: composition.z, pieceCount: composition.pieces.length,
        collisionPieceCount: (composition.collisionPieces || []).length,
        surfaceRevision: composition.surfaceRevision,
        surfaceRevisions: compositions.map((comp) => comp.surfaceRevision),
        roomKey: `CaveStream:${spec.seed}:${composition.k}:coiling`, meshCount: 1,
        visibleGeometryBounds: { frontDepth: bounds.minZ,
          reviewFrontDepth: bounds.minZ, reviewFrontQuantile: 0,
          backDepth: bounds.maxZ, minX: bounds.minX, maxX: bounds.maxX,
          minY: bounds.minY, maxY: bounds.maxY, vertexCount: bounds.vertexCount },
        resolverApi: 'VisualScenarioV1 + live CaveStream room ring vertices / production cave mesh',
      };
    }
    const roomKey = `${spec.seed}:${composition.k}:${spec.family}`;
    const entries = [...app.renderer.landmarkLayer.built.values()]
      .filter((entry) => entry.roomKey === roomKey && entry.group.visible);
    if (entries.length !== 1) {
      throw new Error(`expected exactly one visible ${spec.family} LandmarkLayer group, found ${entries.length}`);
    }
    const group = entries[0].group;
    group.updateMatrixWorld(true);
    const bounds = { minX: Infinity, minY: Infinity, minZ: Infinity,
      maxX: -Infinity, maxY: -Infinity, maxZ: -Infinity, vertexCount: 0 };
    const vertexDepths = [];
    let meshCount = 0;
    group.traverse((object) => {
      const position = object.geometry?.getAttribute?.('position');
      if (!object.isMesh || !position) return;
      meshCount++;
      object.updateMatrixWorld(true);
      const e = object.matrixWorld.elements;
      for (let i = 0; i < position.count; i++) {
        const x = position.getX(i), y = position.getY(i), z = position.getZ(i);
        const wx = e[0] * x + e[4] * y + e[8] * z + e[12];
        const wy = e[1] * x + e[5] * y + e[9] * z + e[13];
        const wz = e[2] * x + e[6] * y + e[10] * z + e[14];
        bounds.minX = Math.min(bounds.minX, wx); bounds.maxX = Math.max(bounds.maxX, wx);
        bounds.minY = Math.min(bounds.minY, wy); bounds.maxY = Math.max(bounds.maxY, wy);
        bounds.minZ = Math.min(bounds.minZ, wz); bounds.maxZ = Math.max(bounds.maxZ, wz);
        vertexDepths.push(wz);
        bounds.vertexCount++;
      }
    });
    if (!meshCount || !bounds.vertexCount || !Number.isFinite(bounds.minZ)) {
      throw new Error(`${spec.family} has no actual visible mesh vertices`);
    }
    vertexDepths.sort((a, b) => a - b);
    // A single spear tip is an exact bound but not a visible form front. Bind
    // approach frames to the first 20% of submitted vertex mass while keeping
    // the true minimum in the manifest. This remains derived only from the real
    // production BufferGeometry and cannot be supplied by family metadata.
    const reviewFrontQuantile = 0.20;
    const reviewFrontDepth = vertexDepths[Math.floor((vertexDepths.length - 1) * reviewFrontQuantile)];
    return {
      family: spec.family,
      seed: spec.seed,
      resolvedAtDepth: snapshot.distance,
      compositionCount: compositions.length,
      compositionRoom: composition.k,
      compositionCenterDepth: composition.z,
      pieceCount: composition.pieces.length,
      bankGroups: [...new Set(composition.pieces.map((piece) => piece.bank)
        .filter(Number.isInteger))].map((bank) => {
        const pieces = composition.pieces.filter((piece) => piece.bank === bank);
        return { bank, pieceCount: pieces.length,
          firstGid: Math.min(...pieces.map((piece) => piece.gid)),
          lastGid: Math.max(...pieces.map((piece) => piece.gid)) };
      }),
      collisionPieceCount: (composition.collisionPieces || []).length,
      surfaceRevision: composition.surfaceRevision,
      surfaceRevisions: compositions.map((comp) => comp.surfaceRevision),
      roomKey,
      meshCount,
      visibleGeometryBounds: {
        frontDepth: bounds.minZ, reviewFrontDepth, reviewFrontQuantile, backDepth: bounds.maxZ,
        minX: bounds.minX, maxX: bounds.maxX, minY: bounds.minY, maxY: bounds.maxY,
        vertexCount: bounds.vertexCount,
      },
      resolverApi: 'VisualScenarioV1 + visible LandmarkLayer BufferGeometry vertices',
    };
  }, { spec, baseDepth: FAMILY_FORM_BASE_DEPTH, settings: visualSettings,
    roomLength: ROOM_LEN, roomSpacing: ROOM_SPACING });
}

async function captureScenario(page, scenario) {
  return page.evaluate(async ({ scenario, api }) => {
    const app = window.__cave9;
    const visual = app?.visual;
    if (typeof visual?.loadScenario !== 'function' || typeof visual?.snapshot !== 'function') {
      throw new Error('VisualScenarioV1 API is required; no legacy fallback is permitted');
    }
    const loaded = visual.loadScenario(scenario.captureOptions);
    await app.renderer.load();
    visual.step(0);
    await app.renderer.surfaceReliefReady();
    visual.step(0);
    const snapshot = visual.snapshot({ includeImage: false });
    if (loaded?.version !== 'VisualSnapshotV1' || snapshot?.version !== 'VisualSnapshotV1') {
      throw new Error(`${scenario.id} returned no VisualSnapshotV1`);
    }
    if (snapshot.family?.requested !== scenario.family || !snapshot.family?.active?.includes(scenario.family)) {
      throw new Error(`${scenario.id} has missing or wrong active family`);
    }
    const capabilities = snapshot.renderCapabilities;
    if (!capabilities?.surfaceMaterialActive || !capabilities?.surfaceReliefActive
      || !capabilities?.surfaceReliefProfile) {
      throw new Error(`${scenario.id} captured before surface array and relief were active`);
    }
    const dev3d = visual.runner?.dev3d;
    const familyMeshes = [];
    if (scenario.family === 'coiling') familyMeshes.push(app.renderer.caveMesh);
    else for (const entry of app.renderer.landmarkLayer.built.values()) {
      if (!entry.group.visible || !entry.roomKey?.endsWith(`:${scenario.family}`)) continue;
      entry.group.traverse((object) => { if (object.isMesh) familyMeshes.push(object); });
    }
    const expectedMaterial = snapshot.renderPass?.active === 'neutral' ? dev3d?.neutralLandmarkMaterial
      : snapshot.renderPass?.active === 'silhouette' ? dev3d?.silhouetteMaterial
        : snapshot.renderPass?.active === 'clay'
          ? scenario.family === 'coiling' ? dev3d?.clayCaveMaterial : dev3d?.clayMaterial : null;
    const matchedMaterialCount = snapshot.renderPass?.active === 'beauty'
      ? familyMeshes.filter((mesh) => scenario.family === 'coiling'
        ? mesh.material === app.renderer.caveMat
        : mesh.userData.visualBeautyMaterial === mesh.material).length
      : familyMeshes.filter((mesh) => mesh.material === expectedMaterial).length;
    return {
      api,
      normalizedScenario: snapshot.scenario,
      snapshot,
      info: {
        distanceReached: snapshot.distance,
        positioning: snapshot.positioning,
        family: snapshot.family,
        camera: snapshot.camera,
        viewport: snapshot.viewport,
      },
      debugGeometry: {
        collisionCapsules: dev3d?.capsuleGroup?.children?.length ?? null,
        booleanTubeObjects: dev3d?.tubeGroup?.children?.length ?? null,
      },
      renderPassEvidence: {
        requested: scenario.captureOptions.renderPass,
        active: snapshot.renderPass?.active ?? null,
        familyMeshCount: familyMeshes.length,
        matchedMaterialCount,
        caveVisible: !!app.renderer.caveMesh.visible,
        caveClayMaterial: app.renderer.caveMesh.material === dev3d?.clayCaveMaterial,
        clayRigVisible: !!dev3d?.clayRig?.visible,
        lightRig: snapshot.renderPass?.lightRig ?? null,
        surfaceArrayActive: capabilities.surfaceMaterialActive,
        surfaceReliefActive: capabilities.surfaceReliefActive,
        surfaceReliefProfile: capabilities.surfaceReliefProfile,
        backgroundHex: app.renderer.scene.background?.getHexString?.() ?? null,
      },
    };
  }, { scenario, api: FAMILY_FORM_API });
}

async function captureFamilyOffControl(page, scenario) {
  const control = resolvedFamilyOffControlScenario(scenario);
  return page.evaluate(async ({ control, api }) => {
    const app = window.__cave9;
    const visual = app?.visual;
    if (typeof visual?.loadScenario !== 'function' || typeof visual?.snapshot !== 'function') {
      throw new Error('VisualScenarioV1 API is required for the family-off control');
    }
    const loaded = visual.loadScenario(control.captureOptions);
    await app.renderer.load();
    visual.step(0);
    await app.renderer.surfaceReliefReady();
    visual.step(0);
    const snapshot = visual.snapshot({ includeImage: false });
    if (loaded?.version !== 'VisualSnapshotV1' || snapshot?.version !== 'VisualSnapshotV1') {
      throw new Error(`${control.id} returned no VisualSnapshotV1`);
    }
    if (snapshot.family?.requested !== 'off' || (snapshot.family?.active?.length ?? 0) !== 0) {
      throw new Error(`${control.id} did not establish an empty family control`);
    }
    if (!snapshot.renderCapabilities?.surfaceMaterialActive
      || !snapshot.renderCapabilities?.surfaceReliefActive) {
      throw new Error(`${control.id} captured before surface array and relief were active`);
    }
    return { api, normalizedScenario: snapshot.scenario, snapshot };
  }, { control, api: FAMILY_FORM_API });
}

async function canvasPng(page) {
  const dataUrl = await page.evaluate(() => {
    const canvas = window.__cave9?.renderer?.canvas || document.querySelector('canvas');
    if (!canvas) throw new Error('capture canvas is missing');
    return canvas.toDataURL('image/png');
  });
  const match = /^data:image\/png;base64,(.+)$/s.exec(dataUrl);
  if (!match) throw new Error('capture canvas did not return PNG data');
  return Buffer.from(match[1], 'base64');
}

async function runtimeSnapshot(page) {
  return page.evaluate(() => {
    const app = window.__cave9;
    const canvas = app?.renderer?.canvas || document.querySelector('canvas');
    const gl = app?.renderer?.renderer?.getContext?.();
    const glErrors = [];
    if (gl) for (let i = 0; i < 16; i++) {
      const error = gl.getError();
      if (error === gl.NO_ERROR) break;
      glErrors.push(error);
    }
    const browserErrors = [...(window.__cave9FamilyFormErrors || [])];
    window.__cave9FamilyFormErrors = [];
    return {
      appState: app?.state ?? null, gamePhase: app?.game?.phase ?? null,
      innerWidth: innerWidth, innerHeight: innerHeight, devicePixelRatio,
      canvasWidth: canvas?.width ?? null, canvasHeight: canvas?.height ?? null,
      canvasClientWidth: canvas?.clientWidth ?? null, canvasClientHeight: canvas?.clientHeight ?? null,
      webglAvailable: !!gl, webglContextLost: gl ? gl.isContextLost() : true,
      glErrors, browserErrors,
    };
  });
}

function selectedFamilies(value) {
  if (!value) return FAMILY_FORM_M1_M2_FAMILIES;
  const names = String(value).split(',').map((entry) => entry.trim()).filter(Boolean);
  const selected = names.map((family) => FAMILY_FORM_FAMILIES.find((entry) => entry.family === family));
  if (selected.some((entry) => !entry)) throw new RangeError(`unknown family in --families=${value}`);
  return selected;
}

export async function captureFamilyForm({ runId: requestedRunId, families, headed = false,
  browserChannel, port } = {}) {
  const createdAt = new Date();
  const git = await gitProvenance(root);
  const runtime = runtimeFingerprint(root);
  const runId = requestedRunId || makeRunId(createdAt, git);
  if (!/^[a-zA-Z0-9._-]+$/.test(runId)) throw new Error('run id contains unsupported characters');
  const familySpecs = selectedFamilies(families);
  const suite = familyFormSuiteDefinition(familySpecs);
  const runDir = resolve(root, 'artifacts/visual-lab/family-form', runId);
  const frameDir = createRunDirectory(runDir);
  const blockedPasses = Object.entries(suite.capabilities)
    .filter(([, capability]) => !capability.supported)
    .map(([pass, capability]) => ({ pass, status: 'capability-blocked', reason: capability.reason }));
  const manifest = {
    schemaVersion: 1,
    kind: 'cave9-family-form-review-run',
    runId, createdAt: createdAt.toISOString(), completedAt: null, status: 'running',
    source: { git, runtime }, suite, resolutions: {}, frames: [], blockedPasses,
    report: null, automated: { status: 'pending' },
    manualReview: { status: 'pending', note: 'Review original Hero, Orbit, Ortho and authority-overlay frames.' },
    errors: [],
  };
  writeManifest(runDir, manifest);
  const serverLog = [];
  try {
    await withViteServer(async ({ url }) => {
      let browser;
      try {
        browser = await chromium.launch({ headless: !headed, channel: browserChannel });
        const context = await browser.newContext({ viewport: { width: suite.viewport.width,
          height: suite.viewport.height }, deviceScaleFactor: suite.viewport.deviceScaleFactor,
          reducedMotion: 'reduce' });
        await context.addInitScript(() => {
          window.__cave9FamilyFormErrors = [];
          const record = (kind, detail) => window.__cave9FamilyFormErrors.push(`${kind}: ${detail}`);
          window.addEventListener('unhandledrejection', (event) =>
            record('unhandledrejection', event.reason?.stack || event.reason || 'unknown rejection'));
          document.addEventListener('webglcontextlost', (event) => {
            event.preventDefault(); record('webglcontextlost', event.statusMessage || 'lost');
          }, true);
          document.addEventListener('webglcontextrestored', () =>
            record('webglcontextrestored', 'restored'), true);
        });
        const page = await context.newPage();
        const errors = [];
        page.on('console', (message) => { if (message.type() === 'error') errors.push(`console: ${message.text()}`); });
        page.on('pageerror', (error) => errors.push(`pageerror: ${error.message}`));
        const visualUrl = new URL(url);
        visualUrl.searchParams.set('visualLab', '1'); visualUrl.searchParams.set('capture', '1');
        await page.goto(visualUrl.href, { waitUntil: 'load', timeout: 30000 });
        await page.waitForFunction(() => window.__cave9?.visual?.snapshot, undefined, { timeout: 30000 });
        manifest.environment = await page.evaluate(() => {
          const renderer = window.__cave9.renderer.renderer;
          const gl = renderer.getContext();
          const extension = gl.getExtension('WEBGL_debug_renderer_info');
          return { userAgent: navigator.userAgent, browserPlatform: navigator.platform,
            hardwareConcurrency: navigator.hardwareConcurrency ?? null,
            webgl: { available: !!gl, contextLost: gl.isContextLost(), version: gl.getParameter(gl.VERSION),
              vendor: extension ? gl.getParameter(extension.UNMASKED_VENDOR_WEBGL) : gl.getParameter(gl.VENDOR),
              renderer: extension ? gl.getParameter(extension.UNMASKED_RENDERER_WEBGL) : gl.getParameter(gl.RENDERER) } };
        });

        for (const spec of familySpecs) {
          const resolution = await resolveVisibleFamilyGeometry(page, spec);
          manifest.resolutions[spec.family] = resolution;
          writeManifest(runDir, manifest);
          for (const template of familyFormTemplates(spec.family)) {
            const scenario = resolvedFamilyScenario(template, spec, resolution);
            const errorStart = errors.length;
            const result = await captureScenario(page, scenario);
            await settle(page);
            const file = resolve(frameDir, `${scenario.id}.png`);
            writeFileSync(file, await canvasPng(page));
            const runtimeState = await runtimeSnapshot(page);
            const runtimeErrors = [...errors.slice(errorStart), ...(runtimeState.browserErrors || []),
              ...(runtimeState.glErrors || []).map((code) => `webgl getError: ${code}`),
              ...(runtimeState.webglAvailable ? [] : ['webgl unavailable']),
              ...(runtimeState.webglContextLost ? ['webgl context lost'] : [])];
            const image = inspectPng(file, suite.viewport);
            let control = null;
            let difference = null;
            if (scenario.kind === 'hero') {
              const controlErrorStart = errors.length;
              const controlResult = await captureFamilyOffControl(page, scenario);
              await settle(page);
              const controlFile = resolve(frameDir, `${scenario.id}-control-off.png`);
              const differenceFile = resolve(frameDir, `${scenario.id}-family-diff.png`);
              writeFileSync(controlFile, await canvasPng(page));
              const controlRuntime = await runtimeSnapshot(page);
              const controlRuntimeErrors = [
                ...errors.slice(controlErrorStart),
                ...(controlRuntime.browserErrors || []),
                ...(controlRuntime.glErrors || []).map((code) => `webgl getError: ${code}`),
                ...(controlRuntime.webglAvailable ? [] : ['webgl unavailable']),
                ...(controlRuntime.webglContextLost ? ['webgl context lost'] : []),
              ];
              const controlImage = inspectPng(controlFile, suite.viewport);
              const metrics = inspectPngDifference(file, controlFile, suite.viewport,
                { writeMaskFile: differenceFile });
              control = {
                captureApi: controlResult.api,
                normalizedScenario: controlResult.normalizedScenario,
                snapshot: controlResult.snapshot,
                runtime: controlRuntime,
                runtimeErrors: controlRuntimeErrors,
                file: relative(runDir, controlFile).replace(/\\/g, '/'),
                image: controlImage,
              };
              difference = {
                file: relative(runDir, differenceFile).replace(/\\/g, '/'),
                image: inspectPng(differenceFile, suite.viewport),
                metrics,
              };
            }
            const evaluated = evaluateFrame({ scenario, captureInfo: result.info,
              runtime: runtimeState, image, errors: runtimeErrors });
            const placementBehindFrontMeters = resolution.visibleGeometryBounds.reviewFrontDepth - result.snapshot.distance;
            const resolvedApproachMeters = scenario.kind === 'hero' ? placementBehindFrontMeters : null;
            const approachPass = scenario.kind !== 'hero'
              || Math.abs(resolvedApproachMeters - scenario.approachMeters) <= 0.01;
            const debugPass = scenario.kind === 'collision' ? result.debugGeometry.collisionCapsules > 0
              : scenario.kind === 'boolean-tube' ? result.debugGeometry.booleanTubeObjects > 0 : true;
            const checks = { ...evaluated.checks,
              framing: familyFormFramingCheck(scenario.kind, image),
              resolvedApproach: { pass: approachPass, expected: scenario.approachMeters,
                actual: resolvedApproachMeters, frontDepth: resolution.visibleGeometryBounds.frontDepth,
                reviewFrontDepth: resolution.visibleGeometryBounds.reviewFrontDepth },
              placementDepth: { pass: Math.abs(placementBehindFrontMeters - scenario.placementBehindFrontMeters) <= 0.01,
                expectedBehindFrontMeters: scenario.placementBehindFrontMeters,
                actualBehindFrontMeters: placementBehindFrontMeters,
                note: scenario.kind === 'orbit' ? 'ship setup depth only; not orbit-camera distance' : null },
              debugGeometry: { pass: debugPass, ...result.debugGeometry },
              familyOffControl: scenario.kind !== 'hero' ? { pass: true, required: false } : {
                pass: control?.snapshot?.version === 'VisualSnapshotV1'
                  && control.snapshot.family?.requested === 'off'
                  && (control.snapshot.family?.active?.length ?? 0) === 0
                  && Math.abs(Number(control.snapshot.distance) - scenario.distance) <= 0.001
                  && control.snapshot.camera?.active === 'hero'
                  && control.snapshot.viewport?.matches === true
                  && control.runtime?.appState === 'capture'
                  && control.runtime?.gamePhase === 'running'
                  && control.runtimeErrors.length === 0
                  && control.image.blank.pass && control.image.viewport.pass,
                required: true,
                actual: control,
              },
              familyDifference: scenario.kind !== 'hero' ? { pass: true, required: false }
                : familyFormHeroDifferenceCheck(scenario.family, scenario.approachMeters,
                  difference?.metrics),
            };
            const passEvidence = result.renderPassEvidence;
            const renderPassOk = passEvidence.active === scenario.captureOptions.renderPass
              && passEvidence.familyMeshCount > 0
              && passEvidence.matchedMaterialCount === passEvidence.familyMeshCount
              && (scenario.captureOptions.renderPass !== 'clay'
                || (passEvidence.caveVisible && passEvidence.caveClayMaterial
                  && passEvidence.clayRigVisible && !!passEvidence.lightRig))
              && (scenario.captureOptions.renderPass !== 'silhouette'
                || (passEvidence.caveVisible === false && passEvidence.backgroundHex === 'ffffff'));
            checks.renderPassEvidence = { pass: renderPassOk, ...passEvidence };
            const status = Object.values(checks).every((check) => check.pass) ? 'pass' : 'fail';
            manifest.frames.push({
              id: scenario.id, family: scenario.family, kind: scenario.kind, seed: scenario.seed,
              approachMeters: scenario.kind === 'hero' ? scenario.approachMeters : null,
              placementBehindFrontMeters, orbitDegrees: scenario.orbitDegrees ?? null,
              requestedDepth: scenario.distance,
              resolvedFrontDepth: resolution.visibleGeometryBounds.reviewFrontDepth,
              absoluteFrontDepth: resolution.visibleGeometryBounds.frontDepth,
              resolvedApproachMeters, captureOptions: scenario.captureOptions, captureApi: result.api,
              normalizedScenario: result.normalizedScenario, snapshot: result.snapshot,
              captureInfo: result.info, debugGeometry: result.debugGeometry,
              renderPassEvidence: result.renderPassEvidence,
              control,
              difference,
              runtime: runtimeState, runtimeErrors,
              file: relative(runDir, file).replace(/\\/g, '/'), image, status, checks,
            });
            writeManifest(runDir, manifest);
          }
        }
      } finally {
        if (browser) await browser.close().catch(() => {});
      }
    }, { root, port: port ? Number(port) : undefined,
      log: (line) => { if (serverLog.join('').length < 16000) serverLog.push(line); } });
    manifest.report = writeFamilyFormReport(runDir, manifest);
    manifest.completedAt = new Date().toISOString();
    manifest.serverLog = serverLog.join('').slice(-16000);
    writeManifest(runDir, manifest);
    return await verifyFamilyFormRun({ root, runDir });
  } catch (error) {
    manifest.completedAt = new Date().toISOString();
    manifest.status = 'fail';
    manifest.automated = { status: 'fail', checkedAt: manifest.completedAt };
    manifest.errors.push(error?.stack || String(error));
    manifest.serverLog = serverLog.join('').slice(-16000);
    writeManifest(runDir, manifest);
    error.runDir = runDir;
    throw error;
  }
}

if (process.argv[1] && resolve(process.argv[1]) === resolve(fileURLToPath(import.meta.url))) {
  const args = parseArgs(process.argv.slice(2));
  captureFamilyForm({ runId: args['run-id'], families: args.families,
    headed: !!args.headed, browserChannel: args.chrome ? 'chrome' : undefined, port: args.port })
    .then((manifest) => {
      console.log(`family-form evidence: ${manifest.status}`);
      console.log(resolve(root, 'artifacts/visual-lab/family-form', manifest.runId));
      if (manifest.status === 'fail' || manifest.status === 'stale') process.exitCode = 1;
    })
    .catch((error) => { console.error(error); if (error.runDir) console.error(`partial run: ${error.runDir}`); process.exitCode = 1; });
}
