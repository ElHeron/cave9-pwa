import { chromium } from '@playwright/test';
import { spawn } from 'node:child_process';
import { existsSync, mkdirSync, writeFileSync } from 'node:fs';
import { join, relative, resolve } from 'node:path';
import { inspectPng, inspectPngDifference } from './image-checks.mjs';
import { gitProvenance, runtimeFingerprint } from './provenance.mjs';

const args = process.argv.slice(2);
const raw = (flag, fallback) => {
  const index = args.indexOf(flag);
  return index >= 0 && args[index + 1] ? args[index + 1] : fallback;
};
const runId = String(raw('--run-id', new Date().toISOString().replace(/[-:.]/g, '')))
  .replace(/[^a-zA-Z0-9._-]/g, '-');
const port = Math.max(1024, Math.min(65535, Number(raw('--port', '5203')) || 5203));
const root = process.cwd();
const runDir = resolve(root, 'artifacts/visual-lab/relief-ab', runId);
if (existsSync(runDir)) throw new Error(`immutable relief A/B run already exists: ${runDir}`);
mkdirSync(runDir, { recursive: true });

const url = `http://127.0.0.1:${port}/?visualLab=1&capture=1`;
const server = spawn(process.execPath,
  [resolve('node_modules/vite/bin/vite.js'), 'preview', '--port', String(port), '--strictPort'], {
    cwd: root, shell: false, stdio: 'ignore',
  });

async function waitForServer() {
  const deadline = Date.now() + 30000;
  while (Date.now() < deadline) {
    try { if ((await fetch(url)).ok) return; } catch { /* retry */ }
    await new Promise((done) => setTimeout(done, 100));
  }
  throw new Error('preview server did not start');
}

const scenes = Object.freeze([
  { id: 'cave', seed: 4096, distance: 500, family: 'off' },
  // A45 for the current seed-2024 Coiling contract: near enough for the
  // near-field samples while preserving the real Hero/route presentation.
  { id: 'coiling', seed: 2024, distance: 2024.969, family: 'coiling' },
]);

let browser;
try {
  await waitForServer();
  browser = await chromium.launch({
    headless: !args.includes('--headed'),
    channel: args.includes('--chrome') ? 'chrome' : undefined,
  });
  const page = await browser.newPage({ viewport: { width: 1280, height: 720 }, deviceScaleFactor: 1 });
  await page.addInitScript(() => {
    window.__reliefAbContextEvents = [];
    const original = HTMLCanvasElement.prototype.getContext;
    HTMLCanvasElement.prototype.getContext = function patchedGetContext(kind, ...rest) {
      if (/^webgl2?$/i.test(String(kind)) && !this.__reliefAbObserved) {
        this.__reliefAbObserved = true;
        this.addEventListener('webglcontextlost', (event) => {
          event.preventDefault();
          window.__reliefAbContextEvents.push('lost-before-capture');
        });
        this.addEventListener('webglcontextrestored', () => {
          window.__reliefAbContextEvents.push('restored-before-capture');
        });
      }
      return original.call(this, kind, ...rest);
    };
  });
  const browserErrors = [];
  page.on('console', (message) => {
    if (message.type() === 'error') browserErrors.push(`console: ${message.text()}`);
  });
  page.on('pageerror', (error) => browserErrors.push(`pageerror: ${error.message}`));
  await page.goto(url, { waitUntil: 'load' });
  await page.waitForFunction(() => window.__cave9?.visual?.loadScenario
    && window.__cave9?.state !== 'boot');
  await page.evaluate(() => {
    const canvas = window.__cave9.canvas;
    canvas.addEventListener('webglcontextlost', (event) => {
      event.preventDefault();
      window.__reliefAbContextEvents.push('lost');
    });
    canvas.addEventListener('webglcontextrestored', () => window.__reliefAbContextEvents.push('restored'));
    window.addEventListener('unhandledrejection', (event) => {
      window.__reliefAbContextEvents.push(`unhandledrejection:${event.reason?.message || event.reason}`);
    });
  });
  await page.waitForFunction(() => !window.__cave9.renderer.renderer.getContext().isContextLost(),
    undefined, { timeout: 10000 });

  const frames = [];
  for (const scene of scenes) {
    for (const enabled of [false, true]) {
      const state = await page.evaluate(async ({ scene, enabled }) => {
        window.__cave9.visual.loadScenario({
          version: 'VisualScenarioV1', name: `relief-${scene.id}-${enabled ? 'on' : 'off'}`,
          seed: scene.seed, distance: scene.distance, family: scene.family,
          placement: 'place', paused: true, camera: 'hero',
          viewport: { width: 1280, height: 720, dpr: 1 },
          settings: {
            readability: true, rockDetail: true, surfaceRelief: enabled,
            landmarks: scene.family !== 'off', cave: true, wireframe: false,
            landmarkMesh: true, collisionCapsules: false, booleanTube: false,
            playerHull: false, frames: false, fog: true, material: true,
            light: true, brightness: 1, fov: 45, motion: 0,
          },
        });
        if (enabled) await window.__cave9.renderer.surfaceReliefReady();
        window.__cave9.visual.step(0);
        const renderer = window.__cave9.renderer;
        const gl = renderer.renderer.getContext();
        return {
          snapshot: window.__cave9.visual.snapshot(),
          relief: {
            enabled: renderer.surfaceRelief,
            profile: renderer.surfaceReliefProfile,
            define: renderer.caveMat.defines?.CAVE_RELIEF_MAPS ?? null,
            normalReady: !!renderer.caveFacet.reliefNormalMap.value?.image?.width,
            heightReady: !!renderer.caveFacet.reliefHeightMap.value?.image?.width,
          },
          assetMetrics: { ...renderer.assetMetrics },
          glError: gl.getError(),
          contextLost: gl.isContextLost(),
          contextEvents: [...window.__reliefAbContextEvents],
        };
      }, { scene, enabled });
      const filename = `${scene.id}-${enabled ? 'relief' : 'baseline'}.png`;
      const file = join(runDir, filename);
      const dataUrl = state.snapshot.image?.dataUrl;
      if (!dataUrl?.startsWith('data:image/png;base64,')) {
        throw new Error(`${filename}: VisualSnapshotV1 did not contain a PNG canvas capture`);
      }
      writeFileSync(file, Buffer.from(dataUrl.slice(dataUrl.indexOf(',') + 1), 'base64'));
      state.snapshot.image.dataUrl = null;
      frames.push({
        id: scene.id, enabled, file: filename, image: inspectPng(file, [1280, 720]), ...state,
      });
    }
  }

  const comparisons = scenes.map((scene) => {
    const mask = `${scene.id}-difference.png`;
    return {
      id: scene.id,
      mask,
      ...inspectPngDifference(
        join(runDir, `${scene.id}-relief.png`),
        join(runDir, `${scene.id}-baseline.png`),
        [1280, 720], { threshold: 2, writeMaskFile: join(runDir, mask) },
      ),
    };
  });
  const source = { git: await gitProvenance(root), runtime: runtimeFingerprint(root) };
  const pass = browserErrors.length === 0
    && frames.every((frame) => frame.image.blank.pass && frame.glError === 0 && !frame.contextLost
      && frame.contextEvents.length === 0)
    && frames.filter((frame) => frame.enabled).every((frame) => frame.relief.enabled
      && frame.relief.define === 1 && frame.relief.normalReady && frame.relief.heightReady
      && frame.assetMetrics.reliefLoadFailures === 0)
    && frames.filter((frame) => !frame.enabled).every((frame) => !frame.relief.enabled
      && frame.relief.define === null)
    && comparisons.every((comparison) => comparison.fraction >= 0.1
      && comparison.meanChangedDelta >= 0.01 && comparison.quadrantCount === 4
      && comparison.radialBinCount >= 3);
  const report = {
    capturedAt: new Date().toISOString(), runId, status: pass ? 'automatic-pass' : 'automatic-fail',
    manualStatus: 'manual-pending', viewport: [1280, 720], dpr: 1,
    source, browserErrors, frames, comparisons, pass,
  };
  writeFileSync(join(runDir, 'report.json'), `${JSON.stringify(report, null, 2)}\n`);
  console.log(JSON.stringify({
    run: relative(root, runDir), status: report.status, browserErrors,
    frames: frames.map(({ id, enabled, relief, assetMetrics, glError, contextLost, contextEvents }) => ({
      id, enabled, relief, assetMetrics, glError, contextLost, contextEvents,
    })),
    comparisons: comparisons.map(({ id, pixels, fraction, meanFrameDelta, bbox }) => ({
      id, pixels, fraction, meanFrameDelta, bbox,
    })),
  }, null, 2));
  if (!pass) process.exitCode = 1;
} finally {
  await browser?.close();
  server.kill();
}
