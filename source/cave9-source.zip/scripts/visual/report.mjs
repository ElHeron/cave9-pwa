import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { assertRunMutable, parseArgs, readManifest, resolveRunDir, writeManifest } from './manifest.mjs';
import { writeReferenceReport } from './reference-report-lib.mjs';
import { assertCurrentRunProvenance, manifestContractCheck } from './verification.mjs';

export async function regenerateReferenceReport({ root = process.cwd(), runDir } = {}) {
  const manifest = readManifest(runDir);
  assertRunMutable(runDir, manifest, 'regenerate report');
  const contract = manifestContractCheck({ root, runDir, manifest });
  // A missing report is the one allowed precondition for this command; all
  // other run-envelope fields remain authoritative.
  const contractReasons = contract.reasons.filter((reason) => reason !== 'run report paths are not canonical');
  if (contractReasons.length) throw new Error(`cannot report malformed run: ${contractReasons.join('; ')}`);
  await assertCurrentRunProvenance(root, manifest, 'regenerate report for stale run');
  manifest.report = writeReferenceReport({ root, runDir, manifest });
  manifest.automated = { status: 'pending', note: 'Report regenerated; visual:verify is required.' };
  manifest.verification = null;
  manifest.manualReview = { status: 'pending',
    note: 'Report regenerated; the new report and frame set require a fresh structured review.' };
  manifest.status = 'fail';
  writeManifest(runDir, manifest);
  return manifest;
}

if (process.argv[1] && resolve(process.argv[1]) === resolve(fileURLToPath(import.meta.url))) {
  const args = parseArgs(process.argv.slice(2));
  const root = process.cwd();
  const runDir = resolveRunDir(root, args.run || args.positional[0]);
  regenerateReferenceReport({ root, runDir })
    .then((manifest) => console.log(resolve(runDir, manifest.report.html)))
    .catch((error) => { console.error(error); process.exitCode = 1; });
}
