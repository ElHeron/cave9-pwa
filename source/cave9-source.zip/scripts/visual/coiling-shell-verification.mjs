import { existsSync } from 'node:fs';
import { resolve } from 'node:path';
import { inspectPng, inspectPngDifference } from './image-checks.mjs';
import { readManifest, writeManifest } from './manifest.mjs';
import { fileSha256, gitProvenance, runtimeFingerprint } from './provenance.mjs';
import {
  COILING_SHELL_API, COILING_SHELL_ROOM, COILING_SHELL_VIEWPORT,
  coilingHeroDifferenceCheck, coilingHeroScenario, coilingShellFramingCheck,
  coilingShellSuiteDefinition,
} from './coiling-shell-config.mjs';

export function exactCoilingShellMatrix(manifest) {
  const expected = coilingShellSuiteDefinition().templates;
  const frames = Array.isArray(manifest.frames) ? manifest.frames : [];
  const expectedById = new Map(expected.map((entry) => [entry.id, entry]));
  const reasons = [];
  if (manifest.suite?.name !== 'coiling-shell-evidence') reasons.push('wrong suite name');
  if (JSON.stringify(manifest.suite?.viewport) !== JSON.stringify(COILING_SHELL_VIEWPORT)) {
    reasons.push('wrong viewport');
  }
  if (frames.length !== expected.length) reasons.push(`expected ${expected.length} frames, found ${frames.length}`);
  if (new Set(frames.map((frame) => frame.id)).size !== frames.length) reasons.push('duplicate frame ids');
  for (const template of expected) if (!frames.some((frame) => frame.id === template.id)) {
    reasons.push(`missing frame ${template.id}`);
  }
  for (const frame of frames) {
    const template = expectedById.get(frame.id);
    if (!template) reasons.push(`unexpected frame ${frame.id}`);
    else if (frame.captureApi !== template.captureApi) reasons.push(`${frame.id} used wrong capture authority`);
    if (frame.kind === 'hero' && frame.snapshot?.version !== 'VisualSnapshotV1') {
      reasons.push(`${frame.id} has no VisualSnapshotV1`);
    }
    if (frame.kind === 'hero') {
      if (!frame.control?.file || !frame.difference?.file) reasons.push(`${frame.id} has no family-off pair`);
      if (frame.control?.snapshot?.version !== 'VisualSnapshotV1'
        || frame.control?.snapshot?.family?.requested !== 'off'
        || (frame.control?.snapshot?.family?.active?.length ?? 0) !== 0) {
        reasons.push(`${frame.id} has no valid family-off VisualSnapshotV1`);
      }
    }
  }
  return { pass: reasons.length === 0, expectedFrames: expected.length,
    actualFrames: frames.length, reasons };
}

export function coilingShellAuthorityChecks(authority) {
  const contract = authority?.contract;
  const rings = authority?.rings;
  const counts = authority?.geometryCounts;
  const identity = authority?.identity;
  const finiteBounds = ['minX', 'minY', 'minZ', 'maxX', 'maxY', 'maxZ']
    .every((key) => Number.isFinite(rings?.bounds?.[key]));
  return {
    forcedBeforePrime: {
      pass: identity?.requestedFamily === 'coiling'
        && identity?.gameFamilyOverride === 'coiling'
        && identity?.caveFamilyOverride === 'coiling'
        && identity?.compositionType === 'coiling'
        && identity?.surfaceResident === true,
      actual: identity ?? null,
    },
    contract: {
      pass: contract?.version === 'coiling-shell-v2'
        && contract?.roomIndex === COILING_SHELL_ROOM
        && contract?.span >= 160 && contract?.span <= 200
        && contract?.turns >= 1.1 && contract?.turns <= 1.5
        && contract?.ridgeStrength >= 7.6 && contract?.ridgeStrength <= 9.2
        && contract?.halfWidth >= 0.68 && contract?.halfWidth <= 0.84
        && contract?.shoulderWidth >= 1.50 && contract?.shoulderWidth <= 1.70
        && contract?.shoulderWidth > contract?.halfWidth
        && contract?.secondaryScale === (contract?.channelCount === 2 ? 0.45 : 0)
        && (contract?.channelCount === 1 || contract?.channelCount === 2)
        && (contract?.handedness === -1 || contract?.handedness === 1)
        && Math.abs((contract?.end - contract?.start) - contract?.span) <= 1e-9,
      actual: contract ?? null,
    },
    ringSpan: {
      pass: rings?.sectorCount === 32
        && rings?.count >= Math.floor(Number(contract?.span) / 2.01) - 1
        && rings?.monotonic === true && rings?.uniqueDepths === true
        && rings?.minimumDepthStep > 0 && rings?.maximumDepthStep <= 2.01
        && Number.isFinite(rings?.firstDepth) && Number.isFinite(rings?.lastDepth)
        && rings.firstDepth - Number(contract?.start) >= -1e-6
        && rings.firstDepth - Number(contract?.start) <= 2.01
        && Number(contract?.end) - rings.lastDepth >= -1e-6
        && Number(contract?.end) - rings.lastDepth <= 2.01,
      actual: rings ?? null,
    },
    ringBoundsAndFingerprint: {
      pass: finiteBounds && rings?.bounds?.vertexCount === rings?.count * 32
        && typeof rings?.fingerprint === 'string' && /^[0-9a-f]{8}$/i.test(rings.fingerprint)
        && typeof rings?.sha256 === 'string' && /^[0-9a-f]{64}$/i.test(rings.sha256),
      actual: { bounds: rings?.bounds ?? null, fingerprint: rings?.fingerprint ?? null,
        sha256: rings?.sha256 ?? null },
    },
    booleanReserve: {
      pass: Number.isFinite(rings?.minimumShipClearReserve)
        && rings.minimumShipClearReserve >= 0.49
        && Number.isFinite(rings?.minimumBooleanReserve)
        && rings.minimumBooleanReserve >= 1.49,
      expected: { shipClearReserve: 0.5, booleanReserveIncludesShip: 1.5 },
      actual: { shipClearReserve: rings?.minimumShipClearReserve ?? null,
        booleanReserve: rings?.minimumBooleanReserve ?? null },
    },
    zeroSecondaryGeometry: {
      pass: counts?.pieces === 0 && counts?.collisionPieces === 0
        && counts?.landmarkMeshes === 0 && counts?.landmarkTriangles === 0
        && counts?.collisionCapsuleObjects === 0,
      actual: counts ?? null,
    },
    atlasAuthority: {
      pass: authority?.atlas?.version === 1
        && authority?.atlas?.ringCount >= rings?.count
        && authority?.atlas?.sectorCount === 32
        && authority?.atlas?.landmarkCount === 0
        && authority?.atlas?.sourceRingFingerprint === rings?.fingerprint,
      actual: authority?.atlas ?? null,
    },
    authorityRuntime: {
      pass: authority?.runtime?.appState === 'capture'
        && authority?.runtime?.gamePhase === 'running'
        && authority?.runtime?.glErrors?.length === 0
        && authority?.runtimeErrors?.length === 0,
      actual: authority?.runtime ?? null,
      errors: authority?.runtimeErrors ?? [],
    },
  };
}

function heroChecks(frame, contract) {
  const expected = coilingHeroScenario({ kind: 'hero', id: frame.id,
    approachMeters: frame.approachMeters }, contract);
  const snapshot = frame.snapshot;
  const runtime = frame.runtime;
  return {
    visualContract: { pass: snapshot?.version === 'VisualSnapshotV1'
      && snapshot?.family?.requested === 'coiling'
      && snapshot?.scenario?.family === 'coiling'
      && snapshot?.scenario?.placement === 'place'
      && snapshot?.camera?.requested === 'hero'
      && snapshot?.camera?.active === 'hero'
      && snapshot?.camera?.supported === true,
    actual: snapshot ?? null },
    exactDepth: { pass: Math.abs(Number(snapshot?.distance) - expected.distance) <= 0.001,
      expected: expected.distance, actual: snapshot?.distance ?? null },
    resolvedApproach: { pass: Math.abs(expected.visibleFrontDepth - Number(snapshot?.distance)
      - frame.approachMeters) <= 0.001, expected: frame.approachMeters,
    actual: expected.visibleFrontDepth - Number(snapshot?.distance),
    visibleFrontDepth: expected.visibleFrontDepth,
    contractStart: contract.start },
    runtime: { pass: runtime?.appState === 'capture' && runtime?.gamePhase === 'running'
      && runtime?.glErrors?.length === 0 && frame.runtimeErrors?.length === 0,
    actual: runtime ?? null, errors: frame.runtimeErrors ?? [] },
    viewport: { pass: snapshot?.viewport?.matches === true },
    api: { pass: frame.captureApi === COILING_SHELL_API, actual: frame.captureApi },
  };
}

export async function verifyCoilingShellRun({ root = process.cwd(), runDir, write = true } = {}) {
  const manifest = readManifest(runDir);
  const currentGit = await gitProvenance(root);
  const currentRuntime = runtimeFingerprint(root);
  const staleReasons = [];
  if (currentGit.commit !== manifest.source?.git?.commit) staleReasons.push('git commit changed');
  if (currentGit.diffFingerprint !== manifest.source?.git?.diffFingerprint) staleReasons.push('workspace diff fingerprint changed');
  if (currentRuntime.source.sha256 !== manifest.source?.runtime?.source?.sha256) staleReasons.push('runtime source fingerprint changed');
  if (currentRuntime.assets.sha256 !== manifest.source?.runtime?.assets?.sha256) staleReasons.push('runtime asset fingerprint changed');

  const authorityChecks = coilingShellAuthorityChecks(manifest.authority);
  const authorityPass = Object.values(authorityChecks).every((check) => check.pass);
  const matrix = exactCoilingShellMatrix(manifest);
  const frames = (manifest.frames || []).map((frame) => {
    const file = resolve(runDir, frame.file || 'missing');
    if (!existsSync(file)) return { ...frame, status: 'fail', checks: {
      file: { pass: false, reason: 'PNG is missing' },
    } };
    const image = inspectPng(file, COILING_SHELL_VIEWPORT);
    const checks = {
      checksum: { pass: image.sha256 === frame.image?.sha256,
        expected: frame.image?.sha256, actual: image.sha256 },
      framing: coilingShellFramingCheck(frame.kind, image),
      runtimeErrors: { pass: (frame.runtimeErrors || []).length === 0,
        errors: frame.runtimeErrors || [] },
    };
    if (frame.kind === 'hero') {
      Object.assign(checks, heroChecks(frame, manifest.authority.contract));
      const controlFile = resolve(runDir, frame.control?.file || 'missing-control');
      const differenceFile = resolve(runDir, frame.difference?.file || 'missing-difference');
      const controlExists = existsSync(controlFile);
      const differenceExists = existsSync(differenceFile);
      const controlImage = controlExists ? inspectPng(controlFile, COILING_SHELL_VIEWPORT) : null;
      const differenceImage = differenceExists ? inspectPng(differenceFile, COILING_SHELL_VIEWPORT) : null;
      const difference = controlExists
        ? inspectPngDifference(file, controlFile, COILING_SHELL_VIEWPORT) : null;
      const controlSnapshot = frame.control?.snapshot;
      checks.familyOffControl = {
        pass: controlExists && controlSnapshot?.version === 'VisualSnapshotV1'
          && controlSnapshot.family?.requested === 'off'
          && (controlSnapshot.family?.active?.length ?? 0) === 0
          && controlSnapshot.layers?.landmarks === false
          && Math.abs(Number(controlSnapshot.distance) - Number(frame.snapshot?.distance)) <= 0.001
          && controlSnapshot.camera?.active === 'hero' && controlSnapshot.viewport?.matches === true
          && frame.control?.runtime?.appState === 'capture'
          && frame.control?.runtime?.gamePhase === 'running'
          && (frame.control?.runtimeErrors?.length ?? 0) === 0
          && controlImage?.blank?.pass === true && controlImage?.viewport?.pass === true,
        required: true,
      };
      checks.controlChecksum = {
        pass: controlExists && controlImage.sha256 === frame.control?.image?.sha256,
        expected: frame.control?.image?.sha256 ?? null,
        actual: controlImage?.sha256 ?? null,
      };
      checks.familyDifference = coilingHeroDifferenceCheck(frame.approachMeters, difference);
      checks.differenceChecksum = {
        pass: differenceExists && differenceImage.sha256 === frame.difference?.image?.sha256
          && difference?.maskSha256 === differenceImage.sha256,
        expected: frame.difference?.image?.sha256 ?? null,
        actual: differenceImage?.sha256 ?? null,
        recomputed: difference?.maskSha256 ?? null,
      };
    }
    if (frame.sourceFile) {
      const sourceFile = resolve(runDir, frame.sourceFile);
      checks.sourceSvg = { pass: existsSync(sourceFile)
        && fileSha256(sourceFile) === frame.sourceSha256,
      expected: frame.sourceSha256,
      actual: existsSync(sourceFile) ? fileSha256(sourceFile) : null };
    }
    const status = Object.values(checks).every((check) => check.pass) ? 'pass' : 'fail';
    return { ...frame, image, checks, status };
  });
  const reportFiles = ['json', 'html'].map((key) => {
    const name = manifest.report?.[key];
    const file = name && resolve(runDir, name);
    return { key, file: name, pass: !!file && existsSync(file)
      && fileSha256(file) === manifest.report?.[`${key}Sha256`] };
  });
  const automatic = matrix.pass && authorityPass
    && frames.every((frame) => frame.status === 'pass')
    && reportFiles.every((entry) => entry.pass);
  manifest.frames = frames;
  manifest.authorityChecks = authorityChecks;
  manifest.automated = { status: automatic ? 'pass' : 'fail', checkedAt: new Date().toISOString(),
    matrix, authorityPass, reportFiles, passedFrames: frames.filter((frame) => frame.status === 'pass').length,
    totalFrames: frames.length };
  manifest.verification = { checkedAt: new Date().toISOString(), stale: staleReasons.length > 0,
    staleReasons, current: { git: currentGit, runtime: currentRuntime } };
  manifest.status = staleReasons.length ? 'stale' : automatic ? 'manual-pending' : 'fail';
  if (write) writeManifest(runDir, manifest);
  return manifest;
}
