import { existsSync } from 'node:fs';
import { resolve } from 'node:path';
import { inspectPng, evaluateFrame } from './image-checks.mjs';
import { fileSha256, gitProvenance, referenceFingerprint, runtimeFingerprint } from './provenance.mjs';
import {
  assertRunMutable,
  isCanonicalRunDir,
  readManifest,
  resolveRunArtifact,
  writeManifest,
} from './manifest.mjs';
import { formReleaseScenarios, suiteDefinition } from './config.mjs';
import { normalizeVisualScenario } from '../../src/dev/scenario/schema.mjs';

export const FORM_RELEASE_RUN_KIND = 'cave9-visual-evidence-run';
export const MANUAL_REVIEW_CRITERIA = Object.freeze([
  'recognizable', 'wallIntegrated', 'depthLayers', 'centralOpening', 'axialEffect',
]);

const equalJson = (a, b) => JSON.stringify(a) === JSON.stringify(b);
const isoDate = (value) => typeof value === 'string' && Number.isFinite(Date.parse(value));

export function exactMatrixCheck(manifest) {
  const expected = formReleaseScenarios();
  const frames = Array.isArray(manifest.frames) ? manifest.frames : [];
  const reasons = [];
  const ids = frames.map((frame) => frame.id);
  const files = frames.map((frame) => frame.file);
  if (frames.length !== expected.length) reasons.push(`expected ${expected.length} frames, found ${frames.length}`);
  if (new Set(ids).size !== ids.length) reasons.push('duplicate frame ids');
  if (new Set(files).size !== files.length) reasons.push('duplicate frame files');
  const byId = new Map(frames.map((frame) => [frame.id, frame]));
  for (const scenario of expected) {
    const frame = byId.get(scenario.id);
    if (!frame) { reasons.push(`missing frame ${scenario.id}`); continue; }
    for (const key of ['family', 'seed', 'offset']) {
      if (frame[key] !== scenario[key]) reasons.push(`${scenario.id} has wrong ${key}`);
    }
    if (frame.requestedDepth !== scenario.distance) reasons.push(`${scenario.id} has wrong requestedDepth`);
    if (!equalJson(frame.captureOptions, scenario.captureOptions)) {
      reasons.push(`${scenario.id} has wrong captureOptions`);
    }
    if (frame.file !== `frames/${scenario.id}.png`) reasons.push(`${scenario.id} has non-canonical frame path`);
    if (frame.captureApi !== suiteDefinition().captureApi) reasons.push(`${scenario.id} did not use VisualScenarioV1 API`);
    if (frame.snapshot?.version !== 'VisualSnapshotV1') reasons.push(`${scenario.id} has no VisualSnapshotV1`);
    const normalizedExpected = normalizeVisualScenario(scenario.captureOptions);
    if (!equalJson(frame.normalizedScenario, normalizedExpected)) {
      reasons.push(`${scenario.id} normalized scenario differs from the complete VisualScenarioV1 contract`);
    }
    if (!equalJson(frame.snapshot?.scenario, normalizedExpected)) {
      reasons.push(`${scenario.id} snapshot scenario differs from the complete VisualScenarioV1 contract`);
    }
  }
  const suite = suiteDefinition();
  if (!equalJson(manifest.suite, suite)) reasons.push('suite definition differs from form-release contract');
  return { pass: reasons.length === 0, expectedFrames: expected.length, actualFrames: frames.length, reasons };
}

export function manifestContractCheck({ root, runDir, manifest }) {
  const reasons = [];
  if (manifest?.schemaVersion !== 1) reasons.push('manifest schemaVersion must be 1');
  if (manifest?.kind !== FORM_RELEASE_RUN_KIND) reasons.push(`manifest kind must be ${FORM_RELEASE_RUN_KIND}`);
  if (typeof manifest?.runId !== 'string' || !/^[a-zA-Z0-9._-]+$/.test(manifest.runId)) {
    reasons.push('manifest runId is invalid');
  } else if (!isCanonicalRunDir(root, runDir, manifest.runId)) {
    reasons.push('run directory is not the canonical artifacts/visual-lab/<runId> directory');
  }
  if (!isoDate(manifest?.createdAt)) reasons.push('manifest createdAt is invalid');
  if (!isoDate(manifest?.completedAt)) reasons.push('manifest completedAt is missing or invalid');
  if (isoDate(manifest?.createdAt) && isoDate(manifest?.completedAt)
    && Date.parse(manifest.completedAt) < Date.parse(manifest.createdAt)) {
    reasons.push('manifest completedAt precedes createdAt');
  }
  if (!manifest?.source?.git || !manifest?.source?.reference || !manifest?.source?.runtime) {
    reasons.push('manifest source provenance is incomplete');
  }
  if (manifest?.environment?.browser?.webgl?.available !== true) {
    reasons.push('capture browser did not prove an available WebGL context');
  }
  if (!Array.isArray(manifest?.errors)) reasons.push('manifest errors must be an array');
  else if (manifest.errors.length > 0) reasons.push('run contains top-level errors');
  if (!manifest?.report || manifest.report.json !== 'reference-report.json'
    || manifest.report.html !== 'reference-report.html') {
    reasons.push('run report paths are not canonical');
  }
  return { pass: reasons.length === 0, reasons };
}

export function manualCriteriaCheck(review) {
  if (review?.status !== 'pass') return { pass: null, reasons: ['manual review is not approved'] };
  const reasons = [];
  const expectedFamilies = suiteDefinition().families.map(({ family }) => family).sort();
  const actualFamilies = Object.keys(review.criteria || {}).sort();
  if (!equalJson(actualFamilies, expectedFamilies)) reasons.push('manual criteria family set differs from suite');
  for (const family of expectedFamilies) {
    const criteria = review.criteria?.[family];
    if (!criteria || typeof criteria !== 'object') {
      reasons.push(`manual criteria are missing for ${family}`);
      continue;
    }
    for (const key of MANUAL_REVIEW_CRITERIA) {
      if (criteria[key] !== true) reasons.push(`${family} manual criterion is not approved: ${key}`);
    }
  }
  return { pass: reasons.length === 0, reasons };
}

export function manualReviewBinding(manifest, frames, reportFiles) {
  if (manifest.manualReview?.status !== 'pass') return { pass: null, reasons: ['manual review is not approved'] };
  const reasons = [];
  const json = reportFiles.find((entry) => entry.key === 'json');
  const html = reportFiles.find((entry) => entry.key === 'html');
  if (manifest.manualReview.reportJsonSha256 !== manifest.report?.jsonSha256 || !json?.pass) {
    reasons.push('reviewed JSON report hash changed');
  }
  if (manifest.manualReview.reportHtmlSha256 !== manifest.report?.htmlSha256 || !html?.pass) {
    reasons.push('reviewed HTML report hash changed');
  }
  const reviewedFrames = new Map((manifest.manualReview.frames || []).map((entry) => [entry.id, entry.sha256]));
  if (reviewedFrames.size !== frames.length) reasons.push('reviewed frame set differs from run');
  for (const frame of frames) {
    if (reviewedFrames.get(frame.id) !== frame.image?.sha256) reasons.push(`reviewed frame changed: ${frame.id}`);
  }
  const criteria = manualCriteriaCheck(manifest.manualReview);
  if (criteria.pass === false) reasons.push(...criteria.reasons);
  return { pass: reasons.length === 0, reasons };
}

export function deriveRunStatus({ stale, automatedStatus, manualStatus }) {
  if (stale) return 'stale';
  if (automatedStatus !== 'pass') return 'fail';
  if (manualStatus === 'fail' || manualStatus === 'invalidated') return 'fail';
  if (manualStatus !== 'pass') return 'manual-pending';
  return 'pass';
}

export function blessingRefusalReasons(manifest) {
  const reasons = [];
  if (manifest.status === 'stale' || manifest.verification?.stale) reasons.push('run is stale');
  if (manifest.automated?.status !== 'pass') reasons.push('automated checks are not passing');
  if (manifest.status === 'fail') reasons.push('run status is fail');
  if (manifest.manualReview?.status !== 'pass') reasons.push('manual review is pending or failed');
  if (manifest.verification?.manualReviewBinding?.pass !== true) reasons.push('manual review binding is not valid');
  if (manifest.status === 'manual-pending') reasons.push('run status is manual-pending');
  return [...new Set(reasons)];
}

export function reconstructRuntimeErrors(frame) {
  const errors = [];
  if (Array.isArray(frame?.runtimeErrors)) errors.push(...frame.runtimeErrors.map(String));
  else errors.push('runtimeErrors is missing or malformed');
  if (Array.isArray(frame?.runtime?.browserErrors)) errors.push(...frame.runtime.browserErrors.map(String));
  else errors.push('runtime.browserErrors is missing or malformed');
  if (Array.isArray(frame?.runtime?.glErrors)) {
    errors.push(...frame.runtime.glErrors.map((code) => `webgl getError: ${code}`));
  } else errors.push('runtime.glErrors is missing or malformed');
  if (frame?.runtime?.webglAvailable !== true) errors.push('webgl unavailable');
  if (frame?.runtime?.webglContextLost === true) errors.push('webgl context lost');
  return [...new Set(errors)];
}

export async function currentRunProvenance(root, manifest) {
  const current = {
    git: await gitProvenance(root),
    reference: referenceFingerprint(root),
    runtime: runtimeFingerprint(root),
  };
  const reasons = [];
  if (current.git.commit !== manifest?.source?.git?.commit) reasons.push('git commit changed');
  if (current.git.diffFingerprint !== manifest?.source?.git?.diffFingerprint) reasons.push('workspace diff fingerprint changed');
  if (current.reference.sha256 !== manifest?.source?.reference?.sha256) reasons.push('reference or frame-metrics inputs changed');
  if (!manifest?.source?.runtime) reasons.push('runtime source/assets fingerprint is missing');
  else {
    if (current.runtime.source.sha256 !== manifest.source.runtime.source?.sha256) reasons.push('runtime source fingerprint changed');
    if (current.runtime.assets.sha256 !== manifest.source.runtime.assets?.sha256) reasons.push('runtime asset fingerprint changed');
  }
  return { current, reasons };
}

export async function assertCurrentRunProvenance(root, manifest, operation = 'use run') {
  const { current, reasons } = await currentRunProvenance(root, manifest);
  if (reasons.length) throw new Error(`refusing to ${operation}: ${reasons.join('; ')}`);
  return current;
}

function failedFrame(frame, reason) {
  return { ...frame, status: 'fail', checks: { file: { pass: false, reason } } };
}

export async function verifyRun({ root = process.cwd(), runDir, write = true }) {
  const manifest = readManifest(runDir);
  assertRunMutable(runDir, manifest, 'verify run');
  const contract = manifestContractCheck({ root, runDir, manifest });
  const { current, reasons: staleReasons } = await currentRunProvenance(root, manifest);
  const matrix = exactMatrixCheck(manifest);
  const frames = (Array.isArray(manifest.frames) ? manifest.frames : []).map((frame) => {
    let file;
    try { file = resolveRunArtifact(runDir, frame.file, { expected: `frames/${frame.id}.png` }); }
    catch (error) { return failedFrame(frame, error.message); }
    if (!existsSync(file)) return failedFrame(frame, 'capture file is missing');
    try {
      const image = inspectPng(file, manifest.suite.viewport);
      const evaluated = evaluateFrame({ scenario: { distance: frame.requestedDepth,
        family: frame.family, captureOptions: frame.captureOptions },
      captureInfo: frame.captureInfo, runtime: frame.runtime, image,
      errors: reconstructRuntimeErrors(frame) });
      if (image.sha256 !== frame.image?.sha256) {
        evaluated.status = 'fail';
        evaluated.checks.checksum = { pass: false, expected: frame.image?.sha256, actual: image.sha256 };
      } else evaluated.checks.checksum = { pass: true, actual: image.sha256 };
      return { ...frame, status: evaluated.status, checks: evaluated.checks, verifiedImage: image };
    } catch (error) { return failedFrame(frame, `capture inspection failed: ${error.message}`); }
  });

  const reportFiles = ['json', 'html'].map((key) => {
    const name = manifest.report?.[key];
    const expectedName = `reference-report.${key}`;
    const expected = manifest.report?.[`${key}Sha256`];
    try {
      const file = resolveRunArtifact(runDir, name, { expected: expectedName });
      return { key, file: name, pass: existsSync(file) && fileSha256(file) === expected };
    } catch { return { key, file: name, pass: false }; }
  });
  const automatedStatus = contract.pass && matrix.pass && frames.every((frame) => frame.status === 'pass')
    && reportFiles.every((entry) => entry.pass) ? 'pass' : 'fail';
  const reviewBinding = manualReviewBinding(manifest, frames, reportFiles);
  if (reviewBinding.pass === false) {
    manifest.manualReview = { ...manifest.manualReview, status: 'invalidated',
      invalidatedAt: new Date().toISOString(), invalidationReasons: reviewBinding.reasons };
  }
  manifest.frames = frames;
  manifest.automated = {
    status: automatedStatus,
    checkedAt: new Date().toISOString(),
    passedFrames: frames.filter((frame) => frame.status === 'pass').length,
    totalFrames: frames.length,
    reportFiles,
    contract,
    matrix,
    similarityIsReleaseGate: false,
  };
  manifest.verification = {
    checkedAt: new Date().toISOString(),
    stale: staleReasons.length > 0,
    staleReasons,
    current,
    manualReviewBinding: reviewBinding,
  };
  manifest.status = deriveRunStatus({ stale: manifest.verification.stale,
    automatedStatus, manualStatus: manifest.manualReview?.status });
  if (write) writeManifest(runDir, manifest);
  return manifest;
}
