import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { basename, relative, resolve } from 'node:path';
import { composition, compositionDistance, loadFrame } from '../lib/frame-metrics.mjs';
import { fileSha256 } from './provenance.mjs';
import { assertRunMutable } from './manifest.mjs';

const escapeHtml = (value) => String(value).replace(/[&<>"']/g, (char) => ({
  '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
}[char]));

export function compositionDescription(file) {
  const projected = composition(loadFrame(file));
  return {
    D7_centralOpening: projected.centralOpening,
    D8_angularSilhouette: projected.angularSilhouette,
    D9_quadrantMass: projected.quadrantMass,
    D10_dominantForms: projected.dominantForms,
    D11_tipDistance: projected.tipDistance,
    D12_projectedOcclusion: projected.projectedOcclusion,
    compositionModel: projected.model,
  };
}

const average = (values) => values.length
  ? values.reduce((sum, value) => sum + value, 0) / values.length : null;

export function aggregateSimilarity(rows) {
  const groups = new Map();
  for (const row of rows) {
    if (!groups.has(row.family)) groups.set(row.family, []);
    if (row.bestPrimaryMatch) groups.get(row.family).push(row.bestPrimaryMatch.similarity);
  }
  const families = Object.fromEntries([...groups].map(([family, values]) => [family, {
    frames: values.length,
    meanBestSimilarity: values.length ? +average(values).toFixed(2) : null,
    minBestSimilarity: values.length ? Math.min(...values) : null,
    maxBestSimilarity: values.length ? Math.max(...values) : null,
  }]));
  const all = Object.values(families).flatMap((entry) => entry.frames ? [entry.meanBestSimilarity] : []);
  return {
    method: 'mean of each capture frame’s best same-family primary-reference similarity',
    diagnosticOnly: true,
    releaseGate: false,
    families,
    overallMeanOfFamilyMeans: all.length ? +average(all).toFixed(2) : null,
  };
}

export function buildReferenceReport({ root, runDir, manifest }) {
  const manifestPath = resolve(root, 'docs/reference/manifest.json');
  const referenceManifest = JSON.parse(readFileSync(manifestPath, 'utf8'));
  const references = referenceManifest.frames.map((entry) => {
    const file = resolve(root, 'docs/reference', entry.file);
    if (!existsSync(file)) throw new Error(`reference manifest lists missing frame: ${entry.file}`);
    return {
      name: entry.file,
      file: relative(root, file).replace(/\\/g, '/'),
      families: entry.families || [],
      roles: entry.roles || [],
      metricEnvelope: entry.metricEnvelope !== false,
      evidence: entry.evidence || [],
      ...compositionDescription(file),
    };
  });
  const captures = manifest.frames.map((entry) => {
    const file = resolve(runDir, entry.file);
    const description = compositionDescription(file);
    const primary = references.filter((ref) => ref.metricEnvelope && ref.families.includes(entry.family));
    const supplemental = references.filter((ref) => !ref.metricEnvelope && ref.families.includes(entry.family));
    const compare = (ref) => ({ reference: ref.name, ...compositionDistance(description, ref) });
    const primaryComparisons = primary.map(compare).sort((a, b) => b.similarity - a.similarity);
    return {
      id: entry.id,
      frame: entry.file,
      family: entry.family,
      offset: entry.offset,
      requestedDepth: entry.requestedDepth,
      capturedDepth: entry.captureInfo?.distanceReached,
      composition: description,
      primaryComparisons,
      bestPrimaryMatch: primaryComparisons[0] || null,
      supplementalComparisons: supplemental.map(compare),
      similarityAuthority: 'diagnostic-only',
    };
  });
  return {
    schemaVersion: 1,
    kind: 'cave9-visual-reference-report',
    generatedAt: new Date().toISOString(),
    runId: manifest.runId,
    suite: manifest.suite.name,
    axes: ['D7', 'D8', 'D9', 'D10', 'D11', 'D12'],
    invariant: 'All capture/reference descriptors use scripts/lib/frame-metrics.mjs on one PNG. Similarity is aggregated diagnostic evidence only and is never an automated release gate.',
    source: {
      referenceManifest: 'docs/reference/manifest.json',
      referenceFingerprint: manifest.source.reference.sha256,
      frameMetrics: 'scripts/lib/frame-metrics.mjs',
    },
    referenceCommonLanguage: referenceManifest.commonLanguage || [],
    references,
    captures,
    aggregateSimilarity: aggregateSimilarity(captures),
  };
}

function metricCells(capture) {
  const d = capture.composition;
  return [
    d.D7_centralOpening.areaRatio,
    d.D8_angularSilhouette.entropy,
    d.D9_quadrantMass.imbalance,
    d.D10_dominantForms.top3Share,
    d.D11_tipDistance.median,
    d.D12_projectedOcclusion.meanCrossings,
  ].map((value) => `<td>${Number(value).toFixed(4)}</td>`).join('');
}

export function reportHtml(report) {
  const rows = report.captures.map((capture) => `<tr>
    <td><a href="${escapeHtml(capture.frame)}"><img src="${escapeHtml(capture.frame)}" alt="${escapeHtml(capture.id)}"></a><br>${escapeHtml(capture.id)}</td>
    <td>${escapeHtml(capture.family)}</td><td>${capture.offset >= 0 ? '+' : ''}${capture.offset}</td>
    ${metricCells(capture)}
    <td>${capture.bestPrimaryMatch ? `${capture.bestPrimaryMatch.similarity.toFixed(2)}%<br><small>${escapeHtml(capture.bestPrimaryMatch.reference)}</small>` : 'n/a'}</td>
  </tr>`).join('\n');
  const familyCards = Object.entries(report.aggregateSimilarity.families).map(([family, value]) =>
    `<li><strong>${escapeHtml(family)}</strong>: ${value.meanBestSimilarity ?? 'n/a'}% mean best-match (${value.frames} frames; min ${value.minBestSimilarity ?? 'n/a'}%, max ${value.maxBestSimilarity ?? 'n/a'}%)</li>`).join('');
  const references = (report.references || []).map((ref) => {
    const href = `../../../docs/reference/${ref.name.split('/').map(encodeURIComponent).join('/')}`;
    return `<tr><td><a href="${href}">${escapeHtml(ref.name)}</a></td><td>${escapeHtml(ref.families.join(', '))}</td><td>${ref.metricEnvelope ? 'primary' : 'supplemental'}</td><td>${(ref.evidence || []).map(escapeHtml).join('<br>')}</td></tr>`;
  }).join('');
  const commonLanguage = (report.referenceCommonLanguage || [])
    .map((item) => `<li>${escapeHtml(item)}</li>`).join('');
  return `<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width">
<title>Cave9 visual evidence · ${escapeHtml(report.runId)}</title>
<style>body{margin:24px;background:#080b11;color:#d8e2ee;font:14px system-ui,sans-serif}h1,h2{color:#fff}a{color:#8ad2ff}code,small{color:#9cafc4}table{border-collapse:collapse;width:100%;background:#0e141e}th,td{padding:8px;border:1px solid #283548;text-align:right;vertical-align:top}th:first-child,td:first-child{text-align:left}img{width:240px;aspect-ratio:16/9;object-fit:cover;background:#000}.notice{padding:12px;border:1px solid #986f20;background:#2a210d;color:#ffe6a3}ul{line-height:1.7}</style></head>
<body><h1>Cave9 form-release evidence</h1>
<p><code>${escapeHtml(report.runId)}</code></p>
<p class="notice"><strong>Diagnostic only:</strong> D7–D12 similarity is not a pass/fail gate and cannot authorize blessing. Automated evidence integrity and explicit manual review remain separate.</p>
<h2>Manifest reference authority</h2><ul>${commonLanguage}</ul>
<table><thead><tr><th>Reference</th><th>Families</th><th>Authority</th><th>Manifest evidence</th></tr></thead><tbody>${references}</tbody></table>
<h2>Aggregate same-family similarity</h2><ul>${familyCards}</ul>
<p>Overall mean of family means: <strong>${report.aggregateSimilarity.overallMeanOfFamilyMeans ?? 'n/a'}%</strong></p>
<h2>Capture matrix</h2><table><thead><tr><th>Frame</th><th>Family</th><th>Offset</th><th>D7 opening</th><th>D8 entropy</th><th>D9 imbalance</th><th>D10 top 3</th><th>D11 tip</th><th>D12 layers</th><th>Best primary similarity</th></tr></thead><tbody>${rows}</tbody></table>
<p>Machine-readable report: <a href="reference-report.json">reference-report.json</a>.</p></body></html>\n`;
}

export function writeReferenceReport({ root = process.cwd(), runDir, manifest }) {
  assertRunMutable(runDir, manifest, 'write reference report');
  const report = buildReferenceReport({ root, runDir, manifest });
  mkdirSync(runDir, { recursive: true });
  const jsonFile = resolve(runDir, 'reference-report.json');
  const htmlFile = resolve(runDir, 'reference-report.html');
  writeFileSync(jsonFile, `${JSON.stringify(report, null, 2)}\n`);
  writeFileSync(htmlFile, reportHtml(report));
  return {
    json: basename(jsonFile), html: basename(htmlFile),
    jsonSha256: fileSha256(jsonFile), htmlSha256: fileSha256(htmlFile),
    diagnosticOnly: true,
    aggregateSimilarity: report.aggregateSimilarity,
  };
}
