import { mkdirSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { fileSha256 } from './provenance.mjs';

const escapeHtml = (value) => String(value ?? '').replace(/[&<>"']/g, (char) => ({
  '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
}[char]));

export function buildFamilyFormReport(manifest) {
  const families = Object.fromEntries(manifest.suite.families.map(({ family }) => [family, {
    resolution: manifest.resolutions[family] ?? null,
    frames: manifest.frames.filter((frame) => frame.family === family).map((frame) => ({
      id: frame.id,
      kind: frame.kind,
      file: frame.file,
      controlFile: frame.control?.file ?? null,
      differenceFile: frame.difference?.file ?? null,
      familyDifference: frame.difference?.metrics ?? null,
      familyDifferenceGate: frame.checks?.familyDifference ?? null,
      status: frame.status,
      requestedDepth: frame.requestedDepth,
      capturedDepth: frame.snapshot?.distance ?? null,
      resolvedFrontDepth: frame.resolvedFrontDepth,
      resolvedApproachMeters: frame.resolvedApproachMeters,
      placementBehindFrontMeters: frame.placementBehindFrontMeters,
      camera: frame.snapshot?.camera ?? null,
      renderPass: frame.snapshot?.renderPass ?? null,
      renderPassEvidence: frame.renderPassEvidence ?? null,
      layers: frame.snapshot?.layers ?? null,
      runtimeErrors: frame.runtimeErrors,
    })),
  }]));
  return {
    schemaVersion: 1,
    kind: 'cave9-family-form-review-report',
    generatedAt: new Date().toISOString(),
    runId: manifest.runId,
    suite: manifest.suite.name,
    source: manifest.source,
    capabilities: manifest.suite.capabilities,
    blockedPasses: manifest.blockedPasses,
    families,
    automaticStatus: manifest.frames.every((frame) => frame.status === 'pass') ? 'pass' : 'fail',
    manualStatus: 'pending',
    note: 'Automatic checks prove capture integrity and authority binding, not visual reference fidelity.',
  };
}

export function familyFormReportHtml(report) {
  const capabilityRows = Object.entries(report.capabilities).map(([name, capability]) => `<tr>
    <td>${escapeHtml(name)}</td><td>${capability.supported ? 'supported' : 'capability-blocked'}</td>
    <td>${escapeHtml(capability.authority || capability.reason || '')}</td></tr>`).join('\n');
  const sections = Object.entries(report.families).map(([family, data]) => {
    const bounds = data.resolution?.visibleGeometryBounds;
    const cards = data.frames.map((frame) => `<figure data-status="${escapeHtml(frame.status)}">
      <div class="${frame.controlFile ? 'triptych' : 'single'}">
      <a href="${escapeHtml(frame.file)}"><img src="${escapeHtml(frame.file)}" alt="${escapeHtml(frame.id)}"></a>
      ${frame.controlFile ? `<a href="${escapeHtml(frame.controlFile)}"><img src="${escapeHtml(frame.controlFile)}" alt="${escapeHtml(frame.id)} family off control"></a>` : ''}
      ${frame.differenceFile ? `<a href="${escapeHtml(frame.differenceFile)}"><img src="${escapeHtml(frame.differenceFile)}" alt="${escapeHtml(frame.id)} family difference mask"></a>` : ''}</div>
      <figcaption><strong>${escapeHtml(frame.id)}</strong><br>
      ${escapeHtml(frame.kind)} · depth ${Number(frame.capturedDepth).toFixed(2)} m
      ${frame.resolvedApproachMeters == null ? '' : ` · approach ${Number(frame.resolvedApproachMeters).toFixed(2)} m`}
      ${frame.kind.startsWith('orbit') ? ` · ${escapeHtml(frame.camera?.scope === 'detail-bank' ? 'Crystal bank detail' : 'isolated full composition')} · ship setup ${Number(frame.placementBehindFrontMeters).toFixed(2)} m behind front` : ''}<br>
      camera ${escapeHtml(frame.camera?.active)}${frame.camera?.axis ? `/${escapeHtml(frame.camera.axis)}` : ''}
      · pass ${escapeHtml(frame.renderPass?.active)} · ${escapeHtml(frame.status)}
      ${frame.familyDifference ? `<br>family Δ ${(100 * frame.familyDifference.fraction).toFixed(3)}% · ${escapeHtml(frame.familyDifference.angularBinCount)}/12 angular bins`
        + ` · ${escapeHtml(frame.familyDifferenceGate?.classification || 'release-gate')}`
        + `${frame.familyDifferenceGate?.required === false ? ' (diagnostic only)' : ''}` : ''}</figcaption></figure>`).join('\n');
    return `<section><h2>${escapeHtml(family)}</h2>
      <p>Visible vertex authority: absolute front ${Number(bounds?.frontDepth).toFixed(3)} m,
      review front ${Number(bounds?.reviewFrontDepth).toFixed(3)} m
      (quantile ${Number(bounds?.reviewFrontQuantile).toFixed(2)}),
      back ${Number(bounds?.backDepth).toFixed(3)} m, ${Number(bounds?.vertexCount)} vertices,
      surface revision <code>${escapeHtml(data.resolution?.surfaceRevision)}</code>.</p>
      <div class="grid">${cards}</div></section>`;
  }).join('\n');
  return `<!doctype html><html lang="en"><meta charset="utf-8"><title>Cave9 family form review</title>
  <style>body{margin:24px;background:#090b10;color:#e7ebf2;font:14px/1.45 system-ui,sans-serif}h1,h2{color:#fff}
  table{border-collapse:collapse;width:100%;margin:16px 0 28px}th,td{border:1px solid #354052;padding:7px;text-align:left}
  .grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(290px,1fr));gap:14px}figure{margin:0;background:#121722;padding:8px}
  img{display:block;width:100%;aspect-ratio:16/9;object-fit:cover;background:#000}.triptych{display:grid;grid-template-columns:1fr 1fr 1fr;gap:4px}.single{display:block}figcaption{padding:7px 2px 2px;color:#bdc7d8}code{color:#9fc5ff}</style>
  <body><h1>Cave9 family-form review · ${escapeHtml(report.runId)}</h1>
  <p>${escapeHtml(report.note)} Manual status: <strong>${escapeHtml(report.manualStatus)}</strong>.</p>
  <h2>Capability truth</h2><table><thead><tr><th>Pass</th><th>Status</th><th>Authority/reason</th></tr></thead>
  <tbody>${capabilityRows}</tbody></table>${sections}</body></html>`;
}

export function writeFamilyFormReport(runDir, manifest) {
  mkdirSync(runDir, { recursive: true });
  const report = buildFamilyFormReport(manifest);
  const json = resolve(runDir, 'family-form-report.json');
  const html = resolve(runDir, 'family-form-report.html');
  writeFileSync(json, `${JSON.stringify(report, null, 2)}\n`);
  writeFileSync(html, familyFormReportHtml(report));
  return {
    json: 'family-form-report.json',
    html: 'family-form-report.html',
    jsonSha256: fileSha256(json),
    htmlSha256: fileSha256(html),
  };
}
