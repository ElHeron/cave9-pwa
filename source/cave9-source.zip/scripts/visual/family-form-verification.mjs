import { existsSync } from 'node:fs';
import { resolve } from 'node:path';
import { evaluateFrame, inspectPng, inspectPngDifference } from './image-checks.mjs';
import { readManifest, writeManifest } from './manifest.mjs';
import { fileSha256, gitProvenance, runtimeFingerprint } from './provenance.mjs';
import { VISUAL_CLAY_LIGHT_RIG } from '../../src/dev/lab/VisualDebug3d.mjs';
import {
  familyFormFramingCheck, familyFormHeroDifferenceCheck, familyFormSuiteDefinition,
  resolvedFamilyScenario,
} from './family-form-config.mjs';

export function exactFamilyFormMatrix(manifest) {
  const suite = familyFormSuiteDefinition(manifest.suite?.families || []);
  const expectedIds = suite.templates.map((template) => template.id);
  const frames = Array.isArray(manifest.frames) ? manifest.frames : [];
  const ids = frames.map((frame) => frame.id);
  const reasons = [];
  if (manifest.suite?.name !== suite.name) reasons.push('wrong family-form suite name');
  if (JSON.stringify(manifest.suite?.viewport) !== JSON.stringify(suite.viewport)) reasons.push('wrong viewport');
  if (frames.length !== expectedIds.length) reasons.push(`expected ${expectedIds.length} frames, found ${frames.length}`);
  if (new Set(ids).size !== ids.length) reasons.push('duplicate frame ids');
  for (const id of expectedIds) if (!ids.includes(id)) reasons.push(`missing frame ${id}`);
  for (const frame of frames) {
    if (!expectedIds.includes(frame.id)) reasons.push(`unexpected frame ${frame.id}`);
    if (frame.captureApi !== suite.captureApi) reasons.push(`${frame.id} used the wrong API`);
    if (frame.snapshot?.version !== 'VisualSnapshotV1') reasons.push(`${frame.id} has no VisualSnapshotV1`);
    if (frame.kind === 'hero') {
      if (!frame.control?.file || !frame.difference?.file) reasons.push(`${frame.id} has no family-off pair`);
      if (frame.control?.snapshot?.version !== 'VisualSnapshotV1'
        || frame.control?.snapshot?.family?.requested !== 'off'
        || (frame.control?.snapshot?.family?.active?.length ?? 0) !== 0) {
        reasons.push(`${frame.id} has no valid family-off VisualSnapshotV1`);
      }
    }
  }
  return { pass: reasons.length === 0, expectedFrames: expectedIds.length,
    actualFrames: frames.length, reasons };
}

export function familyFormAuthorityChecks(frame, scenario, resolution) {
  const placementBehindFront = resolution.visibleGeometryBounds.reviewFrontDepth - Number(frame.snapshot?.distance);
  const camera = frame.snapshot?.camera;
  const crystalOrbitScope = camera?.pieceScope;
  const crystalBank = resolution.bankGroups?.find((bank) =>
    bank.firstGid === crystalOrbitScope?.firstGid
      && bank.lastGid === crystalOrbitScope?.lastGid);
  const layers = frame.snapshot?.layers;
  const expectedCamera = scenario.camera;
  const expectedRenderPass = scenario.captureOptions.renderPass;
  const expectedAxis = scenario.captureOptions.orthographicAxis;
  const renderEvidence = frame.renderPassEvidence;
  return {
    resolvedApproach: {
      pass: scenario.kind !== 'hero' || Math.abs(placementBehindFront - scenario.approachMeters) <= 0.01,
      expected: scenario.kind === 'hero' ? scenario.approachMeters : null,
      actual: scenario.kind === 'hero' ? placementBehindFront : null,
      frontDepth: resolution.visibleGeometryBounds.frontDepth,
      reviewFrontDepth: resolution.visibleGeometryBounds.reviewFrontDepth,
    },
    placementDepth: {
      pass: Math.abs(placementBehindFront - scenario.placementBehindFrontMeters) <= 0.01,
      expectedBehindFrontMeters: scenario.placementBehindFrontMeters,
      actualBehindFrontMeters: placementBehindFront,
      note: scenario.kind === 'orbit' ? 'ship setup depth only; not orbit-camera distance' : null,
    },
    geometryAuthority: {
      pass: resolution.family === frame.family && resolution.meshCount > 0
        && resolution.visibleGeometryBounds.vertexCount > 0
        && Number.isFinite(resolution.visibleGeometryBounds.frontDepth)
        && Number.isFinite(resolution.visibleGeometryBounds.reviewFrontDepth)
        && resolution.visibleGeometryBounds.reviewFrontDepth >= resolution.visibleGeometryBounds.frontDepth
        && resolution.visibleGeometryBounds.reviewFrontDepth <= resolution.visibleGeometryBounds.backDepth
        && resolution.compositionCount === 1
        && Array.isArray(resolution.surfaceRevisions) && resolution.surfaceRevisions.length === 1
        && resolution.roomKey === (frame.family === 'coiling'
          ? `CaveStream:${resolution.seed}:${resolution.compositionRoom}:coiling`
          : `${resolution.seed}:${resolution.compositionRoom}:${frame.family}`),
      resolution,
    },
    cameraAuthority: {
      pass: camera?.requested === expectedCamera && camera?.active === expectedCamera && camera?.supported === true
        && (!scenario.kind.startsWith('ortho-') || (camera?.projection === 'orthographic'
          && camera?.axis === expectedAxis))
        && (!(scenario.kind.startsWith('orbit') && scenario.family === 'crystal')
          || (camera?.isolation === 'landmark-only'
            && camera?.rig === 'crystal-oblique-v1' && camera?.axialViewComponent >= 0.39
            && (scenario.captureOptions.orbitScope === 'complete-composition'
              ? camera?.scope === 'complete-composition'
                && camera?.pieceCount === resolution.pieceCount
                && crystalOrbitScope?.applied === false
              : camera?.scope === 'detail-bank' && !!crystalBank
                && camera?.pieceCount === crystalBank.pieceCount
                && crystalOrbitScope?.applied === true && crystalOrbitScope?.meshCount === 1
                && crystalOrbitScope?.pieceCount === crystalBank.pieceCount))),
      expected: expectedCamera,
      expectedAxis: scenario.kind.startsWith('ortho-') ? expectedAxis : null,
      actual: camera,
    },
    renderPassAuthority: {
      pass: frame.snapshot?.renderPass?.requested === expectedRenderPass
        && frame.snapshot?.renderPass?.active === expectedRenderPass
        && frame.snapshot?.renderPass?.supported === true
        && renderEvidence?.active === expectedRenderPass
        && renderEvidence?.familyMeshCount > 0
        && renderEvidence?.matchedMaterialCount === renderEvidence?.familyMeshCount
        && (expectedRenderPass !== 'clay'
          || (renderEvidence?.caveVisible === true
            && renderEvidence?.caveClayMaterial === true
            && renderEvidence?.clayRigVisible === true
            && JSON.stringify(renderEvidence?.lightRig) === JSON.stringify(VISUAL_CLAY_LIGHT_RIG)
            && JSON.stringify(frame.snapshot?.renderPass?.lightRig) === JSON.stringify(VISUAL_CLAY_LIGHT_RIG)))
        && (expectedRenderPass !== 'silhouette'
          || (renderEvidence?.caveVisible === false && renderEvidence?.backgroundHex === 'ffffff')),
      expected: expectedRenderPass,
      actual: frame.snapshot?.renderPass,
      evidence: renderEvidence,
    },
    surfaceReadiness: {
      pass: frame.snapshot?.renderCapabilities?.surfaceMaterialActive === true
        && frame.snapshot?.renderCapabilities?.surfaceReliefActive === true
        && !!frame.snapshot?.renderCapabilities?.surfaceReliefProfile
        && renderEvidence?.surfaceArrayActive === true
        && renderEvidence?.surfaceReliefActive === true
        && renderEvidence?.surfaceReliefProfile
          === frame.snapshot?.renderCapabilities?.surfaceReliefProfile
        && frame.snapshot?.scenario?.mode === 2
        && frame.snapshot?.scenario?.settings?.fov === 45
        && frame.snapshot?.scenario?.settings?.brightness === 1,
      capabilities: frame.snapshot?.renderCapabilities ?? null,
      scenario: frame.snapshot?.scenario ?? null,
    },
    collisionLayer: {
      pass: scenario.kind !== 'collision' || (layers?.collisionCapsules === true
        && frame.debugGeometry?.collisionCapsules > 0),
      actual: layers?.collisionCapsules,
      objects: frame.debugGeometry?.collisionCapsules ?? null,
    },
    booleanTubeLayer: {
      pass: scenario.kind !== 'boolean-tube' || (layers?.booleanTube === true
        && frame.debugGeometry?.booleanTubeObjects > 0),
      actual: layers?.booleanTube,
      objects: frame.debugGeometry?.booleanTubeObjects ?? null,
    },
  };
}

export async function verifyFamilyFormRun({ root = process.cwd(), runDir, write = true }) {
  const manifest = readManifest(runDir);
  const suite = familyFormSuiteDefinition(manifest.suite?.families || []);
  const templates = new Map(suite.templates.map((template) => [template.id, template]));
  const specs = new Map(suite.families.map((entry) => [entry.family, entry]));
  const currentGit = await gitProvenance(root);
  const currentRuntime = runtimeFingerprint(root);
  const staleReasons = [];
  if (currentGit.commit !== manifest.source.git.commit) staleReasons.push('git commit changed');
  if (currentGit.diffFingerprint !== manifest.source.git.diffFingerprint) staleReasons.push('workspace diff fingerprint changed');
  if (currentRuntime.source.sha256 !== manifest.source.runtime.source.sha256) staleReasons.push('runtime source fingerprint changed');
  if (currentRuntime.assets.sha256 !== manifest.source.runtime.assets.sha256) staleReasons.push('runtime asset fingerprint changed');

  const matrix = exactFamilyFormMatrix(manifest);
  const frames = (manifest.frames || []).map((frame) => {
    const template = templates.get(frame.id);
    const resolution = manifest.resolutions?.[frame.family];
    const spec = specs.get(frame.family);
    const file = resolve(runDir, frame.file || 'missing');
    if (!template || !resolution || !spec || !existsSync(file)) return { ...frame, status: 'fail', checks: {
      fileAndContract: { pass: false, reason: 'template, resolution, family specification or PNG is missing' },
    } };
    const scenario = resolvedFamilyScenario(template, spec, resolution);
    const image = inspectPng(file, suite.viewport);
    const evaluated = evaluateFrame({ scenario, captureInfo: frame.captureInfo,
      runtime: frame.runtime, image, errors: frame.runtimeErrors });
    const authority = familyFormAuthorityChecks(frame, scenario, resolution);
    evaluated.checks = { ...evaluated.checks, ...authority,
      framing: familyFormFramingCheck(scenario.kind, image),
      checksum: { pass: image.sha256 === frame.image?.sha256,
        expected: frame.image?.sha256, actual: image.sha256 } };
    if (scenario.kind === 'hero') {
      const controlFile = resolve(runDir, frame.control?.file || 'missing-control');
      const differenceFile = resolve(runDir, frame.difference?.file || 'missing-difference');
      const controlExists = existsSync(controlFile);
      const differenceExists = existsSync(differenceFile);
      const controlImage = controlExists ? inspectPng(controlFile, suite.viewport) : null;
      const differenceImage = differenceExists ? inspectPng(differenceFile, suite.viewport) : null;
      const difference = controlExists
        ? inspectPngDifference(file, controlFile, suite.viewport) : null;
      const controlSnapshot = frame.control?.snapshot;
      evaluated.checks.familyOffControl = {
        pass: controlExists && controlSnapshot?.version === 'VisualSnapshotV1'
          && controlSnapshot.family?.requested === 'off'
          && (controlSnapshot.family?.active?.length ?? 0) === 0
          && Math.abs(Number(controlSnapshot.distance) - scenario.distance) <= 0.001
          && controlSnapshot.camera?.requested === 'hero'
          && controlSnapshot.camera?.active === 'hero'
          && controlSnapshot.camera?.supported === true
          && controlSnapshot.viewport?.matches === true
          && frame.control?.runtime?.appState === 'capture'
          && frame.control?.runtime?.gamePhase === 'running'
          && (frame.control?.runtimeErrors?.length ?? 0) === 0
          && controlImage?.blank?.pass === true && controlImage?.viewport?.pass === true,
        required: true,
        file: frame.control?.file ?? null,
      };
      evaluated.checks.controlChecksum = {
        pass: controlExists && controlImage.sha256 === frame.control?.image?.sha256,
        expected: frame.control?.image?.sha256 ?? null,
        actual: controlImage?.sha256 ?? null,
      };
      evaluated.checks.familyDifference = familyFormHeroDifferenceCheck(
        scenario.family, scenario.approachMeters, difference);
      evaluated.checks.differenceChecksum = {
        pass: differenceExists && differenceImage.sha256 === frame.difference?.image?.sha256
          && difference?.maskSha256 === differenceImage.sha256,
        expected: frame.difference?.image?.sha256 ?? null,
        actual: differenceImage?.sha256 ?? null,
        recomputed: difference?.maskSha256 ?? null,
      };
    }
    evaluated.status = Object.values(evaluated.checks).every((check) => check.pass) ? 'pass' : 'fail';
    return { ...frame, image, checks: evaluated.checks, status: evaluated.status,
      resolvedApproachMeters: authority.resolvedApproach.actual,
      placementBehindFrontMeters: authority.placementDepth.actualBehindFrontMeters };
  });
  const reportFiles = ['json', 'html'].map((key) => {
    const name = manifest.report?.[key];
    const file = name && resolve(runDir, name);
    return { key, file: name, pass: !!file && existsSync(file)
      && fileSha256(file) === manifest.report?.[`${key}Sha256`] };
  });
  const automatedStatus = matrix.pass && frames.every((frame) => frame.status === 'pass')
    && reportFiles.every((entry) => entry.pass) ? 'pass' : 'fail';
  manifest.frames = frames;
  manifest.automated = { status: automatedStatus, checkedAt: new Date().toISOString(), matrix,
    passedFrames: frames.filter((frame) => frame.status === 'pass').length,
    totalFrames: frames.length, reportFiles };
  manifest.verification = { checkedAt: new Date().toISOString(), stale: staleReasons.length > 0,
    staleReasons, current: { git: currentGit, runtime: currentRuntime } };
  manifest.status = staleReasons.length ? 'stale' : automatedStatus === 'pass' ? 'manual-pending' : 'fail';
  if (write) writeManifest(runDir, manifest);
  return manifest;
}
