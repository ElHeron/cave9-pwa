import { existsSync } from 'node:fs';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import {
  assertRunMutable,
  jsonBytes,
  parseArgs,
  resolveRunArtifact,
  resolveRunDir,
  writeJsonAtomic,
  writeManifest,
} from './manifest.mjs';
import { fileSha256, sha256 } from './provenance.mjs';
import { blessingRefusalReasons, verifyRun } from './verification.mjs';

export async function blessRun({ root = process.cwd(), runDir,
  baselineFile = resolve(root, 'artifacts/visual-lab/baselines/form-release.json') } = {}) {
  assertRunMutable(runDir, null, 'bless run');
  const manifest = await verifyRun({ root, runDir });
  const reasons = blessingRefusalReasons(manifest);
  if (reasons.length) throw new Error(`refusing to bless: ${reasons.join('; ')}`);
  const blessingFile = resolveRunArtifact(runDir, 'blessing.json', { expected: 'blessing.json' });
  if (existsSync(blessingFile)) throw new Error('refusing to overwrite existing blessing.json');

  const blessedAt = new Date().toISOString();
  const blessingMarker = {
    schemaVersion: 2,
    file: 'blessing.json',
    blessedAt,
    reviewer: manifest.manualReview.reviewer,
  };
  const sealedManifest = { ...manifest, blessing: blessingMarker };
  const manifestSha256 = sha256(jsonBytes(sealedManifest));
  const blessing = {
    schemaVersion: 2,
    kind: 'cave9-visual-evidence-blessing',
    runId: manifest.runId,
    suite: manifest.suite.name,
    blessedAt,
    reviewer: manifest.manualReview.reviewer,
    manifest: { file: 'manifest.json', sha256: manifestSha256 },
    source: manifest.source,
    environment: manifest.environment,
    report: manifest.report,
    automated: manifest.automated,
    verification: manifest.verification,
    manualReview: manifest.manualReview,
    frames: manifest.frames.map((frame) => ({
      id: frame.id,
      file: frame.file,
      sha256: frame.image.sha256,
      bytes: frame.image.bytes,
      captureApi: frame.captureApi,
      normalizedScenario: frame.normalizedScenario,
      snapshotVersion: frame.snapshot?.version,
    })),
    note: 'This seal binds the complete canonical manifest and every release frame byte. It does not overwrite docs/reference or docs/screenshots.',
  };

  // Write the sealed manifest first. From this point every ordinary writer is
  // locked even if the process stops before the pointer is published.
  writeManifest(runDir, sealedManifest, { allowBlessedWrite: true });
  writeJsonAtomic(blessingFile, blessing);
  const blessingSha256 = fileSha256(blessingFile);
  writeJsonAtomic(baselineFile, {
    schemaVersion: 2,
    kind: 'cave9-visual-evidence-baseline-pointer',
    suite: manifest.suite.name,
    runId: manifest.runId,
    blessing: `artifacts/visual-lab/${manifest.runId}/blessing.json`,
    blessingSha256,
    manifestSha256,
    blessedAt,
    reviewer: blessing.reviewer,
    source: manifest.source,
    report: manifest.report,
  });
  return { manifest: sealedManifest, blessing, blessingFile, baselineFile };
}

if (process.argv[1] && resolve(process.argv[1]) === resolve(fileURLToPath(import.meta.url))) {
  const args = parseArgs(process.argv.slice(2));
  const root = process.cwd();
  const runDir = resolveRunDir(root, args.run || args.positional[0]);
  blessRun({ root, runDir })
    .then(({ blessingFile }) => console.log(blessingFile))
    .catch((error) => { console.error(error); process.exitCode = 1; });
}
