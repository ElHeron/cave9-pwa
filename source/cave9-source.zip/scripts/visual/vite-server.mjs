import { spawn } from 'node:child_process';
import { createServer } from 'node:net';
import { resolve } from 'node:path';

export function allocatePort(host = '127.0.0.1') {
  return new Promise((resolvePromise, reject) => {
    const server = createServer();
    server.unref();
    server.once('error', reject);
    server.listen(0, host, () => {
      const { port } = server.address();
      server.close((error) => error ? reject(error) : resolvePromise(port));
    });
  });
}

export function startVite({ root, port, log = () => {} }) {
  const child = spawn(process.execPath,
    [resolve(root, 'node_modules/vite/bin/vite.js'), '--host', '127.0.0.1',
      '--port', String(port), '--strictPort'], {
      cwd: root,
      shell: false,
      windowsHide: true,
      stdio: ['ignore', 'pipe', 'pipe'],
    });
  child.stdout.on('data', (chunk) => log(chunk.toString('utf8')));
  child.stderr.on('data', (chunk) => log(chunk.toString('utf8')));
  return child;
}

export async function waitForVite(url, child, { timeoutMs = 30000, fetchImpl = fetch } = {}) {
  const deadline = Date.now() + timeoutMs;
  let lastError = null;
  while (Date.now() < deadline) {
    if (child.exitCode !== null) throw new Error(`Vite exited before readiness (code ${child.exitCode})`);
    try {
      const response = await fetchImpl(url);
      if (response.ok) return;
      lastError = new Error(`HTTP ${response.status}`);
    } catch (error) { lastError = error; }
    await new Promise((resolvePromise) => setTimeout(resolvePromise, 100));
  }
  throw new Error(`Vite readiness timed out after ${timeoutMs} ms${lastError ? `: ${lastError.message}` : ''}`);
}

function waitForExit(child, timeoutMs) {
  if (child.exitCode !== null) return Promise.resolve(true);
  return new Promise((resolvePromise) => {
    const timer = setTimeout(() => {
      child.removeListener('exit', onExit);
      resolvePromise(false);
    }, timeoutMs);
    timer.unref?.();
    const onExit = () => { clearTimeout(timer); resolvePromise(true); };
    child.once('exit', onExit);
  });
}

export async function stopVite(child, timeoutMs = 3000) {
  if (!child || child.exitCode !== null) return;
  child.kill('SIGTERM');
  if (await waitForExit(child, timeoutMs)) return;
  child.kill('SIGKILL');
  await waitForExit(child, Math.min(timeoutMs, 1000));
}

// Dependency injection keeps the finally contract directly testable without
// opening a real socket or starting Vite.
export async function withViteServer(task, options = {}) {
  const root = options.root || process.cwd();
  const port = options.port || await (options.allocatePort || allocatePort)();
  const url = `http://127.0.0.1:${port}/?capture=1`;
  const child = await (options.start || startVite)({ root, port, log: options.log });
  try {
    await (options.wait || waitForVite)(url, child, options);
    return await task({ child, port, url });
  } finally {
    await (options.stop || stopVite)(child);
  }
}
