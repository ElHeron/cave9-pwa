import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { parseArgs } from './manifest.mjs';
import { verifyBaseline } from './baseline-verification.mjs';

if (process.argv[1] && resolve(process.argv[1]) === resolve(fileURLToPath(import.meta.url))) {
  const args = parseArgs(process.argv.slice(2));
  const root = process.cwd();
  const baselineFile = args.baseline ? resolve(root, args.baseline) : undefined;
  verifyBaseline({ root, baselineFile }).then((result) => {
    console.log(JSON.stringify({ status: result.pass ? 'pass' : 'fail',
      runId: result.pointer?.runId || null, reasons: result.reasons }, null, 2));
    if (!result.pass) process.exitCode = 1;
  }).catch((error) => { console.error(error); process.exitCode = 1; });
}
