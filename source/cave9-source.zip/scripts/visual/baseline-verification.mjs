import { existsSync, readFileSync, statSync } from 'node:fs';
import { resolve } from 'node:path';
import {
  canonicalRunDir,
  isCanonicalRunDir,
  readManifest,
  resolveRunArtifact,
} from './manifest.mjs';
import { fileSha256 } from './provenance.mjs';
import {
  currentRunProvenance,
  exactMatrixCheck,
  manifestContractCheck,
  manualReviewBinding,
} from './verification.mjs';

const equalJson = (a, b) => JSON.stringify(a) === JSON.stringify(b);
const parseJson = (file) => JSON.parse(readFileSync(file, 'utf8'));

export async function verifyBaseline({ root = process.cwd(),
  baselineFile = resolve(root, 'artifacts/visual-lab/baselines/form-release.json') } = {}) {
  const reasons = [];
  if (!existsSync(baselineFile)) return { pass: false, reasons: ['baseline pointer is missing'] };
  let pointer;
  try { pointer = parseJson(baselineFile); }
  catch (error) { return { pass: false, reasons: [`baseline pointer is invalid JSON: ${error.message}`] }; }
  if (pointer.schemaVersion !== 2) reasons.push('baseline pointer schemaVersion must be 2');
  if (pointer.kind !== 'cave9-visual-evidence-baseline-pointer') reasons.push('baseline pointer kind is invalid');
  if (pointer.suite !== 'form-release') reasons.push('baseline pointer suite is not form-release');
  if (typeof pointer.runId !== 'string' || !/^[a-zA-Z0-9._-]+$/.test(pointer.runId)) {
    reasons.push('baseline pointer runId is invalid');
  }
  const expectedBlessing = `artifacts/visual-lab/${pointer.runId}/blessing.json`;
  if (pointer.blessing !== expectedBlessing) reasons.push('baseline pointer blessing path is not canonical');
  const runDir = canonicalRunDir(root, pointer.runId || 'invalid');
  let blessingFile;
  try { blessingFile = resolveRunArtifact(root, pointer.blessing, { expected: expectedBlessing }); }
  catch (error) { reasons.push(error.message); }
  if (!blessingFile || !existsSync(blessingFile)) {
    reasons.push('baseline blessing file is missing');
    return { pass: false, reasons, pointer };
  }
  if (fileSha256(blessingFile) !== pointer.blessingSha256) reasons.push('baseline blessing hash changed');
  let blessing;
  try { blessing = parseJson(blessingFile); }
  catch (error) { return { pass: false, reasons: [...reasons, `blessing is invalid JSON: ${error.message}`], pointer }; }
  if (blessing.schemaVersion !== 2) reasons.push('blessing schemaVersion must be 2');
  if (blessing.kind !== 'cave9-visual-evidence-blessing') reasons.push('blessing kind is invalid');
  if (blessing.runId !== pointer.runId || blessing.suite !== pointer.suite) reasons.push('blessing identity differs from pointer');
  if (blessing.blessedAt !== pointer.blessedAt || blessing.reviewer !== pointer.reviewer) {
    reasons.push('blessing review identity differs from pointer');
  }
  if (!isCanonicalRunDir(root, runDir, blessing.runId)) reasons.push('blessing run directory is not canonical');

  let manifestFile;
  try { manifestFile = resolveRunArtifact(runDir, blessing.manifest?.file, { expected: 'manifest.json' }); }
  catch (error) { reasons.push(error.message); }
  if (!manifestFile || !existsSync(manifestFile)) {
    reasons.push('sealed manifest is missing');
    return { pass: false, reasons, pointer, blessing };
  }
  const manifestHash = fileSha256(manifestFile);
  if (manifestHash !== blessing.manifest?.sha256 || manifestHash !== pointer.manifestSha256) {
    reasons.push('sealed manifest hash changed');
  }
  let manifest;
  try { manifest = readManifest(runDir); }
  catch (error) { return { pass: false, reasons: [...reasons, `sealed manifest is invalid: ${error.message}`], pointer, blessing }; }
  const contract = manifestContractCheck({ root, runDir, manifest });
  reasons.push(...contract.reasons);
  const matrix = exactMatrixCheck(manifest);
  reasons.push(...matrix.reasons);
  const frames = Array.isArray(manifest.frames) ? manifest.frames : [];
  if (manifest.status !== 'pass' || manifest.automated?.status !== 'pass') reasons.push('sealed run is not passing');
  if (manifest.verification?.stale !== false || manifest.verification?.manualReviewBinding?.pass !== true) {
    reasons.push('sealed verification is stale or manual binding is not valid');
  }
  if (!equalJson(manifest.blessing, {
    schemaVersion: 2, file: 'blessing.json', blessedAt: blessing.blessedAt, reviewer: blessing.reviewer,
  })) reasons.push('manifest blessing marker differs from seal');
  for (const key of ['source', 'environment', 'report', 'automated', 'verification', 'manualReview']) {
    if (!equalJson(blessing[key], manifest[key])) reasons.push(`blessing does not bind manifest ${key}`);
  }
  if (!equalJson(pointer.source, manifest.source) || !equalJson(pointer.report, manifest.report)) {
    reasons.push('baseline pointer provenance or report differs from manifest');
  }

  const reportFiles = ['json', 'html'].map((key) => {
    const expectedName = `reference-report.${key}`;
    try {
      const file = resolveRunArtifact(runDir, manifest.report?.[key], { expected: expectedName });
      const pass = existsSync(file) && fileSha256(file) === manifest.report?.[`${key}Sha256`];
      if (!pass) reasons.push(`sealed ${key.toUpperCase()} report changed`);
      return { key, file: expectedName, pass };
    } catch (error) {
      reasons.push(error.message);
      return { key, file: expectedName, pass: false };
    }
  });

  const sealedFrames = frames.map((frame) => ({
    id: frame.id, file: frame.file, sha256: frame.image?.sha256, bytes: frame.image?.bytes,
    captureApi: frame.captureApi, normalizedScenario: frame.normalizedScenario,
    snapshotVersion: frame.snapshot?.version,
  }));
  if (!equalJson(blessing.frames, sealedFrames)) reasons.push('blessing frame contract differs from manifest');
  for (const frame of frames) {
    try {
      const file = resolveRunArtifact(runDir, frame.file, { expected: `frames/${frame.id}.png` });
      if (!existsSync(file)) reasons.push(`sealed frame is missing: ${frame.id}`);
      else {
        if (fileSha256(file) !== frame.image?.sha256) reasons.push(`sealed frame hash changed: ${frame.id}`);
        if (statSync(file).size !== frame.image?.bytes) reasons.push(`sealed frame byte count changed: ${frame.id}`);
      }
    } catch (error) { reasons.push(`${frame.id}: ${error.message}`); }
  }
  const reviewBinding = manualReviewBinding(manifest, frames, reportFiles);
  if (reviewBinding.pass !== true) reasons.push(...reviewBinding.reasons);
  const { reasons: staleReasons, current } = await currentRunProvenance(root, manifest);
  reasons.push(...staleReasons.map((reason) => `baseline is stale: ${reason}`));
  return { pass: reasons.length === 0, reasons: [...new Set(reasons)],
    pointer, blessing, manifest, current, contract, matrix, reviewBinding };
}
