import { mkdirSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { fileSha256 } from './provenance.mjs';

const esc = (value) => String(value ?? '').replace(/[&<>"']/g, (char) => ({
  '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
}[char]));

export function buildCoilingShellReport(manifest) {
  return {
    schemaVersion: 1,
    kind: 'cave9-coiling-shell-evidence-report',
    generatedAt: new Date().toISOString(),
    runId: manifest.runId,
    source: manifest.source,
    contract: manifest.authority?.contract ?? null,
    ringEvidence: manifest.authority?.rings ?? null,
    geometryCounts: manifest.authority?.geometryCounts ?? null,
    capabilities: manifest.suite.capabilities,
    blockedPasses: manifest.blockedPasses,
    frames: manifest.frames.map((frame) => ({
      id: frame.id, kind: frame.kind, file: frame.file, sourceFile: frame.sourceFile ?? null,
      controlFile: frame.control?.file ?? null,
      differenceFile: frame.difference?.file ?? null,
      familyDifference: frame.difference?.metrics ?? null,
      familyDifferenceGate: frame.checks?.familyDifference ?? null,
      visibleFrontDepth: frame.visibleFrontDepth ?? null,
      status: frame.status, runtimeErrors: frame.runtimeErrors ?? [],
    })),
    automaticStatus: manifest.frames.every((frame) => frame.status === 'pass') ? 'pass' : 'fail',
    manualStatus: 'pending',
    note: 'Automatic checks prove ring authority, capture integrity and protected reserve. They do not prove visual reference fidelity.',
  };
}

export function coilingShellReportHtml(report) {
  const capabilityRows = Object.entries(report.capabilities).map(([name, value]) => `<tr><td>${esc(name)}</td>`
    + `<td>${value.supported ? 'supported' : 'capability-blocked'}</td>`
    + `<td>${esc(value.authority || value.reason)}</td></tr>`).join('');
  const figures = report.frames.map((frame) => `<figure data-status="${esc(frame.status)}"><div class="${frame.controlFile ? 'triptych' : 'single'}">`
    + `<a href="${esc(frame.file)}"><img src="${esc(frame.file)}" alt="${esc(frame.id)}"></a>`
    + `${frame.controlFile ? `<a href="${esc(frame.controlFile)}"><img src="${esc(frame.controlFile)}" alt="${esc(frame.id)} family off control"></a>` : ''}`
    + `${frame.differenceFile ? `<a href="${esc(frame.differenceFile)}"><img src="${esc(frame.differenceFile)}" alt="${esc(frame.id)} family difference mask"></a>` : ''}</div>`
    + `<figcaption><strong>${esc(frame.id)}</strong><br>${esc(frame.kind)} · ${esc(frame.status)}`
    + `${frame.sourceFile ? ` · <a href="${esc(frame.sourceFile)}">source SVG</a>` : ''}`
    + `${frame.familyDifference ? ` · family Δ ${(100 * frame.familyDifference.fraction).toFixed(3)}%`
      + ` · ${esc(frame.familyDifferenceGate?.classification || 'release-gate')}`
      + `${frame.familyDifferenceGate?.required === false ? ' (diagnostic only)' : ''}` : ''}</figcaption></figure>`).join('');
  const c = report.contract || {};
  const r = report.ringEvidence || {};
  const g = report.geometryCounts || {};
  return `<!doctype html><html lang="en"><meta charset="utf-8"><title>Cave9 Coiling shell evidence</title>
  <style>body{margin:24px;background:#090b10;color:#e7ebf2;font:14px/1.45 system-ui,sans-serif}h1,h2{color:#fff}
  table{border-collapse:collapse;width:100%;margin:16px 0 28px}th,td{border:1px solid #354052;padding:7px;text-align:left}
  .grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(360px,1fr));gap:14px}figure{margin:0;background:#121722;padding:8px}
  img{display:block;width:100%;aspect-ratio:16/9;object-fit:contain;background:#fff}.triptych{display:grid;grid-template-columns:1fr 1fr 1fr;gap:4px}.single{display:block}figcaption{padding:7px 2px 2px;color:#bdc7d8}a{color:#9fc5ff}</style>
  <body><h1>Cave9 Coiling shell evidence · ${esc(report.runId)}</h1><p>${esc(report.note)}</p>
  <p>Contract <code>${esc(c.version)}</code>: ${Number(c.start).toFixed(3)}–${Number(c.end).toFixed(3)} m,
  ${Number(c.span).toFixed(3)} m, ${Number(c.turns).toFixed(3)} turns, one main ridge${c.channelCount === 2 ? ` with a ${Number(c.secondaryScale * 100).toFixed(0)}% companion` : ''},
  ${Number(c.ridgeStrength).toFixed(3)} m nominal inset.
  Live span: ${Number(r.firstDepth).toFixed(3)}–${Number(r.lastDepth).toFixed(3)} m across ${esc(r.count)} rings;
  minimum ship-clear reserve ${Number(r.minimumShipClearReserve).toFixed(3)} m.</p>
  <p>Secondary landmark geometry: ${esc(g.pieces)} pieces, ${esc(g.collisionPieces)} colliders,
  ${esc(g.landmarkMeshes)} meshes, ${esc(g.landmarkTriangles)} triangles.</p>
  <h2>Capability truth</h2><table><thead><tr><th>Pass</th><th>Status</th><th>Authority/reason</th></tr></thead><tbody>${capabilityRows}</tbody></table>
  <h2>Original evidence</h2><div class="grid">${figures}</div></body></html>`;
}

export function writeCoilingShellReport(runDir, manifest) {
  mkdirSync(runDir, { recursive: true });
  const report = buildCoilingShellReport(manifest);
  const json = resolve(runDir, 'coiling-shell-report.json');
  const html = resolve(runDir, 'coiling-shell-report.html');
  writeFileSync(json, `${JSON.stringify(report, null, 2)}\n`);
  writeFileSync(html, coilingShellReportHtml(report));
  return {
    json: 'coiling-shell-report.json', html: 'coiling-shell-report.html',
    jsonSha256: fileSha256(json), htmlSha256: fileSha256(html),
  };
}
