import { createHash } from 'node:crypto';
import { existsSync, mkdirSync, writeFileSync } from 'node:fs';
import { relative, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { chromium } from 'playwright';
import { inspectPng, inspectPngDifference } from './image-checks.mjs';
import { parseArgs, writeJsonAtomic, writeManifest } from './manifest.mjs';
import { fileSha256, gitProvenance, makeRunId, runtimeFingerprint } from './provenance.mjs';
import { renderCrossSectionsSvg, renderLongitudinalSvg, renderUnwrappedSvg } from '../../src/dev/atlas/render.js';
import {
  COILING_SHELL_API, COILING_SHELL_ROOM, COILING_SHELL_SEED, COILING_SHELL_VIEWPORT,
  coilingHeroDifferenceCheck, coilingHeroOffControlScenario, coilingHeroScenario,
  coilingShellFramingCheck, coilingShellInspectionDepth,
  coilingShellSuiteDefinition,
} from './coiling-shell-config.mjs';
import { writeCoilingShellReport } from './coiling-shell-report.mjs';
import { verifyCoilingShellRun } from './coiling-shell-verification.mjs';
import { withViteServer } from './vite-server.mjs';

const root = process.cwd();
const VISUAL_SETTINGS = Object.freeze({
  fov: 45, motion: 0, landmarks: true, readability: true, rockDetail: true,
  cave: true, wireframe: false, landmarkMesh: true,
  collisionCapsules: false, booleanTube: false, playerHull: false, frames: false,
  fog: true, material: true, light: true,
});

function createRunDirectory(runDir) {
  if (existsSync(runDir)) throw new Error(`refusing to overwrite existing coiling-shell run: ${runDir}`);
  const frameDir = resolve(runDir, 'frames');
  const sourceDir = resolve(runDir, 'sources');
  mkdirSync(frameDir, { recursive: true });
  mkdirSync(sourceDir, { recursive: true });
  return { frameDir, sourceDir };
}

async function settle(page, count = 4) {
  for (let i = 0; i < count; i++) {
    await page.evaluate(() => new Promise((done) => requestAnimationFrame(done)));
  }
}

async function canvasPng(page) {
  const dataUrl = await page.evaluate(() => {
    const canvas = window.__cave9?.renderer?.canvas || document.querySelector('canvas');
    if (!canvas) throw new Error('capture canvas is missing');
    return canvas.toDataURL('image/png');
  });
  const match = /^data:image\/png;base64,(.+)$/s.exec(dataUrl);
  if (!match) throw new Error('capture canvas did not return PNG data');
  return Buffer.from(match[1], 'base64');
}

async function runtimeSnapshot(page) {
  return page.evaluate(() => {
    const app = window.__cave9;
    const canvas = app?.renderer?.canvas || document.querySelector('canvas');
    const gl = app?.renderer?.renderer?.getContext?.();
    const glErrors = [];
    if (gl) for (let i = 0; i < 16; i++) {
      const error = gl.getError();
      if (error === gl.NO_ERROR) break;
      glErrors.push(error);
    }
    const browserErrors = [...(window.__cave9CoilingErrors || [])];
    window.__cave9CoilingErrors = [];
    return {
      appState: app?.state ?? null,
      gamePhase: app?.game?.phase ?? null,
      innerWidth, innerHeight, devicePixelRatio,
      canvasWidth: canvas?.width ?? null, canvasHeight: canvas?.height ?? null,
      webglAvailable: !!gl, webglContextLost: gl ? gl.isContextLost() : true,
      glErrors, browserErrors,
    };
  });
}

function shellScenario(name, distance, extraSettings = {}) {
  return {
    version: 'VisualScenarioV1', name, seed: COILING_SHELL_SEED,
    distance, placement: 'place', family: 'coiling', camera: 'hero', renderPass: 'beauty',
    paused: true,
    viewport: { width: COILING_SHELL_VIEWPORT.width, height: COILING_SHELL_VIEWPORT.height,
      dpr: COILING_SHELL_VIEWPORT.deviceScaleFactor },
    settings: { ...VISUAL_SETTINGS, ...extraSettings },
  };
}

async function resolveContract(page) {
  return page.evaluate(async ({ seed, room, scenario }) => {
    const visual = window.__cave9?.visual;
    if (typeof visual?.loadScenario !== 'function' || typeof visual?.snapshot !== 'function') {
      throw new Error('VisualScenarioV1 API is required; no legacy fallback is permitted');
    }
    const snapshot = visual.loadScenario(scenario);
    const { compositionAt } = await import('/src/core/Landmarks.js');
    const app = window.__cave9;
    const comp = compositionAt(seed, app.game.cave, room, 'coiling');
    if (snapshot?.version !== 'VisualSnapshotV1' || snapshot.family?.requested !== 'coiling') {
      throw new Error('forced Coiling VisualSnapshotV1 was not established');
    }
    if (!comp?.surfaceResident || comp.typeName !== 'coiling' || !comp.coilingContract) {
      throw new Error('authoritative Coiling surface composition is missing');
    }
    return structuredClone(comp.coilingContract);
  }, { seed: COILING_SHELL_SEED, room: COILING_SHELL_ROOM,
    scenario: shellScenario('coiling-contract-resolution', COILING_SHELL_ROOM * 1000 + 100) });
}

async function resolveRingAuthority(page, contract) {
  const inspectionDepth = coilingShellInspectionDepth(contract);
  return page.evaluate(async ({ seed, room, contract, scenario }) => {
    const visual = window.__cave9.visual;
    const snapshot = visual.loadScenario(scenario);
    visual.setLayer('collisionCapsules', true);
    const app = window.__cave9;
    const cave = app.game.cave;
    const [{ compositionAt }, { buildCaveAtlas }] = await Promise.all([
      import('/src/core/Landmarks.js'), import('/src/dev/atlas/model.js'),
    ]);
    const comp = compositionAt(seed, cave, room, 'coiling');
    if (!comp || comp.typeName !== 'coiling' || !comp.surfaceResident) {
      throw new Error('Coiling identity disappeared from the live cave');
    }

    const projectedRadius = (frame, point) => {
      const dx = point[0] - frame.center.x;
      const dy = point[1] - frame.center.y;
      const dz = point[2] - frame.center.z;
      return Math.hypot(dx * frame.right.x + dy * frame.right.y + dz * frame.right.z,
        dx * frame.up.x + dy * frame.up.y + dz * frame.up.z);
    };
    const allRings = [];
    for (let bufferIndex = 0; bufferIndex < cave.segs.length; bufferIndex++) {
      const depth = cave.centers[bufferIndex]?.[2];
      const frame = cave.frames[bufferIndex];
      if (!Number.isFinite(depth) || !frame) continue;
      allRings.push({ bufferIndex, depth, frame, center: cave.centers[bufferIndex],
        wall: cave.segs[bufferIndex], innerRadius: Number(cave.innerRadii[bufferIndex]) });
    }
    allRings.sort((a, b) => a.depth - b.depth);
    const shellRings = allRings.filter((ring) => ring.depth >= contract.start && ring.depth <= contract.end);
    if (shellRings.length < 2) throw new Error('live CaveStream does not contain the Coiling contract span');

    const bytesFor = (rings) => {
      const values = new Float32Array(rings.length * 32 * 3);
      let cursor = 0;
      for (const ring of rings) for (const point of ring.wall) for (const value of point) values[cursor++] = value;
      return new Uint8Array(values.buffer);
    };
    const hashes = async (rings) => {
      const bytes = bytesFor(rings);
      let fnv = 2166136261 >>> 0;
      for (const byte of bytes) fnv = Math.imul(fnv ^ byte, 16777619) >>> 0;
      const digest = await crypto.subtle.digest('SHA-256', bytes);
      return { fingerprint: fnv.toString(16).padStart(8, '0'),
        sha256: [...new Uint8Array(digest)].map((b) => b.toString(16).padStart(2, '0')).join('') };
    };
    const [shellHash, fullHash] = await Promise.all([hashes(shellRings), hashes(allRings)]);
    const bounds = { minX: Infinity, minY: Infinity, minZ: Infinity,
      maxX: -Infinity, maxY: -Infinity, maxZ: -Infinity, vertexCount: 0 };
    let minimumShipClearReserve = Infinity;
    let minimumBooleanReserve = Infinity;
    const samples = shellRings.map((ring) => {
      const radii = ring.wall.map((point) => {
        bounds.minX = Math.min(bounds.minX, point[0]); bounds.maxX = Math.max(bounds.maxX, point[0]);
        bounds.minY = Math.min(bounds.minY, point[1]); bounds.maxY = Math.max(bounds.maxY, point[1]);
        bounds.minZ = Math.min(bounds.minZ, point[2]); bounds.maxZ = Math.max(bounds.maxZ, point[2]);
        bounds.vertexCount++;
        return projectedRadius(ring.frame, point);
      });
      const minRadius = Math.min(...radii), maxRadius = Math.max(...radii);
      minimumShipClearReserve = Math.min(minimumShipClearReserve, minRadius - ring.innerRadius - 1);
      minimumBooleanReserve = Math.min(minimumBooleanReserve, minRadius - ring.innerRadius);
      return { depth: ring.depth, innerRadius: ring.innerRadius,
        protectedRadius: ring.innerRadius + 1.5, minRadius, maxRadius };
    });

    // The atlas receives references to the exact selected CaveStream rings.
    // No resynthesised wall points and no LandmarkLayer pieces enter this view.
    const selectedCave = {
      seed,
      segs: shellRings.map((ring) => ring.wall),
      centers: shellRings.map((ring) => ring.center),
      frames: shellRings.map((ring) => ring.frame),
      innerRadii: Float64Array.from(shellRings.map((ring) => ring.innerRadius)),
    };
    const atlas = buildCaveAtlas({ cave: selectedCave, seed, landmarks: [comp], crossSectionSpacing: 10 });

    let landmarkMeshes = 0, landmarkTriangles = 0;
    for (const entry of app.renderer.landmarkLayer.built.values()) {
      if (!entry.roomKey?.endsWith(':coiling')) continue;
      entry.group.traverse((object) => {
        if (!object.isMesh) return;
        landmarkMeshes++;
        const position = object.geometry?.getAttribute?.('position');
        landmarkTriangles += object.geometry?.index?.count
          ? object.geometry.index.count / 3 : (position?.count || 0) / 3;
      });
    }
    return {
      inspectionDepth: scenario.distance,
      contract: structuredClone(comp.coilingContract),
      identity: {
        requestedFamily: snapshot.family?.requested ?? null,
        gameFamilyOverride: app.game.landmarkFamilyOverride,
        caveFamilyOverride: cave.landmarkFamilyOverride,
        compositionType: comp.typeName,
        surfaceResident: comp.surfaceResident,
        surfaceRevision: comp.surfaceRevision,
      },
      rings: {
        sectorCount: 32,
        count: shellRings.length,
        firstDepth: shellRings[0].depth,
        lastDepth: shellRings.at(-1).depth,
        monotonic: shellRings.every((ring, i) => i === 0 || ring.depth > shellRings[i - 1].depth),
        uniqueDepths: new Set(shellRings.map((ring) => ring.depth)).size === shellRings.length,
        minimumDepthStep: Math.min(...shellRings.slice(1).map((ring, i) => ring.depth - shellRings[i].depth)),
        maximumDepthStep: Math.max(...shellRings.slice(1).map((ring, i) => ring.depth - shellRings[i].depth)),
        minimumShipClearReserve,
        minimumBooleanReserve,
        bounds,
        samples,
        ...shellHash,
        fullCaveFingerprint: fullHash.fingerprint,
        fullCaveSha256: fullHash.sha256,
      },
      geometryCounts: {
        pieces: comp.pieces.length,
        collisionPieces: comp.collisionPieces.length,
        landmarkMeshes,
        landmarkTriangles,
        collisionCapsuleObjects: visual.runner.dev3d?.capsuleGroup?.children?.length ?? null,
      },
      atlas: {
        version: atlas.version,
        ringCount: atlas.rings.length,
        sectorCount: atlas.sectorCount,
        landmarkCount: atlas.landmarks.length,
        sourceRingFingerprint: shellHash.fingerprint,
      },
      atlasData: atlas,
    };
  }, { seed: COILING_SHELL_SEED, room: COILING_SHELL_ROOM, contract,
    scenario: shellScenario('coiling-ring-authority', inspectionDepth, { collisionCapsules: true }) });
}

function reserveSvg(rings, { width = 1100, height = 480 } = {}) {
  const samples = rings.samples;
  const margin = { left: 74, right: 28, top: 48, bottom: 54 };
  const minDepth = samples[0].depth, maxDepth = samples.at(-1).depth;
  const values = samples.flatMap((sample) => [sample.innerRadius, sample.protectedRadius,
    sample.minRadius, sample.maxRadius]);
  const minValue = Math.min(...values) - 0.5, maxValue = Math.max(...values) + 0.5;
  const x = (depth) => margin.left + (depth - minDepth) / (maxDepth - minDepth || 1)
    * (width - margin.left - margin.right);
  const y = (value) => height - margin.bottom - (value - minValue) / (maxValue - minValue || 1)
    * (height - margin.top - margin.bottom);
  const path = (key) => samples.map((sample, index) => `${index ? 'L' : 'M'}${x(sample.depth).toFixed(2)},${y(sample[key]).toFixed(2)}`).join(' ');
  const area = `${path('minRadius')} ${[...samples].reverse().map((sample) => `L${x(sample.depth).toFixed(2)},${y(sample.protectedRadius).toFixed(2)}`).join(' ')} Z`;
  return `<svg xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Coiling wall reserve from live CaveStream rings" viewBox="0 0 ${width} ${height}">
  <rect width="100%" height="100%" fill="#f7fafc"/><text x="${margin.left}" y="25" font-family="system-ui" font-size="18" font-weight="700" fill="#111827">Live Coiling wall versus Boolean tube + ship + 0.5 m reserve</text>
  <path d="${area}" fill="#86efac" fill-opacity=".44"/><path d="${path('maxRadius')}" fill="none" stroke="#7c3aed" stroke-width="2"/>
  <path d="${path('minRadius')}" fill="none" stroke="#0f766e" stroke-width="3"/><path d="${path('protectedRadius')}" fill="none" stroke="#dc2626" stroke-width="2" stroke-dasharray="8 5"/>
  <path d="${path('innerRadius')}" fill="none" stroke="#2563eb" stroke-width="2"/>
  <line x1="${margin.left}" y1="${height - margin.bottom}" x2="${width - margin.right}" y2="${height - margin.bottom}" stroke="#64748b"/>
  <text x="${margin.left}" y="${height - 18}" font-family="system-ui" font-size="13" fill="#334155">${minDepth.toFixed(1)} m</text><text x="${width - margin.right}" y="${height - 18}" text-anchor="end" font-family="system-ui" font-size="13" fill="#334155">${maxDepth.toFixed(1)} m</text>
  <g font-family="system-ui" font-size="13" fill="#111827"><text x="${margin.left + 8}" y="${margin.top + 18}">purple: outer wall · teal: nearest wall · red dashed: tube + ship + 0.5 m · blue: Boolean tube</text></g></svg>`;
}

async function rasterizeSvg(page, svg, pngFile) {
  await page.setContent(`<!doctype html><meta charset="utf-8"><style>*{box-sizing:border-box}html,body{margin:0;width:1280px;height:720px;background:#fff;overflow:hidden}body{display:flex;align-items:center;justify-content:center;padding:28px;color:#172033;font-family:system-ui,sans-serif}svg{display:block;width:100%;height:100%;max-width:1224px;max-height:664px}</style>${svg}`,
    { waitUntil: 'load' });
  await page.screenshot({ path: pngFile, type: 'png' });
}

function initialFrameRecord({ template, file, sourceFile = null, image, runtimeErrors = [], extra = {} }) {
  const framing = coilingShellFramingCheck(template.kind, image);
  return {
    id: template.id, kind: template.kind, captureApi: template.captureApi,
    file, sourceFile, image, runtimeErrors,
    status: image.blank.pass && image.viewport.pass && framing.pass && runtimeErrors.length === 0 ? 'pass' : 'fail',
    checks: { blank: image.blank, viewport: image.viewport, framing,
      runtimeErrors: { pass: runtimeErrors.length === 0, errors: runtimeErrors } },
    ...extra,
  };
}

export async function captureCoilingShell({ runId: requestedRunId, headed = false,
  browserChannel, port } = {}) {
  const createdAt = new Date();
  const git = await gitProvenance(root);
  const runtime = runtimeFingerprint(root);
  const runId = requestedRunId || makeRunId(createdAt, git);
  if (!/^[a-zA-Z0-9._-]+$/.test(runId)) throw new Error('run id contains unsupported characters');
  const suite = coilingShellSuiteDefinition();
  const runDir = resolve(root, 'artifacts/visual-lab/coiling-shell', runId);
  const { frameDir, sourceDir } = createRunDirectory(runDir);
  const manifest = {
    schemaVersion: 1,
    kind: 'cave9-coiling-shell-evidence-run',
    runId, createdAt: createdAt.toISOString(), completedAt: null, status: 'running',
    source: { git, runtime }, suite,
    blockedPasses: Object.entries(suite.capabilities).filter(([, value]) => !value.supported)
      .map(([pass, value]) => ({ pass, status: 'capability-blocked', reason: value.reason })),
    authority: null, frames: [], report: null,
    automated: { status: 'pending' },
    manualReview: { status: 'pending', note: 'Inspect original Hero and ring-atlas PNG/SVG evidence.' },
    errors: [],
  };
  writeManifest(runDir, manifest);
  const serverLog = [];
  try {
    await withViteServer(async ({ url }) => {
      let browser;
      try {
        browser = await chromium.launch({ headless: !headed, channel: browserChannel });
        const context = await browser.newContext({
          viewport: { width: suite.viewport.width, height: suite.viewport.height },
          deviceScaleFactor: suite.viewport.deviceScaleFactor,
          reducedMotion: 'reduce',
        });
        await context.addInitScript(() => {
          window.__cave9CoilingErrors = [];
          const record = (kind, detail) => window.__cave9CoilingErrors.push(`${kind}: ${detail}`);
          window.addEventListener('unhandledrejection', (event) =>
            record('unhandledrejection', event.reason?.stack || event.reason || 'unknown rejection'));
          document.addEventListener('webglcontextlost', (event) => {
            event.preventDefault(); record('webglcontextlost', event.statusMessage || 'lost');
          }, true);
          document.addEventListener('webglcontextrestored', () =>
            record('webglcontextrestored', 'restored'), true);
        });
        const page = await context.newPage();
        const errors = [];
        page.on('console', (message) => { if (message.type() === 'error') errors.push(`console: ${message.text()}`); });
        page.on('pageerror', (error) => errors.push(`pageerror: ${error.message}`));
        const visualUrl = new URL(url);
        visualUrl.searchParams.set('visualLab', '1'); visualUrl.searchParams.set('capture', '1');
        await page.goto(visualUrl.href, { waitUntil: 'load', timeout: 30000 });
        await page.waitForFunction(() => window.__cave9?.visual?.snapshot, undefined, { timeout: 30000 });
        manifest.environment = await page.evaluate(() => {
          const renderer = window.__cave9.renderer.renderer;
          const gl = renderer.getContext();
          const extension = gl.getExtension('WEBGL_debug_renderer_info');
          return {
            userAgent: navigator.userAgent, browserPlatform: navigator.platform,
            hardwareConcurrency: navigator.hardwareConcurrency ?? null,
            webgl: { available: !!gl, contextLost: gl.isContextLost(), version: gl.getParameter(gl.VERSION),
              vendor: extension ? gl.getParameter(extension.UNMASKED_VENDOR_WEBGL) : gl.getParameter(gl.VENDOR),
              renderer: extension ? gl.getParameter(extension.UNMASKED_RENDERER_WEBGL) : gl.getParameter(gl.RENDERER) },
          };
        });

        const contract = await resolveContract(page);
        const authority = await resolveRingAuthority(page, contract);
        const authorityRuntime = await runtimeSnapshot(page);
        authority.runtime = authorityRuntime;
        authority.runtimeErrors = [...errors, ...(authorityRuntime.browserErrors || []),
          ...(authorityRuntime.glErrors || []).map((code) => `webgl getError: ${code}`),
          ...(authorityRuntime.webglAvailable ? [] : ['webgl unavailable']),
          ...(authorityRuntime.webglContextLost ? ['webgl context lost'] : [])];
        manifest.authority = authority;
        writeJsonAtomic(resolve(runDir, 'authority.json'), authority);
        writeManifest(runDir, manifest);

        for (const template of suite.templates.filter((entry) => entry.kind === 'hero')) {
          const scenario = coilingHeroScenario(template, contract);
          const errorStart = errors.length;
          const loaded = await page.evaluate((options) => {
            const visual = window.__cave9.visual;
            const snapshot = visual.loadScenario(options);
            return {
              snapshot,
              gameFamilyOverride: window.__cave9.game.landmarkFamilyOverride,
              caveFamilyOverride: window.__cave9.game.cave.landmarkFamilyOverride,
            };
          }, scenario.captureOptions);
          await settle(page);
          const pngFile = resolve(frameDir, `${template.id}.png`);
          writeFileSync(pngFile, await canvasPng(page));
          const runtimeState = await runtimeSnapshot(page);
          const runtimeErrors = [...errors.slice(errorStart), ...(runtimeState.browserErrors || []),
            ...(runtimeState.glErrors || []).map((code) => `webgl getError: ${code}`),
            ...(runtimeState.webglAvailable ? [] : ['webgl unavailable']),
            ...(runtimeState.webglContextLost ? ['webgl context lost'] : [])];
          const image = inspectPng(pngFile, COILING_SHELL_VIEWPORT);
          const controlScenario = coilingHeroOffControlScenario(scenario);
          const controlErrorStart = errors.length;
          const controlLoaded = await page.evaluate((options) => {
            const visual = window.__cave9.visual;
            const snapshot = visual.loadScenario(options);
            return { snapshot, inspected: visual.snapshot({ includeImage: false }) };
          }, controlScenario.captureOptions);
          await settle(page);
          const controlFile = resolve(frameDir, `${template.id}-control-off.png`);
          const differenceFile = resolve(frameDir, `${template.id}-family-diff.png`);
          writeFileSync(controlFile, await canvasPng(page));
          const controlRuntime = await runtimeSnapshot(page);
          const controlRuntimeErrors = [
            ...errors.slice(controlErrorStart),
            ...(controlRuntime.browserErrors || []),
            ...(controlRuntime.glErrors || []).map((code) => `webgl getError: ${code}`),
            ...(controlRuntime.webglAvailable ? [] : ['webgl unavailable']),
            ...(controlRuntime.webglContextLost ? ['webgl context lost'] : []),
          ];
          const controlImage = inspectPng(controlFile, COILING_SHELL_VIEWPORT);
          const differenceMetrics = inspectPngDifference(pngFile, controlFile,
            COILING_SHELL_VIEWPORT, { writeMaskFile: differenceFile });
          const differenceImage = inspectPng(differenceFile, COILING_SHELL_VIEWPORT);
          const record = initialFrameRecord({
            template,
            file: relative(runDir, pngFile).replace(/\\/g, '/'), image, runtimeErrors,
            extra: { approachMeters: template.approachMeters, requestedDepth: scenario.distance,
              visibleFrontDepth: scenario.visibleFrontDepth,
              snapshot: loaded.snapshot, runtime: runtimeState,
              overrideEvidence: { game: loaded.gameFamilyOverride, cave: loaded.caveFamilyOverride },
              control: {
                captureApi: COILING_SHELL_API,
                snapshot: controlLoaded.inspected,
                loadedSnapshot: controlLoaded.snapshot,
                runtime: controlRuntime,
                runtimeErrors: controlRuntimeErrors,
                file: relative(runDir, controlFile).replace(/\\/g, '/'),
                image: controlImage,
              },
              difference: {
                file: relative(runDir, differenceFile).replace(/\\/g, '/'),
                image: differenceImage,
                metrics: differenceMetrics,
              },
            },
          });
          record.checks.familyOffControl = {
            pass: controlLoaded.inspected?.version === 'VisualSnapshotV1'
              && controlLoaded.inspected.family?.requested === 'off'
              && (controlLoaded.inspected.family?.active?.length ?? 0) === 0
              && controlLoaded.inspected.layers?.landmarks === false
              && Math.abs(Number(controlLoaded.inspected.distance) - scenario.distance) <= 0.001
              && controlRuntime.appState === 'capture' && controlRuntime.gamePhase === 'running'
              && controlRuntimeErrors.length === 0 && controlImage.blank.pass && controlImage.viewport.pass,
            required: true,
          };
          record.checks.familyDifference = coilingHeroDifferenceCheck(
            template.approachMeters, differenceMetrics);
          record.status = Object.values(record.checks).every((check) => check.pass) ? 'pass' : 'fail';
          manifest.frames.push(record);
          writeManifest(runDir, manifest);
        }

        const diagrams = new Map([
          ['coiling-atlas-longitudinal', renderLongitudinalSvg(authority.atlasData, { width: 1100, height: 500 })],
          ['coiling-atlas-unwrapped', renderUnwrappedSvg(authority.atlasData, { width: 1100, rowHeight: 3.5 })],
          ['coiling-atlas-cross-sections', renderCrossSectionsSvg(authority.atlasData, { width: 1100, cellHeight: 112 })],
          ['coiling-boolean-reserve', reserveSvg(authority.rings)],
        ]);
        const diagramPage = await context.newPage();
        for (const template of suite.templates.filter((entry) => entry.kind !== 'hero')) {
          const svg = diagrams.get(template.id);
          if (!svg) throw new Error(`missing diagram source ${template.id}`);
          const svgFile = resolve(sourceDir, `${template.id}.svg`);
          const pngFile = resolve(frameDir, `${template.id}.png`);
          writeFileSync(svgFile, svg);
          await rasterizeSvg(diagramPage, svg, pngFile);
          const image = inspectPng(pngFile, COILING_SHELL_VIEWPORT);
          manifest.frames.push(initialFrameRecord({
            template,
            file: relative(runDir, pngFile).replace(/\\/g, '/'),
            sourceFile: relative(runDir, svgFile).replace(/\\/g, '/'),
            image,
            extra: { sourceSha256: fileSha256(svgFile), ringFingerprint: authority.rings.fingerprint },
          }));
          writeManifest(runDir, manifest);
        }
        await diagramPage.close();
      } finally {
        if (browser) await browser.close().catch(() => {});
      }
    }, { root, port: port ? Number(port) : undefined,
      log: (line) => { if (serverLog.join('').length < 16000) serverLog.push(line); } });
    manifest.report = writeCoilingShellReport(runDir, manifest);
    manifest.completedAt = new Date().toISOString();
    manifest.serverLog = serverLog.join('').slice(-16000);
    // atlasData is useful evidence but large; authority.json retains it while the
    // main manifest keeps only the exact fingerprints and summary contract.
    delete manifest.authority.atlasData;
    writeManifest(runDir, manifest);
    return await verifyCoilingShellRun({ root, runDir });
  } catch (error) {
    manifest.completedAt = new Date().toISOString();
    manifest.status = 'fail';
    manifest.automated = { status: 'fail', checkedAt: manifest.completedAt };
    manifest.errors.push(error?.stack || String(error));
    manifest.serverLog = serverLog.join('').slice(-16000);
    writeManifest(runDir, manifest);
    error.runDir = runDir;
    throw error;
  }
}

if (process.argv[1] && resolve(process.argv[1]) === resolve(fileURLToPath(import.meta.url))) {
  const args = parseArgs(process.argv.slice(2));
  captureCoilingShell({ runId: args['run-id'], headed: !!args.headed,
    browserChannel: args.chrome ? 'chrome' : undefined, port: args.port })
    .then((manifest) => {
      console.log(`coiling-shell evidence: ${manifest.status}`);
      console.log(resolve(root, 'artifacts/visual-lab/coiling-shell', manifest.runId));
      if (manifest.status === 'fail' || manifest.status === 'stale') process.exitCode = 1;
    })
    .catch((error) => { console.error(error); if (error.runDir) console.error(`partial run: ${error.runDir}`); process.exitCode = 1; });
}
