import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync } from 'node:fs';
import { PNG } from 'pngjs';

const sha256 = (bytes) => createHash('sha256').update(bytes).digest('hex');

// Compare two captures of the same deterministic scenario, with the only
// intended difference being the requested landmark family.  Generic image
// occupancy cannot prove that a family is visible because the cave itself
// fills almost the entire frame.  This mask is the form-specific evidence.
export function inspectPngDifference(actualFile, controlFile, expectedViewport,
  { threshold = 18, writeMaskFile = null } = {}) {
  const actualBytes = readFileSync(actualFile);
  const controlBytes = readFileSync(controlFile);
  const actual = PNG.sync.read(actualBytes);
  const control = PNG.sync.read(controlBytes);
  const dimensionsMatch = actual.width === control.width && actual.height === control.height;
  const viewportPass = dimensionsMatch
    && actual.width === expectedViewport.width && actual.height === expectedViewport.height;
  if (!dimensionsMatch) {
    return {
      pass: false,
      reason: 'actual and family-off control dimensions differ',
      actualSize: [actual.width, actual.height],
      controlSize: [control.width, control.height],
      threshold,
    };
  }

  const n = actual.width * actual.height;
  const mask = new PNG({ width: actual.width, height: actual.height });
  let changedPixels = 0;
  let changedDelta = 0;
  let allDelta = 0;
  let minX = actual.width, minY = actual.height, maxX = -1, maxY = -1;
  const angular = new Set();
  const quadrants = new Set();
  const radial = new Set();
  const thresholdSq = threshold * threshold * 3;
  for (let y = 0; y < actual.height; y++) for (let x = 0; x < actual.width; x++) {
    const p = (y * actual.width + x) * 4;
    const dr = actual.data[p] - control.data[p];
    const dg = actual.data[p + 1] - control.data[p + 1];
    const db = actual.data[p + 2] - control.data[p + 2];
    const distance = Math.sqrt(dr * dr + dg * dg + db * db);
    allDelta += distance;
    const changed = actual.data[p + 3] > 8 && control.data[p + 3] > 8
      && dr * dr + dg * dg + db * db >= thresholdSq;
    const value = changed ? 255 : 0;
    mask.data[p] = mask.data[p + 1] = mask.data[p + 2] = value;
    mask.data[p + 3] = 255;
    if (!changed) continue;
    changedPixels++;
    changedDelta += distance;
    minX = Math.min(minX, x); maxX = Math.max(maxX, x);
    minY = Math.min(minY, y); maxY = Math.max(maxY, y);
    const nx = (x + 0.5) / actual.width * 2 - 1;
    const ny = (y + 0.5) / actual.height * 2 - 1;
    const angle = (Math.atan2(ny, nx) + Math.PI * 2) % (Math.PI * 2);
    angular.add(Math.min(11, Math.floor(angle / (Math.PI * 2) * 12)));
    quadrants.add((nx >= 0 ? 1 : 0) + (ny >= 0 ? 2 : 0));
    radial.add(Math.min(3, Math.floor(Math.min(0.999999, Math.hypot(nx, ny) / Math.SQRT2) * 4)));
  }
  const maskBytes = PNG.sync.write(mask);
  if (writeMaskFile) writeFileSync(writeMaskFile, maskBytes);
  const bbox = changedPixels ? {
    minX, minY, maxX, maxY,
    width: maxX - minX + 1,
    height: maxY - minY + 1,
    widthFraction: (maxX - minX + 1) / actual.width,
    heightFraction: (maxY - minY + 1) / actual.height,
    touchesEdge: minX <= 1 || minY <= 1 || maxX >= actual.width - 2 || maxY >= actual.height - 2,
  } : null;
  return {
    pass: viewportPass,
    threshold,
    viewport: { pass: viewportPass, actual: [actual.width, actual.height],
      expected: [expectedViewport.width, expectedViewport.height] },
    actualSha256: sha256(actualBytes),
    controlSha256: sha256(controlBytes),
    maskSha256: sha256(maskBytes),
    pixels: changedPixels,
    fraction: changedPixels / n,
    meanChangedDelta: changedPixels ? changedDelta / changedPixels / Math.sqrt(3 * 255 * 255) : 0,
    meanFrameDelta: allDelta / n / Math.sqrt(3 * 255 * 255),
    bbox,
    angularBins: [...angular].sort((a, b) => a - b),
    angularBinCount: angular.size,
    quadrants: [...quadrants].sort((a, b) => a - b),
    quadrantCount: quadrants.size,
    radialBins: [...radial].sort((a, b) => a - b),
    radialBinCount: radial.size,
  };
}

export function inspectPng(file, expectedViewport) {
  const bytes = readFileSync(file);
  const png = PNG.sync.read(bytes);
  const n = png.width * png.height;
  let transparent = 0, white = 0, black = 0, sum = 0, sumSq = 0;
  const buckets = new Set();
  for (let i = 0; i < n; i++) {
    const p = i * 4;
    const r = png.data[p], g = png.data[p + 1], b = png.data[p + 2], a = png.data[p + 3];
    if (a === 0) transparent++;
    if (r >= 254 && g >= 254 && b >= 254) white++;
    if (r <= 1 && g <= 1 && b <= 1) black++;
    const luma = (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255;
    sum += luma; sumSq += luma * luma;
    if ((i & 127) === 0) buckets.add(`${r >> 4}:${g >> 4}:${b >> 4}:${a >> 6}`);
  }
  const mean = sum / n;
  const stddev = Math.sqrt(Math.max(0, sumSq / n - mean * mean));
  const fractions = { transparent: transparent / n, white: white / n, black: black / n };
  const blankReasons = [];
  if (fractions.transparent > 0.4) blankReasons.push('transparent pixels exceed 40%');
  if (fractions.white > 0.98) blankReasons.push('white pixels exceed 98%');
  if (fractions.black > 0.995) blankReasons.push('black pixels exceed 99.5%');
  if (stddev < 0.002 && buckets.size < 3) blankReasons.push('frame is effectively uniform');
  const viewportPass = png.width === expectedViewport.width && png.height === expectedViewport.height;
  // Derive the flat background from the outer border and measure useful
  // foreground occupancy. Family-form evidence uses this to reject views that
  // are technically nonblank but show only sub-pixel fragments or clipped art.
  const borderColors = new Map();
  const rememberBorder = (x, y) => {
    const p = (y * png.width + x) * 4;
    const key = `${png.data[p] >> 3}:${png.data[p + 1] >> 3}:${png.data[p + 2] >> 3}`;
    borderColors.set(key, (borderColors.get(key) || 0) + 1);
  };
  for (let x = 0; x < png.width; x++) {
    rememberBorder(x, 0); rememberBorder(x, png.height - 1);
  }
  for (let y = 1; y < png.height - 1; y++) {
    rememberBorder(0, y); rememberBorder(png.width - 1, y);
  }
  const backgroundKey = [...borderColors.entries()].sort((a, b) => b[1] - a[1])[0]?.[0] || '0:0:0';
  const [bgR, bgG, bgB] = backgroundKey.split(':').map((value) => Number(value) * 8 + 4);
  let foregroundPixels = 0;
  let minX = png.width, minY = png.height, maxX = -1, maxY = -1;
  for (let y = 0; y < png.height; y++) for (let x = 0; x < png.width; x++) {
    const p = (y * png.width + x) * 4;
    const dr = png.data[p] - bgR, dg = png.data[p + 1] - bgG, db = png.data[p + 2] - bgB;
    if (png.data[p + 3] > 8 && dr * dr + dg * dg + db * db > 24 * 24) {
      foregroundPixels++;
      minX = Math.min(minX, x); maxX = Math.max(maxX, x);
      minY = Math.min(minY, y); maxY = Math.max(maxY, y);
    }
  }
  const foreground = {
    backgroundRgb: [bgR, bgG, bgB],
    pixels: foregroundPixels,
    fraction: foregroundPixels / n,
    bbox: foregroundPixels ? {
      minX, minY, maxX, maxY,
      width: maxX - minX + 1, height: maxY - minY + 1,
      widthFraction: (maxX - minX + 1) / png.width,
      heightFraction: (maxY - minY + 1) / png.height,
      touchesEdge: minX <= 1 || minY <= 1 || maxX >= png.width - 2 || maxY >= png.height - 2,
    } : null,
  };
  return {
    width: png.width,
    height: png.height,
    sha256: sha256(bytes),
    bytes: bytes.length,
    fractions,
    luma: { mean, stddev },
    sampledColorBuckets: buckets.size,
    foreground,
    blank: { pass: blankReasons.length === 0, reasons: blankReasons },
    viewport: {
      pass: viewportPass,
      expected: [expectedViewport.width, expectedViewport.height],
      actual: [png.width, png.height],
    },
  };
}

export function evaluateFrame({ scenario, captureInfo, runtime, image, errors = [] }) {
  const depth = Number(captureInfo?.distanceReached);
  const depthPass = Number.isFinite(depth) && Math.abs(depth - scenario.distance) <= 1;
  const crashPass = runtime?.appState === 'capture' && runtime?.gamePhase === 'running';
  const browserViewportPass = runtime?.innerWidth === image.viewport.expected[0]
    && runtime?.innerHeight === image.viewport.expected[1]
    && runtime?.devicePixelRatio === 1
    && runtime?.canvasWidth === image.viewport.expected[0]
    && runtime?.canvasHeight === image.viewport.expected[1];
  const webglPass = runtime?.webglAvailable === true && runtime?.webglContextLost === false;
  const positioning = captureInfo?.positioning;
  const family = captureInfo?.family;
  const camera = captureInfo?.camera;
  const viewport = captureInfo?.viewport;
  const visualContractPresent = !!(positioning && family && camera && viewport);
  const requestedPlacement = scenario.captureOptions?.placement;
  const positioningPass = visualContractPresent
    && Math.abs(Number(positioning.requestedDistance) - scenario.distance) <= 1e-6
    && Math.abs(Number(positioning.actualDistance) - scenario.distance) <= 1
    && positioning.method === requestedPlacement
    && positioning.placed === (requestedPlacement === 'place')
    && positioning.flown === (requestedPlacement === 'fly')
    && positioning.reached === true
    && positioning.crashed === false;
  const requestedFamily = scenario.family;
  const familyPass = requestedFamily === undefined || (family?.requested === requestedFamily
    && (requestedFamily === 'auto' || family?.active?.includes(requestedFamily)));
  const requestedCamera = scenario.captureOptions?.camera;
  const cameraPass = requestedCamera === undefined
    || (camera?.requested === requestedCamera && camera?.active === requestedCamera
      && camera?.supported === true);
  const requestedViewport = scenario.captureOptions?.viewport;
  const visualViewportPass = !!viewport?.matches
    && (!requestedViewport || (viewport.requested?.width === requestedViewport.width
      && viewport.requested?.height === requestedViewport.height
      && viewport.requested?.dpr === requestedViewport.dpr));
  const checks = {
    blank: image.blank,
    pngViewport: image.viewport,
    browserViewport: { pass: browserViewportPass, actual: runtime },
    webgl: { pass: webglPass, available: runtime?.webglAvailable,
      contextLost: runtime?.webglContextLost },
    depth: { pass: depthPass, expected: scenario.distance, actual: depth },
    crash: { pass: crashPass, appState: runtime?.appState, gamePhase: runtime?.gamePhase },
    runtimeErrors: { pass: errors.length === 0, errors: [...errors] },
    visualContract: { pass: visualContractPresent, positioning, family, camera, viewport },
    positioning: { pass: positioningPass, expected: {
      distance: scenario.distance, placement: requestedPlacement,
    }, actual: positioning },
    family: { pass: familyPass, expected: requestedFamily, actual: family },
    camera: { pass: cameraPass, expected: requestedCamera, actual: camera },
    visualViewport: { pass: visualViewportPass, expected: requestedViewport, actual: viewport },
  };
  return { status: Object.values(checks).every((check) => check.pass) ? 'pass' : 'fail', checks };
}
