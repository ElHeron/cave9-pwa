import { existsSync, mkdirSync, readFileSync, renameSync, writeFileSync } from 'node:fs';
import { dirname, isAbsolute, relative, resolve } from 'node:path';

export function resolveRunDir(root, value) {
  if (!value) throw new Error('run id or run directory is required');
  return resolve(root, value.includes('/') || value.includes('\\')
    ? value : `artifacts/visual-lab/${value}`);
}

export function readManifest(runDir) {
  return JSON.parse(readFileSync(resolve(runDir, 'manifest.json'), 'utf8'));
}

export const jsonBytes = (value) => Buffer.from(`${JSON.stringify(value, null, 2)}\n`);

const samePath = (a, b) => {
  const left = resolve(a), right = resolve(b);
  return process.platform === 'win32' ? left.toLowerCase() === right.toLowerCase() : left === right;
};

export function canonicalRunDir(root, runId) {
  return resolve(root, 'artifacts/visual-lab', runId);
}

export function isCanonicalRunDir(root, runDir, runId) {
  return typeof runId === 'string' && samePath(runDir, canonicalRunDir(root, runId));
}

/** Resolve a manifest-owned artifact and reject absolute paths and traversal. */
export function resolveRunArtifact(runDir, value, { expected } = {}) {
  if (typeof value !== 'string' || value.length === 0 || isAbsolute(value)) {
    throw new Error('run artifact path must be a non-empty relative path');
  }
  const portable = value.replace(/\\/g, '/');
  if (portable.startsWith('/') || portable.split('/').some((part) => part === '..' || part === '')) {
    throw new Error(`run artifact path escapes or is not canonical: ${value}`);
  }
  if (expected !== undefined && portable !== expected) {
    throw new Error(`run artifact path must be ${expected}, found ${value}`);
  }
  const file = resolve(runDir, ...portable.split('/'));
  const rel = relative(resolve(runDir), file);
  if (!rel || rel.startsWith('..') || isAbsolute(rel)) {
    throw new Error(`run artifact path escapes run directory: ${value}`);
  }
  return file;
}

function existingManifestBlessing(runDir) {
  const file = resolve(runDir, 'manifest.json');
  if (!existsSync(file)) return null;
  try { return JSON.parse(readFileSync(file, 'utf8')).blessing || null; }
  catch { return null; }
}

export function assertRunMutable(runDir, manifest = null, operation = 'modify run') {
  if (existsSync(resolve(runDir, 'blessing.json')) || manifest?.blessing || existingManifestBlessing(runDir)) {
    throw new Error(`refusing to ${operation}: blessed visual evidence runs are immutable`);
  }
}

export function writeJsonAtomic(file, value) {
  mkdirSync(dirname(file), { recursive: true });
  const temp = `${file}.tmp-${process.pid}`;
  writeFileSync(temp, jsonBytes(value));
  renameSync(temp, file);
}

export function writeManifest(runDir, manifest, { allowBlessedWrite = false } = {}) {
  if (!allowBlessedWrite) assertRunMutable(runDir, manifest, 'write manifest');
  writeJsonAtomic(resolve(runDir, 'manifest.json'), manifest);
}

export function parseArgs(argv) {
  const out = { positional: [] };
  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i];
    if (!arg.startsWith('--')) out.positional.push(arg);
    else if (arg.includes('=')) {
      const [key, ...rest] = arg.slice(2).split('=');
      out[key] = rest.join('=');
    } else if (argv[i + 1] && !argv[i + 1].startsWith('--')) out[arg.slice(2)] = argv[++i];
    else out[arg.slice(2)] = true;
  }
  return out;
}
