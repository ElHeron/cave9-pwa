import { coilingVisibleFrontDepth } from '../../src/core/CoilingShell.js';

export const COILING_SHELL_EVIDENCE_VERSION = 1;
export const COILING_SHELL_SUITE = 'coiling-shell-evidence';
export const COILING_SHELL_API = 'window.__cave9.visual.loadScenario+snapshot';
export const COILING_SHELL_SEED = 2024;
// Review the mature release look, not the intentionally black original-style
// first room. Branching/Crystal evidence is likewise captured around 9 km;
// using room 9 keeps the reference comparison on one visual progression stage.
export const COILING_SHELL_ROOM = 9;
export const COILING_SHELL_VIEWPORT = Object.freeze({ width: 1280, height: 720, deviceScaleFactor: 1 });
export const COILING_SHELL_APPROACHES = Object.freeze([100, 70, 45, 25]);

export const COILING_SHELL_CAPABILITIES = Object.freeze({
  heroApproach: {
    supported: true,
    authority: 'VisualScenarioV1 forced family=coiling before Game.start/CaveStream.prime',
  },
  ringAtlas: {
    supported: true,
    authority: 'live CaveStream.segs/frames/innerRadii through buildCaveAtlas',
  },
  booleanReserve: {
    supported: true,
    authority: 'route-local radii from live ring vertices versus CaveStream.innerRadii + ship hull + reserve',
  },
  landmarkSkeleton: {
    supported: true,
    authority: 'compositionAt identity with exactly zero pieces and collisionPieces',
  },
  shellOrbit: {
    supported: false,
    reason: 'VisualScenarioV1 orbit currently fits LandmarkLayer pieces; Coiling intentionally has none, so a shell orbit would not be authoritative',
  },
  shellOrthographic3d: {
    supported: false,
    reason: 'VisualScenarioV1 orthographic fitting currently consumes LandmarkLayer vertices, not CaveStream ring bounds; atlas views are used instead',
  },
});

export function coilingShellTemplates() {
  return [
    ...COILING_SHELL_APPROACHES.map((approachMeters) => ({
      id: `coiling-hero-a${approachMeters}`,
      kind: 'hero',
      approachMeters,
      captureApi: COILING_SHELL_API,
    })),
    { id: 'coiling-atlas-longitudinal', kind: 'atlas-longitudinal', captureApi: 'live-cavestream-atlas' },
    { id: 'coiling-atlas-unwrapped', kind: 'atlas-unwrapped', captureApi: 'live-cavestream-atlas' },
    { id: 'coiling-atlas-cross-sections', kind: 'atlas-cross-sections', captureApi: 'live-cavestream-atlas' },
    { id: 'coiling-boolean-reserve', kind: 'boolean-reserve', captureApi: 'live-cavestream-ring-reserve' },
  ];
}

export function coilingShellSuiteDefinition() {
  return {
    name: COILING_SHELL_SUITE,
    schemaVersion: COILING_SHELL_EVIDENCE_VERSION,
    seed: COILING_SHELL_SEED,
    room: COILING_SHELL_ROOM,
    family: 'coiling',
    viewport: { ...COILING_SHELL_VIEWPORT },
    approaches: [...COILING_SHELL_APPROACHES],
    capabilities: structuredClone(COILING_SHELL_CAPABILITIES),
    templates: coilingShellTemplates(),
  };
}

export function coilingHeroScenario(template, contract) {
  if (template.kind !== 'hero' || !Number.isFinite(template.approachMeters)) {
    throw new TypeError('coilingHeroScenario requires a Hero template');
  }
  if (!Number.isFinite(contract?.start) || !Number.isFinite(contract?.end)) {
    throw new TypeError('coiling shell contract bounds are missing');
  }
  const visibleFrontDepth = coilingVisibleFrontDepth(contract);
  const distance = +(visibleFrontDepth - template.approachMeters).toFixed(3);
  return {
    id: template.id,
    kind: template.kind,
    approachMeters: template.approachMeters,
    visibleFrontDepth,
    distance,
    captureOptions: {
      version: 'VisualScenarioV1',
      name: template.id,
      seed: COILING_SHELL_SEED,
      distance,
      placement: 'place',
      family: 'coiling',
      camera: 'hero',
      renderPass: 'beauty',
      paused: true,
      viewport: {
        width: COILING_SHELL_VIEWPORT.width,
        height: COILING_SHELL_VIEWPORT.height,
        dpr: COILING_SHELL_VIEWPORT.deviceScaleFactor,
      },
      settings: {
        fov: 45, motion: 0, landmarks: true, readability: true, rockDetail: true,
        cave: true, wireframe: false, landmarkMesh: true,
        collisionCapsules: false, booleanTube: false, playerHull: false, frames: false,
        fog: true, material: true, light: true,
      },
    },
  };
}

export function coilingHeroOffControlScenario(scenario) {
  if (scenario?.kind !== 'hero' || !scenario.captureOptions) {
    throw new TypeError('Coiling family-off control requires a resolved Hero scenario');
  }
  return {
    ...scenario,
    id: `${scenario.id}-control-off`,
    family: 'off',
    controlFor: scenario.id,
    captureOptions: {
      ...scenario.captureOptions,
      name: `${scenario.id}-control-off`,
      family: 'off',
      settings: { ...scenario.captureOptions.settings, landmarks: false },
    },
  };
}

export function coilingHeroDifferenceCheck(approachMeters, difference) {
  const approach = Number(approachMeters);
  const distant = approach >= 90;
  const near = approach <= 30;
  const thresholds = {
    minFraction: distant ? 0.01 : near ? 0.04 : 0.025,
    minWidthFraction: distant ? 0.55 : 0.7,
    minHeightFraction: distant ? 0.45 : 0.6,
    minAngularBins: distant ? 8 : 10,
    minQuadrants: 4,
    minRadialBins: 3,
    minMeanChangedDelta: 0.04,
  };
  const bbox = difference?.bbox;
  const diagnosticPass = difference?.pass === true && !!bbox
    && difference.fraction >= thresholds.minFraction
    && bbox.widthFraction >= thresholds.minWidthFraction
    && bbox.heightFraction >= thresholds.minHeightFraction
    && difference.angularBinCount >= thresholds.minAngularBins
    && difference.quadrantCount >= thresholds.minQuadrants
    && difference.radialBinCount >= thresholds.minRadialBins
    && difference.meanChangedDelta >= thresholds.minMeanChangedDelta;
  const required = !distant;
  return {
    pass: !required || diagnosticPass,
    required,
    diagnosticPass,
    classification: distant ? 'onset-diagnostic' : 'release-gate',
    approachMeters: approach,
    thresholds,
    actual: difference ?? null,
  };
}

export function coilingShellInspectionDepth(contract) {
  if (!Number.isFinite(contract?.start) || !Number.isFinite(contract?.end)) {
    throw new TypeError('coiling shell contract bounds are missing');
  }
  // placeAt generates one complete 144-ring live span in front of the posed
  // depth. Start one lattice step before C3 so the recycled 0,2,4... buffer
  // brackets the complete 160–200 m contract instead of discarding its front.
  return +(contract.start - 2).toFixed(3);
}

export function coilingShellFramingCheck(kind, image) {
  const foreground = image?.foreground;
  const bbox = foreground?.bbox;
  const atlas = kind.startsWith('atlas-') || kind === 'boolean-reserve';
  const thresholds = atlas
    ? { minFraction: 0.008, minWidthFraction: 0.35, minHeightFraction: 0.12,
      mustNotTouchEdge: true, minLumaStddev: 0.015 }
    : { minFraction: 0.02, minWidthFraction: 0.25, minHeightFraction: 0.25,
      mustNotTouchEdge: false, minLumaStddev: 0.01 };
  return {
    pass: !!bbox && image.blank?.pass === true
      && foreground.fraction >= thresholds.minFraction
      && bbox.widthFraction >= thresholds.minWidthFraction
      && bbox.heightFraction >= thresholds.minHeightFraction
      && (!thresholds.mustNotTouchEdge || !bbox.touchesEdge)
      && image.luma?.stddev >= thresholds.minLumaStddev,
    required: true,
    thresholds,
    actual: foreground || null,
    lumaStddev: image?.luma?.stddev ?? null,
  };
}
