import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { assertRunMutable, parseArgs, resolveRunDir, writeManifest } from './manifest.mjs';
import { manualCriteriaCheck, manualReviewBinding, verifyRun } from './verification.mjs';

export async function reviewRun({ root = process.cwd(), runDir, reviewer,
  approve = false, reject = false, note = null, criteria = null } = {}) {
  if (!reviewer) throw new Error('reviewer is required');
  if (!!approve === !!reject) throw new Error('choose exactly one of approve or reject');
  assertRunMutable(runDir, null, 'review run');
  const manifest = await verifyRun({ root, runDir });
  if (manifest.verification.stale) {
    throw new Error(`cannot review stale evidence: ${manifest.verification.staleReasons.join('; ')}`);
  }
  if (manifest.automated.status !== 'pass') throw new Error('cannot review evidence while automated checks fail');
  const proposed = { status: approve ? 'pass' : 'fail', criteria };
  if (approve) {
    const criteriaResult = manualCriteriaCheck(proposed);
    if (!criteriaResult.pass) throw new Error(`cannot approve incomplete manual review: ${criteriaResult.reasons.join('; ')}`);
  }
  manifest.manualReview = {
    status: proposed.status,
    reviewer,
    reviewedAt: new Date().toISOString(),
    note,
    criteria: criteria || null,
    reportJsonSha256: manifest.report.jsonSha256,
    reportHtmlSha256: manifest.report.htmlSha256,
    frames: manifest.frames.map((frame) => ({ id: frame.id, sha256: frame.image.sha256 })),
  };
  const binding = manualReviewBinding(manifest, manifest.frames, manifest.automated.reportFiles || []);
  manifest.verification = { ...manifest.verification, manualReviewBinding: binding };
  manifest.status = approve && binding.pass === true ? 'pass' : 'fail';
  writeManifest(runDir, manifest);
  return manifest;
}

if (process.argv[1] && resolve(process.argv[1]) === resolve(fileURLToPath(import.meta.url))) {
  const args = parseArgs(process.argv.slice(2));
  const root = process.cwd();
  const runDir = resolveRunDir(root, args.run || args.positional[0]);
  const criteria = args.criteria
    ? JSON.parse(readFileSync(resolve(root, args.criteria), 'utf8')) : null;
  reviewRun({ root, runDir, reviewer: args.reviewer, approve: !!args.approve,
    reject: !!args.reject, note: args.note || null, criteria })
    .then((manifest) => console.log(`manual review: ${manifest.manualReview.status}`))
    .catch((error) => { console.error(error); process.exitCode = 1; });
}
