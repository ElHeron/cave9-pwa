// Fixed-camera integration evidence; visual judgment remains manual.
import { mkdirSync, existsSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { chromium } from 'playwright';
import { withViteServer } from './vite-server.mjs';
import { gitProvenance, runtimeFingerprint } from './provenance.mjs';
import { effectiveRenderPixelRatio, drawingBufferSize } from '../../src/render/renderResolution.js';

const args = process.argv.slice(2);
const arg = (name, fallback) => {
  const i = args.indexOf(name);
  return i < 0 ? fallback : args[i + 1];
};
const final = args.includes('--final');
const motion = final || args.includes('--motion');
const runId = arg('--run-id', null);
if (!runId || !/^[a-zA-Z0-9_-]+$/.test(runId)) throw new Error('explicit simple --run-id required');
const families = arg('--families', 'branching,crystal,coiling').split(',');
if (families.some(f => !['branching', 'crystal', 'coiling'].includes(f))) throw new Error('invalid family');
// Seed777 exposed integration defects in the first final review and is now a
// working seed. Reserve a fresh seed for the next integrated decision. An
// explicit override also makes earlier matrices reproducible without silently
// labelling their already-reviewed seed as a new holdout.
const heldOutSeed = Number(arg('--held-out-seed', '6605639'));
if (!Number.isSafeInteger(heldOutSeed) || heldOutSeed < 0 || heldOutSeed > 0xffffffff
  || [2024, 256, 4096].includes(heldOutSeed)) throw new Error('invalid held-out seed');
const seeds = arg('--seeds', final ? `2024,256,4096,${heldOutSeed}` : '2024,256,4096').split(',').map(Number);
if (new Set(seeds).size !== seeds.length || seeds.some(s => !Number.isSafeInteger(s)
  || s < 0 || s > 0xffffffff || (s === heldOutSeed && !final))
  || (final && !seeds.includes(heldOutSeed))) throw new Error('invalid, missing or premature held-out seed');
const out = resolve('artifacts/visual-forms/20260929', runId);
if (existsSync(out)) throw new Error('refusing to overwrite evidence');
mkdirSync(resolve(out, 'frames'), { recursive: true });
const source = runtimeFingerprint();
const git = await gitProvenance();
const evidence = { kind: 'cave9-form-integration', runId, createdAt: new Date().toISOString(),
  purpose: 'Fixed cameras, natural family selection, quality/mobile and sequential motion; manual visual review required.',
  heldOutSeed: final ? heldOutSeed : null,
  source, git, frames: [], motion: [], errors: [], status: 'capturing' };
const settings = { fov: 45, motion: 0, brightness: 1, surfaceRelief: true, rockDetail: true };
const cases = [];
for (const seed of seeds) for (const family of families) for (const distance of [9070, 9120]) {
  for (const renderPass of ['beauty', 'clay']) cases.push({ seed, family, distance, renderPass });
}
for (const family of families) cases.push({ seed: 2024, family: 'auto',
  distance: family === 'branching' ? 6050 : family === 'crystal' ? 2050 : 9070,
  expectedNaturalFamily: family, renderPass: 'beauty' });
// The room-9 exit shoulder is a separate transition check. At 9250 m its
// composition centre has left the live cache, so `family.active` is empty;
// it must not masquerade as proof of an active natural Coiling composition.
if (families.includes('coiling')) cases.push({ seed: 2024, family: 'auto',
  distance: 9250, renderPass: 'beauty' });
if (final) for (const distance of [250, 15600]) cases.push({ seed: 2024, family: 'auto', distance, renderPass: 'beauty' });
const profiles = [{ name: 'desktop-high', width: 1280, height: 720, dpr: 1, quality: 2 }];
if (final) profiles.push({ name: 'desktop-performance', width: 1280, height: 720, dpr: 1, quality: 1 },
  { name: 'mobile-high', width: 812, height: 375, dpr: 2, quality: 2 });

async function capture(page, name, spec, profile, advance = 0) {
  const result = await page.evaluate(async ({ name, spec, profile, advance, settings }) => {
    const app = window.__cave9;
    if (!advance) {
      app.onSettingChange('quality', profile.quality);
      app.visual.loadScenario({ version: 'VisualScenarioV1', name, seed: spec.seed,
        distance: spec.distance, family: spec.family, camera: 'hero', placement: 'place', paused: true,
        renderPass: spec.renderPass, viewport: { width: profile.width, height: profile.height, dpr: profile.dpr }, settings });
      await app.renderer.load();
      app.visual.step(0);
      await app.renderer.surfaceReliefReady();
    }
    app.visual.step(advance);
    const gl = app.renderer.renderer.getContext();
    const extension = gl.getExtension('WEBGL_debug_renderer_info');
    return { snapshot: app.visual.snapshot({ includeImage: false }), capabilities: app.renderer.renderCapabilities(),
      actualQuality: app.settings.get('quality'), actualPixelRatio: app.renderer.renderer.getPixelRatio(),
      drawingBuffer: [gl.drawingBufferWidth, gl.drawingBufferHeight],
      gpu: extension ? gl.getParameter(extension.UNMASKED_RENDERER_WEBGL) : gl.getParameter(gl.RENDERER),
      webglError: gl.getError(), contextLost: gl.isContextLost(),
      image: app.renderer.canvas.toDataURL('image/png') };
  }, { name, spec, profile, advance, settings });
  const { image, ...metadata } = result;
  if (/swiftshader|llvmpipe|software/i.test(metadata.gpu)) throw new Error('hardware evidence unexpectedly uses software');
  if (metadata.webglError || metadata.contextLost || metadata.actualQuality !== profile.quality) throw new Error('invalid render state');
  if (!metadata.capabilities.surfaceMaterialActive || !metadata.capabilities.surfaceReliefActive
    || !metadata.capabilities.rockFacetActive) throw new Error('hardware material assets are not active');
  const expectedPR = effectiveRenderPixelRatio(profile.dpr, profile.quality);
  const expectedSize = drawingBufferSize(profile.width, profile.height, expectedPR);
  if (metadata.actualPixelRatio !== expectedPR || metadata.drawingBuffer.some((v, i) => v !== expectedSize[i])) {
    throw new Error('drawing buffer differs from the documented viewport/quality contract');
  }
  if (spec.family !== 'auto' && [9070, 9120].includes(spec.distance)
    && !metadata.snapshot.family.active.includes(spec.family)) throw new Error('forced family absent');
  if (spec.expectedNaturalFamily
    && (metadata.snapshot.family.requested !== 'auto'
      || metadata.snapshot.family.active.length !== 1
      || metadata.snapshot.family.active[0] !== spec.expectedNaturalFamily)) {
    throw new Error(`natural family differs from expected ${spec.expectedNaturalFamily}`);
  }
  const file = `frames/${name}.png`;
  writeFileSync(resolve(out, file), Buffer.from(image.split(',')[1], 'base64'));
  const entry = { name, file, spec, profile, advance, ...metadata };
  evidence.frames.push(entry);
  return entry;
}

try {
  await withViteServer(async ({ url }) => {
    const browser = await chromium.launch({ channel: 'chrome', headless: true });
    try {
      evidence.browser = browser.version();
      for (const profile of profiles) {
        const context = await browser.newContext({ viewport: { width: profile.width, height: profile.height }, deviceScaleFactor: profile.dpr });
        const page = await context.newPage();
        page.on('pageerror', e => evidence.errors.push(e.message));
        page.on('console', m => { if (m.type() === 'error') evidence.errors.push(m.text()); });
        await page.goto(url + '&visualLab=1', { waitUntil: 'networkidle' });
        await page.waitForFunction(() => window.__cave9?.visual?.snapshot && window.__cave9?.state !== 'boot');
        const selectedCases = profile.name === 'desktop-high' ? cases
          : cases.filter(c => c.renderPass === 'beauty' && (c.seed === 2024 || c.seed === heldOutSeed));
        for (const spec of selectedCases) {
          const name = `${profile.name}-${spec.family}-s${spec.seed}-d${spec.distance}-${spec.renderPass}`;
          await capture(page, name, spec, profile);
          process.stdout.write(name + '\n');
        }
        if (motion && profile.name === 'desktop-high' && !args.includes('--no-motion')) {
          for (const family of families) {
            const spec = { seed: 2024, family, distance: 8950, renderPass: 'beauty' };
            const sequence = { family, seed: 2024, from: spec.distance, simulationStepsPerSample: 6, frames: [] };
            for (let i = 0; i <= 95; i++) {
              const name = `motion-${family}-${String(i).padStart(3, '0')}`;
              const entry = await capture(page, name, spec, profile, i ? 6 : 0);
              if (i && entry.snapshot.distance <= sequence.frames.at(-1).distance) throw new Error('motion stopped advancing');
              sequence.frames.push({ file: entry.file, distance: entry.snapshot.distance, step: i * 6 });
            }
            evidence.motion.push(sequence);
            process.stdout.write(`motion-${family} complete\n`);
          }
        }
        await context.close();
      }
    } finally { await browser.close(); }
  });
  evidence.sourceAfter = runtimeFingerprint();
  evidence.gitAfter = await gitProvenance();
  evidence.sourceStable = source.source.sha256 === evidence.sourceAfter.source.sha256
    && source.assets.sha256 === evidence.sourceAfter.assets.sha256
    && git.commit === evidence.gitAfter.commit
    && git.diffFingerprint === evidence.gitAfter.diffFingerprint;
  if (!evidence.sourceStable || evidence.errors.length) throw new Error('source changed or browser errors occurred');
  evidence.status = 'manual-pending';
} catch (error) {
  evidence.status = 'failed'; evidence.error = String(error.stack || error); process.exitCode = 1;
} finally {
  evidence.completedAt = new Date().toISOString();
  writeFileSync(resolve(out, 'evidence.json'), JSON.stringify(evidence, null, 2));
}
