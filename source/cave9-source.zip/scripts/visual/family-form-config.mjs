export const FAMILY_FORM_SCHEMA_VERSION = 1;
export const FAMILY_FORM_SUITE = 'family-form-review';
export const FAMILY_FORM_VIEWPORT = Object.freeze({ width: 1280, height: 720, deviceScaleFactor: 1 });
export const FAMILY_FORM_API = 'window.__cave9.visual.loadScenario+snapshot';
export const FAMILY_FORM_BASE_DEPTH = 9000;
export const FAMILY_FORM_APPROACHES = Object.freeze([100, 70, 45, 25]);
export const FAMILY_FORM_FIXED_DEPTHS = Object.freeze([9070, 9120]);
// Frozen V00 camera/world positions for the seed-2024 room-9 comparison. New
// geometry must never move these cameras; front-relative views are separate.
export const FAMILY_FORM_BASELINE_APPROACH_DEPTHS = Object.freeze({
  branching: Object.freeze([9011.984, 9041.984, 9066.984, 9086.984]),
  crystal: Object.freeze([8984.190, 9014.190, 9039.190, 9059.190]),
  coiling: Object.freeze([8963.047, 8993.047, 9018.047, 9038.047]),
});
export const FAMILY_FORM_ORBITS = Object.freeze([0, 60, 120, 180, 240, 300]);
export const FAMILY_FORM_FAMILIES = Object.freeze([
  { family: 'branching', seed: 2024 },
  { family: 'crystal', seed: 2024 },
  { family: 'coiling', seed: 2024 },
]);
export const FAMILY_FORM_M1_M2_FAMILIES = Object.freeze(FAMILY_FORM_FAMILIES.slice(0, 2));

export const FAMILY_FORM_CAPABILITIES = Object.freeze({
  heroApproach: { supported: true,
    authority: 'LandmarkLayer geometry for roots/crystal; live CaveStream room rings for coiling' },
  orbit: { supported: true, authority: 'VisualScenarioV1 camera=orbit' },
  orthoFront: { supported: true, authority: 'VisualScenarioV1 orthographicAxis=front' },
  orthoSide: { supported: true, authority: 'VisualScenarioV1 orthographicAxis=side' },
  orthoTop: { supported: true, authority: 'VisualScenarioV1 orthographicAxis=top' },
  neutralFamilyMaterial: { supported: true, authority: 'VisualScenarioV1 renderPass=neutral' },
  litClayWallAndForm: { supported: true,
    authority: 'VisualScenarioV1 renderPass=clay, actual cave and landmark geometry, fixed world-space rig' },
  silhouetteFamilyMaterial: { supported: true,
    authority: 'VisualScenarioV1 orthographic front + renderPass=silhouette with family-only black-on-white output' },
  collisionCapsules: { supported: true, authority: 'VisualDebug3d collisionCapsules layer' },
  booleanTube: { supported: true, authority: 'VisualDebug3d booleanTube layer' },
  coilingShellReview: { supported: true,
    authority: 'CaveStream room rings and the production cave mesh, never LandmarkLayer ribs' },
});

export function familyFormTemplates(family) {
  const hero = FAMILY_FORM_APPROACHES.map((approachMeters) => ({
    id: `${family}-hero-a${approachMeters}`,
    family, kind: 'hero', camera: 'hero', approachMeters,
  }));
  const fixed = FAMILY_FORM_FIXED_DEPTHS.flatMap((distance) => [
    { id: `${family}-fixed-${distance}-beauty`, family, kind: 'fixed-hero', camera: 'hero',
      fixedDepth: distance, renderPass: 'beauty' },
    { id: `${family}-fixed-${distance}-clay`, family, kind: 'fixed-hero', camera: 'hero',
      fixedDepth: distance, renderPass: 'clay' },
  ]);
  const baseline = FAMILY_FORM_APPROACHES.flatMap((approachMeters, index) =>
    ['beauty', 'clay'].map((renderPass) => ({
      id: `${family}-baseline-a${approachMeters}-${renderPass}`,
      family, kind: 'baseline-hero', camera: 'hero',
      fixedDepth: FAMILY_FORM_BASELINE_APPROACH_DEPTHS[family][index],
      baselineApproachMeters: approachMeters, renderPass,
    })));
  const clayApproach = FAMILY_FORM_APPROACHES.map((approachMeters) => ({
    id: `${family}-clay-a${approachMeters}`, family, kind: 'clay-hero', camera: 'hero',
    approachMeters, renderPass: 'clay',
  }));
  if (family === 'coiling') return [...hero, ...fixed, ...baseline, ...clayApproach];
  const orbit = FAMILY_FORM_ORBITS.map((orbitDegrees) => ({
    id: `${family}-orbit-${String(orbitDegrees).padStart(3, '0')}`,
    family, kind: 'orbit', camera: 'orbit', orbitDegrees, renderPass: 'neutral',
    orbitScope: 'detail-bank', setupBehindFrontMeters: 45,
  }));
  const completeOrbit = family === 'crystal' ? FAMILY_FORM_ORBITS.map((orbitDegrees) => ({
    id: `${family}-orbit-complete-${String(orbitDegrees).padStart(3, '0')}`,
    family, kind: 'orbit-complete', camera: 'orbit', orbitDegrees, renderPass: 'clay',
    orbitScope: 'complete-composition', setupBehindFrontMeters: 45,
  })) : [];
  const clayDetailOrbit = family === 'crystal' ? [60, 120].map((orbitDegrees) => ({
    id: `${family}-orbit-detail-clay-${String(orbitDegrees).padStart(3, '0')}`,
    family, kind: 'orbit-detail-clay', camera: 'orbit', orbitDegrees,
    renderPass: 'clay', orbitScope: 'detail-bank', setupBehindFrontMeters: 45,
  })) : [];
  return [
    ...hero,
    ...fixed,
    ...baseline,
    ...clayApproach,
    ...orbit,
    ...clayDetailOrbit,
    ...completeOrbit,
    ...['front', 'side', 'top'].map((orthographicAxis) => ({
      id: `${family}-ortho-${orthographicAxis}`, family, kind: `ortho-${orthographicAxis}`,
      camera: 'orthographic', orthographicAxis, renderPass: 'neutral', setupBehindFrontMeters: 45,
      layerOverrides: { cave: false },
    })),
    { id: `${family}-neutral`, family, kind: 'neutral', camera: 'hero',
      renderPass: 'neutral', setupBehindFrontMeters: 45 },
    // Silhouette is a topology proof, not a perspective beauty frame. The
    // authoritative orthographic family fit keeps every wall contact in view;
    // Hero comparison remains fixed at 100/70/45/25 m above.
    { id: `${family}-silhouette`, family, kind: 'silhouette', camera: 'orthographic',
      orthographicAxis: 'front', renderPass: 'silhouette', setupBehindFrontMeters: 45,
      layerOverrides: { cave: false } },
    { id: `${family}-collision`, family, kind: 'collision', camera: 'hero', setupBehindFrontMeters: 45,
      layerOverrides: { collisionCapsules: true } },
    { id: `${family}-boolean-tube`, family, kind: 'boolean-tube', camera: 'hero', setupBehindFrontMeters: 45,
      layerOverrides: { booleanTube: true } },
  ];
}

export function familyFormSuiteDefinition(families = FAMILY_FORM_M1_M2_FAMILIES) {
  const selected = families.map((entry) => typeof entry === 'string'
    ? FAMILY_FORM_FAMILIES.find((candidate) => candidate.family === entry) : entry);
  if (selected.some((entry) => !entry)) throw new RangeError('unknown family-form family');
  return {
    name: FAMILY_FORM_SUITE,
    schemaVersion: FAMILY_FORM_SCHEMA_VERSION,
    viewport: { ...FAMILY_FORM_VIEWPORT },
    captureApi: FAMILY_FORM_API,
    baseDepth: FAMILY_FORM_BASE_DEPTH,
    approaches: [...FAMILY_FORM_APPROACHES],
    fixedDepths: [...FAMILY_FORM_FIXED_DEPTHS],
    baselineApproachDepths: Object.fromEntries(selected.map(({ family }) =>
      [family, [...FAMILY_FORM_BASELINE_APPROACH_DEPTHS[family]]])),
    orbitDegrees: [...FAMILY_FORM_ORBITS],
    families: selected.map((entry) => ({ ...entry })),
    capabilities: structuredClone(FAMILY_FORM_CAPABILITIES),
    templates: selected.flatMap(({ family }) => familyFormTemplates(family)),
  };
}

export function resolvedFamilyScenario(template, familySpec, resolution) {
  if (!Number.isFinite(resolution?.visibleGeometryBounds?.frontDepth)
    || !Number.isFinite(resolution?.visibleGeometryBounds?.reviewFrontDepth)) {
    throw new Error(`cannot resolve ${template.id}: visible family front depth is missing`);
  }
  const placementBehindFrontMeters = template.fixedDepth == null
    ? template.approachMeters ?? template.setupBehindFrontMeters
    : resolution.visibleGeometryBounds.reviewFrontDepth - template.fixedDepth;
  // VisualSnapshotV1 reports depth to millimetre precision. Resolve to the same
  // precision so requested/actual equality remains a meaningful strict check.
  const distance = template.fixedDepth == null
    ? +(resolution.visibleGeometryBounds.reviewFrontDepth - placementBehindFrontMeters).toFixed(3)
    : template.fixedDepth;
  return {
    ...template,
    seed: familySpec.seed,
    distance,
    resolvedFrontDepth: resolution.visibleGeometryBounds.reviewFrontDepth,
    absoluteFrontDepth: resolution.visibleGeometryBounds.frontDepth,
    placementBehindFrontMeters,
    captureOptions: {
      version: 'VisualScenarioV1',
      name: template.id,
      seed: familySpec.seed,
      mode: 2,
      distance,
      placement: 'place',
      family: familySpec.family,
      camera: template.camera,
      orthographicAxis: template.orthographicAxis ?? 'front',
      renderPass: template.renderPass ?? 'beauty',
      orbitDegrees: template.orbitDegrees ?? 0,
      orbitScope: template.orbitScope ?? 'detail-bank',
      paused: true,
      viewport: { width: FAMILY_FORM_VIEWPORT.width, height: FAMILY_FORM_VIEWPORT.height,
        dpr: FAMILY_FORM_VIEWPORT.deviceScaleFactor },
      settings: {
        fov: 45, brightness: 1, motion: 0, landmarks: true, readability: true, rockDetail: true,
        cave: true, wireframe: false, landmarkMesh: true,
        collisionCapsules: false, booleanTube: false, playerHull: false, frames: false,
        fog: true, material: true, light: true,
        ...(template.layerOverrides || {}),
      },
    },
  };
}

export function resolvedFamilyOffControlScenario(scenario) {
  if (scenario?.kind !== 'hero' || !scenario.captureOptions) {
    throw new TypeError('family-off control requires a resolved Hero scenario');
  }
  return {
    ...scenario,
    id: `${scenario.id}-control-off`,
    family: 'off',
    controlFor: scenario.id,
    captureOptions: {
      ...scenario.captureOptions,
      name: `${scenario.id}-control-off`,
      family: 'off',
      settings: { ...scenario.captureOptions.settings, landmarks: false },
    },
  };
}

export function familyFormHeroDifferenceCheck(family, approachMeters, difference) {
  const approach = Number(approachMeters);
  const distant = approach >= 90;
  const near = approach <= 30;
  const thresholds = {
    minFraction: distant ? 0.0015 : near ? 0.003 : 0.002,
    minWidthFraction: distant ? 0.14 : near ? 0.22 : 0.18,
    minHeightFraction: distant ? 0.14 : near ? 0.22 : 0.18,
    minAngularBins: distant ? 3 : 4,
    minQuadrants: distant ? 2 : 3,
    minRadialBins: 2,
    minMeanChangedDelta: 0.035,
  };
  const bbox = difference?.bbox;
  const diagnosticPass = difference?.pass === true && !!bbox
    && difference.fraction >= thresholds.minFraction
    && bbox.widthFraction >= thresholds.minWidthFraction
    && bbox.heightFraction >= thresholds.minHeightFraction
    && difference.angularBinCount >= thresholds.minAngularBins
    && difference.quadrantCount >= thresholds.minQuadrants
    && difference.radialBinCount >= thresholds.minRadialBins
    && difference.meanChangedDelta >= thresholds.minMeanChangedDelta;
  const required = !distant;
  return {
    pass: !required || diagnosticPass,
    required,
    diagnosticPass,
    classification: distant ? 'onset-diagnostic' : 'release-gate',
    family,
    approachMeters: approach,
    thresholds,
    actual: difference ?? null,
  };
}

export function familyFormFramingCheck(kind, image) {
  const required = kind.startsWith('orbit') || kind.startsWith('ortho-') || kind === 'silhouette';
  if (!required) return { pass: true, required: false };
  const foreground = image?.foreground;
  const bbox = foreground?.bbox;
  // Side/top orthographic topology views legitimately expose the thin edge of
  // broad radial plates. Keep their content floor lower than Hero/Orbit, but
  // still require a substantial two-dimensional bound and no edge clipping.
  const thresholds = kind.startsWith('orbit')
    ? { minFraction: 0.005, minWidthFraction: 0.08, minHeightFraction: 0.05 }
    : kind.startsWith('ortho-')
      ? { minFraction: 0.0015, minWidthFraction: 0.08, minHeightFraction: 0.05 }
      : { minFraction: 0.005, minWidthFraction: 0.08, minHeightFraction: 0.05 };
  return {
    pass: !!bbox && foreground.fraction >= thresholds.minFraction
      && bbox.widthFraction >= thresholds.minWidthFraction
      && bbox.heightFraction >= thresholds.minHeightFraction
      && !bbox.touchesEdge,
    required: true,
    thresholds: {
      ...thresholds, mustNotTouchEdge: true,
    },
    actual: foreground || null,
  };
}
