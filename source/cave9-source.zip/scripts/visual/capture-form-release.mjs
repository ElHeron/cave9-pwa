import { existsSync, mkdirSync, writeFileSync } from 'node:fs';
import { cpus, freemem, platform, release, totalmem, type, version } from 'node:os';
import { relative, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { chromium } from 'playwright';
import { CAPTURE_API, SCHEMA_VERSION, suiteDefinition } from './config.mjs';
import { evaluateFrame, inspectPng } from './image-checks.mjs';
import { parseArgs, writeManifest } from './manifest.mjs';
import { gitProvenance, makeRunId, referenceFingerprint, runtimeFingerprint } from './provenance.mjs';
import { writeReferenceReport } from './reference-report-lib.mjs';
import { assertCurrentRunProvenance, verifyRun } from './verification.mjs';
import { withViteServer } from './vite-server.mjs';

const root = process.cwd();

export function createFreshRunDirectory(runDir) {
  if (existsSync(runDir)) throw new Error(`refusing to overwrite existing visual evidence run: ${runDir}`);
  const frameDir = resolve(runDir, 'frames');
  mkdirSync(frameDir, { recursive: true });
  return frameDir;
}

async function browserMetadata(browser, page) {
  const pageData = await page.evaluate(() => {
    const canvas = window.__cave9?.renderer?.canvas || document.querySelector('canvas');
    let webgl = { available: false, version: null, vendor: null, renderer: null };
    try {
      const gl = canvas?.getContext('webgl2') || canvas?.getContext('webgl');
      if (gl) {
        const debug = gl.getExtension('WEBGL_debug_renderer_info');
        webgl = {
          available: true,
          version: gl.getParameter(gl.VERSION) || null,
          shadingLanguageVersion: gl.getParameter(gl.SHADING_LANGUAGE_VERSION) || null,
          vendor: debug ? gl.getParameter(debug.UNMASKED_VENDOR_WEBGL) : gl.getParameter(gl.VENDOR),
          renderer: debug ? gl.getParameter(debug.UNMASKED_RENDERER_WEBGL) : gl.getParameter(gl.RENDERER),
          contextLost: gl.isContextLost(),
        };
      }
    } catch (error) { webgl.error = String(error); }
    return {
      userAgent: navigator.userAgent,
      language: navigator.language,
      platform: navigator.platform,
      hardwareConcurrency: navigator.hardwareConcurrency ?? null,
      webgl,
    };
  });
  return { engine: 'chromium', version: browser.version(), ...pageData };
}

async function settle(page, frames = 4) {
  for (let i = 0; i < frames; i++) {
    await page.evaluate(() => new Promise((resolvePromise) => requestAnimationFrame(resolvePromise)));
  }
}

async function captureScenario(page, options) {
  return page.evaluate(({ scenario, api }) => {
    const app = window.__cave9;
    const visual = app?.visual;
    if (typeof visual?.loadScenario !== 'function' || typeof visual?.snapshot !== 'function') {
      throw new Error('VisualScenarioV1 API unavailable. Expected window.__cave9.visual.loadScenario and snapshot; legacy capture fallback is forbidden.');
    }
    const loaded = visual.loadScenario(scenario);
    const snapshot = visual.snapshot({ includeImage: false });
    if (snapshot?.version !== 'VisualSnapshotV1' || loaded?.version !== 'VisualSnapshotV1') {
      throw new Error('Visual lab returned an invalid VisualSnapshotV1');
    }
    if (JSON.stringify(loaded.scenario) !== JSON.stringify(snapshot.scenario)) {
      throw new Error('Visual lab load result and frozen snapshot disagree');
    }
    return {
      api,
      normalizedScenario: snapshot.scenario,
      snapshot,
      info: {
        distanceReached: snapshot.distance,
        positioning: snapshot.positioning,
        family: snapshot.family,
        camera: snapshot.camera,
        viewport: snapshot.viewport,
      },
    };
  }, { scenario: options, api: CAPTURE_API });
}

async function runtimeSnapshot(page) {
  return page.evaluate(() => {
    const app = window.__cave9;
    const canvas = app?.renderer?.canvas || document.querySelector('canvas');
    const gl = canvas?.getContext?.('webgl2') || canvas?.getContext?.('webgl');
    const glErrors = [];
    if (gl) {
      for (let i = 0; i < 16; i++) {
        const code = gl.getError();
        if (code === gl.NO_ERROR) break;
        glErrors.push(code);
      }
    }
    const browserErrors = [...(window.__cave9VisualRuntimeErrors || [])];
    window.__cave9VisualRuntimeErrors = [];
    return {
      appState: app?.state ?? null,
      gamePhase: app?.game?.phase ?? null,
      innerWidth: window.innerWidth,
      innerHeight: window.innerHeight,
      devicePixelRatio: window.devicePixelRatio,
      canvasWidth: canvas?.width ?? null,
      canvasHeight: canvas?.height ?? null,
      canvasClientWidth: canvas?.clientWidth ?? null,
      canvasClientHeight: canvas?.clientHeight ?? null,
      webglAvailable: !!gl,
      webglContextLost: gl ? gl.isContextLost() : true,
      glErrors,
      browserErrors,
    };
  });
}

async function canvasPng(page) {
  const dataUrl = await page.evaluate(() => {
    const canvas = window.__cave9?.renderer?.canvas || document.querySelector('canvas');
    if (!canvas) throw new Error('capture canvas is missing');
    return canvas.toDataURL('image/png');
  });
  const match = /^data:image\/png;base64,(.+)$/s.exec(dataUrl);
  if (!match) throw new Error('capture canvas did not return a PNG data URL');
  return Buffer.from(match[1], 'base64');
}

export async function captureFormRelease({ runId: requestedRunId, headed = false, port } = {}) {
  const createdAt = new Date();
  const git = await gitProvenance(root);
  const reference = referenceFingerprint(root);
  const runtime = runtimeFingerprint(root);
  const runId = requestedRunId || makeRunId(createdAt, git);
  if (!/^[a-zA-Z0-9._-]+$/.test(runId)) throw new Error('run id may contain only letters, numbers, dot, underscore, and dash');
  const runDir = resolve(root, 'artifacts/visual-lab', runId);
  const frameDir = createFreshRunDirectory(runDir);
  const suite = suiteDefinition();
  const manifest = {
    schemaVersion: SCHEMA_VERSION,
    kind: 'cave9-visual-evidence-run',
    runId,
    createdAt: createdAt.toISOString(),
    completedAt: null,
    status: 'running',
    source: { git, reference, runtime },
    environment: {
      process: { platform: process.platform, arch: process.arch, node: process.version,
        cwd: root, timezone: Intl.DateTimeFormat().resolvedOptions().timeZone || null },
      operatingSystem: { type: type(), platform: platform(), release: release(), version: version(),
        cpuModel: cpus()[0]?.model || null, logicalCpus: cpus().length,
        totalMemoryBytes: totalmem(), freeMemoryBytesAtStart: freemem() },
      ci: { CI: process.env.CI || null, GITHUB_ACTIONS: process.env.GITHUB_ACTIONS || null },
      browser: null,
    },
    suite,
    frames: [],
    report: null,
    automated: { status: 'pending' },
    manualReview: { status: 'pending', note: 'A human must review reference-report.html before this run can be blessed.' },
    errors: [],
  };
  writeManifest(runDir, manifest);

  const serverLog = [];
  try {
    await withViteServer(async ({ url }) => {
      let browser;
      try {
        browser = await chromium.launch({ headless: !headed });
        const context = await browser.newContext({ viewport: { width: suite.viewport.width,
          height: suite.viewport.height }, deviceScaleFactor: suite.viewport.deviceScaleFactor,
          reducedMotion: 'reduce' });
        // Install before the first document exists so boot-time promise failures
        // and context loss cannot fall through the evidence error window.
        await context.addInitScript(() => {
          window.__cave9VisualRuntimeErrors = [];
          const record = (kind, detail) => window.__cave9VisualRuntimeErrors.push(`${kind}: ${detail}`);
          window.addEventListener('unhandledrejection', (event) =>
            record('unhandledrejection', event.reason?.stack || event.reason || 'unknown rejection'));
          document.addEventListener('webglcontextlost', (event) => {
            event.preventDefault();
            record('webglcontextlost', event.statusMessage || 'context lost');
          }, true);
          document.addEventListener('webglcontextrestored', () =>
            record('webglcontextrestored', 'context restored'), true);
        });
        const page = await context.newPage();
        const runtimeErrors = [];
        page.on('console', (message) => {
          if (message.type() === 'error') runtimeErrors.push(`console: ${message.text()}`);
        });
        page.on('pageerror', (error) => runtimeErrors.push(`pageerror: ${error.message}`));
        const visualUrl = new URL(url);
        visualUrl.searchParams.set('visualLab', '1');
        visualUrl.searchParams.set('capture', '1');
        await page.goto(visualUrl.href, { waitUntil: 'load', timeout: 30000 });
        await page.waitForFunction(() => window.__cave9?.state && window.__cave9.state !== 'boot',
          undefined, { timeout: 30000 });
        await page.waitForFunction(() => window.__cave9?.visual?.snapshot,
          undefined, { timeout: 30000 });
        manifest.environment.browser = await browserMetadata(browser, page);
        if (manifest.environment.browser.webgl?.available !== true
          || manifest.environment.browser.webgl?.contextLost === true) {
          throw new Error('capture browser has no healthy WebGL context');
        }

        for (const scenario of suite.scenarios) {
          const errorStart = runtimeErrors.length;
          const result = await captureScenario(page, scenario.captureOptions);
          await settle(page);
          const file = resolve(frameDir, `${scenario.id}.png`);
          writeFileSync(file, await canvasPng(page));
          const runtime = await runtimeSnapshot(page);
          const image = inspectPng(file, suite.viewport);
          const errors = [
            ...runtimeErrors.slice(errorStart),
            ...(runtime.browserErrors || []),
            ...(runtime.glErrors || []).map((code) => `webgl getError: ${code}`),
            ...(runtime.webglAvailable ? [] : ['webgl unavailable']),
            ...(runtime.webglContextLost ? ['webgl context lost'] : []),
          ];
          const evaluated = evaluateFrame({ scenario, captureInfo: result.info, runtime, image, errors });
          manifest.frames.push({
            id: scenario.id,
            family: scenario.family,
            seed: scenario.seed,
            offset: scenario.offset,
            requestedDepth: scenario.distance,
            captureOptions: scenario.captureOptions,
            captureApi: result.api,
            normalizedScenario: result.normalizedScenario,
            snapshot: result.snapshot,
            captureInfo: result.info,
            runtime,
            runtimeErrors: errors,
            file: relative(runDir, file).replace(/\\/g, '/'),
            image,
            status: evaluated.status,
            checks: evaluated.checks,
          });
          writeManifest(runDir, manifest);
        }
      } finally {
        if (browser) await browser.close().catch(() => {});
      }
    }, { root, port: port ? Number(port) : undefined,
      log: (line) => { if (serverLog.join('').length < 16000) serverLog.push(line); } });

    await assertCurrentRunProvenance(root, manifest, 'generate report for stale run');
    manifest.report = writeReferenceReport({ root, runDir, manifest });
    manifest.completedAt = new Date().toISOString();
    manifest.serverLog = serverLog.join('').slice(-16000);
    writeManifest(runDir, manifest);
    return await verifyRun({ root, runDir });
  } catch (error) {
    manifest.completedAt = new Date().toISOString();
    manifest.status = 'fail';
    manifest.automated = { status: 'fail', checkedAt: manifest.completedAt };
    manifest.errors.push(error?.stack || String(error));
    manifest.serverLog = serverLog.join('').slice(-16000);
    writeManifest(runDir, manifest);
    error.runDir = runDir;
    throw error;
  }
}

if (process.argv[1] && resolve(process.argv[1]) === resolve(fileURLToPath(import.meta.url))) {
  const args = parseArgs(process.argv.slice(2));
  captureFormRelease({ runId: args['run-id'], headed: !!args.headed, port: args.port })
    .then((manifest) => {
      console.log(`visual evidence: ${manifest.status}`);
      console.log(resolve(root, 'artifacts/visual-lab', manifest.runId));
      if (manifest.status === 'fail' || manifest.status === 'stale') process.exitCode = 1;
    })
    .catch((error) => { console.error(error); if (error.runDir) console.error(`partial run: ${error.runDir}`); process.exitCode = 1; });
}
