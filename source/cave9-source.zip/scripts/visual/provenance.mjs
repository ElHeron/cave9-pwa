import { createHash } from 'node:crypto';
import { createReadStream, existsSync, readFileSync, readdirSync, statSync } from 'node:fs';
import { relative, resolve } from 'node:path';
import { spawn } from 'node:child_process';

const ARTIFACT_PREFIX = 'artifacts/visual-lab/';

export const sha256 = (value) => createHash('sha256').update(value).digest('hex');

export function fileSha256(file) {
  return sha256(readFileSync(file));
}

function git(root, args, { binary = false } = {}) {
  return new Promise((resolvePromise, reject) => {
    const child = spawn('git', args, { cwd: root, shell: false, windowsHide: true,
      stdio: ['ignore', 'pipe', 'pipe'] });
    const stdout = [], stderr = [];
    child.stdout.on('data', (chunk) => stdout.push(chunk));
    child.stderr.on('data', (chunk) => stderr.push(chunk));
    child.once('error', reject);
    child.once('close', (code) => {
      if (code !== 0) return reject(new Error(`git ${args[0]} failed: ${Buffer.concat(stderr).toString('utf8').trim()}`));
      const value = Buffer.concat(stdout);
      resolvePromise(binary ? value : value.toString('utf8'));
    });
  });
}

function hashFileInto(hash, root, path) {
  return new Promise((resolvePromise, reject) => {
    hash.update(`untracked\0${path}\0`);
    const stream = createReadStream(resolve(root, path));
    stream.on('data', (chunk) => hash.update(chunk));
    stream.once('error', reject);
    stream.once('end', resolvePromise);
  });
}

export async function gitProvenance(root = process.cwd()) {
  const commit = (await git(root, ['rev-parse', 'HEAD'])).trim();
  const statusRaw = await git(root, ['status', '--porcelain=v1', '-z', '--untracked-files=all'], { binary: true });
  const entries = statusRaw.toString('utf8').split('\0').filter(Boolean);
  const relevantStatus = entries.filter((entry) => {
    const path = entry.slice(3).replace(/\\/g, '/');
    return !path.startsWith(ARTIFACT_PREFIX);
  }).sort();
  const diff = await git(root, ['diff', '--binary', '--no-ext-diff', 'HEAD', '--', '.',
    ':(exclude)artifacts/visual-lab/**'], { binary: true });
  const hash = createHash('sha256');
  hash.update('tracked-diff\0');
  hash.update(diff);
  hash.update('\0status\0');
  hash.update(relevantStatus.join('\0'));

  const untracked = relevantStatus.filter((entry) => entry.startsWith('?? '))
    .map((entry) => entry.slice(3)).filter((path) => existsSync(resolve(root, path))).sort();
  for (const path of untracked) await hashFileInto(hash, root, path);

  return {
    commit,
    shortCommit: commit.slice(0, 12),
    dirty: relevantStatus.length > 0,
    diffFingerprint: hash.digest('hex'),
    status: relevantStatus,
    excludedFromFingerprint: [ARTIFACT_PREFIX],
  };
}

export function referenceFingerprint(root = process.cwd()) {
  const manifestFile = resolve(root, 'docs/reference/manifest.json');
  const metricsFile = resolve(root, 'scripts/lib/frame-metrics.mjs');
  const manifest = JSON.parse(readFileSync(manifestFile, 'utf8'));
  const inputs = [manifestFile, metricsFile,
    ...manifest.frames.map((entry) => resolve(root, 'docs/reference', entry.file))];
  const files = inputs.map((file) => ({
    file: relative(root, file).replace(/\\/g, '/'),
    sha256: fileSha256(file),
  }));
  return { sha256: sha256(JSON.stringify(files)), files };
}

function filesBelow(root, relativeDir, predicate) {
  const start = resolve(root, relativeDir);
  if (!existsSync(start)) return [];
  const out = [];
  const visit = (dir) => {
    for (const name of readdirSync(dir)) {
      const file = resolve(dir, name);
      if (statSync(file).isDirectory()) visit(file);
      else if (predicate(file)) out.push(file);
    }
  };
  visit(start);
  return out.sort();
}

/** Fingerprint the runtime source and shipped visual assets independently of Git metadata. */
export function runtimeFingerprint(root = process.cwd()) {
  const sourceFiles = [...new Set([
    ...filesBelow(root, 'src', (file) => /\.(?:js|mjs|css|html)$/i.test(file)),
    ...filesBelow(root, 'scripts/visual', (file) => /\.mjs$/i.test(file)),
    resolve(root, 'scripts/perf-sim.mjs'),
    resolve(root, 'scripts/perf-scenario-contract.mjs'),
    resolve(root, 'scripts/lib/frame-metrics.mjs'),
    resolve(root, 'index.html'),
    resolve(root, 'vite.config.js'),
    resolve(root, 'package.json'),
    resolve(root, 'package-lock.json'),
    resolve(root, 'pnpm-lock.yaml'),
    resolve(root, 'yarn.lock'),
  ].filter(existsSync))].sort();
  // Every shipped public byte can affect browser initialization, fonts, WebGL
  // resources or the resulting frame. Do not silently omit non-image assets.
  const assetFiles = filesBelow(root, 'public', () => true);
  const group = (files) => {
    const entries = files.map((file) => ({
      file: relative(root, file).replace(/\\/g, '/'),
      bytes: statSync(file).size,
      sha256: fileSha256(file),
    }));
    return { sha256: sha256(JSON.stringify(entries)), files: entries };
  };
  return { source: group(sourceFiles), assets: group(assetFiles) };
}

export function makeRunId(now, provenance) {
  const stamp = now.toISOString().replace(/[-:]/g, '').replace(/\.\d{3}Z$/, 'Z');
  return `${stamp}-${provenance.shortCommit}-${provenance.diffFingerprint.slice(0, 10)}`;
}
