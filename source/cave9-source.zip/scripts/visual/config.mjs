export const SCHEMA_VERSION = 1;
export const SUITE_NAME = 'form-release';
export const VIEWPORT = Object.freeze({ width: 1280, height: 720, deviceScaleFactor: 1 });
export const CAMERA = Object.freeze({ fov: 45, motion: 0 });
export const CAPTURE_API = 'window.__cave9.visual.loadScenario+snapshot';
export const BASE_DEPTH = 9000;
export const OFFSETS = Object.freeze([-64, -32, 0, 32]);

// A single seed makes family-to-family comparisons isolate the forced form.
// `place: true` is deliberate: this suite is visual evidence, not a gameplay or
// autopilot-survival claim.
export const FAMILY_SCENARIOS = Object.freeze([
  { family: 'branching', seed: 2024 },
  { family: 'crystal', seed: 2024 },
  { family: 'coiling', seed: 2024 },
]);

export function formReleaseScenarios() {
  return FAMILY_SCENARIOS.flatMap(({ family, seed }) => OFFSETS.map((offset) => ({
    id: `${family}-${offset < 0 ? `m${Math.abs(offset)}` : `p${offset}`}`,
    family,
    seed,
    offset,
    distance: BASE_DEPTH + offset,
    captureOptions: {
      version: 'VisualScenarioV1',
      name: `form-release-${family}-${offset < 0 ? `m${Math.abs(offset)}` : `p${offset}`}`,
      seed,
      mode: 2,
      distance: BASE_DEPTH + offset,
      steps: 0,
      placement: 'place',
      control: 'autopilot',
      family,
      camera: 'hero',
      orthographicAxis: 'front',
      renderPass: 'beauty',
      orbitDegrees: 0,
      paused: true,
      viewport: { width: VIEWPORT.width, height: VIEWPORT.height, dpr: VIEWPORT.deviceScaleFactor },
      settings: {
        fov: CAMERA.fov,
        motion: CAMERA.motion,
        landmarks: true,
        readability: true,
        rockDetail: true,
        surfaceRelief: true,
        cave: true,
        wireframe: false,
        landmarkMesh: true,
        collisionCapsules: false,
        booleanTube: false,
        playerHull: false,
        frames: false,
        fog: true,
        material: true,
        light: true,
        brightness: 1,
      },
    },
  })));
}

export function suiteDefinition() {
  return {
    name: SUITE_NAME,
    viewport: { ...VIEWPORT },
    camera: { ...CAMERA },
    captureApi: CAPTURE_API,
    baseDepth: BASE_DEPTH,
    offsets: [...OFFSETS],
    families: FAMILY_SCENARIOS.map((entry) => ({ ...entry })),
    scenarios: formReleaseScenarios(),
  };
}
