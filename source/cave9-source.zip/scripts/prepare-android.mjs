import { cp, mkdir, readFile, rm, writeFile } from 'node:fs/promises';
import { execFileSync } from 'node:child_process';
import { dirname, join, relative, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const web = join(root, 'artifacts', 'android', 'web');
// This is a generated directory only. Validate its absolute target before removal.
if (relative(root, web) !== join('artifacts', 'android', 'web')) throw new Error('Unexpected Android web directory');
execFileSync(process.execPath, [join(root, 'node_modules/vite/bin/vite.js'), 'build'], { cwd: root, stdio: 'inherit' });
await rm(web, { recursive: true, force: true });
await mkdir(web, { recursive: true });
await cp(join(root, 'dist'), web, { recursive: true });
await cp(join(root, 'LICENSE'), join(web, 'LICENSE.txt'));
await cp(join(root, 'LICENSE_NOTES.md'), join(web, 'LICENSE_NOTES.txt'));
await cp(join(root, 'licenses'), join(web, 'licenses'), { recursive: true });
for (const [name, path] of [
  ['THREE_MIT.txt', 'three/LICENSE'],
  ['CAPACITOR_MIT.txt', '@capacitor/core/LICENSE'],
  ['CAPACITOR_ANDROID_MIT.txt', '@capacitor/android/LICENSE'],
  ['CAPACITOR_APP_MIT.txt', '@capacitor/app/LICENSE'],
  ['CAPACITOR_CLIPBOARD_MIT.txt', '@capacitor/clipboard/LICENSE'],
]) await cp(join(root, 'node_modules', path), join(web, 'licenses', name));
const { version } = JSON.parse(await readFile(join(root, 'package.json'), 'utf8'));
await writeFile(join(web, 'android-build.json'), JSON.stringify({ appId: 'io.github.elheron.cave9', version, bundled: true }) + '\n');
console.log(`Android assets ready: ${web}`);
