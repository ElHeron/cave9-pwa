// Luminance metrics for screenshot evidence.
//
// Decodes a PNG or JPEG (pure-JS, no native build) and computes the readability
// metrics the Phase 3A goal requires. Every metric is defined here in one place
// so "brighter" / "more readable" claims are always backed by the same maths.
//
// Luminance model: per-pixel relative luminance using Rec.709 coefficients on
// the *displayed* (gamma-encoded sRGB) channel values, normalised to 0..1:
//
//     Y = (0.2126*R + 0.7152*G + 0.0722*B) / 255
//
// We use the displayed value (not linearised) on purpose: the thresholds
// 0.05 / 0.10 in the goal describe what the eye sees on screen, and that is the
// gamma-encoded signal. The same function is applied to every image (before and
// after), so comparisons are apples-to-apples.
//
// Centre region: the central third of the frame on each axis (x in [1/3,2/3],
// y in [1/3,2/3]) — the "tunnel hole" the goal calls out as too dark.
//
// Usage:  node scripts/luminance.mjs <image> [<image> ...]
// Library: import { luminanceMetrics } from './luminance.mjs'

import { readFileSync } from 'node:fs';
import { extname } from 'node:path';
import { pathToFileURL } from 'node:url';
import jpeg from 'jpeg-js';
import { PNG } from 'pngjs';

export const CENTRE_FRACTION = 1 / 3; // central third on each axis

// Decode a PNG/JPEG file to { width, height, data } where data is RGBA bytes.
export function decodeImage(file) {
  const buf = readFileSync(file);
  const ext = extname(file).toLowerCase();
  if (ext === '.png') {
    const png = PNG.sync.read(buf);
    return { width: png.width, height: png.height, data: png.data };
  }
  if (ext === '.jpg' || ext === '.jpeg') {
    const img = jpeg.decode(buf, { useTArray: true, formatAsRGBA: true });
    return { width: img.width, height: img.height, data: img.data };
  }
  throw new Error(`unsupported image type: ${ext}`);
}

// Rec.709 relative luminance of an sRGB pixel, normalised to 0..1.
export function pixelLuminance(r, g, b) {
  return (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255;
}

function percentile(sorted, p) {
  if (sorted.length === 0) return 0;
  const idx = Math.min(sorted.length - 1, Math.max(0, Math.round((p / 100) * (sorted.length - 1))));
  return sorted[idx];
}

function summarise(values) {
  const sorted = Float64Array.from(values).sort();
  let sum = 0;
  let below05 = 0;
  let below10 = 0;
  for (const v of sorted) {
    sum += v;
    if (v < 0.05) below05++;
    if (v < 0.10) below10++;
  }
  const n = sorted.length || 1;
  return {
    count: sorted.length,
    mean: sum / n,
    median: percentile(sorted, 50),
    p5: percentile(sorted, 5),
    p95: percentile(sorted, 95),
    pctBelow05: (below05 / n) * 100,
    pctBelow10: (below10 / n) * 100,
  };
}

// Compute full + centre-region luminance metrics for one decoded image.
export function luminanceMetrics(file) {
  const { width, height, data } = decodeImage(file);
  const all = new Float64Array(width * height);
  const centre = [];

  const cx0 = Math.floor(width * CENTRE_FRACTION);
  const cx1 = Math.ceil(width * (1 - CENTRE_FRACTION));
  const cy0 = Math.floor(height * CENTRE_FRACTION);
  const cy1 = Math.ceil(height * (1 - CENTRE_FRACTION));

  let i = 0;
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const o = (y * width + x) * 4;
      const Y = pixelLuminance(data[o], data[o + 1], data[o + 2]);
      all[i++] = Y;
      if (x >= cx0 && x < cx1 && y >= cy0 && y < cy1) centre.push(Y);
    }
  }

  return {
    file,
    width,
    height,
    full: summarise(all),
    centre: summarise(centre),
    centreBox: { x0: cx0, x1: cx1, y0: cy0, y1: cy1 },
  };
}

function fmt(n) { return n.toFixed(4); }
function pct(n) { return n.toFixed(2) + '%'; }

export function printMetrics(m) {
  console.log(`\n${m.file}  (${m.width}x${m.height})`);
  console.log('  full   mean=%s median=%s p5=%s p95=%s  <0.05=%s  <0.10=%s',
    fmt(m.full.mean), fmt(m.full.median), fmt(m.full.p5), fmt(m.full.p95),
    pct(m.full.pctBelow05), pct(m.full.pctBelow10));
  console.log('  centre mean=%s median=%s p5=%s p95=%s  <0.05=%s  <0.10=%s',
    fmt(m.centre.mean), fmt(m.centre.median), fmt(m.centre.p5), fmt(m.centre.p95),
    pct(m.centre.pctBelow05), pct(m.centre.pctBelow10));
}

// CLI entry
if (import.meta.url === pathToFileURL(process.argv[1]).href) {
  const files = process.argv.slice(2);
  if (files.length === 0) {
    console.error('usage: node scripts/luminance.mjs <image> [<image> ...]');
    process.exit(1);
  }
  const out = [];
  for (const f of files) {
    const m = luminanceMetrics(f);
    printMetrics(m);
    out.push(m);
  }
  // also emit machine-readable JSON on the last line for tooling
  console.log('\nJSON ' + JSON.stringify(out));
}
