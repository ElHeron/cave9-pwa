// Shared seed panel (Phase 3B). Single source of truth for both the seed
// regression test (test/seeds.test.js) and the audit script
// (scripts/audit-seeds.mjs) so "50 seeds" can never drift between them.
//
// The panel mixes round numbers, historically "interesting" values, the daily
// challenge key, and a spread of larger seeds so the fairness check sees a wide
// slice of the generator's behaviour.

import { seedFromString } from '../src/core/RNG.js';

export const SEED_PANEL = [
  // original Phase 2 panel (kept stable for continuity)
  1, 2, 3, 7, 42, 99, 123, 256, 777, 1000, 1337, 2024, 4242, 9999, 12345,
  seedFromString('2026-06-20'), 31337, 55555, 80000, 123456, 654321, 1000000,
  // Phase 3B expansion to 50: more round numbers, primes, dates, big values
  5, 13, 21, 64, 128, 500, 2048, 3000, 5000, 6789, 8191, 13337,
  seedFromString('2026-06-21'), seedFromString('cave9'),
  20260621, 49999, 100003, 271828, 314159, 525600,
  999983, 1234567, 7777777, 19880608, 2000000000,
  17, 360, 4096,
];

// Classify a seed into a difficulty band from its measured metrics. The bands
// are descriptive (for the report), derived purely from data — NOT a claim that
// a seed is "good": an outlier is flagged separately (see auditSeed).
//
// Across the whole panel the *geometry* min clearance converges to the radius
// floor (every seed eventually reaches the deep, tightest tunnel), so the
// discriminating signal is how the deterministic autopilot copes: whether it
// crashes within the sample window and how deep it gets before it does.
//   easy    : autopilot survives the whole window, barely scraping walls
//   normal  : survives the window, or crashes only very deep
//   hard    : autopilot crashes at a moderate depth
//   extreme : autopilot crashes early (tight/curvy early cave)
export function classify(geom, flight) {
  if (!flight.crashed) {
    return flight.nearWallDensity < 0.005 ? 'easy' : 'normal';
  }
  if (flight.depthReached < 1200) return 'extreme';
  if (flight.depthReached < 1800) return 'hard';
  return 'normal';
}

// Sanity-check one seed. Returns { ok, warnings[] }. A warning means the seed
// is suspicious (potentially unfair) and must be documented honestly — it does
// NOT silently pass as "good".
export function auditSeed(geom, flight, thresholds) {
  const w = [];
  if (!geom.allFinite) w.push('non-finite geometry');
  if (geom.minClearance < thresholds.minClearance)
    w.push(`min clearance ${geom.minClearance.toFixed(2)} < ${thresholds.minClearance}`);
  if (geom.minRadius <= thresholds.shipRadius)
    w.push(`tunnel narrower than ship (${geom.minRadius.toFixed(2)})`);
  if (geom.minReactionWindow < thresholds.minReaction)
    w.push(`reaction ${geom.minReactionWindow.toFixed(2)}s < ${thresholds.minReaction}s`);
  if (geom.maxNarrowing > thresholds.maxNarrowing)
    w.push(`narrowing spike ${geom.maxNarrowing.toFixed(2)} > ${thresholds.maxNarrowing}`);
  if (flight.depthReached < thresholds.minSpawnDepth)
    w.push(`autopilot died early at ${flight.depthReached.toFixed(0)}m (spawn risk)`);
  if (flight.falseDeaths > 0)
    w.push(`${flight.falseDeaths} false death(s)`);
  if (flight.graceFrames > 0)
    w.push(`${flight.graceFrames} numeric grace frame(s)`);
  if (flight.maxTrackingError >= thresholds.maxTrackingError)
    w.push(`tracking error ${flight.maxTrackingError.toFixed(3)} >= ${thresholds.maxTrackingError}`);
  if (flight.minTrackingReserve <= thresholds.minTrackingReserve)
    w.push(`route reserve ${flight.minTrackingReserve.toFixed(3)} <= ${thresholds.minTrackingReserve}`);
  if (flight.depthReached < thresholds.minSpeedProofDepth)
    w.push(`post-15-km speed regime not reached (${flight.depthReached.toFixed(0)}m)`);
  if (flight.depthReached >= thresholds.minSpeedProofDepth &&
      flight.difficulty.speedMul < thresholds.minReferenceSpeedMul)
    w.push(`speed multiplier ${flight.difficulty.speedMul.toFixed(3)} < reference ${thresholds.minReferenceSpeedMul}`);
  if (flight.nearWallDensity > thresholds.maxNearWall)
    w.push(`autopilot scraped walls ${(flight.nearWallDensity * 100).toFixed(1)}%`);
  return { ok: w.length === 0, warnings: w };
}
