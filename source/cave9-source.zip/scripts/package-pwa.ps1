# Produce a Cloudflare Pages upload with an offline game and matching GPL source.
[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
$cave9Root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$cave9Output = Join-Path $cave9Root 'artifacts/pwa'
$cave9Run = [Guid]::NewGuid().ToString('N')
$cave9Stage = Join-Path $cave9Output "upload-$cave9Run"
$cave9Source = Join-Path $cave9Output "source-$cave9Run"

Push-Location $cave9Root
try {
    & npm run build
    if ($LASTEXITCODE -ne 0) { throw 'Cave9 production build failed.' }

    New-Item -ItemType Directory -Path $cave9Stage, $cave9Source -Force | Out-Null
    Get-ChildItem -LiteralPath (Join-Path $cave9Root 'dist') | ForEach-Object {
        Copy-Item -LiteralPath $_.FullName -Destination $cave9Stage -Recurse
    }
    Copy-Item -LiteralPath (Join-Path $cave9Root 'LICENSE') -Destination (Join-Path $cave9Stage 'LICENSE.txt')
    Copy-Item -LiteralPath (Join-Path $cave9Root 'LICENSE_NOTES.md') -Destination (Join-Path $cave9Stage 'LICENSE_NOTES.txt')
    Copy-Item -LiteralPath (Join-Path $cave9Root 'licenses') -Destination $cave9Stage -Recurse
    Copy-Item -LiteralPath (Join-Path $cave9Root 'node_modules/three/LICENSE') -Destination (Join-Path $cave9Stage 'licenses/THREE_MIT.txt')

    # The source download is deliberately added after the offline manifest so
    # installing the game does not download a second copy of its source assets.
    & node scripts/build-service-worker.mjs $cave9Stage
    if ($LASTEXITCODE -ne 0) { throw 'Cave9 offline worker generation failed.' }

    $cave9SourceEntries = @(
        'src', 'public', 'scripts', 'test', 'licenses', '_original', 'docs/assets',
        'assets/branding', 'docs/branding',
        'index.html', 'package.json', 'package-lock.json', 'vite.config.js',
        'playwright.config.mjs', 'README.md', 'LICENSE', 'LICENSE_NOTES.md'
    )
    foreach ($cave9Relative in $cave9SourceEntries) {
        $cave9Destination = Join-Path $cave9Source $cave9Relative
        New-Item -ItemType Directory -Path (Split-Path -Parent $cave9Destination) -Force | Out-Null
        Copy-Item -LiteralPath (Join-Path $cave9Root $cave9Relative) -Destination $cave9Destination -Recurse
    }
    New-Item -ItemType Directory -Path (Join-Path $cave9Stage 'source') -Force | Out-Null
    Compress-Archive -Path (Join-Path $cave9Source '*') -DestinationPath (Join-Path $cave9Stage 'source/cave9-source.zip')

    $cave9Archive = Join-Path $cave9Output 'cave9-pwa.zip'
    Compress-Archive -Path (Join-Path $cave9Stage '*') -DestinationPath $cave9Archive -Force
    Write-Output "PWA upload: $cave9Archive"
    Write-Output "Upload directory: $cave9Stage"
} finally {
    Pop-Location
}
