import { cp, mkdir, readdir, readFile, writeFile } from 'node:fs/promises';
import { execFileSync } from 'node:child_process';
import { dirname, join, relative, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { randomUUID, createHash } from 'node:crypto';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const output = join(root, 'artifacts/android');
const staging = join(output, `source-${randomUUID()}`);
await mkdir(staging, { recursive: true });
// An explicit allowlist keeps signing keys, local SDK paths and unrelated private files out of releases.
for (const item of ['src', 'public', 'scripts', 'test', 'licenses', '_original', 'docs/assets',
  'assets/branding', 'docs/branding',
  'LICENSE', 'LICENSE_NOTES.md', 'README.md', 'index.html', 'package.json',
  'package-lock.json', 'vite.config.js', 'playwright.config.mjs', 'capacitor.config.json']) {
  await mkdir(dirname(join(staging, item)), { recursive: true });
  await cp(join(root, item), join(staging, item), { recursive: true });
}
await cp(join(root, 'android'), join(staging, 'android'), {
  recursive: true,
  filter: path => {
    const parts = relative(join(root, 'android'), path).split(/[\\/]/);
    return !parts.some(part => ['build', '.gradle', '.idea', 'local.properties',
      'capacitor-cordova-android-plugins'].includes(part))
      && !/\.p12$|\.jks$|\.keystore$|\.apk$|\.aab$/.test(path)
      && !parts.join('/').startsWith('app/src/main/assets/');
  },
});
const { version } = JSON.parse(await readFile(join(root, 'package.json'), 'utf8'));
const zipName = `cave9-${version}-source.zip`;
const zipPath = join(output, zipName);
// PowerShell arguments are passed through environment variables, never interpolated as executable text.
execFileSync('powershell.exe', ['-NoProfile', '-Command',
  `$ErrorActionPreference = 'Stop'
  Add-Type -AssemblyName System.IO.Compression, System.IO.Compression.FileSystem
  $archiveStream = [IO.File]::Open($env:CAVE9_SOURCE_ZIP, [IO.FileMode]::Create)
  $archive = [IO.Compression.ZipArchive]::new($archiveStream, [IO.Compression.ZipArchiveMode]::Create)
  try {
    Get-ChildItem -LiteralPath $env:CAVE9_SOURCE_STAGING -File -Recurse -Force | ForEach-Object {
      $entryName = $_.FullName.Substring($env:CAVE9_SOURCE_STAGING.Length + 1).Replace('\\', '/')
      [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive, $_.FullName, $entryName, [IO.Compression.CompressionLevel]::Optimal) | Out-Null
    }
  } finally { $archive.Dispose(); $archiveStream.Dispose() }`],
  { stdio: 'inherit', env: { ...process.env, CAVE9_SOURCE_STAGING: staging, CAVE9_SOURCE_ZIP: zipPath } });
const filenames = [`cave9-${version}.apk`, zipName];
const sums = await Promise.all(filenames.map(async name =>
  `${createHash('sha256').update(await readFile(join(output, name))).digest('hex')}  ${name}`));
await writeFile(join(output, 'SHA256SUMS.txt'), sums.join('\n') + '\n');
console.log(`Corresponding Android source: ${zipPath}`);
