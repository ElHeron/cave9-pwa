// Per-frame, headless flight telemetry for numerical analysis. No renderer and
// no screenshots: every row comes from the fixed-step Game path.
import { mkdirSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { Game } from '../src/core/Game.js';
import { computeWarn } from '../src/core/WarnState.js';
import { roomAt } from '../src/core/RoomState.js';
import { pathFrameAt, tubeRadiusAt } from '../src/core/FlightPath.js';
import { styleAt } from '../src/core/Difficulty.js';
import { SEED_PANEL } from './seed-panel.mjs';

const args = process.argv.slice(2);
const arg = (name, fallback) => {
  const i = args.indexOf(name);
  return i >= 0 && args[i + 1] ? Number(args[i + 1]) : fallback;
};
const count = Math.max(1, Math.min(SEED_PANEL.length, arg('--count', 3) | 0));
const maxDepth = Math.max(100, arg('--depth', 10000));
const outIndex = args.indexOf('--out');
const outFile = resolve(outIndex >= 0 && args[outIndex + 1]
  ? args[outIndex + 1] : 'docs/measure/flight-recorder.json');
const round = (v, n = 5) => Number.isFinite(v) ? +v.toFixed(n) : null;

const runs = [];
for (const seed of SEED_PANEL.slice(0, count)) {
  const game = new Game().start({ seed, mode: 2 });
  const frames = [];
  let maxTrackingError = 0, minClearance = Infinity;
  while (game.phase === 'running' && game.player.pos[2] - game.player.start < maxDepth) {
    game.autopilot();
    const crashed = game.step();
    const p = game.player, depth = p.pos[2] - p.start;
    const frame = pathFrameAt(seed, depth);
    const dx = p.pos[0] - frame.center.x, dy = p.pos[1] - frame.center.y;
    const dz = p.pos[2] - frame.center.z;
    const trackingRight = dx * frame.right.x + dy * frame.right.y + dz * frame.right.z;
    const trackingUp = dx * frame.up.x + dy * frame.up.y + dz * frame.up.z;
    const trackingError = Math.hypot(trackingRight, trackingUp);
    const warn = computeWarn(game), room = roomAt(p.pos[2]);
    maxTrackingError = Math.max(maxTrackingError, trackingError);
    if (p.dist > 0) minClearance = Math.min(minClearance, p.dist);
    frames.push({
      frame: frames.length, t: round(game.time), depth: round(depth),
      pos: p.pos.map((v) => round(v)), vel: p.vel.map((v) => round(v)),
      thrusters: { left: p.lefton, right: p.righton },
      clearance: round(p.dist), leftClear: round(p.leftClear), rightClear: round(p.rightClear),
      warn: { reactive: round(warn.reactive), predictive: round(warn.predictive), final: round(warn.final), pan: round(warn.pan) },
      probes: p.probePos.map((pos, i) => ({ pos: pos.map((v) => round(v)), inside: p.probeInside[i] })),
      graced: !!p.graced,
      room: { index: room.index, distance: round(room.distance), t: round(room.t) },
      style: round(styleAt(depth)), tubeRadius: round(tubeRadiusAt(depth, seed)),
      tracking: { right: round(trackingRight), up: round(trackingUp), radial: round(trackingError) },
      trackingError: round(trackingError), landmarkPieces: game.landmarkCompositions.reduce((n, c) => n + c.pieces.length, 0),
      crashed,
    });
    if (crashed) break;
  }
  runs.push({ seed, summary: {
    frames: frames.length, depth: round(game.player.pos[2] - game.player.start),
    crashed: game.phase === 'dead', maxTrackingError: round(maxTrackingError),
    minClearance: minClearance === Infinity ? null : round(minClearance),
    graceFrames: frames.filter((f) => f.graced).length,
  }, frames });
}

const report = {
  generatedAt: new Date().toISOString(), fixedStepHz: 60, maxDepth, seedCount: count,
  fields: ['thrusters', 'clearance', 'warn', 'probes', 'room', 'style', 'tubeRadius', 'tracking', 'landmarkPieces'],
  runs,
};
mkdirSync(resolve(outFile, '..'), { recursive: true });
writeFileSync(outFile, JSON.stringify(report) + '\n');
console.log(JSON.stringify({ outFile, runs: runs.map((r) => r.summary) }, null, 2));
if (runs.some((r) => r.summary.crashed || r.summary.graceFrames > 0 || r.summary.depth < maxDepth)) process.exitCode = 1;
