// npm run ref:profile — turn the reference frames into a measurable target.
//
// Reads docs/reference/*.png (labelled by docs/reference/manifest.json), computes
// the D1-D6 descriptors for each, and writes the ENVELOPE — the min/max each axis
// spans across the references — to docs/measure/reference-target.json.
//
// That envelope is what `npm run style` then measures captures against. Until it
// existed, the reference was prose and every art change was judged by eye.

import { readFileSync, writeFileSync, mkdirSync, existsSync } from 'node:fs';
import { resolve, join } from 'node:path';
import { describe, envelope, referenceEnvelope, AXES, axisValue } from './lib/frame-metrics.mjs';

const REF_DIR = resolve(process.cwd(), 'docs/reference');
const OUT = resolve(process.cwd(), 'docs/measure');

const manifestPath = join(REF_DIR, 'manifest.json');
if (!existsSync(manifestPath)) {
  console.error(`No reference manifest at ${manifestPath}`);
  process.exit(1);
}
const manifest = JSON.parse(readFileSync(manifestPath, 'utf8'));

const described = [];
for (const entry of manifest.frames) {
  const file = join(REF_DIR, entry.file);
  if (!existsSync(file)) {
    console.error(`  ! missing ${entry.file} (listed in the manifest)`);
    continue;
  }
  const d = describe(file);
  d.families = entry.families;
  d.roles = entry.roles || [];
  d.metricEnvelope = entry.metricEnvelope !== false;
  d.name = entry.file;
  described.push(d);
}

if (!described.length) {
  console.error('No reference frames could be read.');
  process.exit(1);
}

const pad = (s, n) => String(s).padEnd(n);
const num = (v, n = 3) => (Number.isFinite(v) ? v.toFixed(n) : '—');

console.log('\nReference frames\n');
console.log(pad('frame', 48), AXES.map((a) => pad(a.replace(/^D\d_/, ''), 14)).join(''));
for (const d of described) {
  console.log(pad(`${d.metricEnvelope ? '*' : '·'} ${d.name.replace('.png', '')}`, 48),
    AXES.map((a) => pad(num(axisValue(d, a), a === 'D6_blobs' ? 0 : 3), 14)).join(''));
}

const targetFrames = described.filter((d) => d.metricEnvelope);
const supplementalFrames = described.filter((d) => !d.metricEnvelope);
const env = referenceEnvelope(described);
console.log('\nTarget envelope (min – max across the references)\n');
for (const axis of AXES) {
  const e = env[axis];
  const dec = axis === 'D6_blobs' ? 0 : 3;
  console.log(`  ${pad(axis, 22)} ${num(e.min, dec)} – ${num(e.max, dec)}   (mean ${num(e.mean, dec)})`);
}

mkdirSync(OUT, { recursive: true });
const outFile = join(OUT, 'reference-target.json');
writeFileSync(outFile, JSON.stringify({
  capturedAt: new Date().toISOString(),
  source: 'docs/reference',
  frames: described.map((d) => ({
    name: d.name, families: d.families, size: d.size,
    roles: d.roles, metricEnvelope: d.metricEnvelope,
    ...Object.fromEntries(AXES.map((a) => [a, axisValue(d, a)])),
    D2_profile: d.D2_profile,
    compositionModel: d.compositionModel,
    D7_centralOpening: d.D7_centralOpening,
    D8_angularSilhouette: d.D8_angularSilhouette,
    D9_quadrantMass: d.D9_quadrantMass,
    D10_dominantForms: d.D10_dominantForms,
    D11_tipDistance: d.D11_tipDistance,
    D12_projectedOcclusion: d.D12_projectedOcclusion,
  })),
  envelope: env,
  supplementalEnvelope: supplementalFrames.length ? envelope(supplementalFrames) : null,
  commonLanguage: manifest.commonLanguage,
}, null, 2));

console.log(`\n› wrote ${outFile}\n`);
