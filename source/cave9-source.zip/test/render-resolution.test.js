import test from 'node:test';
import assert from 'node:assert/strict';
import { drawingBufferSize, effectiveRenderPixelRatio } from '../src/render/renderResolution.js';

test('High keeps the original DPR cap while Performance reduces internal pixels at DPR 1', () => {
  assert.equal(effectiveRenderPixelRatio(1, 2), 1);
  assert.equal(effectiveRenderPixelRatio(2, 2), 2);
  assert.equal(effectiveRenderPixelRatio(3, 2), 2);
  assert.equal(effectiveRenderPixelRatio(1, 1), 0.75);
  assert.equal(effectiveRenderPixelRatio(2, 1), 0.75);
  assert.deepEqual(drawingBufferSize(1920, 1080, 0.75), [1440, 810]);
  assert.deepEqual(drawingBufferSize(801, 601, 0.75), [600, 450]);
});
