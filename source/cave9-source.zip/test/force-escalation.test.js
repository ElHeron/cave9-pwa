import { test } from 'node:test';
import assert from 'node:assert/strict';

import { Ship } from '../src/core/Ship.js';
import { GRAVITY, SHIP_RADIUS } from '../src/core/constants.js';
import { speedMul, SPEED_REFERENCE_DEPTH } from '../src/core/Difficulty.js';

function oneSecond(scale, left, right) {
  const ship = new Ship(SHIP_RADIUS);
  ship.forceScale = scale;
  ship.lefton = left;
  ship.righton = right;
  ship.move(1);
  return ship;
}

test('gravity and vertical thrust share the speed staircase multiplier', () => {
  for (const depth of [0, 9000, SPEED_REFERENCE_DEPTH, 30000]) {
    const scale = speedMul(depth);
    const falling = oneSecond(scale, false, false);
    const hovering = oneSecond(scale, true, false);
    const climbing = oneSecond(scale, true, true);
    assert.ok(Math.abs(falling.vel[1] + GRAVITY * scale) < 1e-9,
      `fall acceleration must scale at ${depth} m`);
    assert.ok(Math.abs(hovering.vel[1]) < 1e-9,
      `one thruster must still hover at ${depth} m`);
    assert.ok(Math.abs(climbing.vel[1] - GRAVITY * scale) < 1e-9,
      `climb acceleration must scale at ${depth} m`);
  }
});

test('later stairs make both falling and climbing strictly stronger', () => {
  const early = speedMul(9000);
  const reference = speedMul(SPEED_REFERENCE_DEPTH);
  const deep = speedMul(30000);
  assert.ok(early < reference && reference < deep);
  assert.ok(Math.abs(oneSecond(deep, false, false).vel[1]) >
    Math.abs(oneSecond(reference, false, false).vel[1]));
  assert.ok(oneSecond(deep, true, true).vel[1] > oneSecond(reference, true, true).vel[1]);
});
