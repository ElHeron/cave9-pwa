// Input direction logic. Run with: npm test
// resolveThrust / touchMapping are pure, so the "invert changes direction",
// "one-button collapses" and "mirror layout swaps zones" rules are proven
// without any DOM or window.
import { test } from 'node:test';
import assert from 'node:assert/strict';

import { InputAdapter, resolveThrust, touchMapping } from '../src/platform/InputAdapter.js';
import { ONE_BUTTON, TWO_BUTTONS } from '../src/core/constants.js';

test('two-button mode passes left/right through unchanged', () => {
  assert.deepEqual(resolveThrust({ l: true, r: false, mode: TWO_BUTTONS }), { left: true, right: false });
  assert.deepEqual(resolveThrust({ l: false, r: true, mode: TWO_BUTTONS }), { left: false, right: true });
});

test('up plus one side produces a deterministic diagonal duty cycle', () => {
  assert.deepEqual(
    resolveThrust({ l: false, r: true, up: true, mode: TWO_BUTTONS, diagonalPhase: 0 }),
    { left: true, right: true },
  );
  assert.deepEqual(
    resolveThrust({ l: false, r: true, up: true, mode: TWO_BUTTONS, diagonalPhase: 1 }),
    { left: false, right: true },
  );
  assert.deepEqual(
    resolveThrust({ l: true, r: false, up: true, mode: TWO_BUTTONS, diagonalPhase: 1 }),
    { left: true, right: false },
  );
});

test('left plus right remains pure upward thrust', () => {
  for (const diagonalPhase of [0, 1]) {
    assert.deepEqual(
      resolveThrust({ l: true, r: true, up: false, mode: TWO_BUTTONS, diagonalPhase }),
      { left: true, right: true },
    );
  }
});

test('invertX swaps left and right thrusters', () => {
  assert.deepEqual(
    resolveThrust({ l: true, r: false, mode: TWO_BUTTONS, invertX: true }),
    { left: false, right: true },
  );
  assert.deepEqual(
    resolveThrust({ l: false, r: true, mode: TWO_BUTTONS, invertX: true }),
    { left: true, right: false },
  );
});

test('one-button mode collapses any input to both thrusters', () => {
  assert.deepEqual(resolveThrust({ l: true, r: false, mode: ONE_BUTTON }), { left: true, right: true });
  assert.deepEqual(resolveThrust({ l: false, r: false, mode: ONE_BUTTON }), { left: false, right: false });
});

test('touch layout: split keeps zones, mirror swaps them', () => {
  assert.deepEqual(touchMapping('split'), { left: 'R', right: 'L' });
  assert.deepEqual(touchMapping('mirror'), { left: 'L', right: 'R' });
});

// Integration over the adapter itself, with a minimal window stub so the
// constructor's keyboard binding does not throw.
test('InputAdapter.update applies sensitivity-independent direction + invert', async () => {
  globalThis.window = {
    addEventListener() {},
    removeEventListener() {},
  };
  const a = new InputAdapter();
  a.setEnabled(true);
  a.setMode(TWO_BUTTONS);
  a._keys.add('ArrowLeft'); // screen-left uses the right actuator in the +Z camera
  a.update();
  assert.equal(a.left, false);
  assert.equal(a.right, true);

  a.setInvertX(true);
  a.update();
  assert.equal(a.left, true, 'invert should reverse the corrected screen direction');
  assert.equal(a.right, false);

  delete globalThis.window;
});

function eventWindow() {
  const listeners = new Map();
  return {
    addEventListener(type, fn) { listeners.set(type, fn); },
    removeEventListener() {},
    fire(type, event = {}) { listeners.get(type)?.(event); },
  };
}

function withInputEnvironment(run) {
  const previousWindow = globalThis.window;
  const previousNavigator = globalThis.navigator;
  const fakeWindow = eventWindow();
  globalThis.window = fakeWindow;
  Object.defineProperty(globalThis, 'navigator', {
    configurable: true, value: { getGamepads: () => [] },
  });
  try { run(fakeWindow); } finally {
    if (previousWindow === undefined) delete globalThis.window;
    else globalThis.window = previousWindow;
    if (previousNavigator === undefined) delete globalThis.navigator;
    else Object.defineProperty(globalThis, 'navigator', { configurable: true, value: previousNavigator });
  }
}

test('a complete key tap between samples survives for exactly one fixed step', () => {
  withInputEnvironment((fakeWindow) => {
    const a = new InputAdapter();
    a.setEnabled(true);
    a.setMode(TWO_BUTTONS);
    fakeWindow.fire('keydown', { code: 'ArrowLeft', repeat: false });
    fakeWindow.fire('keyup', { code: 'ArrowLeft' });
    a.update();
    assert.deepEqual(a.sampleStep(), { left: false, right: true }, 'tap reached the first tick');
    assert.deepEqual(a.sampleStep(), { left: false, right: false }, 'tap was not replayed on catch-up ticks');
  });
});

test('a held key remains active across every fixed step', () => {
  withInputEnvironment((fakeWindow) => {
    const a = new InputAdapter();
    a.setEnabled(true);
    fakeWindow.fire('keydown', { code: 'ArrowRight', repeat: false });
    a.update();
    assert.deepEqual(a.sampleStep(), { left: true, right: false });
    assert.deepEqual(a.sampleStep(), { left: true, right: false });
    fakeWindow.fire('keyup', { code: 'ArrowRight' });
    a.update();
    assert.deepEqual(a.sampleStep(), { left: false, right: false });
  });
});

test('held up plus screen-right is accepted together and alternates both/side per physics step', () => {
  withInputEnvironment((fakeWindow) => {
    const a = new InputAdapter();
    a.setEnabled(true);
    a.setMode(TWO_BUTTONS);
    fakeWindow.fire('keydown', { code: 'ArrowUp', repeat: false, preventDefault() {} });
    fakeWindow.fire('keydown', { code: 'ArrowRight', repeat: false, preventDefault() {} });
    a.update();
    assert.deepEqual(a.sampleStep(), { left: true, right: true });
    assert.deepEqual(a.sampleStep(), { left: true, right: false });
    assert.deepEqual(a.sampleStep(), { left: true, right: true });
    assert.deepEqual(a.sampleStep(), { left: true, right: false });
  });
});

function touchZone() {
  const listeners = new Map();
  return {
    addEventListener(type, fn) {
      if (!listeners.has(type)) listeners.set(type, new Set());
      listeners.get(type).add(fn);
    },
    removeEventListener(type, fn) { listeners.get(type)?.delete(fn); },
    count(type) { return listeners.get(type)?.size ?? 0; },
    fire(type) {
      for (const fn of listeners.get(type) ?? []) fn({ preventDefault() {} });
    },
  };
}

test('repeated touch layout changes, rebinds and reset keep one live mapping', () => {
  withInputEnvironment(() => {
    const a = new InputAdapter();
    const left = touchZone();
    const right = touchZone();
    a.setEnabled(true);
    a.bindTouch(left, right);
    for (const hand of ['mirror', 'split', 'mirror', 'split']) {
      a.setTouchHand(hand);
      a.rebindTouch(left, right);
      assert.equal(left.count('mousedown'), 1);
      assert.equal(right.count('touchstart'), 1);
      left.fire('mousedown');
      a.update();
      assert.deepEqual(a.sampleStep(), hand === 'mirror'
        ? { left: true, right: false }
        : { left: false, right: true });
      left.fire('mouseup');
      a.update();
      assert.deepEqual(a.sampleStep(), { left: false, right: false });
    }
    a.setTouchHand('mirror');
    a.setTouchHand('split'); // settings reset
    left.fire('touchstart');
    a.update();
    assert.deepEqual(a.sampleStep(), { left: false, right: true });
    left.fire('touchend');
  });
});

test('gamepad Start pauses, releases its latch while paused, then resumes once', () => {
  withInputEnvironment(() => {
    let pressed = false;
    let actions = 0;
    Object.defineProperty(globalThis, 'navigator', {
      configurable: true,
      value: { getGamepads: () => [{ axes: [0], buttons: Array.from({ length: 10 }, (_, i) => ({ pressed: i === 9 && pressed })) }] },
    });
    const a = new InputAdapter({ onPause: () => { actions++; a.setEnabled(!a.enabled); } });
    a.setEnabled(true);
    pressed = true; a.update(); a.update();
    assert.equal(actions, 1);
    assert.equal(a.enabled, false);
    pressed = false; a.update();
    pressed = true; a.update(); a.update();
    assert.equal(actions, 2);
    assert.equal(a.enabled, true);
  });
});

test('gamepad A confirms once in a menu while flight control is disabled', () => {
  withInputEnvironment(() => {
    let pressed = false;
    let confirms = 0;
    Object.defineProperty(globalThis, 'navigator', {
      configurable: true,
      value: { getGamepads: () => [{ axes: [0], buttons: [{ pressed }] }] },
    });
    const a = new InputAdapter({ onConfirm: () => confirms++ });
    pressed = true; a.update(); a.update();
    assert.equal(confirms, 1);
    pressed = false; a.update();
    pressed = true; a.update();
    assert.equal(confirms, 2);
  });
});

test('Enter activates global confirm only when focus is outside a control', () => {
  withInputEnvironment((fakeWindow) => {
    let confirms = 0;
    new InputAdapter({ onConfirm: () => confirms++ });
    fakeWindow.fire('keydown', { code: 'Enter', repeat: false, target: { tagName: 'BUTTON' } });
    fakeWindow.fire('keydown', { code: 'Enter', repeat: false, target: { tagName: 'INPUT' } });
    fakeWindow.fire('keydown', { code: 'Enter', repeat: false, target: { tagName: 'DIV' } });
    assert.equal(confirms, 1);
  });
});
