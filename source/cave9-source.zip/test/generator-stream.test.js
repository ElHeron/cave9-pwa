// The deterministic corridor run, pinned to literal fingerprints.
//
// Every other determinism test compares two runs of the SAME build, so both
// sides move together when a change shifts the RNG stream by one draw — the kind
// of change that silently makes every existing seed generate a different cave.
// These fingerprints are literals: they only match if the stream is unchanged
// since they were recorded.
//
// This first pin includes the ship state, so a physics/control change moves it
// even when CaveStream's RNG is untouched. The room-only fingerprint below is
// the independent generator oracle. Re-record either only for an authorised
// generator, route, physics or controller change.
//
// Run with: npm test

import { test } from 'node:test';
import assert from 'node:assert/strict';

import { Game } from '../src/core/Game.js';
import { ROOM_LEN, ROOM_START, SECTOR_COUNT, SEGMENT_COUNT, SEGMENT_LEN } from '../src/core/constants.js';
import { coilingAxialStrengthAtDepth, coilingContractForRoom } from '../src/core/CoilingShell.js';
import { bracketingRingIndices, nearestRingIndex } from '../src/core/SurfaceQuery.js';
import {
  expectedGeneratorFingerprintReport, generatorFingerprintReport,
} from '../src/core/GeneratorFingerprint.js';

// Fold the live cave buffer + the ship's final position into one 32-bit hash.
// Exact integer arithmetic over float32 bit patterns — no accumulated float
// drift, so the value is stable across engines.
const f32 = new Float32Array(1);
const u32 = new Uint32Array(f32.buffer);

function fingerprint(seed, steps = 3000) {
  const g = new Game();
  g.start({ mode: 2, seed });
  for (let s = 0; s < steps; s++) {
    g.autopilot();
    if (g.step()) break;
  }
  let h = 2166136261 >>> 0; // FNV-1a offset basis
  const fold = (c) => { f32[0] = c; h = Math.imul(h ^ u32[0], 16777619) >>> 0; };
  for (const ring of g.cave.segs) for (const v of ring) for (const c of v) fold(c);
  for (const c of g.player.pos) fold(c);
  return { hash: h, writeHead: g.cave.i, score: g.scoreValue() };
}

// The ordinary 3000-step pin ends just before the first room enters the live
// buffer.  This second fingerprint deliberately flies far enough to hold the
// complete 280 m first-room interval, then folds only those depth-sorted rings.
// It therefore pins the authorised long-room shoulders/core, route frames,
// organic shell and real three-start coil instead of another corridor sample.
function roomFingerprint(seed) {
  const g = new Game();
  g.start({ mode: 2, seed });
  // Generate the exact end plane. A 144 × 2 m circular buffer then retains the
  // complete inclusive 2000–2280 m room interval (141 rings) at once.
  g.cave.generateThrough(ROOM_START + ROOM_LEN);

  let h = 2166136261 >>> 0;
  const fold = (c) => { f32[0] = c; h = Math.imul(h ^ u32[0], 16777619) >>> 0; };
  const rings = g.cave.centers
    .map((center, index) => ({ center, index }))
    .filter(({ center }) => center[2] >= ROOM_START && center[2] <= ROOM_START + ROOM_LEN)
    .sort((a, b) => a.center[2] - b.center[2]);

  for (const { center, index } of rings) {
    for (const c of center) fold(c);
    fold(g.cave.innerRadii[index]);
    for (const vertex of g.cave.segs[index]) for (const c of vertex) fold(c);
  }

  return {
    hash: h,
    ringCount: rings.length,
    firstZ: rings[0]?.center[2] ?? null,
    lastZ: rings.at(-1)?.center[2] ?? null,
  };
}

function orderedRings(cave) {
  return cave.centers.map((center, index) => ({ depth: center[2], index }))
    .filter(({ depth }) => Number.isFinite(depth))
    .sort((a, b) => a.depth - b.depth);
}

function legacyNearest(cave, z) {
  let best = -1, gap = Infinity;
  for (let i = 0; i < cave.centers.length; i++) {
    const cz = cave.centers[i][2];
    const d = Math.abs(cz - z);
    if (Number.isFinite(cz) && d < gap) { gap = d; best = i; }
  }
  return best;
}

function legacyBracket(cave, z) {
  let before = -1, after = -1, beforeZ = -Infinity, afterZ = Infinity;
  for (let i = 0; i < cave.centers.length; i++) {
    const cz = cave.centers[i][2];
    if (!Number.isFinite(cz)) continue;
    if (cz <= z && cz > beforeZ) { beforeZ = cz; before = i; }
    if (cz >= z && cz < afterZ) { afterZ = cz; after = i; }
  }
  const nearest = legacyNearest(cave, z);
  return [before < 0 ? nearest : before, after < 0 ? nearest : after];
}

function assertTwoMetreLattice(cave, label) {
  const rings = orderedRings(cave);
  assert.equal(rings.length, cave.count, `${label}: every counted ring has a centre`);
  for (let i = 0; i < rings.length; i++) {
    assert.equal(rings[i].depth % SEGMENT_LEN, 0, `${label}: ${rings[i].depth}m is off lattice`);
    assert.equal(cave.segs[rings[i].index].length, SECTOR_COUNT, `${label}: sector count changed`);
    if (i) assert.equal(rings[i].depth - rings[i - 1].depth, SEGMENT_LEN,
      `${label}: ring gap changed at ${rings[i].depth}m`);
  }
  return rings;
}

test('prime emits the complete initial buffer on the exact two metre lattice', () => {
  const g = new Game().start({ mode: 2, seed: 2024 });
  const rings = assertTwoMetreLattice(g.cave, 'prime');
  assert.equal(rings.length, SEGMENT_COUNT);
  assert.equal(rings[0].depth, 0);
  assert.equal(rings.at(-1).depth, (SEGMENT_COUNT - 1) * SEGMENT_LEN);
});

test('the prime-to-runtime transition and distant generation never change cadence', () => {
  const cave = new Game().start({ mode: 2, seed: 2024 }).cave;
  cave.generateThrough(600);
  let rings = assertTwoMetreLattice(cave, 'prime to runtime');
  assert.equal(rings.at(-1).depth, 600);
  cave.generateThrough(20_001);
  rings = assertTwoMetreLattice(cave, 'distant runtime');
  assert.equal(rings.at(-1).depth, 20_002);
});

test('constant-time ring lookup is exactly equivalent to the legacy scans', () => {
  for (const seed of [1, 42, 4096, 424242]) {
    const cave = new Game().start({ mode: 2, seed }).cave;
    cave.ensureCapacityForDistance(900);
    cave.fill();
    cave.generateThrough(5000);
    const rings = orderedRings(cave);
    const from = rings[0].depth - 5;
    const to = rings.at(-1).depth + 5;
    // Integer and half-metre probes include exact ring planes, midpoint ties,
    // both out-of-range clamps, and the circular-buffer wrap seam.
    for (let z = from; z <= to; z += 0.5) {
      assert.equal(nearestRingIndex(cave, z), legacyNearest(cave, z), `nearest seed ${seed} z=${z}`);
      assert.deepEqual(bracketingRingIndices(cave, z), legacyBracket(cave, z),
        `bracket seed ${seed} z=${z}`);
    }
  }
});

test('each emitted ring retains the exact authoritative Coiling crest strength', () => {
  const seed = 2024;
  const cave = new Game().start({ mode: 2, seed, family: 'coiling' }).cave;
  cave.generateThrough(2280);
  const contract = coilingContractForRoom(seed, 2, 'coiling');
  let active = 0, crest = 0;
  for (const { depth, index } of orderedRings(cave)) {
    const expected = coilingAxialStrengthAtDepth(depth, contract);
    assert.equal(cave.coilingStrengths[index], expected, `strength drifted at ${depth}m`);
    if (expected > 0) active++;
    crest = Math.max(crest, expected);
  }
  assert.ok(active >= 80, 'the complete 160–200m shell span carries ring metadata');
  assert.ok(crest >= 7.6, 'the retained range includes sustained axial ridge relief');

  const plain = new Game().start({ mode: 2, seed, family: 'off' }).cave;
  plain.generateThrough(2280);
  assert.ok(plain.coilingStrengths.every((value) => value === 0),
    'ordinary and family-off rings do not receive C3 highlights');
});

test('ring RNG is depth-stable across preallocated prime and runtime generation', () => {
  const seed = 4096;
  const primed = new Game().start({ mode: 2, seed }).cave;
  primed.ensureCapacityForDistance(2500);
  // Re-prime after growing to exercise the prime path across the distant room.
  primed.reset(seed);
  primed.ensureCapacityForDistance(2500);
  primed.prime();

  const runtime = new Game().start({ mode: 2, seed }).cave;
  runtime.generateThrough(2200);
  const byDepth = (cave) => new Map(orderedRings(cave).map(({ depth, index }) => [depth, cave.segs[index]]));
  const a = byDepth(primed), b = byDepth(runtime);
  for (let depth = 2000; depth <= 2200; depth += SEGMENT_LEN) {
    assert.deepEqual(b.get(depth), a.get(depth), `seeded wall differs by generation phase at ${depth}m`);
  }
});

// [seed, cave+position hash, ring-buffer write head, score] after 3000 steps of
// the deterministic autopilot. Deliberately re-recorded 2026-08-09 for the
// authorised depth-stable speed plateaus. The exact 2 m route-first ring
// lattice is unchanged; the slower first plateau simply reaches a different
// deterministic depth and write head after the same 3000 physics steps.
const PINNED = [
  [1, 1000550680, 43, 1699],
  [42, 4129849094, 43, 1699],
  [4096, 901656642, 43, 1699],
  [424242, 1312335657, 43, 1699],
  [555, 4222977386, 43, 1699],
];

// [seed, hash] for every generated ring whose centre lies in [2000, 2280].
// Deliberately re-recorded 2026-08-08 with the authorised route-first 220 m
// room core and two 30 m shoulders. Seeds 1 and 42 use C3 and were deliberately
// re-recorded after the V04 original-image acceptance of its continuous crest,
// co-moving 32-sector grid and quiet shoulder. The same submitted wall remains
// the collision authority. All corridor and non-C3 room pins stay unchanged.
const PINNED_FIRST_ROOM = [
  [1, 3607373194],
  [42, 3134901291],
  [4096, 2409672045],
  [424242, 726037667],
  [555, 2543800698],
];

for (const [seed, hash, writeHead, score] of PINNED) {
  test(`seed ${seed}: the generated cave is unchanged`, () => {
    const fp = fingerprint(seed);
    assert.equal(fp.hash, hash, 'the corridor run baseline moved');
    assert.equal(fp.writeHead, writeHead, 'a different number of rings was carved');
    assert.equal(fp.score, score);
  });
}

test('the fingerprint actually discriminates between seeds', () => {
  const hashes = new Set(PINNED.map(([s]) => fingerprint(s).hash));
  assert.equal(hashes.size, PINNED.length, 'a fingerprint that collides proves nothing');
});

test('the fingerprint is stable across instances', () => {
  assert.deepEqual(fingerprint(4096), fingerprint(4096));
});

for (const [seed, hash] of PINNED_FIRST_ROOM) {
  test(`seed ${seed}: the complete first-room shell is unchanged`, () => {
    const fp = roomFingerprint(seed);
    assert.equal(fp.hash, hash, 'the route/room/coil baseline moved');
    assert.equal(fp.ringCount, ROOM_LEN / SEGMENT_LEN + 1,
      'the pinned 280 m room interval changed density');
    assert.equal(fp.firstZ, ROOM_START, `room starts at the wrong ring ${fp.firstZ}`);
    assert.equal(fp.lastZ, ROOM_START + ROOM_LEN, `room ends at the wrong ring ${fp.lastZ}`);
  });
}

test('the first-room fingerprint is stable and seed-discriminating', () => {
  assert.deepEqual(roomFingerprint(4096), roomFingerprint(4096));
  const hashes = new Set(PINNED_FIRST_ROOM.map(([seed]) => roomFingerprint(seed).hash));
  assert.equal(hashes.size, PINNED_FIRST_ROOM.length);
});

test('the cross-runtime fingerprint API matches the literal generator oracle', () => {
  assert.deepEqual(generatorFingerprintReport(), expectedGeneratorFingerprintReport());
});
