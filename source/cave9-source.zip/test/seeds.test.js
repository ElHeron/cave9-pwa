// Boolean-tube release oracle: every shared seed has finite geometry and the
// route-tracking controller physically reaches 10 km through the real Game.step
// and collision path.
import { test } from 'node:test';
import assert from 'node:assert/strict';

import { caveGeometryMetrics, flightMetrics } from '../src/core/CaveMetrics.js';
import { SHIP_RADIUS } from '../src/core/constants.js';
import { SEED_PANEL as SEEDS } from '../scripts/seed-panel.mjs';

test(`seed panel has ${SEEDS.length} unique seeds`, () => {
  assert.equal(SEEDS.length, 50);
  assert.equal(new Set(SEEDS).size, SEEDS.length);
});

test('all 50 seeds keep the boolean tube finite through 10 km', () => {
  for (const seed of SEEDS) {
    const m = caveGeometryMetrics(seed, { maxDepth: 10000 });
    assert.ok(m.allFinite, `seed ${seed}: non-finite geometry`);
    assert.ok(m.samples > 1000, `seed ${seed}: only ${m.samples} rings`);
    assert.ok(m.minClearance >= 2 * SHIP_RADIUS,
      `seed ${seed}: clearance ${m.minClearance.toFixed(2)} < 2R`);
    assert.ok(m.minReactionWindow >= 3, `seed ${seed}: reaction ${m.minReactionWindow.toFixed(2)}s`);
    assert.ok(m.maxNarrowing <= 8, `seed ${seed}: narrowing ${m.maxNarrowing.toFixed(2)}`);
  }
});

test('route autopilot reaches 10 km on all 50 seeds', () => {
  for (const seed of SEEDS) {
    const f = flightMetrics(seed, { maxSteps: 25000 });
    assert.equal(f.crashed, false, `seed ${seed}: crashed at ${f.depthReached.toFixed(0)}m`);
    assert.ok(f.depthReached >= 10000, `seed ${seed}: reached only ${f.depthReached.toFixed(0)}m`);
    assert.equal(f.falseDeaths, 0, `seed ${seed}: false death`);
    assert.equal(f.graceFrames, 0, `seed ${seed}: numeric grace frame`);
    assert.ok(f.maxTrackingError < SHIP_RADIUS,
      `seed ${seed}: tracking error ${f.maxTrackingError.toFixed(3)} >= one ship radius`);
    assert.ok(f.minTrackingReserve > 0,
      `seed ${seed}: route reserve ${f.minTrackingReserve.toFixed(3)} exhausted`);
    assert.ok(f.depthReached >= 15000, `seed ${seed}: post-15km regime not covered`);
    assert.ok(f.difficulty.speedMul >= 2.2, `seed ${seed}: 15km reference speed not reached`);
  }
});

test('a seed reproduces identical route and flight metrics', () => {
  assert.deepEqual(caveGeometryMetrics(12345, { maxDepth: 3000 }),
    caveGeometryMetrics(12345, { maxDepth: 3000 }));
  const a = flightMetrics(424242, { maxSteps: 5000 });
  const b = flightMetrics(424242, { maxSteps: 5000 });
  assert.deepEqual(a, b);
});
