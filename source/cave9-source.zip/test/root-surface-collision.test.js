import { test } from 'node:test';
import assert from 'node:assert/strict';
import { Game } from '../src/core/Game.js';
import { collision } from '../src/core/CollisionSystem.js';
import { compositionAt, roomZ } from '../src/core/Landmarks.js';
import { pathFrameAt } from '../src/core/FlightPath.js';
import { closestTrianglePoint, queryNearestSurface } from '../src/core/SurfaceQuery.js';
import { buildCompositionAccums } from '../src/render/landmarks/LandmarkMeshBuilder.js';
import { closestTrianglePointInto, queryTriangleSurface } from '../src/core/landmarks/TriangleSurfaceQuery.js';

const emptyCave = { centers: [], segs: [], frames: [] };
const vertex = (surface, index) => Array.from(surface.vertices.subarray(index * 3, index * 3 + 3));
const triangleAt = (surface, indices, offset) => [0, 1, 2].map(i => vertex(surface, indices[offset + i]));
const mix = (triangle, weights) => [0, 1, 2].map(axis =>
  triangle.reduce((sum, point, corner) => sum + point[axis] * weights[corner], 0));
const isolated = surface => ({ rootSurfaces: [surface], pieces: [], collisionPieces: [] });

function chamber(seed) {
  const game = new Game();
  game.start({ mode: 2, seed, family: 'branching' });
  game.cave.generateThrough(roomZ(9) + 120);
  const comp = compositionAt(seed, game.cave, 9, 'branching');
  const mesh = buildCompositionAccums(comp).rock;
  const triangles = [];
  for (let i = 0; i < mesh.i.length; i += 3) {
    triangles.push([0, 1, 2].map(j => mesh.p.slice(mesh.i[i + j] * 3, mesh.i[i + j] * 3 + 3)));
  }
  return { cave: game.cave, ship: game.player, comp, triangles };
}

function inwardProbe(seed, root, fraction, inwardDistance) {
  const along = (fraction - 0.5) * root.length;
  const center = [root.cx + root.dx * along, root.cy + root.dy * along, root.cz + root.dz * along];
  const frame = pathFrameAt(seed, center[2]);
  const d = [center[0] - frame.center.x, center[1] - frame.center.y, center[2] - frame.center.z];
  const x = d[0] * frame.right.x + d[1] * frame.right.y + d[2] * frame.right.z;
  const y = d[0] * frame.up.x + d[1] * frame.up.y + d[2] * frame.up.z;
  const radius = Math.hypot(x, y);
  return center.map((v, i) => {
    const axis = ['x', 'y', 'z'][i];
    return v - inwardDistance * (frame.right[axis] * x + frame.up[axis] * y) / radius;
  });
}

test('a one-metre ship clears the measured root shoulder phantom zones', () => {
  // Search the authored shoulders deterministically: the new tree grammar has
  // different stations, but must still expose and reject capsule phantom hits.
  // Independently emitted render triangles remain the geometric oracle.
  for (const seed of [2024, 256, 4096]) {
    const { cave, comp, triangles } = chamber(seed);
    assert.ok(comp.rootSurfaces?.length, 'production roots provide exact surfaces');
    assert.equal(Object.getOwnPropertyDescriptor(comp, 'rootSurfaces').enumerable, false);
    let point;
    outer: for (const root of comp.pieces.filter(p => p.wallRooted && p.node === 0)) {
      for (const fraction of [0.4, 0.6, 0.8]) for (const distance of [1.5, 2, 2.5, 3, 3.5, 4, 4.5, 5]) {
        const candidate = inwardProbe(seed, root, fraction, distance);
        const coarse = queryNearestSurface(cave, candidate, 1, [{ ...comp }]);
        const exact = queryNearestSurface(cave, candidate, 1, [comp]);
        const rendered = Math.min(...triangles.map(tri => closestTrianglePoint(candidate, ...tri).distance));
        if (coarse.landmark.hullClearance < -0.05 && exact.wall.hullClearance > 1
            && exact.landmark.surfaceDistance > 1.4 && rendered > 1.4) {
          point = candidate; break outer;
        }
      }
    }
    assert.ok(point, `${seed}: new tree shoulders still exercise capsule phantom clearance`);
    const coarse = queryNearestSurface(cave, point, 1, [{ ...comp }]);
    const exact = queryNearestSurface(cave, point, 1, [comp]);
    const renderDistance = Math.min(...triangles.map(tri => closestTrianglePoint(point, ...tri).distance));
    assert.ok(coarse.landmark.hullClearance < -0.05, `${seed}: fixture exposes old capsule hit`);
    assert.ok(exact.wall.hullClearance > 1, `${seed}: wall does not explain the hit`);
    assert.ok(renderDistance > 1.4, `${seed}: actual ship has visible clearance`);
    assert.ok(Math.abs(exact.landmark.surfaceDistance - renderDistance) < 1e-7,
      `${seed}: collision and rendered nearest point agree`);
    assert.ok(exact.nearest.hullClearance > 0, `${seed}: no invisible collision remains`);
  }
});

test('root contacts use visible triangles and preserve ship-sphere clearance', () => {
  const { cave, comp, ship } = chamber(2024);
  for (const surface of comp.rootSurfaces) {
    // Middle body strips are clear of the buried, parity-only wall closure.
    const offset = surface.strips[3].start + 6;
    const points = [0, 1, 2].map(i => {
      const index = surface.visibleTriangles[offset + i] * 3;
      return Array.from(surface.vertices.subarray(index, index + 3));
    });
    const point = [0, 1, 2].map(i => points[0][i] * 0.2 + points[1][i] * 0.3 + points[2][i] * 0.5);
    const query = queryNearestSurface(cave, point, 1, [isolated(surface)]);
    assert.ok(Math.abs(query.landmark.surfaceDistance) < 1e-7, `${surface.gid}: visible contact is exact`);
    assert.ok(Math.abs(query.landmark.hullClearance + 1) < 1e-7, `${surface.gid}: real sphere radius retained`);
    assert.equal(query.landmark.piece.gid, surface.gid);
    assert.ok(queryNearestSurface(cave, point, 1, [comp]).landmark.hullClearance <= -1 + 1e-7,
      'overlapping roots retain the actual contact without requiring an exact interior union distance');
    ship.radius = 1;
    ship.pos.splice(0, 3, ...point);
    assert.equal(collision(cave, ship, [comp]), 0, 'actual ship contacts the visible union');
  }
});

test('child closures remain wholly buried in their parent at vertices, edges and triangle interiors', () => {
  for (const seed of [2024, 256, 4096]) {
    const { comp } = chamber(seed);
    const children = comp.rootSurfaces.filter(surface => surface.piece.parentGid);
    assert.ok(children.length >= 5, `${seed}: child fixtures must be present`);
    for (const child of children) {
      const parent = comp.rootSurfaces.find(surface => surface.gid === child.piece.parentGid);
      assert.ok(parent);
      assert.equal(child.closureKind, 'base-plane-fan');
      assert.equal(child.piece.wallRooted, false);
      assert.ok(child.queryClosureTriangles.length);
      for (let at = 0; at < child.queryClosureTriangles.length; at += 3) {
        const triangle = triangleAt(child, child.queryClosureTriangles, at);
        for (const weights of [[1, 0, 0], [0, 1, 0], [0, 0, 1],
          [0.5, 0.5, 0], [0.5, 0, 0.5], [0, 0.5, 0.5],
          [1 / 3, 1 / 3, 1 / 3], [0.6, 0.2, 0.2], [0.2, 0.6, 0.2], [0.2, 0.2, 0.6]]) {
          const point = mix(triangle, weights);
          assert.ok(queryTriangleSurface(point, parent).distance < -1e-6,
            `${seed}/${child.gid}: entire sampled closure must be strictly inside parent`);
          assert.ok(queryNearestSurface(emptyCave, point, 0.1, [comp]).landmark.hullClearance < 0);
        }
      }
    }
  }
});

test('the entire child closure fits inside a ball strictly contained by the closed parent boundary', () => {
  let checked = 0;
  for (const seed of [2024, 256, 4096, 777]) {
    const { comp } = chamber(seed);
    const children = comp.rootSurfaces.filter(surface => surface.piece.parentGid);
    assert.equal(children.length, 5, `${seed}: all authored children must exercise containment`);
    for (const child of children) {
      const parent = comp.rootSurfaces.find(surface => surface.gid === child.piece.parentGid);
      assert.ok(parent);
      const p = child.piece, half = p.length / 2;
      const attachment = [p.cx - p.dx * half, p.cy - p.dy * half, p.cz - p.dz * half];
      assert.ok(queryTriangleSurface(attachment, parent).inside,
        `${seed}/${child.gid}: attachment must be inside its parent solid`);
      let boundaryDistance = Infinity;
      const scratch = {};
      // Include the parent's hidden closure: distance to only its visible
      // mantle would not prove that this ball remains in the closed solid.
      for (const indices of [parent.visibleTriangles, parent.queryClosureTriangles]) {
        for (let at = 0; at < indices.length; at += 3) {
          closestTrianglePointInto(...attachment, parent.vertices,
            indices[at] * 3, indices[at + 1] * 3, indices[at + 2] * 3, scratch);
          boundaryDistance = Math.min(boundaryDistance, Math.hypot(
            attachment[0] - scratch.qx, attachment[1] - scratch.qy, attachment[2] - scratch.qz));
        }
      }
      let closureRadius = 0;
      assert.ok(child.queryClosureTriangles.length);
      for (const index of new Set(child.queryClosureTriangles)) {
        const point = vertex(child, index);
        closureRadius = Math.max(closureRadius, Math.hypot(...point.map((value, axis) => value - attachment[axis])));
      }
      // A ball is convex, so containing all closure vertices contains every
      // edge and every triangle interior too. Its positive gap to the entire
      // parent boundary, together with the inside attachment, proves burial.
      const margin = boundaryDistance - closureRadius;
      assert.ok(margin > 1e-6,
        `${seed}/${child.gid}: closure ball crosses parent boundary (margin ${margin}m)`);
      checked++;
    }
  }
  assert.equal(checked, 20);
});

test('parent-only, child-only and shared interior remain solid without claiming exact union distances', () => {
  const { comp, ship } = chamber(2024);
  for (const child of comp.rootSurfaces.filter(surface => surface.piece.parentGid)) {
    const parent = comp.rootSurfaces.find(surface => surface.gid === child.piece.parentGid);
    const found = new Set();
    for (const surface of [parent, child]) {
      for (let at = 0; at < surface.visibleTriangles.length; at += 9) {
        const face = triangleAt(surface, surface.visibleTriangles, at);
        const center = mix(face, [1 / 3, 1 / 3, 1 / 3]);
        const normal = queryTriangleSurface(center, surface);
        for (const inset of [0.01, 0.05, 0.15, 0.3]) {
          const point = center.map((value, axis) => value - inset * normal[['nx', 'ny', 'nz'][axis]]);
          const inParent = queryTriangleSurface(point, parent).distance < -1e-7;
          const inChild = queryTriangleSurface(point, child).distance < -1e-7;
          if (!inParent && !inChild) continue;
          found.add(inParent && inChild ? 'both' : inParent ? 'parent' : 'child');
          const query = queryNearestSurface(emptyCave, point, 0.1, [isolated(parent), isolated(child)]);
          assert.ok(query.landmark.hullClearance < 0, `${child.gid}: union interior is solid`);
          ship.radius = 0.1;
          ship.pos.splice(0, 3, ...point);
          assert.equal(collision(emptyCave, ship, [isolated(parent), isolated(child)]), 0);
        }
      }
    }
    assert.deepEqual([...found].sort(), ['both', 'child', 'parent'], `${child.gid}: all interior cases exercised`);
  }
});

test('free approaches around each branch agree with visible triangles and preserve sphere clearance', () => {
  const { comp, triangles, ship } = chamber(2024);
  for (const child of comp.rootSurfaces.filter(surface => surface.piece.parentGid)) {
    const p = child.piece;
    const origin = [p.cx, p.cy, p.cz];
    let directions = 0;
    for (const direction of [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]]) {
      for (const offset of [0.5, 1, 2, 4, 8]) {
        const point = origin.map((value, axis) => value + direction[axis] * offset);
        if (comp.rootSurfaces.some(surface => queryTriangleSurface(point, surface).distance <= 1e-7)) continue;
        const rendered = Math.min(...triangles.map(triangle => closestTrianglePoint(point, ...triangle).distance));
        const query = queryNearestSurface(emptyCave, point, 0.25, [comp]);
        assert.ok(Math.abs(query.landmark.surfaceDistance - rendered) < 1e-7,
          `${child.gid}: external closest surface equals actual visible geometry`);
        assert.ok(Math.abs(query.landmark.hullClearance - (rendered - 0.25)) < 1e-7);
        ship.radius = 0.25;
        ship.pos.splice(0, 3, ...point);
        const actual = collision(emptyCave, ship, [comp]);
        if (rendered <= 0.25) assert.equal(actual, 0);
        else assert.ok(Math.abs(actual - (rendered - 0.25)) < 1e-7);
        directions++;
        break;
      }
    }
    assert.ok(directions >= 3, `${child.gid}: exercise several independent free-space directions`);
  }
});

test('exact root surfaces preserve numeric collision grace', () => {
  const { cave, ship, comp } = chamber(2024);
  ship.pos[0] = NaN;
  assert.doesNotThrow(() => collision(cave, ship, [comp]));
  assert.equal(ship.graced, true);
  assert.equal(ship.dist, 2 * ship.radius);
});
