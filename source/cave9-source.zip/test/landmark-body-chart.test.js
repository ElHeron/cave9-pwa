import { test } from 'node:test';
import assert from 'node:assert/strict';
import { Game } from '../src/core/Game.js';
import { compositionAt, roomZ } from '../src/core/Landmarks.js';
import { buildCompositionAccums, growTubeForm } from '../src/render/landmarks/LandmarkMeshBuilder.js';
import { MeshAccum } from '../src/render/landmarks/MeshAccum.js';
import {
  LandmarkSurfaceProjector, landmarkBodyChartOffset,
} from '../src/render/landmarks/surfaceProjection.js';

const seeds = [2024, 256, 4096];
const room = 9;

test('child attachment continues the parent station, chart offset, contact and palette', () => {
  for (const seed of seeds) {
    const game = new Game();
    game.start({ mode: 2, seed, family: 'branching' });
    game.cave.generateThrough(roomZ(room) + 120);
    const comp = compositionAt(seed, game.cave, room, 'branching');
    const projector = new LandmarkSurfaceProjector(seed, room);
    for (const first of comp.pieces.filter(p => p.parentGid && p.node === 0)) {
      const parentForm = comp.pieces.filter(p => p.gid === first.parentGid).sort((a, b) => a.node - b.node);
      const childForm = comp.pieces.filter(p => p.gid === first.gid).sort((a, b) => a.node - b.node);
      const parent = new MeshAccum(), child = new MeshAccum();
      growTubeForm(parent, comp, parentForm, 'limb', parentForm[0].shade);
      // An independent child shade must never create a new dark foot palette.
      growTubeForm(child, comp, childForm, 'limb', parentForm[0].shade + 13);
      const station = first.parentNode * 17;
      assert.equal(child.chart[0], parent.chart[station], 'actual parent station object is shared');
      assert.equal(child.chart[17].previous, parent.chart[station]);
      assert.equal(child.contact[0], parent.contact[station]);
      assert.deepEqual(child.c.slice(0, 3), parent.c.slice(station * 3, station * 3 + 3));
      const cache = new Map();
      assert.equal(landmarkBodyChartOffset(projector, child.chart[0], cache),
        landmarkBodyChartOffset(projector, parent.chart[station], cache));

      const partial = { ...comp, pieces: childForm, rootChartPieces: comp.pieces,
        rootSurfaces: comp.rootSurfaces };
      const refreshed = buildCompositionAccums(partial).rock;
      assert.deepEqual(refreshed.p, child.p);
      assert.deepEqual(refreshed.c, child.c);
      assert.deepEqual(refreshed.contact, child.contact);
      assert.deepEqual(refreshed.toGeometry(projector).attributes.landmarkBodyChartOffset.array,
        child.toGeometry(projector).attributes.landmarkBodyChartOffset.array,
        'partial refresh retains the entire parent chart ancestry');
    }
  }
});

function area3(a, b, c) {
  const u = [b[0] - a[0], b[1] - a[1], b[2] - a[2]];
  const v = [c[0] - a[0], c[1] - a[1], c[2] - a[2]];
  return Math.hypot(u[1] * v[2] - u[2] * v[1],
    u[2] * v[0] - u[0] * v[2], u[0] * v[1] - u[1] * v[0]) / 2;
}

function chartMetrics(geometry) {
  const position = geometry.attributes.position;
  const local = geometry.attributes.landmarkSurfaceLocal;
  const offset = geometry.attributes.landmarkBodyChartOffset;
  const index = geometry.index.array;
  const measured = [0, 0], collapsed = [0, 0], overscaled = [0, 0];
  const chart = [0, 0];
  let roleTransitions = 0;
  const role = (i) => {
    const h = local.getZ(i) / Math.max(0.001, Math.hypot(local.getY(i), local.getZ(i)));
    return Math.abs(h + 0.52) < 0.035 || Math.abs(h - 0.56) < 0.035 ? 0
      : h <= -0.52 ? 1 : h >= 0.56 ? 3 : 2;
  };
  for (let t = 0; t < index.length; t += 3) {
    const ids = [index[t], index[t + 1], index[t + 2]];
    const xyz = ids.map((i) => [position.getX(i), position.getY(i), position.getZ(i)]);
    const area = area3(...xyz);
    if (area < 1e-9) continue;
    const roles = ids.map(role);
    if (new Set(roles).size > 1) roleTransitions++;
    const midRight = ids.reduce((sum, i) => sum + local.getY(i), 0) / 3;
    const midUp = ids.reduce((sum, i) => sum + local.getZ(i), 0) / 3;
    const h = midUp / Math.max(0.001, Math.hypot(midRight, midUp));
    const side = !(Math.abs(h + 0.52) < 0.035 || Math.abs(h - 0.56) < 0.035)
      && h > -0.52 && h < 0.56;
    const second = ids.map((i) => side ? local.getZ(i) : local.getY(i));
    for (let variant = 0; variant < 2; variant++) {
      const first = ids.map((i) => local.getX(i) + (variant ? offset.getX(i) : 0));
      const uvArea = Math.abs((first[1] - first[0]) * (second[2] - second[0])
        - (first[2] - first[0]) * (second[1] - second[0])) / 2;
      const ratio = uvArea / area;
      measured[variant] += area;
      chart[variant] += uvArea;
      if (ratio < 0.20) collapsed[variant] += area;
      if (ratio > 3) overscaled[variant] += area;
    }
  }
  return { weighted: chart[1] / measured[1], previousWeighted: chart[0] / measured[0],
    collapsed: collapsed[1] / measured[1], previousCollapsed: collapsed[0] / measured[0],
    overscaled: overscaled[1] / measured[1], roleTransitions };
}

test('body chart unfolds missing axis length without doubling a good vertical or oblique chart', () => {
  const projector = { project: ({ x, y, z }) =>
    ({ axialDepth: z, localRight: x, localUp: y }) };
  const base = { point: { x: 10, y: 0, z: 0 }, previous: null };
  const radial = { point: { x: 5, y: 0, z: 0 }, previous: base };
  const vertical = { point: { x: 10, y: 4, z: 0 }, previous: base };
  const oblique = { point: { x: 10, y: 4, z: 3 }, previous: base };
  const cache = new Map();
  assert.equal(landmarkBodyChartOffset(projector, base, cache), 0);
  assert.equal(landmarkBodyChartOffset(projector, radial, cache), 5);
  assert.equal(landmarkBodyChartOffset(projector, vertical, cache), 0);
  assert.equal(landmarkBodyChartOffset(projector, oblique, cache), 0);
});

test('real charts preserve geometry, feet and bounded centreline scale; crystal recovers chart area', () => {
  for (const seed of seeds) {
    const game = new Game();
    game.start({ mode: 2, seed, family: 'branching' });
    game.cave.generateThrough(roomZ(room) + 120);
    for (const family of ['branching', 'crystal']) {
      const comp = compositionAt(seed, game.cave, room, family);
      assert.ok(comp, `${seed} ${family} composition`);
      const acc = buildCompositionAccums(comp)[family === 'branching' ? 'rock' : 'crystal'];
      const projector = new LandmarkSurfaceProjector(seed, room);
      const geometry = acc.toGeometry(projector);
      const position = geometry.attributes.position;
      const uv = geometry.attributes.uv;
      const chart = geometry.attributes.landmarkBodyChartOffset;
      assert.equal(chart.itemSize, 1);
      for (let i = 0; i < acc.vcount(); i++) {
        assert.equal(position.getX(i), Math.fround(acc.p[i * 3]));
        assert.equal(uv.getX(i), Math.fround(acc.u[i * 2]));
        assert.equal(uv.getY(i), Math.fround(acc.u[i * 2 + 1]));
        assert.ok(Number.isFinite(chart.getX(i)));
        if (acc.chart[i] && !acc.chart[i].previous) {
          assert.equal(chart.getX(i), 0, `${seed} ${family} foot vertex ${i}`);
        }
      }
      assert.deepEqual([...geometry.index.array], acc.i, 'authoritative triangles stay byte-identical');
      const stationOffsets = new Map(acc.chart.map((node, i) => [node, chart.getX(i)]));
      let alreadyProjected = 0;
      for (const [node, correctedOffset] of stationOffsets) {
        if (!node?.previous) continue;
        const parentOffset = stationOffsets.get(node.previous);
        const base = (() => { let current = node; while (current.previous) current = current.previous; return current; })();
        const anchor = projector.project(base.point);
        const h = anchor.localUp / Math.max(0.001,
          Math.hypot(anchor.localRight, anchor.localUp));
        const selected = h > -0.485 && h < 0.525 ? 'localUp' : 'localRight';
        const a = projector.project(node.previous.point), b = projector.project(node.point);
        const world = Math.hypot(node.point.x - node.previous.point.x,
          node.point.y - node.previous.point.y, node.point.z - node.previous.point.z);
        if (world < 0.01) continue;
        const second = b[selected] - a[selected];
        const axial = b.axialDepth - a.axialDepth;
        const before = Math.hypot(axial, second) / world;
        const after = Math.hypot(axial + correctedOffset - parentOffset, second) / world;
        assert.ok(after < 1.025, `${seed} ${family}: centreline overscaled ${after}`);
        if (before > 0.9) {
          alreadyProjected++;
          assert.ok(after < 1.025,
            `${seed} ${family}: already well-projected axis must not double`);
        }
      }
      const metrics = chartMetrics(geometry);
      // Root's new branch surfaces also use F's front chart. The two axial
      // chart aggregate is not a complete area metric; original-image review
      // of all three charts remains required.
      if (family === 'crystal') {
        assert.ok(metrics.collapsed < metrics.previousCollapsed,
          `${seed} ${family}: ${JSON.stringify(metrics)}`);
        assert.ok(metrics.weighted > metrics.previousWeighted,
          `${seed} ${family}: ${JSON.stringify(metrics)}`);
        assert.ok(metrics.roleTransitions > 0, `${seed} ${family} spans real role boundaries`);
      }
      assert.ok(metrics.overscaled < 0.05,
        `${seed} ${family}: excessive chart expansion ${JSON.stringify(metrics)}`);
      assert.ok(alreadyProjected > 0, `${seed} ${family} includes well-projected axes`);
      geometry.dispose();
      projector.dispose();
    }
  }
});
