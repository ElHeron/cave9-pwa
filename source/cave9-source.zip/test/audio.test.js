// Audio volume / mute. Run with: npm test
// WebAudio is unavailable headlessly, so we inject a fake master gain node and
// assert the real setVolume/setEnabled code path drives it correctly.
import { test } from 'node:test';
import assert from 'node:assert/strict';

import { AudioSystem } from '../src/platform/AudioSystem.js';

function withFakeMaster() {
  const a = new AudioSystem();
  a.master = { gain: { value: -1 } };
  return a;
}

// A minimal fake WebAudio context that records the proximity pan/gain so we can
// assert the pan is set while mute/volume still work (WebAudio is headless-less).
function fakeAudioParam(initial = 0) {
  return { value: initial, setTargetAtTime(v) { this.value = v; } };
}
function withFakeContext() {
  const a = new AudioSystem();
  const node = () => ({ connect: (n) => n, frequency: fakeAudioParam(200), gain: fakeAudioParam(0), pan: fakeAudioParam(0), start() {}, stop() {}, type: '' });
  a.ctx = {
    currentTime: 0,
    createStereoPanner: () => node(),
    createOscillator: () => node(),
    createGain: () => node(),
  };
  a.master = { gain: { value: 0.7 } };
  return a;
}

test('defaults: enabled with 0.7 volume', () => {
  const a = new AudioSystem();
  assert.equal(a.enabled, true);
  assert.equal(a.volume, 0.7);
});

test('setVolume drives the master gain when enabled', () => {
  const a = withFakeMaster();
  a.setVolume(0.4);
  assert.equal(a.volume, 0.4);
  assert.equal(a.master.gain.value, 0.4);
});

test('setEnabled(false) mutes the master gain to 0', () => {
  const a = withFakeMaster();
  a.setVolume(0.5);
  a.setEnabled(false);
  assert.equal(a.master.gain.value, 0);
  // volume value is retained for un-mute
  assert.equal(a.volume, 0.5);
});

test('changing volume while muted keeps gain at 0', () => {
  const a = withFakeMaster();
  a.setEnabled(false);
  a.setVolume(0.9);
  assert.equal(a.master.gain.value, 0);
  a.setEnabled(true);
  a.setVolume(0.9);
  assert.equal(a.master.gain.value, 0.9);
});

test('proximity() sets the stereo pan while mute/volume stay on the master', () => {
  const a = withFakeContext();
  a.proximity(0.9, -0.8);
  assert.equal(a._proxPan.pan.value, -0.8, 'pan applied');
  assert.ok(a._proxGain.gain.value > 0, 'audible at high danger');
  // master gain (mute/volume) is independent of panning
  assert.equal(a.master.gain.value, 0.7);
  a.setEnabled(false);
  assert.equal(a.master.gain.value, 0, 'mute still zeroes the master');
});

test('proximity() while muted does not play (enabled gate respected)', () => {
  const a = withFakeContext();
  a.setEnabled(false);      // master → 0
  a.master.gain.value = 0;
  a.proximity(0.9, 1);      // should early-return on !enabled
  assert.equal(a._proxOsc, null, 'no proximity node created while muted');
});

test('proximity() clamps an out-of-range pan into [-1,1]', () => {
  const a = withFakeContext();
  a.proximity(0.9, 5);
  assert.equal(a._proxPan.pan.value, 1);
  a.proximity(0.9, -5);
  assert.equal(a._proxPan.pan.value, -1);
});
