// Landmark MESH generation (src/render/landmarks/*).
//
// These builders used to live inside Renderer, where a WebGL context was needed
// to reach them and nothing could be asserted about the geometry they produce.
// They are now pure functions over an accumulator, so the important guarantees
// are testable headlessly:
//
//   * geometry is deterministic (same composition → identical buffers),
//   * every emitted vertex is finite,
//   * NOTHING a formation grows enters the central no-entry tube — the flight
//     path / vanishing point guarantee that core/Landmarks.js enforces on the
//     skeleton must survive the geometry grown on top of it.
//
// Run with: npm test

import { test } from 'node:test';
import assert from 'node:assert/strict';

import { MeshAccum } from '../src/render/landmarks/MeshAccum.js';
import { buildTube, perpendicular, lerp3 } from '../src/render/landmarks/primitives.js';
import { rockColors, crystalColors } from '../src/render/landmarks/palette.js';
import { buildCompositionAccums, groupForms } from '../src/render/landmarks/LandmarkMeshBuilder.js';
import { compositionAt, roomZ } from '../src/core/Landmarks.js';
import { Game } from '../src/core/Game.js';

// ---- helpers ---------------------------------------------------------------

// Carve a seed's cave forward until room k sits inside the live ring buffer,
// then return that room's composition (or null if the chamber is too tight).
function compositionFor(seed, k, forcedType = null) {
  const g = new Game();
  g.start({ mode: 2, seed, family: forcedType ?? 'auto' });
  const target = roomZ(k) + 40;
  g.cave.generateThrough(target, 2_000_000);
  return compositionAt(seed, g.cave, k, forcedType);
}

function pointCapsule(x, y, z, p) {
  const h = p.length / 2;
  const ax = p.cx - p.dx * h, ay = p.cy - p.dy * h, az = p.cz - p.dz * h;
  const bx = p.cx + p.dx * h, by = p.cy + p.dy * h, bz = p.cz + p.dz * h;
  const dx = bx - ax, dy = by - ay, dz = bz - az;
  const den = dx * dx + dy * dy + dz * dz || 1;
  const t = Math.max(0, Math.min(1, ((x - ax) * dx + (y - ay) * dy + (z - az) * dz) / den));
  return Math.hypot(x - (ax + dx * t), y - (ay + dy * t), z - (az + dz * t));
}

const GREY = [0.5, 0.5, 0.5];
const RAMP = { cBase: [0, 0, 0], cBody: [0.5, 0.5, 0.5], cTip: [1, 1, 1] };

function straightTube(opts = {}) {
  const acc = new MeshAccum();
  const pts = [
    { pos: { x: 10, y: 0, z: 0 }, r: 1 },
    { pos: { x: 8, y: 0, z: 5 }, r: 1 },
    { pos: { x: 6, y: 0, z: 10 }, r: 1 },
  ];
  buildTube(acc, pts, { radial: 6, ...RAMP, ...opts });
  return { acc, pts, radial: opts.radial || 6 };
}

// ---- MeshAccum -------------------------------------------------------------

test('MeshAccum: vert() appends position/colour/uv and returns the new index', () => {
  const a = new MeshAccum();
  assert.equal(a.vert(1, 2, 3, GREY, 0.25, 0.75), 0);
  assert.equal(a.vert(4, 5, 6, GREY), 1);
  assert.equal(a.vcount(), 2);
  assert.deepEqual(a.p, [1, 2, 3, 4, 5, 6]);
  assert.deepEqual(a.u, [0.25, 0.75, 0, 0]);
  assert.equal(a.c.length, 6);
});

test('MeshAccum: an accumulator with no indices is empty', () => {
  const a = new MeshAccum();
  assert.equal(a.empty(), true);
  a.vert(0, 0, 0, GREY);
  assert.equal(a.empty(), true, 'loose vertices still draw nothing');
  a.tri(0, 0, 0);
  assert.equal(a.empty(), false);
});

test('MeshAccum: quad() emits two triangles sharing the a–c diagonal', () => {
  const a = new MeshAccum();
  a.quad(0, 1, 2, 3);
  assert.deepEqual(a.i, [0, 1, 2, 0, 2, 3]);
});

test('MeshAccum: toGeometry() carries position, colour, uv and the index', () => {
  const a = new MeshAccum();
  a.vert(0, 0, 0, GREY); a.vert(1, 0, 0, GREY); a.vert(0, 1, 0, GREY);
  a.tri(0, 1, 2);
  const g = a.toGeometry();
  assert.equal(g.attributes.position.count, 3);
  assert.equal(g.attributes.color.count, 3);
  assert.equal(g.attributes.uv.count, 3);
  assert.equal(g.index.count, 3);
  assert.ok(g.attributes.normal, 'vertex normals are computed for lighting');
});

// ---- primitives: buildTube -------------------------------------------------

test('buildTube: emits one closed ring per point plus a single tip apex', () => {
  const { acc, pts, radial } = straightTube();
  // (radial + 1) verts per ring (the seam vertex is duplicated for UVs) + apex
  assert.equal(acc.vcount(), pts.length * (radial + 1) + 1);
  // quads between consecutive rings + a triangle fan closing the tip
  assert.equal(acc.i.length, (pts.length - 1) * radial * 6 + radial * 3);
});

test('buildTube: tip fan faces outward instead of rendering as a hole', () => {
  const { acc, pts, radial } = straightTube();
  const cap = acc.i.slice((pts.length - 1) * radial * 6);
  const lastRing = (pts.length - 1) * (radial + 1);
  const apex = pts.length * (radial + 1);
  for (let segment = 0; segment < radial; segment++) {
    assert.deepEqual(cap.slice(segment * 3, segment * 3 + 3),
      [lastRing + segment, lastRing + segment + 1, apex]);
  }
});

test('buildTube: every emitted vertex is finite', () => {
  const { acc } = straightTube({ gnarl: 0.34, baseBoost: 2.8 });
  assert.ok(acc.p.every(Number.isFinite));
  assert.ok(acc.c.every(Number.isFinite));
  assert.ok(acc.u.every(Number.isFinite));
});

test('buildTube: identical input produces identical buffers (deterministic)', () => {
  const a = straightTube({ gnarl: 0.34, baseBoost: 2.8 }).acc;
  const b = straightTube({ gnarl: 0.34, baseBoost: 2.8 }).acc;
  assert.deepEqual(a.p, b.p);
  assert.deepEqual(a.c, b.c);
  assert.deepEqual(a.i, b.i);
});

test('buildTube: flat < 1 squashes the cross-section into an oval rib', () => {
  // A tube running straight down +z gets a clean frame: the transported normal
  // lands on y and the binormal on x, so `flat` is visible as x-only narrowing.
  const along = (flat) => {
    const acc = new MeshAccum();
    buildTube(acc, [
      { pos: { x: 10, y: 0, z: 0 }, r: 1 },
      { pos: { x: 10, y: 0, z: 5 }, r: 1 },
    ], { radial: 8, flat, ...RAMP });
    return acc;
  };
  const spread = (acc, axis) => {
    let lo = Infinity, hi = -Infinity;
    for (let i = axis; i < acc.p.length; i += 3) { lo = Math.min(lo, acc.p[i]); hi = Math.max(hi, acc.p[i]); }
    return hi - lo;
  };
  const round = along(1.0), oval = along(0.5);
  assert.ok(spread(oval, 0) < spread(round, 0) - 0.5, 'the rib is narrower across the flattened axis');
  assert.ok(Math.abs(spread(oval, 1) - spread(round, 1)) < 1e-9, 'the other axis is untouched');
});

test('buildTube: the inner clamp keeps a fattened trunk out of the no-entry tube', () => {
  const inner = 5;
  const acc = new MeshAccum();
  buildTube(acc, [
    { pos: { x: 12, y: 0, z: 0 }, r: 0.5 },
    { pos: { x: 9, y: 0, z: 6 }, r: 0.5 },
    { pos: { x: 7, y: 0, z: 12 }, r: 0.5 },
  ], { radial: 8, baseBoost: 8, gnarl: 0.4, cx: 0, cy: 0, inner, ...RAMP });
  for (let i = 0; i < acc.p.length; i += 3) {
    const r = Math.hypot(acc.p[i], acc.p[i + 1]);
    assert.ok(r >= inner, `vertex at r=${r.toFixed(2)} intruded the inner tube (${inner})`);
  }
});

// ---- palette ---------------------------------------------------------------

test('rockColors: runs dark contact → body → light edge for any shade', () => {
  for (const shade of [0, 0.5, 1]) {
    const c = rockColors(shade);
    assert.ok(c.cBase[2] < c.cBody[2] && c.cBody[2] < c.cTip[2]);
    assert.ok(c.cTip.every((v) => v >= 0 && v <= 1));
    assert.ok(c.cBody[2] - c.cBody[0] <= 0.035,
      'root bodies stay neutral enough to read as the surrounding cave rock');
    assert.ok(Math.max(...c.cTip) <= 0.211,
      'only a restrained crest separates the root from the wall');
  }
});

test('crystalColors: shade splits the inner planes into blue vs violet', () => {
  const blue = crystalColors(0.2), violet = crystalColors(0.8);
  assert.ok(blue.cInner[2] > blue.cInner[0], 'blue leans toward the blue channel');
  assert.ok(violet.cInner[0] > blue.cInner[0], 'violet carries more red');
  assert.deepEqual(blue.cBase, violet.cBase, 'the obsidian contact tone is shared');
  assert.ok(blue.cEdge[2] >= 0.45, 'the single crystal crest remains readable at approach distance');
  assert.ok(blue.cInner2[2] - blue.cInner2[0] >= 0.049,
    'broad crystal faces retain a restrained cool separation without a sampler');
  assert.ok(Math.max(...blue.cInner2, ...violet.cInner2) <= 0.11,
    'obsidian bodies stay dark enough to read as mineral mass instead of blue signs');
});

// ---- composition builder ---------------------------------------------------

test('groupForms: pieces are grouped by gid and ordered along each form', () => {
  const comp = {
    pieces: [
      { gid: 1, node: 2 }, { gid: 0, node: 0 }, { gid: 1, node: 0 },
      { gid: 0, node: 1 }, { gid: 1, node: 1 },
    ],
  };
  const forms = groupForms(comp);
  assert.equal(forms.length, 2);
  for (const f of forms) {
    assert.deepEqual(f.map((p) => p.node), [...f.map((p) => p.node)].sort((a, b) => a - b));
  }
});

test('groupForms: pieces without a gid each become their own form', () => {
  const forms = groupForms({ pieces: [{}, {}, {}] });
  assert.equal(forms.length, 3);
});

test('piece-resident compositions build finite geometry; C3 adds no landmark draw', () => {
  let built = 0;
  for (const seed of [4096, 424242, 555]) {
    const comp = compositionFor(seed, 2);
    if (!comp) continue;
    built++;
    const { rock, crystal } = buildCompositionAccums(comp);
    if (comp.surfaceResident) {
      assert.equal(comp.typeName, 'coiling');
      assert.ok(rock.empty() && crystal.empty(), 'C3 draws only through the cave ring mesh');
    } else {
      assert.ok(!rock.empty() || !crystal.empty(), 'a piece composition must draw something');
    }
    for (const acc of [rock, crystal]) {
      assert.ok(acc.p.every(Number.isFinite), 'positions are finite');
      assert.ok(acc.c.every((v) => v >= 0 && v <= 1), 'vertex colours stay in range');
      assert.ok(acc.i.every((v) => Number.isInteger(v) && v < acc.vcount()), 'indices are in range');
    }
  }
  assert.ok(built > 0, 'expected at least one buildable room');
});

test('buildCompositionAccums: the same composition rebuilds identically', () => {
  const comp = compositionFor(4096, 2);
  assert.ok(comp, 'seed 4096 room 2 has a composition');
  const a = buildCompositionAccums(comp), b = buildCompositionAccums(comp);
  assert.deepEqual(a.rock.p, b.rock.p);
  assert.deepEqual(a.rock.c, b.rock.c);
  assert.deepEqual(a.crystal.p, b.crystal.p);
});

test('no landmark geometry ever enters the central no-entry tube', () => {
  // The safety guarantee core/Landmarks.js enforces on the piece SKELETON has to
  // survive the geometry grown on it: nothing may occlude the flight path or the
  // dark vanishing point. Checked on every vertex of every family.
  let checked = 0;
  const families = new Set();
  for (const seed of [4096, 424242, 555, 360]) {
    for (let k = 2; k <= 3; k++) {
      const comp = compositionFor(seed, k);
      if (!comp) continue;
      families.add(comp.typeName);
      const { rock, crystal } = buildCompositionAccums(comp);
      for (const acc of [rock, crystal]) {
        for (let i = 0; i < acc.p.length; i += 3) {
          const dx = acc.p[i] - comp.frame.center.x;
          const dy = acc.p[i + 1] - comp.frame.center.y;
          const dz = acc.p[i + 2] - comp.frame.center.z;
          const x = dx * comp.frame.right.x + dy * comp.frame.right.y + dz * comp.frame.right.z;
          const y = dx * comp.frame.up.x + dy * comp.frame.up.y + dz * comp.frame.up.z;
          const r = Math.hypot(x, y);
          assert.ok(r >= comp.inner - 1e-6,
            `${comp.typeName} (seed ${seed}, room ${k}) reached r=${r.toFixed(2)} ` +
            `inside the ${comp.inner} keep-out tube`);
          checked++;
        }
      }
    }
  }
  assert.ok(checked > 1000, `expected a substantial vertex sample, got ${checked}`);
  assert.ok(families.size >= 2, `expected several families, saw ${[...families]}`);
});

test('every visible landmark vertex is covered by an authoritative piece capsule', () => {
  let checked = 0;
  for (const seed of [4096, 424242, 555, 360]) {
    const comp = compositionFor(seed, 2);
    if (!comp) continue;
    const { rock, crystal } = buildCompositionAccums(comp);
    for (const acc of [rock, crystal]) for (let i = 0; i < acc.p.length; i += 3) {
      const covered = comp.collisionPieces.some((p) => pointCapsule(acc.p[i], acc.p[i + 1], acc.p[i + 2], p) <= p.radius + 1e-5);
      assert.ok(covered, `${comp.typeName} vertex ${i / 3} escapes every capsule`);
      checked++;
    }
  }
  assert.ok(checked > 1000);
});

test('every visible landmark triangle lies inside the authoritative collision capsules', () => {
  const samples = [
    [1 / 3, 1 / 3, 1 / 3], // face centroid
    [0.5, 0.5, 0],         // three edge midpoints
    [0.5, 0, 0.5],
    [0, 0.5, 0.5],
    [0.6, 0.2, 0.2],       // asymmetric interior sample catches swept-profile bias
  ];
  let checked = 0;
  for (const seed of [4096, 424242, 555, 360]) {
    for (const family of ['branching', 'crystal', 'coiling']) {
      const comp = compositionFor(seed, 2, family);
      if (!comp) continue;
      const { rock, crystal } = buildCompositionAccums(comp);
      for (const acc of [rock, crystal]) {
        for (let i = 0; i < acc.i.length; i += 3) {
          const ia = acc.i[i] * 3, ib = acc.i[i + 1] * 3, ic = acc.i[i + 2] * 3;
          for (const [wa, wb, wc] of samples) {
            const x = acc.p[ia] * wa + acc.p[ib] * wb + acc.p[ic] * wc;
            const y = acc.p[ia + 1] * wa + acc.p[ib + 1] * wb + acc.p[ic + 1] * wc;
            const z = acc.p[ia + 2] * wa + acc.p[ib + 2] * wb + acc.p[ic + 2] * wc;
            const covered = comp.collisionPieces.some((p) => pointCapsule(x, y, z, p) <= p.radius + 1e-5);
            assert.ok(covered,
              `${family} seed ${seed} triangle ${i / 3} sample escaped every collision capsule`);
            checked++;
          }
        }
      }
    }
  }
  assert.ok(checked >= 4 * (800 + 432) * samples.length,
    `the two piece families retain broad sampled triangle coverage; got ${checked}`);
});

// ---- small shared helpers --------------------------------------------------

test('perpendicular: returns a unit vector orthogonal to its input', () => {
  for (const v of [{ x: 1, y: 0, z: 0 }, { x: 0, y: 0, z: 1 }, { x: 0.3, y: -0.5, z: 0.8 }]) {
    const t = { x: v.x, y: v.y, z: v.z };
    const len = Math.hypot(t.x, t.y, t.z);
    const unit = { x: t.x / len, y: t.y / len, z: t.z / len };
    const p = perpendicular(unit);
    assert.ok(Math.abs(p.length() - 1) < 1e-9, 'unit length');
    assert.ok(Math.abs(p.x * unit.x + p.y * unit.y + p.z * unit.z) < 1e-9, 'orthogonal');
  }
});

test('lerp3: blends two colour triples component-wise', () => {
  assert.deepEqual(lerp3([0, 0, 0], [1, 2, 4], 0.5), [0.5, 1, 2]);
  assert.deepEqual(lerp3([1, 1, 1], [0, 0, 0], 0), [1, 1, 1]);
});
