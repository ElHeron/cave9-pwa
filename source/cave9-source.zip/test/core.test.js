// Headless verification of the ported core logic. Run with: npm test
import { test } from 'node:test';
import assert from 'node:assert/strict';

import { RNG, seedFromString } from '../src/core/RNG.js';
import { Game, RunPhase } from '../src/core/Game.js';
import { TWO_BUTTONS } from '../src/core/constants.js';

test('RNG is deterministic for a given seed', () => {
  const a = new RNG(12345);
  const b = new RNG(12345);
  for (let i = 0; i < 1000; i++) assert.equal(a.next(), b.next());
});

test('RNG drand stays in [0,1)', () => {
  const r = new RNG(7);
  for (let i = 0; i < 10000; i++) {
    const v = r.drand();
    assert.ok(v >= 0 && v < 1, `drand out of range: ${v}`);
  }
});

test('seedFromString is stable and non-zero', () => {
  assert.equal(seedFromString('2026-06-20'), seedFromString('2026-06-20'));
  assert.notEqual(seedFromString('a'), 0);
});

test('a fresh run produces a finite cave', () => {
  const g = new Game();
  g.start({ mode: TWO_BUTTONS, seed: 999 });
  assert.equal(g.phase, RunPhase.RUNNING);
  for (const ring of g.cave.segs) {
    for (const p of ring) {
      assert.ok(Number.isFinite(p[0]) && Number.isFinite(p[1]) && Number.isFinite(p[2]));
    }
  }
});

test('same seed reproduces the same cave (no input)', () => {
  const run = (seed) => {
    const g = new Game();
    g.start({ mode: TWO_BUTTONS, seed });
    for (let i = 0; i < 300; i++) g.step();
    return g.cave.centers.map((c) => [c[0].toFixed(4), c[1].toFixed(4), c[2].toFixed(4)]);
  };
  assert.deepEqual(run(424242), run(424242));
});

test('with no input the ship eventually crashes and score advances', () => {
  const g = new Game();
  g.start({ mode: TWO_BUTTONS, seed: 555 });
  let crashed = false;
  for (let i = 0; i < 6000; i++) {
    if (g.step()) { crashed = true; break; }
  }
  assert.ok(crashed, 'ship should crash without input (gravity)');
  assert.equal(g.phase, RunPhase.DEAD);
  assert.ok(g.scoreValue() > 0, 'score should be > 0');
});
