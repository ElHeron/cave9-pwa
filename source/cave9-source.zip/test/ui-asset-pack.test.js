import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import test from 'node:test';
import { fileURLToPath } from 'node:url';
import { PNG } from 'pngjs';
import { UI_MENU_CONTACT_SHEET_SIZE, writeUiMenuContactSheet } from '../scripts/ui-menu-contact-sheet.mjs';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const ASSET_DIR = path.join(ROOT, 'src', 'ui', 'textures', 'v2');

const EXPECTED = new Map([
  ['panel.png', [512, 512]],
  ['button-neutral.png', [384, 192]],
  ['button-hover.png', [384, 192]],
  ['button-primary.png', [384, 192]],
  ['button-disabled.png', [384, 192]],
  ['toggle-off.png', [256, 128]],
  ['toggle-on.png', [256, 128]],
  ['slider-rail.png', [384, 48]],
  ['slider-hinge.png', [128, 128]],
  ['slider-lever.png', [96, 128]],
  ['divider.png', [384, 64]],
  ['button-danger.png', [384, 192]],
  ['crash-plate.png', [384, 192]],
  ['success-badge.png', [384, 192]],
  ['success-medallion.png', [192, 192]],
]);

test('complete menu asset pack contains every declared component', () => {
  const actual = fs.readdirSync(ASSET_DIR).filter((name) => name.endsWith('.png')).sort();
  assert.deepEqual(actual, [...EXPECTED.keys()].sort());
});

test('menu asset dimensions match the runtime contract', () => {
  let totalBytes = 0;
  for (const [name, [width, height]] of EXPECTED) {
    const bytes = fs.readFileSync(path.join(ASSET_DIR, name));
    const png = PNG.sync.read(bytes);
    assert.equal(png.width, width, `${name} width`);
    assert.equal(png.height, height, `${name} height`);
    assert.ok(
      png.data.some((value, index) => index % 4 === 3 && value === 0),
      `${name} should contain transparent exterior pixels`,
    );
    totalBytes += bytes.length;
  }
  assert.ok(totalBytes < 1_800_000, `asset pack is unexpectedly large: ${totalBytes}`);
});

test('asset builder is present and a contact sheet can be reproduced from shipped runtime PNGs', (t) => {
  assert.ok(fs.existsSync(path.join(ROOT, 'scripts', 'build-ui-menu-assets.mjs')));
  const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'cave9-ui-contact-sheet-'));
  t.after(() => fs.rmSync(tempDir, { recursive: true, force: true }));

  const assets = new Map([...EXPECTED.keys()].map((name) => [
    name.replace(/\.png$/, ''),
    PNG.sync.read(fs.readFileSync(path.join(ASSET_DIR, name))),
  ]));
  const contactSheet = path.join(tempDir, 'ui-menu-assets-v2-contact-sheet.png');
  writeUiMenuContactSheet(contactSheet, assets);

  assert.ok(fs.existsSync(contactSheet));
  const png = PNG.sync.read(fs.readFileSync(contactSheet));
  assert.deepEqual([png.width, png.height], UI_MENU_CONTACT_SHEET_SIZE);
  assert.equal(png.data[(0 * png.width + 0) * 4 + 3], 255, 'checkerboard has an opaque background');
  let compositedPixels = 0;
  for (let y = 0; y < png.height; y++) {
    for (let x = 0; x < png.width; x++) {
      const offset = (y * png.width + x) * 4;
      const checker = (Math.floor(x / 24) + Math.floor(y / 24)) % 2
        ? [29, 36, 47]
        : [13, 17, 24];
      if (png.data[offset] !== checker[0]
        || png.data[offset + 1] !== checker[1]
        || png.data[offset + 2] !== checker[2]) compositedPixels++;
    }
  }
  assert.ok(compositedPixels > 10_000, `contact sheet contains too little rendered asset content: ${compositedPixels}`);
});
