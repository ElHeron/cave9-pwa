import { test } from 'node:test';
import assert from 'node:assert/strict';

import { makePiece } from '../src/core/landmarks/safety.js';
import { querySlabHull, slabHullForPiece } from '../src/core/landmarks/SlabHull.js';

function plate(z = 0) {
  const piece = makePiece('blade', { x: 0, y: 0, z }, { x: 1, y: 0, z: 0 }, 12, 3);
  piece.roll = 0;
  return piece;
}

function vertex(hull, index) {
  const at = index * 3;
  return [hull.vertices[at], hull.vertices[at + 1], hull.vertices[at + 2]];
}

function pointCapsuleDistance(point, piece) {
  const half = piece.length / 2;
  const a = [piece.cx - piece.dx * half, piece.cy - piece.dy * half, piece.cz - piece.dz * half];
  const b = [piece.cx + piece.dx * half, piece.cy + piece.dy * half, piece.cz + piece.dz * half];
  const d = b.map((value, axis) => value - a[axis]);
  const t = Math.max(0, Math.min(1, point.reduce((sum, value, axis) =>
    sum + (value - a[axis]) * d[axis], 0) / d.reduce((sum, value) => sum + value * value, 0)));
  return Math.hypot(...point.map((value, axis) => value - a[axis] - d[axis] * t));
}

function trianglePoint(hull, triangle, weights = [1 / 3, 1 / 3, 1 / 3]) {
  const at = triangle * 3;
  const a = vertex(hull, hull.triangles[at]);
  const b = vertex(hull, hull.triangles[at + 1]);
  const c = vertex(hull, hull.triangles[at + 2]);
  return [0, 1, 2].map((axis) => a[axis] * weights[0] + b[axis] * weights[1] + c[axis] * weights[2]);
}

function shiftedFromFace(hull, triangle, distance) {
  const face = triangle < 16 ? triangle : 16 + Math.floor((triangle - 16) / 2);
  const at = face * 4;
  return trianglePoint(hull, triangle).map((value, axis) =>
    value + hull.planes[at + axis] * distance);
}

test('eight-corner ridge wedge is deterministic and has one fixed, outward closed topology', () => {
  const piece = plate();
  const a = slabHullForPiece(piece), b = slabHullForPiece(piece);
  assert.deepEqual(a.vertices, b.vertices);
  assert.deepEqual(a.triangles, b.triangles);
  assert.deepEqual(a.planes, b.planes);
  assert.equal(a.vertices.length / 3, 18);
  assert.equal(a.triangles.length / 3, 32);
  assert.equal(a.planes.length / 4, 24);

  const directedEdges = new Map();
  const center = [0, 1, 2].map((axis) => {
    let sum = 0;
    for (let i = 0; i < 18; i++) sum += a.vertices[i * 3 + axis];
    return sum / 18;
  });
  for (let triangle = 0; triangle < 32; triangle++) {
    const ids = Array.from(a.triangles.slice(triangle * 3, triangle * 3 + 3));
    for (let edge = 0; edge < 3; edge++) {
      const from = ids[edge], to = ids[(edge + 1) % 3];
      const key = [Math.min(from, to), Math.max(from, to)].join(':');
      const e = directedEdges.get(key) || { count: 0, orientation: 0 };
      e.count++; e.orientation += from < to ? 1 : -1;
      directedEdges.set(key, e);
    }
    const [p, q, r] = ids.map((id) => vertex(a, id));
    const u = q.map((v, axis) => v - p[axis]);
    const v = r.map((value, axis) => value - p[axis]);
    const normal = [
      u[1] * v[2] - u[2] * v[1],
      u[2] * v[0] - u[0] * v[2],
      u[0] * v[1] - u[1] * v[0],
    ];
    assert.ok(normal.reduce((sum, value, axis) =>
      sum + value * (p[axis] - center[axis]), 0) > 1e-5,
    `triangle ${triangle} faces outward`);
  }
  assert.equal(directedEdges.size, 48, 'Euler edge count for an 18-vertex closed polyhedron');
  for (const edge of directedEdges.values()) {
    assert.equal(edge.count, 2, 'every edge belongs to two triangles');
    assert.equal(edge.orientation, 0, 'adjacent triangles traverse an edge oppositely');
  }
});

test('a live circumferential axis controls the broad face independently of world-axis roll', () => {
  const piece = plate(9000);
  piece.slabAcross = { x: 0, y: 1, z: 0 };
  piece.orbitTwist = 0;
  piece.roll = Math.PI / 2;
  const aligned = slabHullForPiece(piece);
  // T points along +X and width along +Y, so the front face is axial (+Z).
  assert.ok(aligned.planes[2] > 0.97);
  piece.roll = -1.2;
  assert.deepEqual(slabHullForPiece(piece).vertices, aligned.vertices,
    'the old helper-basis roll cannot rotate a live wall-aligned plate');
  piece.orbitTwist = 0.30;
  const turned = slabHullForPiece(piece);
  assert.ok(turned.planes[2] > 0.87 && turned.planes[2] < aligned.planes[2] - 0.06,
    'the authored twist reveals a side while retaining a broad route-facing ridge facet');
  for (let i = 0; i < 18; i++) {
    assert.ok(pointCapsuleDistance(vertex(turned, i), piece) <= piece.radius + 1e-8);
  }
});

test('asymmetric authored profiles remain convex, fully inside their capsules and stable at deep z', () => {
  for (let i = 0; i < 64; i++) {
    const piece = plate(9000 + i * 107);
    piece.roll = Math.PI / 2 + (i % 7 - 3) * 0.09;
    piece.slab = {
      baseLeft: 0.68 + (i % 5) * 0.035,
      baseRight: 0.74 + (i % 4) * 0.045,
      lowerBreakAt: 0.22 + (i % 5) * 0.015,
      lowerBreak2At: 0.64 + (i % 5) * 0.014,
      upperBreakAt: 0.25 + (i % 5) * 0.015,
      upperBreak2At: 0.62 + (i % 5) * 0.014,
      lowerBulge: 0.35 + (i % 4) * 0.035,
      upperBulge: 0.27 + (i % 4) * 0.035,
      tipWidth: 0.07 + (i % 3) * 0.015,
      tipShift: (i % 5 - 2) * 0.027,
      baseThickness: 0.36 + (i % 4) * 0.04,
      tipThickness: 0.13 + (i % 3) * 0.025,
      ridgeAt: 0.48 + (i % 5) * 0.025,
      ridgeShift: (i % 5 - 2) * 0.025,
      ridgeHeight: 0.08 + (i % 4) * 0.012,
      rootOverhang: 0.12 + (i % 3) * 0.03,
    };
    const hull = slabHullForPiece(piece);
    for (let vertexIndex = 0; vertexIndex < 18; vertexIndex++) {
      assert.ok(pointCapsuleDistance(vertex(hull, vertexIndex), piece) <= piece.radius + 2e-3,
        `profile ${i} vertex ${vertexIndex} escapes capsule`);
    }
    // Capsules are convex. Checking each hull vertex establishes that every
    // closed face triangle and all its interior points stay capsule-covered.
    for (let triangle = 0; triangle < 32; triangle++) {
      const p = trianglePoint(hull, triangle, [0.23, 0.31, 0.46]);
      assert.ok(pointCapsuleDistance(p, piece) <= piece.radius + 2e-3);
    }
  }
});

test('the cached exact query measures front, sides, edge and clipped tip', () => {
  const hull = slabHullForPiece(plate());
  for (const [name, triangle] of [['front', 0], ['back', 8], ['lower side', 16],
    ['tip', 22], ['upper side', 26]]) {
    const onSurface = trianglePoint(hull, triangle);
    assert.ok(Math.abs(querySlabHull(onSurface, hull).surfaceDistance) < 1e-5, name);
    const outside = shiftedFromFace(hull, triangle, 0.20);
    const result = querySlabHull(outside, hull);
    assert.equal(result.inside, false, `${name} outside`);
    assert.ok(Math.abs(result.surfaceDistance - 0.20) < 1e-4,
      `${name} distance ${result.surfaceDistance}`);
  }
  const frontEdge = [0, 1, 2].map((axis) =>
    (vertex(hull, 8)[axis] + vertex(hull, 9)[axis]) / 2);
  const normal = [0, 1, 2].map((axis) => hull.planes[axis] + hull.planes[16 * 4 + axis]);
  const length = Math.hypot(...normal);
  const outsideEdge = frontEdge.map((value, axis) => value + normal[axis] / length * 0.23);
  const edgeQuery = querySlabHull(outsideEdge, hull);
  assert.ok(Math.abs(edgeQuery.surfaceDistance - 0.23) < 1e-4,
    `edge distance ${edgeQuery.surfaceDistance}`);

  const inside = querySlabHull([6, 0, 0], hull);
  assert.equal(inside.inside, true);
  assert.ok(inside.surfaceDistance < -0.3);
  const expectedInside = { ...inside };
  const reusedOutside = querySlabHull([6, -2.4, 0], hull, inside);
  assert.strictEqual(reusedOutside, inside, 'caller receives the supplied object');
  assert.equal(reusedOutside.inside, false);
  assert.ok(reusedOutside.surfaceDistance > 1);
  const reusedInside = querySlabHull([6, 0, 0], hull, inside);
  assert.deepEqual(reusedInside, expectedInside,
    'reusing the object restores the independently saved inside result');
});

test('points inside the old wide capsule but outside the thin visible plate do not collide', () => {
  const piece = plate();
  const hull = slabHullForPiece(piece);
  for (const point of [[6, -2.4, 0], [6, 2.4, 0], [6, 0, 2.8]]) {
    assert.ok(pointCapsuleDistance(point, piece) < piece.radius,
      'probe is inside the old authoritative capsule');
    const q = querySlabHull(point, hull);
    assert.equal(q.inside, false);
    assert.ok(q.surfaceDistance > 0.35,
      `phantom capsule probe ${point} has ${q.surfaceDistance} m clearance`);
  }
});

test('oblique deep-world plate clears real 1 m ship probes inside its outer capsule', () => {
  const raw = [-0.53, 0.46, 0.71];
  const magnitude = Math.hypot(...raw);
  const dir = { x: raw[0] / magnitude, y: raw[1] / magnitude, z: raw[2] / magnitude };
  const piece = makePiece('blade', { x: 1234.5, y: -2711.25, z: 15600.75 }, dir, 18, 4.2);
  piece.roll = Math.PI / 2 + 0.31;
  piece.slab = {
    baseLeft: 0.73, baseRight: 0.90,
    lowerBreakAt: 0.27, lowerBreak2At: 0.67,
    upperBreakAt: 0.31, upperBreak2At: 0.66,
    lowerBulge: 0.43, upperBulge: 0.32,
    tipWidth: 0.085, tipShift: -0.05,
    baseThickness: 0.43, tipThickness: 0.17,
    ridgeAt: 0.55, ridgeShift: -0.06, ridgeHeight: 0.11,
  };
  const hull = slabHullForPiece(piece);
  assert.deepEqual(hull.vertices, slabHullForPiece(piece).vertices,
    'rotated hull remains deterministic at deep coordinates');
  for (const triangle of [0, 8, 16, 22, 30]) {
    const surface = trianglePoint(hull, triangle);
    assert.ok(Math.abs(querySlabHull(surface, hull).surfaceDistance) < 1e-7,
      `deep triangle ${triangle} lies on the exact queried surface`);
    const probe = shiftedFromFace(hull, triangle, 0.35);
    const q = querySlabHull(probe, hull);
    assert.ok(Math.abs(q.surfaceDistance - 0.35) < 1e-6,
      `deep triangle ${triangle}: ${q.surfaceDistance} m outside`);
  }
  const shipRadius = 1;
  const axisMid = [piece.cx, piece.cy, piece.cz];
  for (const sign of [-1, 1]) {
    const phantom = axisMid.map((value, axis) =>
      value + hull.planes[axis] * piece.radius * 0.86 * sign);
    assert.ok(pointCapsuleDistance(phantom, piece) < piece.radius,
      'ship probe is inside the broad old capsule');
    const q = querySlabHull(phantom, hull);
    assert.equal(q.inside, false);
    assert.ok(q.surfaceDistance > shipRadius,
      `the visible wedge remains more than one ship radius away: ${q.surfaceDistance}`);
    assert.ok(q.surfaceDistance - shipRadius > 0,
      'the exact hull query does not report a phantom ship hit');
  }
});

test('invalid nonconvex or capsule-escaping profiles fail before rendering and collision', () => {
  const nonconvex = plate();
  nonconvex.slab = { lowerBulge: -0.05 };
  assert.throws(() => slabHullForPiece(nonconvex), RangeError);
  const outsideCapsule = plate();
  outsideCapsule.slab = { baseRight: 1.1 };
  assert.throws(() => slabHullForPiece(outsideCapsule), RangeError);
  const overlongRoot = plate();
  overlongRoot.slab = { rootOverhang: 0.6 };
  assert.throws(() => slabHullForPiece(overlongRoot), RangeError);
});
