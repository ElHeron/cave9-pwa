// The app's DOM contract: every element id src/app/dom.js reaches for must
// actually exist in index.html. A renamed id used to mean a silently dead button
// that only a manual click would catch. Run with: npm test

import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';

import { ELEMENT_IDS, BUTTON_IDS } from '../src/app/dom.js';

const html = readFileSync(fileURLToPath(new URL('../index.html', import.meta.url)), 'utf8');
const idsInHtml = new Set([...html.matchAll(/\bid="([^"]+)"/g)].map((m) => m[1]));

test('index.html actually declares ids (the scrape works)', () => {
  assert.ok(idsInHtml.size > 20, `only found ${idsInHtml.size} ids — the scrape is broken`);
});

test('every element the app looks up exists in index.html', () => {
  for (const [name, id] of Object.entries(ELEMENT_IDS)) {
    assert.ok(idsInHtml.has(id), `dom.ELEMENT_IDS.${name} points at missing #${id}`);
  }
});

test('every button the app binds a click to exists in index.html', () => {
  for (const [name, id] of Object.entries(BUTTON_IDS)) {
    assert.ok(idsInHtml.has(id), `dom.BUTTON_IDS.${name} points at missing #${id}`);
  }
});

test('no id is claimed by two different names', () => {
  const all = [...Object.values(ELEMENT_IDS), ...Object.values(BUTTON_IDS)];
  assert.equal(new Set(all).size, all.length, 'duplicate id in the dom table');
});

test('every button in index.html is either bound or owned by MenuSystem', () => {
  // MenuSystem builds the settings rows and the credits body itself; everything
  // else in the static markup should be wired by the app.
  const bound = new Set(Object.values(BUTTON_IDS));
  const staticButtons = [...html.matchAll(/<button[^>]*\bid="([^"]+)"/g)].map((m) => m[1]);
  const unbound = staticButtons.filter((id) => !bound.has(id));
  assert.deepEqual(unbound, [], `static buttons nothing binds: ${unbound.join(', ')}`);
});
