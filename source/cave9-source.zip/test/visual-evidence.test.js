import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { PNG } from 'pngjs';

import { formReleaseScenarios, suiteDefinition } from '../scripts/visual/config.mjs';
import { evaluateFrame, inspectPng, inspectPngDifference } from '../scripts/visual/image-checks.mjs';
import { gitProvenance, runtimeFingerprint } from '../scripts/visual/provenance.mjs';
import {
  blessingRefusalReasons, deriveRunStatus, exactMatrixCheck, manualReviewBinding,
  manifestContractCheck, reconstructRuntimeErrors,
} from '../scripts/visual/verification.mjs';
import { withViteServer } from '../scripts/visual/vite-server.mjs';
import { createFreshRunDirectory } from '../scripts/visual/capture-form-release.mjs';
import { normalizeVisualScenario } from '../src/dev/scenario/schema.mjs';

function pngFile(dir, name, width, height, pixel) {
  const png = new PNG({ width, height });
  for (let y = 0; y < height; y++) for (let x = 0; x < width; x++) {
    const i = (y * width + x) * 4;
    const [r, g, b, a = 255] = pixel(x, y);
    png.data[i] = r; png.data[i + 1] = g; png.data[i + 2] = b; png.data[i + 3] = a;
  }
  const file = join(dir, name);
  writeFileSync(file, PNG.sync.write(png));
  return file;
}

test('form-release is the exact 3-family by 4-offset deterministic matrix', () => {
  const suite = suiteDefinition();
  const scenarios = formReleaseScenarios();
  assert.equal(scenarios.length, 12);
  assert.deepEqual([...new Set(scenarios.map((entry) => entry.family))],
    ['branching', 'crystal', 'coiling']);
  for (const family of ['branching', 'crystal', 'coiling']) {
    assert.deepEqual(scenarios.filter((entry) => entry.family === family).map((entry) => entry.offset),
      [-64, -32, 0, 32]);
  }
  assert.deepEqual(suite.viewport, { width: 1280, height: 720, deviceScaleFactor: 1 });
  for (const scenario of scenarios) {
    assert.equal(scenario.captureOptions.version, 'VisualScenarioV1');
    assert.equal(scenario.captureOptions.placement, 'place');
    assert.equal(scenario.captureOptions.camera, 'hero');
    assert.deepEqual(scenario.captureOptions.viewport, { width: 1280, height: 720, dpr: 1 });
    assert.equal(scenario.captureOptions.settings.fov, 45);
    assert.equal(scenario.captureOptions.settings.motion, 0);
    assert.equal(scenario.captureOptions.settings.surfaceRelief, true);
    assert.equal(scenario.distance, 9000 + scenario.offset);
  }
});

test('PNG inspection rejects blank and wrong-sized evidence', (t) => {
  const dir = mkdtempSync(join(tmpdir(), 'cave9-visual-'));
  t.after(() => rmSync(dir, { recursive: true, force: true }));
  const blank = inspectPng(pngFile(dir, 'blank.png', 16, 9, () => [255, 255, 255, 255]),
    { width: 16, height: 9 });
  assert.equal(blank.blank.pass, false);
  const real = inspectPng(pngFile(dir, 'real.png', 16, 9, (x, y) =>
    [(x * 17) % 255, (y * 31) % 255, ((x + y) * 13) % 255, 255]),
  { width: 1280, height: 720 });
  assert.equal(real.blank.pass, true);
  assert.equal(real.viewport.pass, false);
});

test('family image difference isolates changed form pixels and emits a reproducible mask', (t) => {
  const dir = mkdtempSync(join(tmpdir(), 'cave9-visual-diff-'));
  t.after(() => rmSync(dir, { recursive: true, force: true }));
  const control = pngFile(dir, 'control.png', 32, 18, (x, y) => [20 + x, 24 + y, 30, 255]);
  const actual = pngFile(dir, 'actual.png', 32, 18, (x, y) => {
    const changed = x >= 4 && x <= 26 && y >= 3 && y <= 14 && (x + y) % 3 === 0;
    return changed ? [190, 40, 30, 255] : [20 + x, 24 + y, 30, 255];
  });
  const mask = join(dir, 'mask.png');
  const difference = inspectPngDifference(actual, control, { width: 32, height: 18 },
    { threshold: 18, writeMaskFile: mask });
  assert.equal(difference.pass, true);
  assert.ok(difference.pixels > 0);
  assert.ok(difference.fraction > 0.1);
  assert.ok(difference.bbox.widthFraction > 0.6);
  assert.ok(difference.angularBinCount >= 6);
  assert.ok(difference.quadrantCount >= 3);
  assert.equal(inspectPng(mask, { width: 32, height: 18 }).sha256, difference.maskSha256);
  const identical = inspectPngDifference(control, control, { width: 32, height: 18 });
  assert.equal(identical.pixels, 0);
  assert.equal(identical.bbox, null);
});

test('frame evaluation independently catches viewport, depth, crash, and runtime errors', () => {
  const base = {
    scenario: { distance: 9000, family: 'branching', captureOptions: {
      placement: 'place', camera: 'hero', viewport: { width: 1280, height: 720, dpr: 1 },
    } },
    captureInfo: { distanceReached: 9000,
      positioning: { requestedDistance: 9000, actualDistance: 9000, method: 'place',
        placed: true, flown: false, reached: true, crashed: false },
      family: { requested: 'branching', active: ['branching'] },
      camera: { requested: 'hero', active: 'hero', supported: true },
      viewport: { requested: { width: 1280, height: 720, dpr: 1 }, matches: true } },
    runtime: { appState: 'capture', gamePhase: 'running', innerWidth: 1280, innerHeight: 720,
      devicePixelRatio: 1, canvasWidth: 1280, canvasHeight: 720,
      webglAvailable: true, webglContextLost: false, browserErrors: [], glErrors: [] },
    image: { blank: { pass: true, reasons: [] }, viewport: { pass: true,
      expected: [1280, 720], actual: [1280, 720] } },
    errors: [],
  };
  assert.equal(evaluateFrame(base).status, 'pass');
  assert.equal(evaluateFrame({ ...base, captureInfo: { ...base.captureInfo, distanceReached: 8990 } }).checks.depth.pass, false);
  assert.equal(evaluateFrame({ ...base, captureInfo: { ...base.captureInfo,
    positioning: { ...base.captureInfo.positioning, reached: false } } }).checks.positioning.pass, false);
  assert.equal(evaluateFrame({ ...base, captureInfo: { ...base.captureInfo,
    family: { requested: 'crystal', active: ['crystal'] } } }).checks.family.pass, false);
  assert.equal(evaluateFrame({ ...base, captureInfo: { ...base.captureInfo,
    camera: { requested: 'hero', active: 'orbit', supported: true } } }).checks.camera.pass, false);
  assert.equal(evaluateFrame({ ...base, captureInfo: { ...base.captureInfo,
    viewport: { ...base.captureInfo.viewport, matches: false } } }).checks.visualViewport.pass, false);
  assert.equal(evaluateFrame({ ...base, runtime: { ...base.runtime, gamePhase: 'dead' } }).checks.crash.pass, false);
  assert.equal(evaluateFrame({ ...base, errors: ['pageerror: boom'] }).checks.runtimeErrors.pass, false);
  assert.equal(evaluateFrame({ ...base, runtime: { ...base.runtime, webglAvailable: false } }).checks.webgl.pass, false);
});

test('runtime verification reconstructs browser, WebGL and flattened errors independently', () => {
  const frame = { runtimeErrors: [], runtime: { browserErrors: ['unhandledrejection: boom'],
    glErrors: [1282], webglAvailable: false, webglContextLost: true } };
  const errors = reconstructRuntimeErrors(frame);
  assert.ok(errors.includes('unhandledrejection: boom'));
  assert.ok(errors.includes('webgl getError: 1282'));
  assert.ok(errors.includes('webgl unavailable'));
  assert.ok(errors.includes('webgl context lost'));
});

test('Vite orchestration always stops the child when capture work throws', async () => {
  const events = [];
  await assert.rejects(withViteServer(async () => {
    events.push('task');
    throw new Error('capture failed');
  }, {
    root: process.cwd(), port: 54321,
    start: async () => ({ fake: true }),
    wait: async () => { events.push('ready'); },
    stop: async () => { events.push('stopped'); },
  }), /capture failed/);
  assert.deepEqual(events, ['ready', 'task', 'stopped']);
});

test('capture installs rejection and context-loss listeners before first navigation', () => {
  const source = readFileSync(new URL('../scripts/visual/capture-form-release.mjs', import.meta.url), 'utf8');
  const init = source.indexOf('context.addInitScript');
  const navigation = source.indexOf('page.goto');
  assert.ok(init >= 0 && navigation > init);
  assert.match(source, /unhandledrejection/);
  assert.match(source, /webglcontextlost/);
  assert.match(source, /capture browser has no healthy WebGL context/);
});

test('git fingerprint ignores its own visual-lab artifacts but detects source changes', async (t) => {
  const dir = mkdtempSync(join(tmpdir(), 'cave9-visual-git-'));
  t.after(() => rmSync(dir, { recursive: true, force: true }));
  const git = (...args) => execFileSync('git', args, { cwd: dir, stdio: 'ignore' });
  git('init'); git('config', 'user.email', 'visual-test@example.invalid');
  git('config', 'user.name', 'Visual Test');
  writeFileSync(join(dir, '.gitignore'), 'artifacts/\n');
  writeFileSync(join(dir, 'source.txt'), 'one\n');
  git('add', '.'); git('commit', '-m', 'fixture');
  const before = await gitProvenance(dir);
  mkdirSync(join(dir, 'artifacts/visual-lab/run'), { recursive: true });
  writeFileSync(join(dir, 'artifacts/visual-lab/run/manifest.json'), '{}\n');
  const artifactOnly = await gitProvenance(dir);
  assert.equal(artifactOnly.diffFingerprint, before.diffFingerprint);
  writeFileSync(join(dir, 'source.txt'), 'two\n');
  const changed = await gitProvenance(dir);
  assert.notEqual(changed.diffFingerprint, before.diffFingerprint);
  assert.equal(changed.dirty, true);
});

test('runtime fingerprint binds entry/config/lock files and every public asset type', (t) => {
  const dir = mkdtempSync(join(tmpdir(), 'cave9-runtime-fingerprint-'));
  t.after(() => rmSync(dir, { recursive: true, force: true }));
  mkdirSync(join(dir, 'public/assets'), { recursive: true });
  writeFileSync(join(dir, 'index.html'), 'one');
  writeFileSync(join(dir, 'vite.config.js'), 'one');
  writeFileSync(join(dir, 'package.json'), '{}');
  writeFileSync(join(dir, 'package-lock.json'), '{}');
  writeFileSync(join(dir, 'public/assets/hud.ttf'), 'font-one');
  const before = runtimeFingerprint(dir);
  writeFileSync(join(dir, 'index.html'), 'two');
  const sourceChanged = runtimeFingerprint(dir);
  assert.notEqual(sourceChanged.source.sha256, before.source.sha256);
  writeFileSync(join(dir, 'public/assets/hud.ttf'), 'font-two');
  const assetChanged = runtimeFingerprint(dir);
  assert.notEqual(assetChanged.assets.sha256, sourceChanged.assets.sha256);
});

test('status and blessing policy refuse stale, failed, and manual-pending runs', () => {
  assert.equal(deriveRunStatus({ stale: true, automatedStatus: 'pass', manualStatus: 'pass' }), 'stale');
  assert.equal(deriveRunStatus({ stale: false, automatedStatus: 'fail', manualStatus: 'pass' }), 'fail');
  assert.equal(deriveRunStatus({ stale: false, automatedStatus: 'pass', manualStatus: 'fail' }), 'fail');
  assert.equal(deriveRunStatus({ stale: false, automatedStatus: 'pass', manualStatus: 'pending' }), 'manual-pending');
  assert.equal(deriveRunStatus({ stale: false, automatedStatus: 'pass', manualStatus: 'pass' }), 'pass');
  assert.ok(blessingRefusalReasons({ status: 'stale', automated: { status: 'pass' },
    verification: { stale: true }, manualReview: { status: 'pass' } }).includes('run is stale'));
  assert.ok(blessingRefusalReasons({ status: 'fail', automated: { status: 'fail' },
    verification: { stale: false }, manualReview: { status: 'pass' } }).length > 0);
  assert.ok(blessingRefusalReasons({ status: 'manual-pending', automated: { status: 'pass' },
    verification: { stale: false }, manualReview: { status: 'pending' } }).length > 0);
  assert.deepEqual(blessingRefusalReasons({ status: 'pass', automated: { status: 'pass' },
    verification: { stale: false, manualReviewBinding: { pass: true } }, manualReview: { status: 'pass' } }), []);
});

test('run directories are immutable and exact matrix validation fails closed', (t) => {
  const dir = mkdtempSync(join(tmpdir(), 'cave9-visual-run-'));
  t.after(() => rmSync(dir, { recursive: true, force: true }));
  const runDir = join(dir, 'fresh-run');
  assert.equal(createFreshRunDirectory(runDir), join(runDir, 'frames'));
  assert.throws(() => createFreshRunDirectory(runDir), /refusing to overwrite/);

  const suite = suiteDefinition();
  const frames = formReleaseScenarios().map((scenario) => ({
    id: scenario.id, family: scenario.family, seed: scenario.seed, offset: scenario.offset,
    requestedDepth: scenario.distance, captureOptions: scenario.captureOptions,
    captureApi: suite.captureApi,
    file: `frames/${scenario.id}.png`,
    normalizedScenario: normalizeVisualScenario(scenario.captureOptions),
    snapshot: { version: 'VisualSnapshotV1', scenario: normalizeVisualScenario(scenario.captureOptions) },
  }));
  assert.equal(exactMatrixCheck({ suite, frames }).pass, true);
  assert.equal(exactMatrixCheck({ suite, frames: frames.slice(1) }).pass, false);
  assert.equal(exactMatrixCheck({ suite, frames: [...frames, frames[0]] }).pass, false);
  assert.equal(exactMatrixCheck({ suite, frames: frames.map((frame, index) => index === 0
    ? { ...frame, captureApi: 'window.__cave9.captureScenario' } : frame) }).pass, false);
  assert.equal(exactMatrixCheck({ suite, frames: frames.map((frame, index) => index === 0
    ? { ...frame, file: '../escape.png' } : frame) }).pass, false);
  assert.equal(exactMatrixCheck({ suite, frames: frames.map((frame, index) => index === 1
    ? { ...frame, file: frames[0].file } : frame) }).pass, false);
});

test('manifest envelope fails closed on schema, WebGL, completion and non-canonical run roots', () => {
  const root = join(tmpdir(), 'cave9-contract-root');
  const manifest = { schemaVersion: 1, kind: 'cave9-visual-evidence-run', runId: 'run-a',
    createdAt: '2026-08-08T00:00:00.000Z', completedAt: '2026-08-08T00:01:00.000Z',
    source: { git: {}, reference: {}, runtime: {} }, errors: [],
    environment: { browser: { webgl: { available: true } } },
    report: { json: 'reference-report.json', html: 'reference-report.html' } };
  const runDir = join(root, 'artifacts', 'visual-lab', 'run-a');
  assert.equal(manifestContractCheck({ root, runDir, manifest }).pass, true);
  assert.equal(manifestContractCheck({ root, runDir, manifest: { ...manifest, schemaVersion: 9 } }).pass, false);
  assert.equal(manifestContractCheck({ root, runDir, manifest: { ...manifest,
    environment: { browser: { webgl: { available: false } } } } }).pass, false);
  assert.equal(manifestContractCheck({ root, runDir, manifest: { ...manifest, completedAt: null } }).pass, false);
  assert.equal(manifestContractCheck({ root, runDir: join(root, 'copied-run'), manifest }).pass, false);
});

test('approved manual review binds both reports and the exact frame set', () => {
  const frames = [{ id: 'a', image: { sha256: 'frame-a' } }];
  const reportFiles = [{ key: 'json', pass: true }, { key: 'html', pass: true }];
  const manifest = {
    report: { jsonSha256: 'json-a', htmlSha256: 'html-a' },
    manualReview: { status: 'pass', reportJsonSha256: 'json-a', reportHtmlSha256: 'html-a',
      frames: [{ id: 'a', sha256: 'frame-a' }],
      criteria: Object.fromEntries(['branching', 'coiling', 'crystal'].map((family) => [family, {
        recognizable: true, wallIntegrated: true, depthLayers: true,
        centralOpening: true, axialEffect: true,
      }])) },
  };
  assert.deepEqual(manualReviewBinding(manifest, frames, reportFiles), { pass: true, reasons: [] });
  manifest.manualReview.frames[0].sha256 = 'changed';
  assert.equal(manualReviewBinding(manifest, frames, reportFiles).pass, false);
});
