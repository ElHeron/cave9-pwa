// Daily challenge + local persistence (Phase 3B). Backend-free: the day's date
// hashes to a stable seed; "today's best" and per-seed best persist locally.
import { test } from 'node:test';
import assert from 'node:assert/strict';

import { dailyKey, dailySeed, seedFromString } from '../src/core/RNG.js';

// In-memory localStorage so SaveSystem (imported after) has a store to use.
class MemStore {
  constructor() { this.m = new Map(); }
  getItem(k) { return this.m.has(k) ? this.m.get(k) : null; }
  setItem(k, v) { this.m.set(k, String(v)); }
  removeItem(k) { this.m.delete(k); }
}
globalThis.localStorage = new MemStore();
const { SaveSystem } = await import('../src/platform/SaveSystem.js');

test('same calendar day → same seed; different day → different seed', () => {
  const d1 = new Date('2026-06-21T03:00:00Z');
  const d1b = new Date('2026-06-21T23:30:00Z');
  const d2 = new Date('2026-06-22T03:00:00Z');
  assert.equal(dailyKey(d1), '2026-06-21');
  assert.equal(dailySeed(d1), dailySeed(d1b), 'same day is reproducible');
  assert.notEqual(dailySeed(d1), dailySeed(d2), 'next day differs');
  assert.equal(dailySeed(d1), seedFromString('2026-06-21'));
});

test('daily seed is a valid (non-zero, positive) RNG seed', () => {
  const s = dailySeed(new Date('2026-06-21T00:00:00Z'));
  assert.ok(Number.isInteger(s) && s > 0 && s <= 0x7fffffff);
});

test('today best stores and loads, keeps the maximum', () => {
  const key = '2026-06-21';
  assert.equal(SaveSystem.getDailyBest(key), 0, 'no record yet');
  assert.equal(SaveSystem.setDailyBest(key, 1200), true, 'first score is a record');
  assert.equal(SaveSystem.getDailyBest(key), 1200);
  assert.equal(SaveSystem.setDailyBest(key, 800), false, 'lower score not a record');
  assert.equal(SaveSystem.getDailyBest(key), 1200, 'best retained');
  assert.equal(SaveSystem.setDailyBest(key, 1500), true);
  assert.equal(SaveSystem.getDailyBest(key), 1500);
  // a different day is tracked separately
  assert.equal(SaveSystem.getDailyBest('2026-06-22'), 0);
});

test('per-seed best stores and loads independently', () => {
  assert.equal(SaveSystem.getSeedBest(424242), 0);
  assert.equal(SaveSystem.setSeedBest(424242, 999), true);
  assert.equal(SaveSystem.getSeedBest(424242), 999);
  assert.equal(SaveSystem.setSeedBest(424242, 500), false);
  assert.equal(SaveSystem.getSeedBest(424242), 999);
  assert.equal(SaveSystem.getSeedBest(123), 0, 'other seeds independent');
});
