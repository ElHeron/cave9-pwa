import { test } from 'node:test';
import assert from 'node:assert/strict';

import { CaveStream } from '../src/core/CaveStream.js';
import { compositionAt } from '../src/core/Landmarks.js';
import { pathFrameAt } from '../src/core/FlightPath.js';
import { queryNearestSurface } from '../src/core/SurfaceQuery.js';
import {
  buildCaveAtlas, inspectDepthSector, inspectWorldPoint,
  renderCaveAtlasFragment, renderUnwrappedSvg,
} from '../src/dev/atlas/index.js';

const TAU = Math.PI * 2;
const SECTORS = 32;

function syntheticTube({ rings = 7, step = 5, helix = false } = {}) {
  const cave = { seed: 17, segs: [], centers: [], frames: [], innerRadii: [] };
  for (let i = 0; i < rings; i++) {
    const depth = i * step;
    const phase = helix ? depth * 0.08 : 0;
    const center = [helix ? 3 * Math.cos(phase) : 0, helix ? 2 * Math.sin(phase) : 0, depth];
    const frame = {
      center: { x: center[0], y: center[1], z: center[2] },
      tangent: { x: 0, y: 0, z: 1 },
      right: { x: 1, y: 0, z: 0 },
      up: { x: 0, y: 1, z: 0 },
    };
    const wall = [];
    // Match CaveStream's topology: original sector 25 is route-frame +Right.
    for (let sector = 0; sector < SECTORS; sector++) {
      const angle = Math.PI / 2 + (sector - 1) * TAU / SECTORS;
      const right = (6 + i * 0.1) * Math.cos(angle);
      const up = (3 + i * 0.05) * Math.sin(angle);
      wall.push([center[0] + right, center[1] + up, depth]);
    }
    cave.centers.push(center);
    cave.frames.push(frame);
    cave.segs.push(wall);
    cave.innerRadii.push(2);
  }
  return cave;
}

function weightedPoint(vertices, weights) {
  return [0, 1, 2].map((axis) => vertices.reduce((sum, point, index) =>
    sum + point[axis] * weights[index], 0));
}

test('straight oval tube produces actual Right/Up sections and ten metre strips', () => {
  const cave = syntheticTube();
  const atlas = buildCaveAtlas({ cave, crossSectionSpacing: 10 });

  assert.equal(atlas.unwrapped.seam.originalSector, 25);
  assert.deepEqual(atlas.unwrapped.sectorOrder.slice(0, 3), [25, 26, 27]);
  assert.equal(atlas.unwrapped.rows[0].points.length, 32);
  assert.equal(atlas.unwrapped.depthStep, 2);
  for (let i = 1; i < atlas.unwrapped.rows.length - 1; i++) {
    assert.ok(Math.abs(atlas.unwrapped.rows[i].depth - atlas.unwrapped.rows[i - 1].depth - 2) < 1e-9);
  }
  assert.equal(atlas.unwrapped.rows[0].boundaryPoints.length, 33);
  assert.deepEqual(atlas.unwrapped.rows[0].boundaryPoints[0].world,
    atlas.unwrapped.rows[0].boundaryPoints[32].world);
  assert.equal(atlas.longitudinal.right[0].positive.local.right, 6);
  assert.ok(Math.abs(atlas.longitudinal.right[0].negative.local.right + 6) < 1e-12);
  assert.equal(atlas.longitudinal.up[0].positive.local.up, 3);
  assert.ok(Math.abs(atlas.longitudinal.up[0].negative.local.up + 3) < 1e-12);
  for (const depth of [0, 10, 20, 30]) {
    assert.ok(atlas.crossSections.some((section) => section.depth === depth && section.reasons.includes('grid')));
  }
  assert.ok(atlas.crossSections.some((section) => section.reasons.includes('right-span-max')),
    'meaningful width extrema supplement the fixed strip cadence');
  assert.ok(atlas.crossSections.some((section) => section.reasons.includes('boolean-reserve-min')),
    'protected boolean-tube reserve extrema supplement the strip cadence');
});

test('rotating wall columns do not rotate the atlas directional sections', () => {
  const cave = new CaveStream();
  cave.reset(2024, 'coiling');
  cave.prime();
  cave.generateThrough(9200);
  const atlas = buildCaveAtlas({ cave });
  let changedColumns = 0;
  for (let i = 0; i < atlas.rings.length; i++) {
    for (const [axis, side, angle] of [
      ['right', 'positive', 0], ['right', 'negative', Math.PI],
      ['up', 'positive', Math.PI / 2], ['up', 'negative', -Math.PI / 2],
    ]) {
      const selected = atlas.longitudinal[axis][i][side];
      const gap = Math.abs(Math.atan2(Math.sin(selected.angle - angle), Math.cos(selected.angle - angle)));
      assert.ok(gap <= Math.PI / SECTORS + 1e-9,
        'directional samples stay within half a real sector of the requested route axis');
    }
    if (atlas.longitudinal.right[i].positive.originalSector !== atlas.directions.right) changedColumns++;
  }
  assert.ok(changedColumns > 30, 'the test must cross the rotating C3 columns');
  assert.equal(atlas.unwrapped.seam.anchor, 'first-ring');
  assert.equal(atlas.unwrapped.seam.follows, 'vertex-column');
  const sample = inspectDepthSector(atlas, 9101, 5);
  const inverse = inspectWorldPoint(atlas, sample.world);
  assert.ok(Math.abs(inverse.depth - 9101) < 1e-6, 'unwrapped mesh-column inverse remains exact');
});

test('clearance and reserve use the exact collision triangles rather than ring vertices', () => {
  const cave = syntheticTube({ rings: 7, step: 5 });
  for (let ring = 0; ring < cave.segs.length; ring++) {
    for (let sector = 0; sector < SECTORS; sector++) {
      const angle = Math.PI / 2 + (sector - 1) * TAU / SECTORS;
      cave.segs[ring][sector] = [6 * Math.cos(angle), 6 * Math.sin(angle), cave.centers[ring][2]];
    }
  }
  const atlas = buildCaveAtlas({ cave, crossSectionSpacing: 2.5 });
  const section = atlas.crossSections.find((entry) => entry.depth === 2.5);
  const collision = queryNearestSurface(cave, [0, 0, 2.5]);
  const vertexMinimum = Math.min(...cave.segs[0].map(([x, y]) => Math.hypot(x, y)));

  assert.ok(section);
  assert.ok(collision.wall);
  assert.ok(section.clearance.wall < vertexMinimum,
    'the polygon chord is closer than every submitted ring vertex');
  assert.ok(Math.abs(section.clearance.wall - collision.wall.surfaceDistance) < 1e-12,
    'atlas clearance delegates to the exact production wall triangles');
  assert.ok(Math.abs(section.clearance.booleanReserve
    - (collision.wall.surfaceDistance - 2)) < 1e-12);
  for (const reason of ['wall-clearance-min', 'boolean-reserve-min']) {
    const extremum = atlas.crossSections.find((entry) => entry.reasons.includes(reason));
    assert.ok(extremum, `${reason} is retained as a cross-section`);
    assert.ok(extremum.clearance.wall < vertexMinimum,
      `${reason} is derived from triangle clearance, not a vertex radius`);
  }
});

test('unwrapped rows never append a short depth interval', () => {
  const atlas = buildCaveAtlas({ cave: syntheticTube({ rings: 4, step: 5 }) });
  assert.equal(atlas.depthRange[1], 15);
  assert.equal(atlas.unwrapped.rows.at(-1).depth, 14);
  for (let index = 1; index < atlas.unwrapped.rows.length; index++) {
    assert.equal(atlas.unwrapped.rows[index].depth - atlas.unwrapped.rows[index - 1].depth, 2);
  }
});

test('helix centreline and cyclic inspection are deterministic and round-trip', () => {
  const cave = syntheticTube({ rings: 13, step: 5, helix: true });
  const a = buildCaveAtlas({ cave });
  const b = buildCaveAtlas({ cave });
  assert.deepEqual(a, b);
  assert.notEqual(a.centerline.top[0].value, a.centerline.top[4].value);
  assert.notEqual(a.centerline.side[0].value, a.centerline.side[4].value);

  const seam = inspectDepthSector(a, 17.5, 0);
  const cyclic = inspectDepthSector(a, 17.5, 32);
  assert.deepEqual(seam.world, cyclic.world);
  assert.equal(seam.originalSector, 25);
  assert.equal(seam.source.t, 0.5);

  const inverse = inspectWorldPoint(a, seam.world);
  assert.ok(Math.abs(inverse.depth - 17.5) < 1e-9);
  assert.equal(inverse.displaySector, 0);
  assert.ok(inverse.atlasPointDistance < 1e-9);
});

test('world inverse preserves barycentric depth and sector fraction in both triangles and at the seam', () => {
  const atlas = buildCaveAtlas({ cave: syntheticTube({ rings: 5, step: 5 }) });
  const lo = atlas.rings[1], hi = atlas.rings[2];
  const cases = [
    {
      displayCell: 4,
      triangle: 0,
      weights: [0.2, 0.3, 0.5],
      expectedFraction: 4.5,
      expectedDepthT: 0.3,
    },
    {
      displayCell: 4,
      triangle: 1,
      weights: [0.2, 0.3, 0.5],
      expectedFraction: 4.7,
      expectedDepthT: 0.8,
    },
    {
      displayCell: 31,
      triangle: 1,
      weights: [0.2, 0.3, 0.5],
      expectedFraction: 31.7,
      expectedDepthT: 0.8,
      seam: true,
    },
  ];

  for (const spec of cases) {
    const original = atlas.unwrapped.sectorOrder[spec.displayCell];
    const next = (original + 1) % SECTORS;
    const vertices = spec.triangle === 0
      ? [lo.sectors[original].world, hi.sectors[original].world, lo.sectors[next].world]
      : [lo.sectors[next].world, hi.sectors[original].world, hi.sectors[next].world];
    const world = weightedPoint(vertices, spec.weights);
    const inverse = inspectWorldPoint(atlas, world);
    assert.ok(inverse.atlasPointDistance < 1e-9);
    assert.ok(Math.abs(inverse.depth - (lo.depth + (hi.depth - lo.depth) * spec.expectedDepthT)) < 1e-9);
    assert.ok(Math.abs(inverse.displaySectorFraction - spec.expectedFraction) < 1e-9);
    assert.equal(inverse.source.triangle, spec.triangle);
    if (spec.seam) {
      assert.equal(inverse.displaySector, 0);
      assert.equal(inverse.seam, true);
    }
  }
});

test('the atlas consumes real CaveStream and FlightPath ring data without a substitute cave', () => {
  const cave = new CaveStream();
  cave.reset(4096);
  cave.prime();
  const atlas = buildCaveAtlas({ cave });

  assert.equal(atlas.rings.length, cave.count);
  for (const sample of [atlas.rings[0], atlas.rings[37], atlas.rings.at(-1)]) {
    const expected = pathFrameAt(4096, sample.depth);
    assert.ok(Math.abs(sample.center[0] - expected.center.x) < 1e-12);
    assert.ok(Math.abs(sample.center[1] - expected.center.y) < 1e-12);
    assert.deepEqual(sample.sectors.map((sector) => sector.world), cave.segs[sample.bufferIndex]);
  }
  const point = inspectDepthSector(atlas, atlas.rings[20].depth, 7);
  assert.ok(point.surface.surfaceDistance < 1e-8, 'inspection delegates to the exact SurfaceQuery wall');
  assert.equal(point.surface.kind, 'wall');

  const lo = atlas.rings[50], hi = atlas.rings[51], j = 7, j1 = 8;
  const triangleInterior = [0, 1, 2].map((axis) =>
    (lo.sectors[j].world[axis] + hi.sectors[j].world[axis] + lo.sectors[j1].world[axis]) / 3);
  const inverse = inspectWorldPoint(atlas, triangleInterior);
  assert.ok(inverse.surface.surfaceDistance < 1e-8);
  assert.ok(inverse.atlasPointDistance < 1e-8,
    'world-to-atlas inverse retains points inside real wall triangles, not only longitudinal edges');
  assert.ok(inverse.displaySectorFraction >= 0 && inverse.displaySectorFraction < 32);
});

test('real Landmark compositions are retained as world and unwrapped metadata', () => {
  const cave = new CaveStream();
  cave.reset(42, 'branching');
  cave.ensureCapacityForDistance(2500);
  cave.prime();
  const composition = compositionAt(42, cave, 2, 'branching');
  assert.ok(composition?.pieces.length > 0, 'real room 2 should produce an authored composition');

  const atlas = buildCaveAtlas({ cave, landmarks: [composition] });
  assert.equal(atlas.landmarks.length, composition.pieces.length);
  assert.ok(atlas.landmarks.every((piece) => piece.displaySector >= 0 && piece.displaySector < 32));
  const original = composition.pieces[0];
  const mapped = atlas.landmarks[0];
  assert.deepEqual(mapped.centre, [original.cx, original.cy, original.cz]);
  assert.equal(mapped.type, composition.typeName);
});

test('SVG and HTML renderers expose structured, inspectable atlas markup', () => {
  const atlas = buildCaveAtlas({ cave: syntheticTube() });
  const unwrap = renderUnwrappedSvg(atlas);
  const fragment = renderCaveAtlasFragment(atlas, { title: 'A < B' });

  assert.match(unwrap, /^<svg /);
  assert.equal((unwrap.match(/class="atlas-unwrapped-cell"/g) || []).length,
    atlas.unwrapped.rows.length * 32);
  assert.match(unwrap, /atlas-seam-start/);
  assert.match(unwrap, /atlas-seam-cyclic/);
  assert.match(fragment, /^<section class="cave-atlas"/);
  assert.match(fragment, /A &lt; B/);
  assert.match(fragment, /data-seam-sector="25"/);
  assert.doesNotMatch(fragment, /<canvas|data:image/);
});
