import { test } from 'node:test';
import assert from 'node:assert/strict';

import { buildReferenceRoots } from '../src/core/landmarks/families/roots.js';
import { LANDMARK_MAX_PIECES, pieceSafe } from '../src/core/landmarks/safety.js';
import { mulberry32 } from '../src/core/landmarks/rng.js';
import { buildCompositionAccums } from '../src/render/landmarks/LandmarkMeshBuilder.js';

const CX = 1.5, CY = -2.25, Z = 9050;
const INNER = 4, OUTER = 15.5, WALL = 17;

function build(seed = 2024, inner = INNER, outer = OUTER, wall = WALL) {
  return buildReferenceRoots(mulberry32(seed), CX, CY, Z, inner, outer, wall);
}

function endpoint(piece, sign) {
  const h = piece.length / 2 * sign;
  return { x: piece.cx + piece.dx * h, y: piece.cy + piece.dy * h, z: piece.cz + piece.dz * h };
}

function radial(point) { return Math.hypot(point.x - CX, point.y - CY); }
function form(pieces, gid) { return pieces.filter((p) => p.gid === gid).sort((a, b) => a.node - b.node); }
function nodes(pieces, gid) {
  const chain = form(pieces, gid);
  return [endpoint(chain[0], -1), ...chain.map((p) => endpoint(p, 1))];
}

test('root composition is deterministic and varies with seed', () => {
  assert.deepEqual(build(2024), build(2024));
  assert.notDeepEqual(build(2024), build(256));
});

test('three trunks carry five parent-attached children within the piece budget', () => {
  const pieces = build();
  const claws = pieces.filter((p) => p.role === 'hero-claw');
  assert.equal(new Set(claws.map((p) => p.gid)).size, 3);
  assert.equal(claws.length, 24);
  assert.equal(pieces.length, 49);
  assert.equal(new Set(pieces.map((p) => p.componentGid)).size, 3);
  assert.equal(pieces.some((p) => p.role === 'wall-spine' || p.role === 'hero-arch'), false);
  for (let claw = 0; claw < 3; claw++) {
    assert.deepEqual(form(pieces, `root-tree-${claw}`).map((p) => p.node),
      [0, 1, 2, 3, 4, 5, 6, 7]);
  }
  const children = pieces.filter((p) => p.parentGid && p.node === 0);
  assert.equal(children.length, 5);
  for (const child of children) {
    const parent = form(pieces, child.parentGid), attachment = nodes(pieces, child.parentGid)[child.parentNode];
    const start = endpoint(child, -1);
    assert.ok(Math.hypot(start.x - attachment.x, start.y - attachment.y,
      start.z - attachment.z) < 1e-9);
    assert.equal(child.wallRooted, false);
    assert.ok(child.radius < parent[child.parentNode].radius * 0.7,
      'substantial branches retain a smaller section than their parent');
    const prior = nodes(pieces, child.parentGid)[child.parentNode - 1];
    const after = nodes(pieces, child.parentGid)[child.parentNode + 1];
    const delta = [after.x - prior.x, after.y - prior.y, after.z - prior.z];
    const cosine = (delta[0] * child.dx + delta[1] * child.dy + delta[2] * child.dz) / Math.hypot(...delta);
    assert.ok(cosine > 0.8, 'initial fork follows parent rather than forming a T');
  }
});

test('trunks taper along monotone reaches and substantial branches taper separately', () => {
  for (const seed of [1, 256, 2024, 4096]) {
    const pieces = build(seed);
    for (let claw = 0; claw < 3; claw++) {
      const chain = form(pieces, `root-tree-${claw}`);
      const n = nodes(pieces, `root-tree-${claw}`);
      const base = chain[0].radius, tip = chain.at(-1).radius;
      assert.ok(base / tip > 2.5, `${claw}: distinct taper`);
      assert.ok(chain[0].wallContact && chain[1].wallContact);
      assert.ok(Math.abs(radial(n[0]) - WALL) < 2e-4, 'wall-authored base');
      for (let i = 1; i < n.length; i++) {
        assert.ok(radial(n[i]) < radial(n[i - 1]), `${claw}/${i}: reaches inward`);
        assert.ok(n[i].z < n[i - 1].z, `${claw}/${i}: no U-turn`);
      }
    }
    for (const child of pieces.filter((p) => p.parentGid && p.node === 0)) {
      const chain = form(pieces, child.gid);
      assert.ok(chain[0].radius / chain.at(-1).radius > 2.5);
      assert.ok(chain.reduce((sum, p) => sum + p.length, 0) > 6,
        'side branch is a substantial reach');
    }
  }
});

test('root pieces retain tube and wall safety over narrow and wide room envelopes', () => {
  const envelopes = [
    { inner: 3, outer: 8, wall: 8.7 },
    { inner: 4, outer: 15.5, wall: 17 },
    { inner: 5.2, outer: 8.1, wall: 8.8 },
  ];
  for (const e of envelopes) for (let seed = 1; seed <= 100; seed++) {
    const pieces = build(seed, e.inner, e.outer, e.wall);
    assert.equal(pieces.length, 49, `seed ${seed}: no authored piece discarded`);
    assert.ok(pieces.length <= LANDMARK_MAX_PIECES);
    assert.ok(pieces.every((p) => p.shape === 'limb' && (p.wallRooted || p.parentGid)));
    for (const p of pieces) {
      assert.ok(pieceSafe(p, CX, CY, e.inner, e.wall), `seed ${seed}: ${p.gid}/${p.node}`);
    }
    for (const p of pieces.filter((piece) => piece.node === 0 && piece.wallRooted)) {
      assert.ok(radial(endpoint(p, -1)) + p.radius >= e.wall,
        `seed ${seed}: ${p.gid} embedded at the wall`);
    }
  }
});

test('root geometry stays within the piece and triangle budgets', () => {
  for (const seed of [1, 256, 2024, 4096]) {
    const pieces = build(seed);
    const forms = new Map();
    for (const p of pieces) forms.set(p.gid, (forms.get(p.gid) || 0) + 1);
    const collisionCapsules = pieces.length + [...forms.values()].reduce((n, count) => n + count - 1, 0);
    assert.ok(collisionCapsules <= 120, `${collisionCapsules} collision capsules`);
    const { rock, crystal } = buildCompositionAccums({ typeName: 'branching', pieces });
    assert.ok(crystal.empty());
    assert.ok(rock.i.length / 3 <= 1800, `${rock.i.length / 3} root triangles`);
  }
});
