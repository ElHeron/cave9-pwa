import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';

import { Game } from '../src/core/Game.js';
import { compositionAt, roomZ } from '../src/core/Landmarks.js';
import { buildRootSurface } from '../src/core/landmarks/RootSurface.js';
import { buildReferenceRoots } from '../src/core/landmarks/families/roots.js';
import { mulberry32 } from '../src/core/landmarks/rng.js';
import { queryNearestSurface } from '../src/core/SurfaceQuery.js';
import { pathFrameAt } from '../src/core/FlightPath.js';
import { growTubeForm } from '../src/render/landmarks/LandmarkMeshBuilder.js';
import { MeshAccum } from '../src/render/landmarks/MeshAccum.js';

function composition(seed) {
  const game = new Game();
  game.start({ mode: 2, seed, family: 'branching' });
  game.cave.generateThrough(roomZ(9) + 120);
  return { cave: game.cave, comp: compositionAt(seed, game.cave, 9, 'branching') };
}

function formFor(comp, gid) {
  return comp.pieces.filter((p) => p.gid === gid)
    .sort((a, b) => a.node - b.node);
}

function signedOutwardFromWall(seed, cave, point) {
  const wall = queryNearestSurface(cave, point).wall;
  const frame = pathFrameAt(seed, point[2]);
  const dx = point[0] - frame.center.x, dy = point[1] - frame.center.y,
    dz = point[2] - frame.center.z;
  const rx = dx * frame.right.x + dy * frame.right.y + dz * frame.right.z;
  const ry = dx * frame.up.x + dy * frame.up.y + dz * frame.up.z;
  const n = Math.hypot(rx, ry);
  const radial = [(frame.right.x * rx + frame.up.x * ry) / n,
    (frame.right.y * rx + frame.up.y * ry) / n,
    (frame.right.z * rx + frame.up.z * ry) / n];
  return (point[0] - wall.qx) * radial[0]
    + (point[1] - wall.qy) * radial[1]
    + (point[2] - wall.qz) * radial[2];
}

test('Core root surfaces reproduce deterministic visible buffers without renderer geometry', () => {

  for (const seed of [2024, 256, 4096]) {
    const { comp } = composition(seed);
    const repeated = composition(seed).comp;
    assert.deepEqual(comp.pieces, repeated.pieces);
    assert.deepEqual(comp.rootSurfaces, repeated.rootSurfaces,
      'independent fresh compositions reproduce every exact Core buffer');
    assert.equal(comp.rootSurfaces?.length, 8);
    assert.equal(Object.keys(comp).includes('rootSurfaces'), false,
      'the shared geometry cache does not alter public composition serialization');
    assert.equal(({ ...comp }).rootSurfaces, undefined);
    for (const { gid } of comp.rootSurfaces) {
      const form = formFor(comp, gid);
      const surface = comp.rootSurfaces.find((entry) => entry.gid === form[0].gid);
      assert.ok(surface);
      assert.equal(surface.piece, form[0]);
      assert.ok(surface.vertices instanceof Float64Array);
      assert.ok(surface.visibleTriangles instanceof Uint32Array);
      assert.ok(surface.queryClosureTriangles instanceof Uint32Array);
      assert.equal(surface.visibleVertexCount, form.length === 8 ? 154 : 103);
      assert.equal(surface.visibleTriangles.length / 3, form.length * 32 + 16);
      assert.equal(surface.uvs.length, surface.vertices.length / 3 * 2);
      assert.equal(surface.along.length, surface.vertices.length / 3);
      const rebuilt = buildRootSurface(comp, form);
      assert.deepEqual(rebuilt.vertices, surface.vertices);
      assert.deepEqual(rebuilt.visibleTriangles, surface.visibleTriangles);

      const acc = new MeshAccum();
      growTubeForm(acc, comp, form, 'limb', form[0].shade);
      const repeatedAcc = new MeshAccum();
      const repeatedForm = formFor(repeated, gid);
      growTubeForm(repeatedAcc, repeated, repeatedForm, 'limb', repeatedForm[0].shade);
      for (const buffer of ['p', 'u', 'i', 'c', 'contact']) {
        assert.deepEqual(acc[buffer], repeatedAcc[buffer], `${gid}: deterministic ${buffer}`);
      }
      assert.equal(acc.p.length, surface.visibleVertexCount * 3);
      assert.equal(acc.i.length, surface.visibleTriangles.length);
      for (let i = 0; i < acc.p.length; i++) {
        assert.ok(Math.abs(acc.p[i] - surface.vertices[i]) < 1e-10);
      }
      for (let i = 0; i < acc.i.length; i++) assert.equal(acc.i[i], surface.visibleTriangles[i]);
      for (let i = 0; i < acc.u.length; i++) assert.equal(acc.u[i], surface.uvs[i]);
    }
  }

});

test('root strips cover every visible triangle exactly once and the wall cap closes the mesh', () => {
  for (const seed of [2024, 256, 4096]) {
    const { comp } = composition(seed);
    for (const surface of comp.rootSurfaces) {
      assert.equal(surface.strips.length, formFor(comp, surface.gid).length + 1);
      let cursor = 0;
      for (const strip of surface.strips) {
        assert.equal(strip.start, cursor);
        assert.equal(strip.count % 3, 0);
        cursor += strip.count;
        for (let j = strip.start; j < cursor; j++) {
          const offset = surface.visibleTriangles[j] * 3;
          for (let axis = 0; axis < 3; axis++) {
            const value = surface.vertices[offset + axis];
            assert.ok(value >= strip.bounds.min[axis] - 1e-9
              && value <= strip.bounds.max[axis] + 1e-9);
          }
        }
      }
      assert.equal(cursor, surface.visibleTriangles.length);
      assert.equal(surface.queryClosureTriangles.length / 3, 16);
      assert.equal(surface.closureKind, surface.piece.parentGid ? 'base-plane-fan' : 'wall-buried-fan');
      assert.equal(surface.vertices.length / 3, surface.visibleVertexCount + 1);
      const edgeUses = new Map();
      const vertexKey = (index) => Array.from(surface.vertices.slice(index * 3, index * 3 + 3))
        .map((v) => v.toFixed(7)).join(',');
      for (const indices of [surface.visibleTriangles, surface.queryClosureTriangles]) {
        for (let i = 0; i < indices.length; i += 3) {
          for (const [a, b] of [[indices[i], indices[i + 1]],
            [indices[i + 1], indices[i + 2]], [indices[i + 2], indices[i]]]) {
            const ak = vertexKey(a), bk = vertexKey(b);
            const key = ak < bk ? `${ak}|${bk}` : `${bk}|${ak}`;
            const sign = ak < bk ? 1 : -1;
            const uses = edgeUses.get(key) || [];
            uses.push(sign); edgeUses.set(key, uses);
          }
        }
      }
      for (const [edge, uses] of edgeUses) {
        assert.deepEqual(uses.sort(), [-1, 1], `${seed}/${surface.gid}: open or reversed edge ${edge}`);
      }
    }
  }
});

test('synthetic roots without a measured wall close at their own first ring', () => {
  const pieces = buildReferenceRoots(mulberry32(2024), 1.5, -2.25, 9050, 4, 15.5, 17);
  const form = pieces.filter((p) => p.gid === 'root-tree-0').sort((a, b) => a.node - b.node);
  const surface = buildRootSurface({ typeName: 'branching', pieces }, form);
  assert.equal(surface.closureKind, 'base-plane-fan');
  assert.equal(surface.queryClosureTriangles.length / 3, 16);
  assert.equal(surface.vertices.length / 3, surface.visibleVertexCount + 1);
  const base = form[0], h = base.length / 2;
  const back = surface.visibleVertexCount * 3;
  assert.ok(Math.hypot(
    surface.vertices[back] - (base.cx - base.dx * h),
    surface.vertices[back + 1] - (base.cy - base.dy * h),
    surface.vertices[back + 2] - (base.cz - base.dz * h),
  ) < 1e-10, 'query cap adds no hidden free-space reach');
});

test('query-only root caps remain behind real CaveStream wall triangles', () => {
  const weights = [[1, 0, 0], [0, 1, 0], [0, 0, 1], [0.5, 0.5, 0],
    [0.5, 0, 0.5], [0, 0.5, 0.5], [1 / 3, 1 / 3, 1 / 3], [0.6, 0.2, 0.2]];
  let checked = 0;
  for (const seed of [2024, 256, 4096]) {
    const { cave, comp } = composition(seed);
    for (const surface of comp.rootSurfaces) {
      if (surface.piece.parentGid) continue; // Child closures are verified inside their parent in collision tests.
      const indices = surface.queryClosureTriangles, vertices = surface.vertices;
      for (let i = 0; i < indices.length; i += 3) {
        const tri = [0, 1, 2].map((j) =>
          Array.from(vertices.slice(indices[i + j] * 3, indices[i + j] * 3 + 3)));
        for (const blend of weights) {
          const point = [0, 1, 2].map((axis) => tri.reduce((sum, v, j) =>
            sum + v[axis] * blend[j], 0));
          assert.ok(signedOutwardFromWall(seed, cave, point) > 0.005,
            `${seed}/${surface.gid}: query cap enters free cave at triangle ${i / 3}`);
          checked++;
        }
      }
    }
  }
  assert.equal(checked, 3 * 3 * 16 * weights.length);
});
