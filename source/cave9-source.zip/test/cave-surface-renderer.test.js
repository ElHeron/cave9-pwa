import test from 'node:test';
import assert from 'node:assert/strict';
import * as THREE from 'three';

import {
  caveSurfaceTextureBytes, configureCaveSurfaceArray, unpackCaveSurfacePixels,
} from '../src/render/Renderer.js';

test('surface transport cells unpack into isolated, vertically-correct array layers', () => {
  // Two 2x2 cells next to one another. Rows are authored top-to-bottom; the
  // runtime buffer is bottom-to-top because DataArrayTexture does not flipY.
  const pixel = (value) => [value, value, value, 255];
  const data = new Uint8ClampedArray([
    ...pixel(1), ...pixel(2), ...pixel(11), ...pixel(12),
    ...pixel(3), ...pixel(4), ...pixel(13), ...pixel(14),
  ]);
  const manifest = {
    width: 2, height: 2, layerCount: 2,
    layers: [
      { id: 'a', index: 0, atlas: { x: 0, y: 0, width: 2, height: 2 } },
      { id: 'b', index: 1, atlas: { x: 2, y: 0, width: 2, height: 2 } },
    ],
  };
  const out = unpackCaveSurfacePixels({ width: 4, height: 2, data }, manifest);
  assert.deepEqual([...out.filter((_, index) => index % 4 === 0)], [3, 4, 1, 2, 13, 14, 11, 12]);
});

test('surface array configuration smooths nearby texels and keeps mip filters at range', () => {
  const texture = configureCaveSurfaceArray(new THREE.DataArrayTexture(
    new Uint8Array(4 * 4 * 4), 2, 2, 4,
  ), 12);
  assert.equal(texture.wrapS, THREE.RepeatWrapping);
  assert.equal(texture.wrapT, THREE.RepeatWrapping);
  assert.equal(texture.colorSpace, THREE.SRGBColorSpace);
  assert.equal(texture.magFilter, THREE.LinearFilter);
  assert.equal(texture.minFilter, THREE.LinearMipmapLinearFilter);
  assert.equal(texture.anisotropy, 4);
  assert.equal(texture.generateMipmaps, true);
});

test('surface array byte estimate includes the complete mip pyramid', () => {
  const bytes = caveSurfaceTextureBytes(128, 128, 53);
  assert.equal(bytes, 128 * 128 * 53 * 4 * 4 / 3);
  assert.ok(bytes < 4.8 * 1024 * 1024);
});
