// WarnState — the one warning model for proximity audio, scene tint and debug
// tint and the debug overlay all read. Run with: npm test
//
// The directionalPan cases moved here from audio.test.js when the pan mapping
// moved out of AudioSystem: it is part of the warning model (which side is the
// danger on), not part of playing a sound.

import { test } from 'node:test';
import assert from 'node:assert/strict';

import { computeWarn, directionalPan } from '../src/core/WarnState.js';
import { predictiveWarn, finalWarn } from '../src/core/Predictive.js';
import { Game, DT } from '../src/core/Game.js';

const runningGame = (seed = 4096) => new Game().start({ mode: 2, seed });

// ---- directional pan -------------------------------------------------------

test('directionalPan: a near LEFT wall pans left (negative)', () => {
  assert.ok(directionalPan(2, 10) < 0, 'left nearer → pan left');
});

test('directionalPan: a near RIGHT wall pans right (positive)', () => {
  assert.ok(directionalPan(10, 2) > 0, 'right nearer → pan right');
});

test('directionalPan: symmetric clearance is centred (0)', () => {
  assert.equal(directionalPan(5, 5), 0);
});

test('directionalPan: no info (both far/unknown) is centred', () => {
  assert.equal(directionalPan(Infinity, Infinity), 0);
  // equal large finite clearances (the Ship default MAX_VALUE) also centre
  assert.equal(directionalPan(Number.MAX_VALUE, Number.MAX_VALUE), 0);
});

test('directionalPan: only one side in range pans fully to that side', () => {
  assert.equal(directionalPan(3, Infinity), -1); // only left → full left
  assert.equal(directionalPan(Infinity, 3), 1);  // only right → full right
});

test('directionalPan: output is always within [-1, 1]', () => {
  for (const [l, r] of [[0, 9], [9, 0], [1, 1], [0.01, 100], [100, 0.01]]) {
    const p = directionalPan(l, r);
    assert.ok(p >= -1 && p <= 1, `pan ${p} out of range for ${l}/${r}`);
  }
});

// ---- computeWarn -----------------------------------------------------------

test('computeWarn: reports the full breakdown', () => {
  const game = runningGame();
  const w = computeWarn(game);
  assert.deepEqual(Object.keys(w).sort(),
    ['final', 'leadDist', 'pan', 'predictive', 'reactive']);
});

test('computeWarn: the snapshot is frozen — a consumer cannot edit the frame', () => {
  const w = computeWarn(runningGame());
  assert.throws(() => { w.final = 0; }, TypeError);
});

test('computeWarn: agrees with the pure probes it is built from', () => {
  const game = runningGame();
  for (let i = 0; i < 300; i++) {
    game.autopilot();
    if (game.step()) break;
    const w = computeWarn(game);
    const pred = predictiveWarn(game.cave, game.player);
    assert.equal(w.reactive, game.score.warnLevel || 0);
    assert.equal(w.predictive, pred.warn);
    assert.equal(w.final, finalWarn(w.reactive, pred.warn));
    assert.equal(w.leadDist, pred.leadDist);
    assert.equal(w.pan, directionalPan(game.player.leftClear, game.player.rightClear));
  }
});

test('computeWarn: final never drops below reactive', () => {
  // The predictive probe exists to light the warning EARLIER. It must never
  // quiet a warning the player has already earned by being close right now.
  const game = runningGame();
  let raised = 0;
  for (let i = 0; i < 3000; i++) {
    game.autopilot();
    if (game.step()) break;
    const w = computeWarn(game);
    assert.ok(w.final >= w.reactive - 1e-12);
    assert.ok(w.final >= 0 && w.final <= 1);
    if (w.final > w.reactive + 1e-9) raised++;
  }
  assert.ok(raised > 0, 'over a whole flight the probe should lead at least once');
});

test('computeWarn: is a read-only view — it never advances the sim', () => {
  const game = runningGame();
  for (let i = 0; i < 60; i++) { game.autopilot(); game.step(); }
  const before = {
    z: game.player.pos[2], time: game.time, dist: game.score.distance,
    score: game.scoreValue(), caveI: game.cave.i, phase: game.phase,
  };
  for (let i = 0; i < 50; i++) computeWarn(game);
  assert.deepEqual({
    z: game.player.pos[2], time: game.time, dist: game.score.distance,
    score: game.scoreValue(), caveI: game.cave.i, phase: game.phase,
  }, before);
});

test('computeWarn: repeated calls on an unchanged frame agree', () => {
  const game = runningGame();
  for (let i = 0; i < 120; i++) { game.autopilot(); if (game.step()) break; }
  assert.deepEqual({ ...computeWarn(game) }, { ...computeWarn(game) });
});

test('computeWarn: the warning does not decide death — collision does', () => {
  // Reading the warning is harmless even at an invalid position. Only the next
  // simulation step runs the authoritative collision and ends the run.
  const game = runningGame(424242);
  const ring = game.cave.segs[game.cave.i];
  game.player.pos[0] = ring[0][0] + 100;
  game.player.pos[1] = ring[0][1] + 100;
  const before = game.phase;
  computeWarn(game);
  assert.equal(game.phase, before, 'warning is read-only even outside the wall');
  game.step();
  assert.equal(game.phase, 'dead');
});

test('computeWarn: a fresh run starts with no warning', () => {
  const w = computeWarn(runningGame());
  assert.equal(w.reactive, 0);
  assert.ok(w.final >= 0);
});

test('computeWarn: DT-stepping and the warning stay independent', () => {
  // Computing the warning between steps must not change what the next step does.
  const a = runningGame(555), b = runningGame(555);
  for (let i = 0; i < 400; i++) {
    a.autopilot(); a.step();
    b.autopilot(); computeWarn(b); b.step(); computeWarn(b);
  }
  assert.equal(a.player.pos[2], b.player.pos[2]);
  assert.equal(a.scoreValue(), b.scoreValue());
  assert.equal(a.time, b.time);
  assert.ok(Math.abs(a.time - 400 * DT) < 1e-9);
});
