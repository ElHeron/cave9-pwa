// Pure renderer helpers. Run with: npm test
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

import {
  caveGeomKey, caveGeomChanged, caveGeomUpdateMode, caveDrawRange,
  caveVertexColor, corridorCoilCrest, cameraFarFor,
  configureCaveTexture, Renderer, webglRendererIdentity,
  configureCaveReliefTexture,
} from '../src/render/Renderer.js';
import * as THREE from 'three';
import { CaveStream } from '../src/core/CaveStream.js';
import { COILING_MAX_RIDGE_STRENGTH } from '../src/core/CoilingShell.js';
import { SECTOR_COUNT } from '../src/core/constants.js';
import { roomShellAt } from '../src/core/RoomState.js';

function geometryProbe() {
  const probe = Object.create(Renderer.prototype);
  probe.caveGeo = new THREE.BufferGeometry();
  probe.surfaceVariantOverride = null;
  probe.caveSurface = null;
  probe.surfaceMaterialActive = false;
  probe.caveSurfaceTexture = null;
  probe.caveSurfaceManifest = null;
  return probe;
}

const CAVE_ATTRIBUTES = [
  'positions', 'uvs', 'colors', 'coilingCrests', 'caveSurfaceLocals',
  'caveSurfaceStates', 'caveSurfaceMixes', 'caveRoomWeights',
];

function assertCaveAttributesByteEqual(actual, expected) {
  for (const name of CAVE_ATTRIBUTES) {
    const a = actual[name], b = expected[name];
    assert.equal(a.byteLength, b.byteLength, `${name} byte length`);
    assert.deepEqual(Buffer.from(a.buffer, a.byteOffset, a.byteLength),
      Buffer.from(b.buffer, b.byteOffset, b.byteLength), `${name} differs from full rebuild`);
  }
}

// ---- Phase 4C / L1: per-frame cave-geometry rebuild gate -------------------
// Pure, WebGL-free helpers that decide when the cave geometry must be rebuilt.
// A minimal fake cave: segs[i][0] is the front ring's first vertex [x,y,z].
function fakeCave(i, frontZ) {
  const segs = [];
  for (let k = 0; k < 64; k++) segs[k] = [[0, 0, k === i ? frontZ : 0]];
  return { i, segs };
}

test('caveGeomChanged: first frame (no prior key) always rebuilds', () => {
  assert.equal(caveGeomChanged(null, fakeCave(0, 0)), true);
});

test('caveGeomChanged: unchanged cave (same i, same front-z) skips', () => {
  const cave = fakeCave(5, 123.5);
  const key = caveGeomKey(cave);
  assert.equal(caveGeomChanged(key, cave), false); // no new ring → skip
});

test('caveGeomChanged: a carved ring (i advances) forces a rebuild', () => {
  const key = caveGeomKey(fakeCave(5, 123.5));
  assert.equal(caveGeomChanged(key, fakeCave(6, 125.5)), true);
});

test('caveGeomChanged: front-z change alone forces a rebuild', () => {
  const key = caveGeomKey(fakeCave(5, 123.5));
  // same write head but the front ring moved forward → geometry changed
  assert.equal(caveGeomChanged(key, fakeCave(5, 130.0)), true);
});

test('caveGeomChanged: a different cave object always rebuilds', () => {
  // switching between the run cave and the menu-demo cave must never be skipped,
  // even if i and front-z coincide
  const a = fakeCave(5, 123.5);
  const b = fakeCave(5, 123.5);
  const key = caveGeomKey(a);
  assert.equal(caveGeomChanged(key, b), true);
});

test('caveGeomChanged: resetting the same CaveStream generation rebuilds', () => {
  const cave = fakeCave(5, 123.5);
  cave.generation = 1;
  const key = caveGeomKey(cave);
  cave.generation = 2;
  assert.equal(caveGeomChanged(key, cave), true);
});

test('one emitted CaveStream ring reuses rows byte-identically across every cave attribute', () => {
  const cave = new CaveStream();
  cave.reset(2024, 'coiling');
  cave.prime();
  cave.generateThrough(9010);
  const reused = geometryProbe();
  reused._updateCaveGeometry(cave);
  for (let step = 0; step < 3; step++) {
    const previous = reused._geomKey;
    cave.generateThrough(cave._lastRingDepth + 2);
    assert.equal(caveGeomUpdateMode(previous, cave), 'shift');
    reused._updateCaveGeometry(cave);
    const full = geometryProbe();
    full._updateCaveGeometry(cave);
    assertCaveAttributesByteEqual(reused, full);
    full.caveGeo.dispose();
  }
  reused.caveGeo.dispose();
});

test('C3 accents follow actual displaced sectors while corridor crests yield inside the room', () => {
  const cave = new CaveStream();
  cave.reset(2024, 'coiling');
  cave.prime();
  cave.generateThrough(9200);
  const probe = geometryProbe();
  probe._updateCaveGeometry(cave);
  let checkedActiveRings = 0;
  let checkedCorridorSectors = 0;
  let suppressedCorridorSectors = 0;
  for (let row = 0; row < cave.segs.length; row++) {
    const buf = (cave.i + row) % cave.segs.length;
    const weight = roomShellAt(cave.centers[buf][2]).weight;
    const values = [];
    for (let sector = 0; sector < SECTOR_COUNT; sector++) {
      const physicalSector = sector + (cave.ringAngleOffsets?.[buf] || 0)
        * SECTOR_COUNT / (Math.PI * 2);
      const familyCrest = Math.min(1, Math.max(0,
        cave.coilingInsets[buf][sector] / COILING_MAX_RIDGE_STRENGTH));
      const corridorCrest = corridorCoilCrest(physicalSector, cave.seed, cave.centers[buf][2]);
      const actual = probe.coilingCrests[row * SECTOR_COUNT + sector];
      if (weight === 0) {
        assert.equal(actual, Math.fround(corridorCrest), 'ordinary corridor retains its own crest');
        checkedCorridorSectors++;
      } else if (weight >= 0.8) {
        assert.equal(actual, Math.fround(familyCrest), 'full C3 room accents only its actual wall crest');
        if (corridorCrest > familyCrest + 0.01) suppressedCorridorSectors++;
      } else {
        assert.ok(actual >= Math.fround(familyCrest)
          && actual <= Math.fround(Math.max(familyCrest, corridorCrest)),
        'shoulder transition never erases the physical crest or amplifies the legacy one');
      }
      values.push(actual);
    }
    if (!(cave.coilingStrengths[buf] > 4) || weight < 0.8) continue;
    assert.ok(Math.max(...values) - Math.min(...values) > 0.15,
      'untouched wall sectors must not inherit a full C3 ridge accent');
    checkedActiveRings++;
  }
  assert.ok(checkedActiveRings > 30, 'the test covers the full continuous room crest');
  assert.ok(checkedCorridorSectors > 100, 'ordinary corridor preservation is exercised');
  assert.ok(suppressedCorridorSectors > 100, 'the old competing room stripe is actually removed');
  probe.caveGeo.dispose();
});

test('rotating C3 columns keep colour and texture phase on the actual wall angle', () => {
  const cave = new CaveStream();
  cave.reset(2024, 'coiling');
  cave.prime();
  cave.generateThrough(9200);
  const probe = geometryProbe();
  probe._updateCaveGeometry(cave);
  let rotated = 0;
  for (let row = 0; row < cave.segs.length; row++) {
    const buf = (cave.i + row) % cave.segs.length;
    const offset = cave.ringAngleOffsets?.[buf] || 0;
    if (Math.abs(offset) < 0.01) continue;
    const frame = cave.frames[buf], center = cave.centers[buf];
    for (let sector = 0; sector < SECTOR_COUNT; sector++) {
      const v = cave.segs[buf][sector];
      const delta = v.map((value, i) => value - center[i]);
      const right = delta[0] * frame.right.x + delta[1] * frame.right.y + delta[2] * frame.right.z;
      const up = delta[0] * frame.up.x + delta[1] * frame.up.y + delta[2] * frame.up.z;
      const physicalSector = sector + offset * SECTOR_COUNT / (Math.PI * 2);
      const materialAngle = Math.PI / 2 + (physicalSector - 1) * Math.PI * 2 / SECTOR_COUNT;
      const actualAngle = Math.atan2(up, right);
      assert.ok(Math.abs(Math.atan2(Math.sin(actualAngle - materialAngle),
        Math.cos(actualAngle - materialAngle))) < 1e-10, 'material angle follows the actual vertex');
      const at = row * SECTOR_COUNT + sector;
      assert.equal(probe.uvs[at * 2], Math.fround(physicalSector / SECTOR_COUNT * 4));
      const expected = caveVertexColor(...v, physicalSector, cave.seed, center[2]);
      for (let channel = 0; channel < 3; channel++) {
        assert.equal(probe.colors[at * 3 + channel], Math.fround(expected[channel]));
      }
    }
    rotated++;
  }
  assert.ok(rotated > 30, 'the check must exercise the real rotated C3 lattice');
  probe.caveGeo.dispose();
});

test('cave row reuse fails closed on multi-ring, wrap, generation and variant changes', () => {
  const cave = new CaveStream();
  cave.reset(256, 'coiling');
  cave.prime();
  const probe = geometryProbe();
  probe._updateCaveGeometry(cave);
  const first = probe._geomKey;
  cave.generateThrough(cave._lastRingDepth + 4);
  assert.equal(caveGeomUpdateMode(first, cave), 'full', 'two emitted rings require full rebuild');
  probe._updateCaveGeometry(cave);
  const discontinuous = { ...probe._geomKey, i: probe._geomKey.i - 1,
    ringDepth: probe._geomKey.ringDepth - 2,
    centerDepth: probe._geomKey.centerDepth - 2.25 };
  assert.equal(caveGeomUpdateMode(discontinuous, cave), 'full',
    'an inexact spatial center step cannot reuse a row');
  assert.equal(caveGeomUpdateMode({ ...probe._geomKey, capacity: cave.segs.length - 1 }, cave),
    'full', 'capacity changes require full rebuild');
  assert.equal(caveGeomUpdateMode(probe._geomKey, cave, 'S2'), 'full',
    'surface variant changes require full rebuild');
  cave.generation++;
  assert.equal(caveGeomUpdateMode(probe._geomKey, cave), 'full',
    'same-object reset generation requires full rebuild');
  probe._updateCaveGeometry(cave);
  while (cave.i !== cave.segs.length - 1) cave.generateThrough(cave._lastRingDepth + 2);
  probe._updateCaveGeometry(cave);
  const beforeWrap = probe._geomKey;
  cave.generateThrough(cave._lastRingDepth + 2);
  assert.equal(cave.i, 0);
  assert.equal(caveGeomUpdateMode(beforeWrap, cave), 'full', 'head wrap requires full rebuild');
  probe._updateCaveGeometry(cave);
  const full = geometryProbe();
  full._updateCaveGeometry(cave);
  assertCaveAttributesByteEqual(probe, full);
  probe.caveGeo.dispose();
  full.caveGeo.dispose();
});

test('caveDrawRange submits only ring pairs intersecting the fog interval', () => {
  const centers = Array.from({ length: 144 }, (_, i) => [0, 0, i * 2]);
  const range = caveDrawRange({ i: 0, centers }, 100, 40, 0);

  // Rings 50..70 are in [100, 140]. The camera-straddling pair 49 is omitted
  // and pair 70 leaves the interval, so the visible strip has 21 ring pairs.
  assert.deepEqual(range, {
    start: 50 * 32 * 6,
    count: 21 * 32 * 6,
    firstPair: 50,
    pairCount: 21,
  });
});

test('caveDrawRange respects circular-buffer spatial order', () => {
  const centers = Array.from({ length: 144 }, () => [0, 0, -999]);
  const cave = { i: 140, centers };
  for (let s = 0; s < 144; s++) centers[(cave.i + s) % 144][2] = s * 3;

  const range = caveDrawRange(cave, 30, 9, 0);
  assert.equal(range.firstPair, 10);
  assert.equal(range.pairCount, 4);
  assert.equal(range.start, 10 * 32 * 6);
  assert.equal(range.count, 4 * 32 * 6);
});

test('camera far plane never clips the difficulty-driven fog distance', () => {
  for (const fogFar of [64, 192, 271, 800, 5000]) {
    assert.ok(cameraFarFor(fogFar) > fogFar);
  }
});

test('cave detail texture uses mirrored wrapping and bounded anisotropy', () => {
  const texture = configureCaveTexture(new THREE.Texture(), 16);
  assert.equal(texture.wrapS, THREE.MirroredRepeatWrapping);
  assert.equal(texture.wrapT, THREE.MirroredRepeatWrapping);
  assert.equal(texture.colorSpace, THREE.SRGBColorSpace);
  assert.equal(texture.anisotropy, 2);
  assert.equal(texture.generateMipmaps, true);
  assert.ok(texture.version > 0, 'configuration marks the texture for upload');
});

test('normal and height maps remain linear-data textures with bounded anisotropy', () => {
  const texture = configureCaveReliefTexture(new THREE.Texture(), 16);
  assert.equal(texture.wrapS, THREE.MirroredRepeatWrapping);
  assert.equal(texture.wrapT, THREE.MirroredRepeatWrapping);
  assert.equal(texture.colorSpace, THREE.NoColorSpace);
  assert.equal(texture.anisotropy, 2);
  assert.equal(texture.generateMipmaps, true);
  assert.equal(texture.format, THREE.RGBAFormat);
  const webgl2Height = configureCaveReliefTexture(new THREE.Texture(), 16,
    { heightOnly: true, webgl2: true });
  assert.equal(webgl2Height.format, THREE.RedFormat);
  assert.equal(webgl2Height.unpackAlignment, 1);
  assert.equal(webgl2Height.colorSpace, THREE.NoColorSpace);
  const webgl1Height = configureCaveReliefTexture(new THREE.Texture(), 16,
    { heightOnly: true, webgl2: false });
  assert.equal(webgl1Height.format, THREE.RGBAFormat);
});

test('surface relief is hardware-only and compiles out when disabled', async () => {
  const renderer = Object.create(Renderer.prototype);
  const normal = new THREE.Texture(), height = new THREE.Texture();
  renderer.surfaceRelief = false;
  renderer.surfaceReliefRequested = false;
  renderer.gpuIdentity = { vendor: 'NVIDIA', renderer: 'RTX', software: false };
  renderer.surfaceReliefProfile = 'cave';
  renderer._surfaceReliefAssets = new Map([['cave', { normal, height }]]);
  renderer._surfaceReliefPromises = new Map();
  renderer.caveFacet = {
    reliefNormalMap: { value: null }, reliefHeightMap: { value: null },
    reliefStrength: { value: 0 },
  };
  renderer.caveMat = { defines: {}, needsUpdate: false };
  renderer.assetMetrics = { reliefProfile: null };
  renderer._loadSurfaceRelief = async (profile) => renderer._surfaceReliefAssets.get(profile);

  assert.equal(await renderer.setSurfaceRelief(true, 'cave'), true);
  assert.equal(renderer.caveFacet.reliefNormalMap.value, normal);
  assert.equal(renderer.caveFacet.reliefHeightMap.value, height);
  assert.equal(renderer.caveFacet.reliefStrength.value, 1);
  assert.equal(renderer.caveMat.defines.CAVE_RELIEF_MAPS, 1);
  assert.equal(renderer.assetMetrics.reliefProfile, 'cave');

  assert.equal(await renderer.setSurfaceRelief(false), false);
  assert.equal(renderer.caveFacet.reliefStrength.value, 0);
  assert.equal('CAVE_RELIEF_MAPS' in renderer.caveMat.defines, false,
    'default shader recompiles without either additional texture sample');
  assert.equal(renderer.assetMetrics.reliefProfile, null);
});

test('surface relief switches preloaded Cave/Coiling maps by live ring authority without recompiling', () => {
  const renderer = Object.create(Renderer.prototype);
  const cave = { normal: new THREE.Texture(), height: new THREE.Texture() };
  const coiling = { normal: new THREE.Texture(), height: new THREE.Texture() };
  renderer.surfaceRelief = true;
  renderer.surfaceReliefProfile = 'cave';
  renderer.gpuIdentity = { vendor: 'NVIDIA', renderer: 'RTX', software: false };
  renderer._surfaceReliefAssets = new Map([['cave', cave], ['coiling', coiling]]);
  renderer.caveFacet = {
    reliefNormalMap: { value: cave.normal }, reliefHeightMap: { value: cave.height },
    reliefStrength: { value: 1 },
  };
  renderer.caveMat = { defines: { CAVE_RELIEF_MAPS: 1 }, needsUpdate: false };
  renderer.assetMetrics = { reliefProfile: 'cave' };

  renderer._syncSurfaceReliefProfile({ coilingStrengths: new Float32Array([0, 0.5, 0]) });
  assert.equal(renderer.surfaceReliefProfile, 'coiling');
  assert.equal(renderer.caveFacet.reliefNormalMap.value, coiling.normal);
  assert.equal(renderer.caveFacet.reliefHeightMap.value, coiling.height);
  assert.equal(renderer.caveMat.needsUpdate, false,
    'preloaded profile changes only uniforms and cannot trigger a room-entry compile');

  renderer._syncSurfaceReliefProfile({ coilingStrengths: new Float32Array(3) });
  assert.equal(renderer.surfaceReliefProfile, 'cave');
  assert.equal(renderer.caveFacet.reliefNormalMap.value, cave.normal);
  assert.equal(renderer.caveMat.needsUpdate, false);
});

test('software rejects requested surface samplers while reporting the fallback', async () => {
  const renderer = Object.create(Renderer.prototype);
  renderer.gpuIdentity = { vendor: 'Google', renderer: 'SwiftShader', software: true };
  renderer.surfaceReliefRequested = false;
  renderer.surfaceRelief = false;
  renderer.surfaceReliefProfile = 'cave';
  renderer.caveFacet = { reliefStrength: { value: 0 } };
  renderer.caveMat = { defines: {}, needsUpdate: false };
  renderer.assetMetrics = { reliefProfile: null };
  renderer._loadSurfaceRelief = () => { throw new Error('software must not load relief maps'); };
  assert.equal(await renderer.setSurfaceRelief(true, 'cave'), false);
  assert.equal(renderer.surfaceReliefRequested, true);
  assert.equal(renderer.surfaceRelief, false);
  assert.equal(renderer.assetMetrics.reliefProfile, null);
});

test('WebGL identity detects software rasterizers without making identity mandatory', () => {
  const ext = { UNMASKED_VENDOR_WEBGL: 100, UNMASKED_RENDERER_WEBGL: 101 };
  const swift = webglRendererIdentity({
    VENDOR: 1, RENDERER: 2,
    getExtension: () => ext,
    getParameter: (key) => key === 100 ? 'Google Inc.' : 'ANGLE (SwiftShader Device)',
  });
  assert.equal(swift.software, true);
  assert.match(swift.renderer, /SwiftShader/);

  const hardware = webglRendererIdentity({
    VENDOR: 1, RENDERER: 2,
    getExtension: () => null,
    getParameter: (key) => key === 1 ? 'NVIDIA' : 'RTX 4060',
  });
  assert.deepEqual(hardware, { vendor: 'NVIDIA', renderer: 'RTX 4060', software: false });
  assert.deepEqual(webglRendererIdentity(null), { vendor: '', renderer: '', software: false });
});

test('software fallback keeps authoritative cave colours but removes fragment detail work', () => {
  const renderer = Object.create(Renderer.prototype);
  renderer.caveFacet = { value: 0, detailStrength: { value: 0 } };
  renderer.caveMat = { defines: { CAVE_DETAIL_MAPS: 1 }, needsUpdate: false };
  renderer.caveTexture = {};
  renderer.rockDetail = true;
  renderer.surfaceReliefRequested = true;
  renderer.surfaceRelief = false;
  renderer.assetMetrics = { reliefProfile: null };
  renderer.gpuIdentity = { vendor: 'Google', renderer: 'SwiftShader', software: true };
  renderer.landmarkLayer = { softwareRenderer: true };
  renderer.coilingRimActive = false;
  renderer._applyRockDetail();
  assert.equal(renderer.caveFacet.value, 0, 'fragment facets are disabled on software');
  assert.equal(renderer.caveFacet.detailStrength.value, 0, 'the expensive sample is disabled');
  assert.equal('CAVE_DETAIL_MAPS' in renderer.caveMat.defines, false,
    'software program compiles the complete sample block out');
  assert.equal(renderer.caveMat.needsUpdate, true);
  assert.equal(renderer.rockDetailSampleActive, false);
  assert.deepEqual(renderer.renderCapabilities(), {
    gpu: { vendor: 'Google', renderer: 'SwiftShader', software: true },
    rockDetailRequested: true,
    rockFacetActive: false,
    rockFacetSoftwareFallback: true,
    rockDetailSampleActive: false,
    surfaceMaterialActive: false,
    surfaceArraySupported: false,
    surfaceArrayLayers: 0,
    surfaceArrayTextureBytes: 0,
    rockDetailSoftwareFallback: true,
    surfaceReliefRequested: true,
    surfaceReliefActive: false,
    surfaceReliefProfile: null,
    surfaceReliefSoftwareFallback: true,
    landmarkMineralActive: false,
    landmarkRimActive: true,
    landmarkSoftwareFallback: true,
    landmarkLightingModel: 'lambert',
    coilingRimActive: false,
    coilingRimSoftwareFallback: false,
  });

  renderer._syncCoilingRim({ coilingStrengths: new Float32Array([0, 0.5, 0]) });
  assert.equal(renderer.coilingRimActive, true);
  assert.equal(renderer.caveMat.defines.CAVE_COILING_RIM, 1);
  assert.equal(renderer.caveMat.needsUpdate, true);
  renderer.caveMat.needsUpdate = false;
  renderer._syncCoilingRim({ coilingStrengths: new Float32Array(3) });
  assert.equal(renderer.coilingRimActive, false);
  assert.equal('CAVE_COILING_RIM' in renderer.caveMat.defines, false);
  assert.equal(renderer.caveMat.needsUpdate, true);

  renderer.gpuIdentity = { vendor: 'NVIDIA', renderer: 'RTX', software: false };
  renderer.landmarkLayer.softwareRenderer = false;
  renderer.caveMat.needsUpdate = false;
  renderer._applyRockDetail();
  assert.equal(renderer.caveFacet.detailStrength.value, 1, 'hardware retains the texture sample');
  assert.equal(renderer.caveMat.defines.CAVE_DETAIL_MAPS, 1);
  assert.equal(renderer.caveMat.needsUpdate, true);
  assert.equal(renderer.rockDetailSampleActive, true);
});

test('renderer asset loading is session-warm and shares one in-flight result', async () => {
  const renderer = Object.create(Renderer.prototype);
  let loads = 0;
  renderer._loadAssets = async () => {
    loads++;
    await Promise.resolve();
    return 'ready';
  };

  const first = renderer.load();
  const second = renderer.load();
  assert.equal(await first, 'ready');
  assert.equal(await second, 'ready');
  assert.equal(loads, 1, 'load/decode/upload preparation is started once per Renderer session');
});

test('texture prewarm uploads each texture once and records failures without throwing', () => {
  const renderer = Object.create(Renderer.prototype);
  let uploads = 0;
  renderer.renderer = { initTexture: () => { uploads++; } };
  renderer._prewarmedTextureIds = new Set();
  renderer.assetMetrics = { texturePrewarms: 0, texturePrewarmFailures: 0 };
  const texture = new THREE.Texture();
  assert.equal(renderer._prewarmTexture(texture), true);
  assert.equal(renderer._prewarmTexture(texture), false);
  assert.equal(uploads, 1);
  assert.equal(renderer.assetMetrics.texturePrewarms, 1);

  renderer.renderer.initTexture = () => { throw new Error('upload'); };
  const originalWarn = console.warn;
  console.warn = () => {};
  try {
    assert.equal(renderer._prewarmTexture(new THREE.Texture()), false);
  } finally {
    console.warn = originalWarn;
  }
  assert.equal(renderer.assetMetrics.texturePrewarmFailures, 1);
});

test('landmark materials compile once during asset prewarm', () => {
  const renderer = Object.create(Renderer.prototype);
  let compiles = 0;
  renderer.renderer = { compile: () => { compiles++; } };
  renderer.camera = new THREE.PerspectiveCamera();
  renderer.landmarkLayer = {
    rockMat: new THREE.MeshStandardMaterial(), crystalMat: new THREE.MeshStandardMaterial(),
  };
  renderer._landmarkProgramsPrewarmed = false;
  renderer.assetMetrics = { landmarkProgramPrewarms: 0, landmarkProgramPrewarmFailures: 0 };
  assert.equal(renderer._prewarmLandmarkMaterials(), true);
  assert.equal(renderer._prewarmLandmarkMaterials(), false);
  assert.equal(compiles, 1);
  assert.equal(renderer.assetMetrics.landmarkProgramPrewarms, 1);
  renderer.landmarkLayer.rockMat.dispose();
  renderer.landmarkLayer.crystalMat.dispose();
});

test('cave relief program is compiled during asset prewarm', () => {
  const renderer = Object.create(Renderer.prototype);
  let compiles = 0;
  renderer.renderer = { compile: () => { compiles++; } };
  renderer.scene = new THREE.Scene();
  renderer.camera = new THREE.PerspectiveCamera();
  renderer.assetMetrics = { caveProgramPrewarms: 0, caveProgramPrewarmFailures: 0 };
  assert.equal(renderer._prewarmCaveMaterial(), true);
  assert.equal(compiles, 1);
  assert.equal(renderer.assetMetrics.caveProgramPrewarms, 1);
});

test('idle renderer contains no removed third-person ship path', () => {
  const source = readFileSync(new URL('../src/render/Renderer.js', import.meta.url), 'utf8');
  assert.doesNotMatch(source, /this\.ship\b/);
  assert.doesNotMatch(source, /new THREE\.MeshBasicMaterial\([\s\S]*?flatShading/);
});

test('caveVertexColor is deterministic, finite and mineral-dark', () => {
  const a = caveVertexColor(1.25, -3.5, 9000, 17);
  assert.deepEqual(a, caveVertexColor(1.25, -3.5, 9000, 17));
  assert.ok(a.every((v) => Number.isFinite(v) && v > 0 && v < 1));
  assert.ok(a[0] < a[1] && a[1] < a[2], 'cool mineral ordering');
});

test('the corridor coil exposes a seed-stable three-start rim without changing geometry', () => {
  const values = Array.from({ length: 32 }, (_, sector) => corridorCoilCrest(sector, 2024, 500));
  assert.deepEqual(values,
    Array.from({ length: 32 }, (_, sector) => corridorCoilCrest(sector, 2024, 500)));
  assert.ok(Math.max(...values) > 0.62, 'raised thread receives a readable rim');
  assert.ok(Math.min(...values) < 0.001, 'channel remains dark');
  const localMaxima = values.filter((value, index) => {
    const previous = values[(index + values.length - 1) % values.length];
    const next = values[(index + 1) % values.length];
    return value > previous && value > next;
  });
  assert.equal(localMaxima.length, 3, 'the visual emphasis preserves the three-start grammar');
});

test('cave amber nests are sparse, deterministic and absent from the original look', () => {
  let earlyWarm = 0, lateWarm = 0;
  let maxLateSaturation = 0;
  for (let z = 0; z < 240; z += 2) for (let sector = 0; sector < 32; sector++) {
    const early = caveVertexColor(3, -2, z, sector);
    const late = caveVertexColor(3, -2, z + 9000, sector);
    if (early[0] > early[2]) earlyWarm++;
    if (late[0] > late[2]) lateWarm++;
    maxLateSaturation = Math.max(maxLateSaturation,
      Math.max(...late) - Math.min(...late));
  }
  assert.equal(earlyWarm, 0, 'style=0 keeps the original cool wall');
  assert.ok(lateWarm > 0, 'full morph contains amber pockets');
  assert.ok(lateWarm < 240 / 2 * 32 * 0.10, 'warm wall area stays below ten percent');
  assert.ok(maxLateSaturation < 0.16, 'pockets stay mineral-brown instead of saturated orange');
});

test('cave mineral variation stays within a form-readable luminance band', () => {
  const luminances = [];
  for (let z = 8800; z < 9240; z += 2) for (let sector = 0; sector < 32; sector++) {
    const [r, g, b] = caveVertexColor(3, -2, z, sector, 2024, z);
    luminances.push(0.2126 * r + 0.7152 * g + 0.0722 * b);
  }
  luminances.sort((a, b) => a - b);
  const at = (p) => luminances[Math.floor((luminances.length - 1) * p)];
  assert.ok(at(0.05) > 0.035, 'lower wall tones must not collapse to black');
  assert.ok(at(0.95) < 0.17, 'vertex colour must not become a competing highlight field');
  assert.ok(at(0.95) / at(0.05) < 4, 'colour variation must preserve the chamber silhouette');
});

test('the standard wall carries a seed-stable textured three-start coil', () => {
  const seed = 4096;
  const values = [];
  for (let sector = 0; sector < 32; sector++) {
    const color = caveVertexColor(4, -3, 500, sector, seed);
    assert.deepEqual(color, caveVertexColor(4, -3, 500, sector, seed));
    values.push(color[2]);
  }
  assert.ok(Math.max(...values) - Math.min(...values) > 0.04,
    'embedded coil threads need visible mineral contrast in the standard corridor');
  assert.notDeepEqual(
    caveVertexColor(4, -3, 500, 7, seed),
    caveVertexColor(4, -3, 500, 7, seed + 1),
    'the texture phase must follow the same seeded coil as wall geometry');
});
