// Collision model edge cases — proves: a centred ship never dies (no false
// deaths), a ship pushed through the wall does die, probes report inside/outside
// correctly, and numeric (NaN/Inf) frames are graced instead of killing.
// Run with: npm test
import { test } from 'node:test';
import assert from 'node:assert/strict';

import { Game } from '../src/core/Game.js';
import { collision, sweptCollision } from '../src/core/CollisionSystem.js';
import { TWO_BUTTONS, SECTOR_COUNT, SHIP_RADIUS } from '../src/core/constants.js';
import { pathFrameAt, tubeRadiusAt } from '../src/core/FlightPath.js';

// Run a fresh seeded game and return it parked mid-cave (no death yet).
function midCaveGame(seed = 4242, steps = 60) {
  const g = new Game();
  g.start({ mode: TWO_BUTTONS, seed });
  for (let i = 0; i < steps; i++) { g.autopilot(); if (g.step()) break; }
  return g;
}

test('a ship centred in the tunnel is NOT a hit (no false death)', () => {
  const g = midCaveGame();
  const p = g.player;
  // place the ship at the centre of the head ring
  const ring = g.cave.segs[g.cave.i];
  let cx = 0, cy = 0;
  for (let j = 0; j < SECTOR_COUNT; j++) { cx += ring[j][0]; cy += ring[j][1]; }
  cx /= SECTOR_COUNT; cy /= SECTOR_COUNT;
  p.pos[0] = cx; p.pos[1] = cy;
  const d = collision(g.cave, p);
  assert.ok(d > 0, `centred ship should be clear, got dist ${d}`);
  assert.ok(p.dist > 0, 'ship.dist should be positive when clear');
  assert.ok(p.probeInside.every(Boolean), 'all 4 probes should read inside when centred');
});

test('a ship shoved far outside the tunnel IS a hit', () => {
  const g = midCaveGame();
  const p = g.player;
  p.pos[0] += 1000; // way outside any ring
  const d = collision(g.cave, p);
  assert.equal(d, 0, 'far-outside ship must register a hit');
  assert.equal(p.dist, 0);
  assert.ok(!p.probeInside.every(Boolean), 'not all probes inside when outside the cave');
});

test('probe positions form the route-local diamond around the ship', () => {
  const g = midCaveGame();
  const p = g.player;
  collision(g.cave, p);
  const r = p.radius;
  let best = 0, gap = Infinity;
  for (let i = 0; i < g.cave.frames.length; i++) {
    const d = Math.abs(g.cave.centers[i][2] - p.pos[2]);
    if (d < gap) { gap = d; best = i; }
  }
  const frame = g.cave.frames[best];
  // [local-left, local-top, local-right, local-bottom]
  assert.ok(Math.abs(p.probePos[0][0] - (p.pos[0] - frame.right.x * r)) < 1e-9);
  assert.ok(Math.abs(p.probePos[0][1] - (p.pos[1] - frame.right.y * r)) < 1e-9);
  assert.ok(Math.abs(p.probePos[1][0] - (p.pos[0] + frame.up.x * r)) < 1e-9);
  assert.ok(Math.abs(p.probePos[1][1] - (p.pos[1] + frame.up.y * r)) < 1e-9);
});

test('directional clearance (L3) is populated and does not change the hit', () => {
  const g = midCaveGame();
  const p = g.player;
  // centre the ship, then nudge it toward the +x (right) wall
  const ring = g.cave.segs[g.cave.i];
  let cx = 0, cy = 0;
  for (let j = 0; j < SECTOR_COUNT; j++) { cx += ring[j][0]; cy += ring[j][1]; }
  cx /= SECTOR_COUNT; cy /= SECTOR_COUNT;
  p.pos[0] = cx; p.pos[1] = cy;

  collision(g.cave, p);
  assert.ok(Number.isFinite(p.leftClear) && Number.isFinite(p.rightClear),
    'both side clearances are measured');
  // Move a safe fraction toward a measured route-frame side. A concave wall can
  // legitimately leave one directional ray open (Number.MAX_VALUE), so select
  // the side with an actual hit instead of assuming world/+X always is Right.
  let frameIndex = 0, frameGap = Infinity;
  for (let i = 0; i < g.cave.frames.length; i++) {
    const gap = Math.abs(g.cave.centers[i][2] - p.pos[2]);
    if (gap < frameGap) { frameGap = gap; frameIndex = i; }
  }
  const right = g.cave.frames[frameIndex].right;
  const towardRight = p.rightClear < Number.MAX_VALUE;
  const measured = towardRight ? p.rightClear : p.leftClear;
  assert.ok(measured < Number.MAX_VALUE, 'at least one side wall is measured');
  const sign = towardRight ? 1 : -1;
  p.pos[0] = cx + right.x * measured * 0.4 * sign;
  p.pos[1] = cy + right.y * measured * 0.4 * sign;
  p.pos[2] += right.z * measured * 0.4 * sign;
  const dSide = collision(g.cave, p);
  assert.ok(dSide > 0, 'still clear near the wall (no false death)');
  assert.ok(towardRight ? p.rightClear < p.leftClear : p.leftClear < p.rightClear,
    `approached wall should read nearer: L=${p.leftClear.toFixed(2)} R=${p.rightClear.toFixed(2)}`);
});

function capsuleAt(p, shape, offset = 0, radius = 0.5) {
  return { pieces: [{
    shape, cx: p.pos[0] + offset, cy: p.pos[1], cz: p.pos[2],
    dx: 0, dy: 0, dz: 1, length: 4, radius,
  }] };
}

for (const [shape, name] of [['limb', 'root'], ['blade', 'blade'], ['rib', 'rib']]) {
  test(`${name} landmark is lethal at contact`, () => {
    const g = midCaveGame(424242, 20);
    assert.equal(collision(g.cave, g.player, [capsuleAt(g.player, shape)]), 0);
    assert.equal(g.player.dist, 0);
  });
}

test('a safe landmark flyby stays clear and reports that same surface', () => {
  const g = midCaveGame(424242, 20);
  const expected = 0.25;
  const comp = capsuleAt(g.player, 'rib', SHIP_RADIUS + 0.5 + expected);
  const d = collision(g.cave, g.player, [comp]);
  assert.ok(Math.abs(d - expected) < 1e-9, `expected capsule clearance ${expected}, got ${d}`);
  assert.ok(g.player.probeInside.every(Boolean), 'wall probes remain clear');
  assert.ok(g.player.repulsion[0] > 0, 'repulsion names the capsule on the right');
  assert.ok(g.player.rightClear < g.player.leftClear, 'directional warning names the same side');
});

test('exact hull contact with a landmark is lethal', () => {
  const g = midCaveGame(424242, 20);
  const caveWithoutWall = { centers: [], segs: [], frames: [], count: 0 };
  const comp = capsuleAt(g.player, 'rib', SHIP_RADIUS + 0.5, 0.5);
  assert.equal(collision(caveWithoutWall, g.player, [comp]), 0,
    'zero clearance is contact, not a safe flyby');
});

test('a deep-speed step cannot tunnel through a thin lethal capsule', () => {
  const g = midCaveGame(424242, 20);
  const p = g.player;
  const from = [p.pos[0], p.pos[1], p.pos[2] - 4];
  const centreZ = p.pos[2];
  const comp = { pieces: [{
    shape: 'blade', cx: p.pos[0], cy: p.pos[1], cz: centreZ,
    dx: 1, dy: 0, dz: 0, length: 0.2, radius: 0.1,
  }] };
  p.pos[2] = centreZ + 4;
  assert.ok(collision(g.cave, p, [comp]) > 0, 'endpoint alone has already passed the blade');
  assert.equal(sweptCollision(g.cave, p, from, [comp]), 0,
    'the swept hull must catch the surface between endpoints');
});

test('numeric crash-grace: a NaN position is graced, not a kill', () => {
  const g = midCaveGame();
  const p = g.player;
  p.pos[0] = NaN;
  const d = collision(g.cave, p);
  assert.ok(p.graced, 'NaN frame should set graced');
  assert.ok(d > 0, 'graced frame returns a safe (non-hit) distance');
  assert.notEqual(p.dist, 0, 'graced frame must not report a wall hit');
});

test('grace only triggers on degenerate frames, not normal play', () => {
  const g = midCaveGame();
  const p = g.player;
  // normal centred frame
  const ring = g.cave.segs[g.cave.i];
  let cx = 0, cy = 0;
  for (let j = 0; j < SECTOR_COUNT; j++) { cx += ring[j][0]; cy += ring[j][1]; }
  p.pos[0] = cx / SECTOR_COUNT; p.pos[1] = cy / SECTOR_COUNT;
  collision(g.cave, p);
  assert.equal(p.graced, false, 'finite normal frame must not be graced');
});

test('no false deaths across a long autopilot flight', () => {
  // The analytic Boolean tube is an independent oracle: every visible surface
  // is outside it, so a death while the complete hull remains inside is false.
  const g = new Game();
  g.start({ mode: TWO_BUTTONS, seed: 9999 });
  let falseDeaths = 0;
  for (let i = 0; i < 3000; i++) {
    g.autopilot();
    const died = g.step();
    if (died) {
      const p = g.player, depth = p.pos[2] - p.start;
      const f = pathFrameAt(g.seed, depth);
      const dx = p.pos[0] - f.center.x, dy = p.pos[1] - f.center.y, dz = p.pos[2] - f.center.z;
      const tracking = Math.hypot(
        dx * f.right.x + dy * f.right.y + dz * f.right.z,
        dx * f.up.x + dy * f.up.y + dz * f.up.z,
      );
      if (tubeRadiusAt(depth, g.seed) - p.radius - tracking > 0.05) falseDeaths++;
      break;
    }
  }
  assert.equal(falseDeaths, 0, 'no death should occur while safely inside the cave');
});
