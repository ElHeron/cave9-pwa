import test from 'node:test';
import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import {
  mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync,
} from 'node:fs';
import { tmpdir } from 'node:os';
import { dirname, join } from 'node:path';
import { PNG } from 'pngjs';

import { blessRun } from '../scripts/visual/bless.mjs';
import { verifyBaseline } from '../scripts/visual/baseline-verification.mjs';
import { formReleaseScenarios, suiteDefinition } from '../scripts/visual/config.mjs';
import { inspectPng } from '../scripts/visual/image-checks.mjs';
import { writeJsonAtomic, writeManifest } from '../scripts/visual/manifest.mjs';
import {
  fileSha256, gitProvenance, referenceFingerprint, runtimeFingerprint,
} from '../scripts/visual/provenance.mjs';
import { writeReferenceReport } from '../scripts/visual/reference-report-lib.mjs';
import { regenerateReferenceReport } from '../scripts/visual/report.mjs';
import { reviewRun } from '../scripts/visual/review.mjs';
import { assertCurrentRunProvenance, verifyRun } from '../scripts/visual/verification.mjs';
import { normalizeVisualScenario } from '../src/dev/scenario/schema.mjs';

const mkdirFor = (file) => mkdirSync(dirname(file), { recursive: true });
const write = (file, value) => { mkdirFor(file); writeFileSync(file, value); };
const json = (file, value) => writeJsonAtomic(file, value);
const git = (root, ...args) => execFileSync('git', args, { cwd: root, stdio: 'ignore' });

function evidencePng() {
  const png = new PNG({ width: 1280, height: 720 });
  for (let y = 0; y < png.height; y++) for (let x = 0; x < png.width; x++) {
    const p = (y * png.width + x) * 4;
    png.data[p] = (x * 3 + y) & 255;
    png.data[p + 1] = (x + y * 5) & 255;
    png.data[p + 2] = ((x >> 2) ^ (y * 7)) & 255;
    png.data[p + 3] = 255;
  }
  return PNG.sync.write(png);
}

const approvedCriteria = () => Object.fromEntries(
  ['branching', 'crystal', 'coiling'].map((family) => [family, {
    recognizable: true,
    wallIntegrated: true,
    depthLayers: true,
    centralOpening: true,
    axialEffect: true,
    note: `${family} inspected in the synthetic evidence fixture`,
  }]),
);

async function syntheticRun(t) {
  const root = mkdtempSync(join(tmpdir(), 'cave9-evidence-e2e-'));
  t.after(() => rmSync(root, { recursive: true, force: true }));
  const pngBytes = evidencePng();
  write(join(root, 'index.html'), '<!doctype html><canvas></canvas>\n');
  write(join(root, 'vite.config.js'), 'export default {};\n');
  write(join(root, 'package.json'), '{"type":"module"}\n');
  write(join(root, 'package-lock.json'), '{"lockfileVersion":3}\n');
  write(join(root, 'scripts/lib/frame-metrics.mjs'), 'export const fixture = true;\n');
  write(join(root, 'public/assets/cave.png'), pngBytes);
  write(join(root, 'docs/reference/reference.png'), pngBytes);
  json(join(root, 'docs/reference/manifest.json'), {
    frames: [{ file: 'reference.png', families: ['branching', 'crystal', 'coiling'] }],
  });
  git(root, 'init');
  git(root, 'config', 'user.email', 'evidence@example.invalid');
  git(root, 'config', 'user.name', 'Evidence Fixture');
  git(root, 'add', '.');
  git(root, 'commit', '-m', 'fixture source');

  const source = {
    git: await gitProvenance(root),
    reference: referenceFingerprint(root),
    runtime: runtimeFingerprint(root),
  };
  const runId = 'synthetic-form-release';
  const runDir = join(root, 'artifacts', 'visual-lab', runId);
  const frameDir = join(runDir, 'frames');
  mkdirSync(frameDir, { recursive: true });
  const suite = suiteDefinition();
  const frames = formReleaseScenarios().map((scenario) => {
    const file = join(frameDir, `${scenario.id}.png`);
    write(file, pngBytes);
    const image = inspectPng(file, suite.viewport);
    const positioning = {
      requestedDistance: scenario.distance,
      actualDistance: scenario.distance,
      method: 'place',
      placed: true,
      flown: false,
      reached: true,
      crashed: false,
    };
    const family = { requested: scenario.family, active: [scenario.family] };
    const camera = { requested: 'hero', active: 'hero', supported: true };
    const viewport = { requested: { width: 1280, height: 720, dpr: 1 }, matches: true };
    const normalizedScenario = normalizeVisualScenario(scenario.captureOptions);
    return {
      id: scenario.id,
      family: scenario.family,
      seed: scenario.seed,
      offset: scenario.offset,
      requestedDepth: scenario.distance,
      captureOptions: scenario.captureOptions,
      captureApi: suite.captureApi,
      normalizedScenario,
      snapshot: { version: 'VisualSnapshotV1', scenario: normalizedScenario },
      captureInfo: { distanceReached: scenario.distance, positioning, family, camera, viewport },
      runtime: {
        appState: 'capture', gamePhase: 'running', innerWidth: 1280, innerHeight: 720,
        devicePixelRatio: 1, canvasWidth: 1280, canvasHeight: 720,
        webglAvailable: true, webglContextLost: false, browserErrors: [], glErrors: [],
      },
      runtimeErrors: [],
      file: `frames/${scenario.id}.png`,
      image,
      status: 'pending',
      checks: {},
    };
  });
  write(join(runDir, 'reference-report.json'), '{"kind":"synthetic-reference-report"}\n');
  write(join(runDir, 'reference-report.html'), '<!doctype html><title>Synthetic review</title>\n');
  const now = new Date().toISOString();
  const manifest = {
    schemaVersion: 1,
    kind: 'cave9-visual-evidence-run',
    runId,
    createdAt: now,
    completedAt: now,
    status: 'running',
    source,
    environment: { process: { platform: process.platform }, browser: {
      engine: 'chromium', version: 'fixture', webgl: { available: true, contextLost: false },
    } },
    suite,
    frames,
    report: {
      json: 'reference-report.json', html: 'reference-report.html',
      jsonSha256: fileSha256(join(runDir, 'reference-report.json')),
      htmlSha256: fileSha256(join(runDir, 'reference-report.html')),
      diagnosticOnly: true,
    },
    automated: { status: 'pending' },
    manualReview: { status: 'pending' },
    errors: [],
  };
  writeManifest(runDir, manifest);
  return { root, runDir, pngBytes };
}

test('synthetic verify → review → bless → baseline verify is sealed and tamper-evident', async (t) => {
  const { root, runDir, pngBytes } = await syntheticRun(t);
  const verified = await verifyRun({ root, runDir });
  assert.equal(verified.status, 'manual-pending');
  assert.equal(verified.automated.status, 'pass');

  const reviewed = await reviewRun({ root, runDir, reviewer: 'Synthetic Reviewer',
    approve: true, criteria: approvedCriteria() });
  assert.equal(reviewed.manualReview.status, 'pass');

  const sealed = await blessRun({ root, runDir });
  assert.equal(sealed.manifest.blessing.schemaVersion, 2);
  const baseline = await verifyBaseline({ root });
  assert.equal(baseline.pass, true, baseline.reasons.join('; '));

  await assert.rejects(verifyRun({ root, runDir }), /blessed visual evidence runs are immutable/);
  await assert.rejects(reviewRun({ root, runDir, reviewer: 'Second Reviewer',
    reject: true }), /blessed visual evidence runs are immutable/);
  await assert.rejects(regenerateReferenceReport({ root, runDir }),
    /blessed visual evidence runs are immutable/);
  assert.throws(() => writeReferenceReport({ root, runDir, manifest: sealed.manifest }),
    /blessed visual evidence runs are immutable/);

  const pointerFile = join(root, 'artifacts/visual-lab/baselines/form-release.json');
  const pointer = JSON.parse(readFileSync(pointerFile, 'utf8'));
  json(pointerFile, { ...pointer, blessingSha256: '0'.repeat(64) });
  assert.equal((await verifyBaseline({ root })).pass, false);
  json(pointerFile, pointer);

  const frameFile = join(runDir, 'frames/branching-m64.png');
  write(frameFile, 'tampered');
  const frameTamper = await verifyBaseline({ root });
  assert.equal(frameTamper.pass, false);
  assert.ok(frameTamper.reasons.some((reason) => reason.includes('frame hash changed')));
  write(frameFile, pngBytes);
  assert.equal((await verifyBaseline({ root })).pass, true);

  write(join(root, 'index.html'), '<!doctype html><canvas data-changed></canvas>\n');
  await assert.rejects(assertCurrentRunProvenance(root, sealed.manifest, 'regenerate report for stale run'),
    /runtime source fingerprint changed|workspace diff fingerprint changed/);
  const stale = await verifyBaseline({ root });
  assert.equal(stale.pass, false);
  assert.ok(stale.reasons.some((reason) => reason.startsWith('baseline is stale:')));
});

test('manual approval refuses missing per-family form criteria before mutating the run', async (t) => {
  const { root, runDir } = await syntheticRun(t);
  await verifyRun({ root, runDir });
  const incomplete = approvedCriteria();
  incomplete.crystal.axialEffect = false;
  await assert.rejects(reviewRun({ root, runDir, reviewer: 'Synthetic Reviewer',
    approve: true, criteria: incomplete }), /crystal manual criterion is not approved: axialEffect/);
});

test('standalone report regeneration refuses stale source before overwriting report bytes', async (t) => {
  const { root, runDir } = await syntheticRun(t);
  const reportFile = join(runDir, 'reference-report.json');
  const before = readFileSync(reportFile);
  write(join(root, 'index.html'), '<!doctype html><canvas data-stale></canvas>\n');
  await assert.rejects(regenerateReferenceReport({ root, runDir }),
    /workspace diff fingerprint changed|runtime source fingerprint changed/);
  assert.deepEqual(readFileSync(reportFile), before);
});
