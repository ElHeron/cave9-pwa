// Visible landmarks — art-directed compositions (Phase 4G / M2 + 4G.2).
// Proves the room formations are:
//   * deterministic (same seed + roomIndex → identical composition),
//   * seed-varying (different seeds → different but valid compositions),
//   * drawn from ≥3 families, reachable deterministically,
//   * fully inside the visual safety bounds (every piece outside the central
//     no-entry tube and inside the wall) → the dark vanishing point stays free,
//   * a PURE read — composition queries never mutate the cave or the ship, so the
//     kill model is untouched.
// Run with: npm test
import { test } from 'node:test';
import assert from 'node:assert/strict';

import { Game } from '../src/core/Game.js';
import { collision } from '../src/core/CollisionSystem.js';
import {
  landmarksInView, compositionAt, nearestLandmarkDistance, landmarkPieceCount,
  landmarkType, roomZ, FIRST_ROOM_K, LANDMARK_TYPES, LANDMARK_MAX_PIECES,
  LANDMARK_FORM_HALF_SPAN, LANDMARK_WALL_MARGIN_FRAC,
} from '../src/core/Landmarks.js';
import { TWO_BUTTONS, ROOM_SPACING, ROOM_LEN, FOG_END, SEGMENT_LEN } from '../src/core/constants.js';
import { tubeRadiusAt } from '../src/core/FlightPath.js';

const RANGE = FOG_END * 1.3;
const SURVIVOR = 256; // autopilot survives well past the first room (z≈2050)

function flyTo(seed, depth, family = 'auto') {
  const g = new Game();
  g.start({ mode: TWO_BUTTONS, seed, family });
  let guard = 0;
  while (g.player.pos[2] - g.player.start < depth && guard++ < 200000) {
    g.autopilot();
    if (g.step()) break;
  }
  return g;
}

// Validate every piece of a composition against the safety annulus.
function assertCompositionSafe(c) {
  if (c.surfaceResident) {
    assert.equal(c.typeName, 'coiling');
    assert.deepEqual(c.pieces, []);
    assert.deepEqual(c.collisionPieces, []);
    return;
  }
  assert.ok(c.pieces.length > 0 && c.pieces.length <= LANDMARK_MAX_PIECES,
    `piece count ${c.pieces.length} in (0, ${LANDMARK_MAX_PIECES}]`);
  for (const p of c.pieces) {
    const q = p.local || p;
    const hl = (p.localLength || p.length) / 2;
    const pts = [
      [q.cx - q.dx * hl, q.cy - q.dy * hl, p.wallRadiusBase || c.clearance],
      [q.cx, q.cy, ((p.wallRadiusBase || c.clearance) + (p.wallRadiusTip || c.clearance)) / 2],
      [q.cx + q.dx * hl, q.cy + q.dy * hl, p.wallRadiusTip || c.clearance],
    ];
    for (const [sx, sy, localWall] of pts) {
      const r = Math.hypot(sx, sy);
      // STRICT: the piece's thickness clears the central no-entry tube
      assert.ok(r - p.radius >= c.inner - 1e-9,
        `piece intrudes the central tube: r-radius=${(r - p.radius).toFixed(2)} < inner=${c.inner}`);
      // the sample centre stays inside the rock wall (a thick base may embed)
      assert.ok(r <= localWall + 1e-9,
        `piece centre is beyond the wall: r=${r.toFixed(2)} > wall=${localWall.toFixed(2)}`);
    }
  }
}

test('roomZ + first-room index match the generator room planes', () => {
  assert.equal(roomZ(2), ROOM_LEN / 2 + ROOM_SPACING * 2);
  assert.equal(FIRST_ROOM_K, 2);
  assert.equal(LANDMARK_TYPES.length, 3);
});

test('a composition is visible when approaching the first room', () => {
  const g = flyTo(SURVIVOR, 2010);
  const cs = landmarksInView(g.cave, g.player.pos[2], RANGE, g.seed);
  assert.ok(cs.length >= 1, `expected a composition near the first room, got ${cs.length}`);
  assert.ok(cs[0].surfaceResident || cs[0].pieces.length >= 3,
    'a room identity is either the authoritative shell or a group of pieces');
  assert.ok(LANDMARK_TYPES.includes(cs[0].typeName), 'has a known family');
});

test('same seed + roomIndex → identical composition (deterministic)', () => {
  const a = flyTo(SURVIVOR, 2010);
  const b = flyTo(SURVIVOR, 2010);
  const ca = compositionAt(a.seed, a.cave, FIRST_ROOM_K);
  const cb = compositionAt(b.seed, b.cave, FIRST_ROOM_K);
  assert.deepEqual(ca, cb, 'two runs of the same seed produce the identical composition');
});

test('different seeds → different but valid compositions', () => {
  const a = flyTo(SURVIVOR, 2010);
  const b = flyTo(5, 2010);
  const ca = compositionAt(a.seed, a.cave, FIRST_ROOM_K);
  const cb = compositionAt(b.seed, b.cave, FIRST_ROOM_K);
  assert.ok(ca && cb);
  assert.equal(ca.z, cb.z, 'same room plane');
  // either a different family OR a different piece layout — never identical
  const differs = ca.type !== cb.type ||
    JSON.stringify(ca.pieces) !== JSON.stringify(cb.pieces) ||
    JSON.stringify(ca.coilingContract) !== JSON.stringify(cb.coilingContract);
  assert.ok(differs, 'compositions differ across seeds');
  assertCompositionSafe(ca);
  assertCompositionSafe(cb);
});

test('all three landmark families are reachable deterministically', () => {
  // scan (seed, roomIndex) pairs; landmarkType is pure, so this is reproducible.
  const seen = new Set();
  for (let seed = 1; seed <= 40 && seen.size < 3; seed++) {
    for (let k = FIRST_ROOM_K; k <= FIRST_ROOM_K + 12; k++) {
      seen.add(landmarkType(seed, k));
    }
  }
  assert.equal(seen.size, 3, `expected all 3 families, saw ${[...seen].sort()}`);
  // determinism of the selector
  assert.equal(landmarkType(SURVIVOR, 2), landmarkType(SURVIVOR, 2));
});

test('capture tooling freezes each forced family before cave generation', () => {
  for (const family of ['branching', 'crystal', 'coiling']) {
    const g = flyTo(SURVIVOR, 2010, family);
    const comp = compositionAt(g.seed, g.cave, FIRST_ROOM_K, family);
    assert.equal(comp?.typeName, family);
    if (family === 'coiling') {
      assert.equal(comp.surfaceResident, true);
      assert.equal(comp.pieces.length, 0);
    } else {
      assert.ok(comp?.pieces.length > 0);
    }
  }
});

test('every composition piece stays inside the safety bounds (centre + wall)', () => {
  // exercise all three families by picking room indices of each type.
  const found = new Set();
  // seed-driven safety sweep on the live first room — many seeds → all families
  for (let seed = 1; seed <= 18; seed++) {
    const g = flyTo(seed, 2010);
    const c = compositionAt(seed, g.cave, FIRST_ROOM_K);
    if (!c) continue;
    found.add(c.type);
    assertCompositionSafe(c);
  }
  assert.equal(found.size, 3, `safety checked across all families, saw ${found.size}`);
});

test('the central no-entry tube (vanishing point) is never intruded', () => {
  for (let seed = 1; seed <= 12; seed++) {
    const g = flyTo(seed, 2010);
    const c = compositionAt(seed, g.cave, FIRST_ROOM_K);
    if (!c) continue;
    for (let dz = -LANDMARK_FORM_HALF_SPAN; dz <= LANDMARK_FORM_HALF_SPAN; dz += SEGMENT_LEN) {
      assert.ok(c.inner >= tubeRadiusAt(c.z + dz, seed) + 0.35 - 1e-9,
        'the only keepout is the dynamic Boolean tube plus landmark reserve');
    }
    for (const p of c.pieces) {
      const q = p.local || p;
      // nearest point of the whole piece to the axis must clear the tube
      const hl = p.length / 2;
      const rTip = Math.hypot(q.cx + q.dx * hl, q.cy + q.dy * hl);
      const rBase = Math.hypot(q.cx - q.dx * hl, q.cy - q.dy * hl);
      assert.ok(Math.min(rTip, rBase) - p.radius >= c.inner - 1e-9, 'piece clears the central tube');
    }
  }
});

test('landmarks are room-only — none before ROOM_START', () => {
  const g = flyTo(SURVIVOR, 800);
  assert.equal(landmarksInView(g.cave, g.player.pos[2], RANGE, g.seed).length, 0);
});

test('querying landmarks does NOT mutate the cave or the kill decision', () => {
  const g = flyTo(SURVIVOR, 2010);
  const p = g.player;
  const distBefore = collision(g.cave, p);
  const snap = { dist: p.dist, pos: [...p.pos], leftClear: p.leftClear, rightClear: p.rightClear };

  landmarksInView(g.cave, p.pos[2], RANGE, g.seed);
  nearestLandmarkDistance(g.cave, p.pos[2], RANGE, g.seed);
  landmarkPieceCount(g.cave, p.pos[2], RANGE, g.seed);
  compositionAt(g.seed, g.cave, FIRST_ROOM_K);

  assert.equal(p.dist, snap.dist, 'ship.dist untouched');
  assert.deepEqual([...p.pos], snap.pos, 'pos untouched');
  assert.equal(p.leftClear, snap.leftClear, 'leftClear untouched');
  assert.equal(p.rightClear, snap.rightClear, 'rightClear untouched');
  assert.equal(collision(g.cave, p), distBefore, 'collision result unchanged');
});

test('nearestLandmarkDistance + piece count report near a room', () => {
  const g = flyTo(SURVIVOR, 2010);
  const d = nearestLandmarkDistance(g.cave, g.player.pos[2], RANGE, g.seed);
  assert.ok(d !== null && Number.isFinite(d));
  assert.equal(landmarkPieceCount(g.cave, g.player.pos[2], RANGE, g.seed), 0,
    'the in-view C3 room has identity but no secondary piece geometry');
});
