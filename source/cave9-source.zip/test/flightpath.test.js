// FlightPath — the route the cave is built around.
//
// The point of this module is that "a run can be completed" stops being a
// measured hope and becomes a property of the generator. These tests are what
// makes that claim real: the flyability bound is checked ANALYTICALLY (worst
// case, every octave peaking at once) rather than by sampling, because a sampled
// maximum passes while a rare seed fails.
//
// Run with: npm test

import { test } from 'node:test';
import assert from 'node:assert/strict';

import {
  pathAt, pathTangent, tubeRadiusAt, atTubeFloor,
  curvatureBound, maxFlyableSpeed, isFlyable, routeCurvatureBoundAt,
  asymptoticCurvatureBoundAt, pathDerivativesAt,
  MAX_ACC_X, MAX_ACC_Y, PATH_ACC_BUDGET, PATH_REFERENCE_SPEED_MUL,
  ROUTE_STRAIGHTEN_START,
  TUBE_MIN_RADIUS, TUBE_MAX_RADIUS, TUBE_FLOOR_DEPTH,
} from '../src/core/FlightPath.js';
import { GRAVITY, THRUST, VELOCITY, SHIP_RADIUS } from '../src/core/constants.js';
import { speedMul } from '../src/core/Difficulty.js';

const SEEDS = [1, 42, 256, 2024, 4096, 424242, 99991, 8888];

// ---- the envelope matches the ship that has to fly it ----------------------

test('the acceleration envelope is the one Ship.move actually produces', () => {
  // one thruster: ay = THRUST/2 - GRAVITY, which is exactly zero — the hover
  // that makes horizontal the strong axis and vertical the binding one
  assert.equal(THRUST / 2 - GRAVITY, 0, 'a single thruster must hold altitude');
  assert.equal(MAX_ACC_Y, THRUST - GRAVITY, 'both thrusters minus gravity');
  assert.equal(MAX_ACC_X, THRUST, 'a single thruster, full sideways');
  assert.ok(MAX_ACC_Y < MAX_ACC_X, 'vertical is the weaker axis, so it binds');
});

// ---- flyability, proven rather than sampled --------------------------------

test('the route is flyable at the speed it is planned for', () => {
  assert.ok(isFlyable(), `max flyable ${maxFlyableSpeed().toFixed(1)} < planned ` +
    `${(VELOCITY * PATH_REFERENCE_SPEED_MUL).toFixed(1)}`);
});

test('the route approaches a straight line forever but never becomes exactly straight', () => {
  for (const seed of SEEDS) for (const z of [15000, 30000, 1e6]) {
    const d = pathDerivativesAt(seed, z);
    assert.ok(Number.isFinite(d.ddx) && Number.isFinite(d.ddy));
    assert.ok(Math.abs(d.ddx) + Math.abs(d.ddy) > 0,
      `seed ${seed} became perfectly straight at ${z}`);
  }
  assert.ok(routeCurvatureBoundAt(1e6) > 0);
  assert.ok(routeCurvatureBoundAt(1e6) < routeCurvatureBoundAt(30000));
});

test('the path leaves most of the envelope to the pilot', () => {
  // A path that consumed the whole envelope would be flyable only by a perfect
  // controller with zero tracking error, which no real pilot is.
  assert.ok(PATH_ACC_BUDGET < 0.5, 'the path must not claim half the authority');
  const used = curvatureBound() * (VELOCITY * PATH_REFERENCE_SPEED_MUL) ** 2;
  assert.ok(used <= MAX_ACC_Y * PATH_ACC_BUDGET + 1e-9,
    `path needs ${used.toFixed(2)} m/s² of ${MAX_ACC_Y} available`);
});

test('the analytic bound really does bound every sampled seed', () => {
  // If sampling ever exceeded the closed-form bound the proof would be worthless.
  const h = 0.5;
  for (const seed of SEEDS) {
    for (let z = 0; z < 12000; z += 7) {
      const a = pathAt(seed, z - h), b = pathAt(seed, z), c = pathAt(seed, z + h);
      const yPP = (a.y - 2 * b.y + c.y) / (h * h);
      const xPP = (a.x - 2 * b.x + c.x) / (h * h);
      const localBound = routeCurvatureBoundAt(z);
      assert.ok(Math.abs(yPP) <= localBound + 1e-6, `seed ${seed} z=${z} y''=${yPP}`);
      assert.ok(Math.abs(xPP) <= localBound + 1e-6, `seed ${seed} z=${z} x''=${xPP}`);
    }
  }
});

test('the required acceleration remains inside the path budget at every depth', () => {
  const h = 0.5;
  for (const seed of SEEDS) {
    for (let z = 0; z < 30000; z += 11) {
      const v = VELOCITY * speedMul(z);
      const a = pathAt(seed, z - h), b = pathAt(seed, z), c = pathAt(seed, z + h);
      const ay = Math.abs((a.y - 2 * b.y + c.y) / (h * h)) * v * v;
      const ax = Math.abs((a.x - 2 * b.x + c.x) / (h * h)) * v * v;
      assert.ok(ay <= MAX_ACC_Y * PATH_ACC_BUDGET + 1e-6,
        `seed ${seed} needs ${ay.toFixed(2)} m/s² vertical at ${z}`);
      assert.ok(ax <= MAX_ACC_X * PATH_ACC_BUDGET + 1e-6,
        `seed ${seed} needs ${ax.toFixed(2)} m/s² horizontal at ${z}`);
    }
  }
});

test('the asymptotic C2 straightening has a closed conservative bound', () => {
  for (const z of [9000, 10000, 15000, 30000, 100000, 1e6, 1e7]) {
    const required = asymptoticCurvatureBoundAt(z) * (VELOCITY * speedMul(z)) ** 2;
    assert.ok(required <= MAX_ACC_Y * PATH_ACC_BUDGET,
      `bound needs ${required.toFixed(3)} m/s² at ${z}`);
  }
  for (const seed of SEEDS) {
    const before = pathDerivativesAt(seed, ROUTE_STRAIGHTEN_START - 1e-5);
    const after = pathDerivativesAt(seed, ROUTE_STRAIGHTEN_START + 1e-5);
    assert.ok(Math.abs(before.ddx - after.ddx) < 1e-6);
    assert.ok(Math.abs(before.ddy - after.ddy) < 1e-6);
  }
});

// ---- the route itself ------------------------------------------------------

test('pathAt is pure and deterministic per seed', () => {
  for (const seed of SEEDS) {
    for (const z of [0, 137, 5000]) {
      assert.deepEqual(pathAt(seed, z), pathAt(seed, z));
    }
  }
});

test('different seeds give genuinely different routes', () => {
  // Compared over a STRETCH, not at one z: two distinct routes are free to cross,
  // and sampling a single point once reported a real pair as identical.
  const rms = (a, b) => {
    let sum = 0, n = 0;
    for (let z = 0; z < 8000; z += 25) {
      const p = pathAt(a, z), q = pathAt(b, z);
      sum += (p.x - q.x) ** 2 + (p.y - q.y) ** 2; n++;
    }
    return Math.sqrt(sum / n);
  };
  for (let i = 0; i < SEEDS.length; i++) {
    for (let j = i + 1; j < SEEDS.length; j++) {
      const d = rms(SEEDS[i], SEEDS[j]);
      assert.ok(d > 5, `seeds ${SEEDS[i]}/${SEEDS[j]} only ${d.toFixed(2)} m apart on average`);
    }
  }
});

test('the route is continuous — no jumps a ship could not follow', () => {
  for (const seed of SEEDS) {
    let prev = pathAt(seed, 0);
    for (let z = 1; z < 6000; z += 1) {
      const p = pathAt(seed, z);
      assert.ok(Math.hypot(p.x - prev.x, p.y - prev.y) < 1.5, `jump at z=${z}`);
      prev = p;
    }
  }
});

test('the tangent is a unit vector pointing down the tunnel', () => {
  for (const seed of SEEDS) {
    for (const z of [0, 500, 3333, 9000]) {
      const t = pathTangent(seed, z);
      assert.ok(Math.abs(Math.hypot(t.x, t.y, t.z) - 1) < 1e-9, 'unit length');
      assert.ok(t.z > 0.5, 'the route always leads forward, never doubles back');
    }
  }
});

// ---- the tube --------------------------------------------------------------

test('the tube never drops below the ship plus its clearance', () => {
  for (const seed of SEEDS) {
    for (let d = 0; d < 20000; d += 13) {
      const r = tubeRadiusAt(d, seed);
      assert.ok(r >= TUBE_MIN_RADIUS - 1e-9, `tube ${r} at ${d} m`);
      assert.ok(r <= TUBE_MAX_RADIUS + 1e-9);
      assert.ok(r - SHIP_RADIUS >= SHIP_RADIUS - 1e-9,
        'at least one ship radius of clearance outside the hull');
    }
  }
});

test('the tube narrows in waves, not on a slope', () => {
  // a squeeze then an opening, repeatedly — tension with a rhythm
  const r = [];
  for (let d = 0; d < 3000; d += 25) r.push(tubeRadiusAt(d, 4096));
  let turns = 0;
  for (let i = 2; i < r.length; i++) {
    const a = r[i - 1] - r[i - 2], b = r[i] - r[i - 1];
    if (a > 0 !== b > 0) turns++;
  }
  assert.ok(turns >= 4, `expected several squeezes in 3 km, saw ${turns} turns`);
});

test('the wave envelope closes with depth', () => {
  // sample the widest point of each region: deeper regions may never be as open
  const widest = (from, to) => {
    let m = 0;
    for (let d = from; d < to; d += 5) m = Math.max(m, tubeRadiusAt(d, 4096));
    return m;
  };
  const shallow = widest(0, 1500);
  const mid = widest(4000, 5500);
  const deep = widest(8500, 10000);
  assert.ok(mid < shallow, `mid ${mid} should be tighter than shallow ${shallow}`);
  assert.ok(deep < mid, `deep ${deep} should be tighter than mid ${mid}`);
});

test('past the floor depth the tube is constant at its minimum', () => {
  assert.ok(atTubeFloor(TUBE_FLOOR_DEPTH));
  assert.ok(!atTubeFloor(TUBE_FLOOR_DEPTH - 1));
  for (const seed of SEEDS) {
    for (let d = TUBE_FLOOR_DEPTH; d < 16000; d += 37) {
      assert.ok(Math.abs(tubeRadiusAt(d, seed) - TUBE_MIN_RADIUS) < 1e-9,
        `tube still varying at ${d} m — difficulty must come from speed alone there`);
    }
  }
});
