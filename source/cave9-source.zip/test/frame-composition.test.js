import test from 'node:test';
import assert from 'node:assert/strict';
import { AXES, composition, compositionDistance, referenceEnvelope } from '../scripts/lib/frame-metrics.mjs';

function analyticFrame(w, h, pixel) {
  const data = new Uint8Array(w * h * 4);
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
    const nx = (x + 0.5) / w - 0.5;
    const ny = ((y + 0.5) / h - 0.5) * h / w;
    const value = Math.max(0, Math.min(1, pixel(nx, ny, x, y)));
    const i = (y * w + x) * 4;
    data[i] = data[i + 1] = data[i + 2] = Math.round(value * 255);
    data[i + 3] = 255;
  }
  return { w, h, data };
}

const aperture = (radius, w = 320, h = 180) => analyticFrame(w, h, (x, y) =>
  Math.hypot(x, y) < radius * (h / w) * 0.5 ? 0.15 : 0.82);

function asDescription(projected) {
  return {
    D7_centralOpening: projected.centralOpening,
    D8_angularSilhouette: projected.angularSilhouette,
    D9_quadrantMass: projected.quadrantMass,
    D10_dominantForms: projected.dominantForms,
    D11_tipDistance: projected.tipDistance,
    D12_projectedOcclusion: projected.projectedOcclusion,
  };
}

test('composition is byte-for-byte deterministic for one frame', () => {
  const frame = aperture(0.42);
  assert.deepEqual(composition(frame), composition(frame));
});

test('central negative-form area grows monotonically with aperture radius', () => {
  const small = composition(aperture(0.22)).centralOpening.areaRatio;
  const medium = composition(aperture(0.42)).centralOpening.areaRatio;
  const large = composition(aperture(0.65)).centralOpening.areaRatio;
  assert.ok(small < medium && medium < large, `${small} < ${medium} < ${large}`);
});

test('canonical sampling keeps composition stable across source resolution', () => {
  const low = composition(aperture(0.44, 160, 90));
  const high = composition(aperture(0.44, 640, 360));
  assert.ok(Math.abs(low.centralOpening.areaRatio - high.centralOpening.areaRatio) < 0.025);
  assert.ok(Math.abs(low.tipDistance.median - high.tipDistance.median) < 0.025);
  assert.ok(Math.abs(low.projectedOcclusion.meanCrossings - high.projectedOcclusion.meanCrossings) < 0.15);
});

test('composition distance is symmetric and identical frames score 100', () => {
  const a = asDescription(composition(aperture(0.3)));
  const b = asDescription(composition(aperture(0.62)));
  assert.deepEqual(compositionDistance(a, a), { distance: 0, similarity: 100, terms: {
    centralOpening: 0, angularSilhouette: 0, quadrantMass: 0,
    dominantForms: 0, tipDistance: 0, projectedOcclusion: 0,
  } });
  assert.equal(compositionDistance(a, b).distance, compositionDistance(b, a).distance);
  assert.ok(compositionDistance(a, b).similarity < 100);
});

test('supplemental frames cannot widen the primary reference envelope', () => {
  const described = (value, metricEnvelope) => ({
    metricEnvelope,
    D1_figureGround: value,
    D2_centreOverEdge: value,
    D3_tone: { median: value, brightTail: value },
    D4_radialAlignment: value,
    D5_edgeDensity: value,
    D6_embers: { blobs: value },
    D7_centralOpening: { areaRatio: value },
    D8_angularSilhouette: { entropy: value },
    D9_quadrantMass: { imbalance: value },
    D10_dominantForms: { top3Share: value },
    D11_tipDistance: { median: value },
    D12_projectedOcclusion: { meanCrossings: value },
  });
  const primary = described(0.4, true);
  const supplemental = described(99, false);
  const target = referenceEnvelope([primary, supplemental]);
  for (const axis of AXES) assert.deepEqual(target[axis], { min: 0.4, max: 0.4, mean: 0.4 });
});
