import { test } from 'node:test';
import assert from 'node:assert/strict';
import { Game } from '../src/core/Game.js';
import { placeAt } from '../src/app/CaptureHarness.js';
import { compositionAt, roomRingIndex, roomZ } from '../src/core/Landmarks.js';
import { LANDMARK_SURFACE_HALF_SPAN } from '../src/core/landmarks/rooms.js';
import { queryNearestSurface } from '../src/core/SurfaceQuery.js';
import { buildCompositionAccums } from '../src/render/landmarks/LandmarkMeshBuilder.js';

function equivalent(a, b) {
  assert.deepEqual(a, b);
  assert.deepEqual(a?.rootSurfaces, b?.rootSurfaces);
  assert.deepEqual(a?.rootWallQueries, b?.rootWallQueries);
  assert.deepEqual(a?.bladeWallQueries, b?.bladeWallQueries);
  assert.deepEqual(a?.slabHulls, b?.slabHulls);
}

for (const family of ['branching', 'crystal']) {
  test(`${family}: the canonical room survives the exact recycled-centre exit`, () => {
    const game = new Game().start({ mode: 2, seed: 2024, family });
    placeAt(game, 8950);
    let before;
    for (let step = 0; step <= 288; step++) {
      game._carve();
      if (step >= 282) {
        const cached = game.landmarkCache.compositionAt(game.seed, game.cave, 9, family);
        const fresh = compositionAt(game.seed, game.cave, 9, family);
        assert.ok(cached, `step ${step}: authoritative form remains present`);
        equivalent(cached, fresh);
        assert.equal(cached.frame.center.z, roomZ(9));
        if (step === 282) before = cached;
        else assert.equal(cached, before, 'recycling unrelated render slots cannot reshape the form');
      }
      if (step === 288) {
        assert.equal(roomRingIndex(game.cave, 9), -1, 'fixture reaches the old early-null failure');
        const accum = buildCompositionAccums(before)[family === 'branching' ? 'rock' : 'crystal'];
        assert.ok(accum.p.some((value, index) => index % 3 === 2 && value > game.player.pos[2] + 10));
        // The rendered triangle itself is the independent collision oracle.
        const triangle = accum.i.slice(0, 3).map(index => accum.p.slice(index * 3, index * 3 + 3));
        const point = [0, 1, 2].map(axis => triangle.reduce((sum, vertex) => sum + vertex[axis], 0) / 3);
        // Crystal plates can overlap: the signed full-composition distance can
        // then be negative inside another plate. Isolate the first rendered
        // plate for exact contact, while checking the actual full collision too.
        const queryComp = family === 'crystal'
          ? { pieces: [before.pieces[0]], collisionPieces: [before.pieces[0]] } : before;
        const contact = queryNearestSurface(game.cave, point, 0.25, [queryComp]).landmark;
        assert.ok(Math.abs(contact.surfaceDistance) < 1e-6);
        assert.ok(contact.hullClearance < -0.249);
        assert.ok(queryNearestSurface(game.cave, point, 0.25, [before]).landmark.hullClearance < 0);
      }
      game.player.pos[2] += 0.675;
    }
  });

  test(`${family}: direct placement behind the centre uses actually emitted history`, () => {
    const game = new Game().start({ mode: 2, seed: 2024, family });
    placeAt(game, 9160);
    assert.equal(roomRingIndex(game.cave, 9), -1);
    const view = game.cave.landmarkRoomSurface(9);
    assert.ok(view);
    assert.equal(view.frames[roomRingIndex(view, 9)].center.z, roomZ(9));
    equivalent(game.landmarkCache.compositionAt(game.seed, game.cave, 9, family),
      compositionAt(game.seed, game.cave, 9, family));
    assert.ok(compositionAt(game.seed, game.cave, 9, family));
  });
}

test('emitted room copies are immutable, bounded, retired and reset independently of recycled arrays', () => {
  const game = new Game().start({ mode: 2, seed: 2024, family: 'branching' });
  const cave = game.cave;
  cave.generateThrough(roomZ(9) + 112);
  const view = cave.landmarkRoomSurface(9);
  const snapshot = structuredClone(view);
  assert.ok(Object.isFrozen(view) && Object.isFrozen(view.segs[0]) && Object.isFrozen(view.segs[0][0]));
  assert.ok(Object.isFrozen(view.frames[0].center));
  assert.equal(new Set(view.centers.map(center => center[2])).size, view.count);
  for (let slot = 0; slot < cave.centers.length; slot++) {
    const retained = view.centers.findIndex(center => center[2] === cave.centers[slot][2]);
    if (retained < 0) continue;
    assert.deepEqual(view.segs[retained], cave.segs[slot]);
    assert.notEqual(view.segs[retained], cave.segs[slot]);
    assert.notEqual(view.frames[retained].center, cave.frames[slot].center);
  }
  cave.generateThrough(roomZ(9) + cave.len() + LANDMARK_SURFACE_HALF_SPAN + 4);
  assert.deepEqual(view, snapshot, 'retired circular slots cannot mutate even an older captured view');
  assert.equal(cave.landmarkRoomSurface(9), null);
  assert.equal(compositionAt(game.seed, cave, 9, 'branching'), null);
  for (let k = 10; k <= 15; k++) {
    cave.generateThrough(roomZ(k) + 112);
    const metrics = cave.roomSurfaceMetrics();
    assert.ok(metrics.rooms <= 2);
    assert.ok(metrics.rings <= metrics.maxRooms * metrics.maxRingsPerRoom);
    assert.ok(metrics.numericBytes <= 2 * 114 * 888);
  }
  const generation = cave.generation;
  cave.reset(256, 'crystal');
  assert.ok(cave.generation > generation);
  assert.equal(cave.roomSurfaceMetrics().rooms, 0);
  assert.equal(cave.landmarkRoomSurface(15), null);
  cave.generateThrough(roomZ(9) + 112);
  const next = cave.landmarkRoomSurface(9);
  assert.equal(next.generation, cave.generation);
  assert.notDeepEqual(next.segs, view.segs, 'a new seed cannot inherit old authoritative rings');
});
