import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { PNG } from 'pngjs';
import {
  COILING_MAP_SOURCE,
  COILING_NORMAL_STRENGTH,
  generateCoilingMaps,
} from '../scripts/make-coiling-maps.mjs';

function load(name) {
  return PNG.sync.read(readFileSync(`public/assets/${name}`));
}

test('coiling material maps regenerate deterministically from the committed build source', () => {
  assert.match(COILING_MAP_SOURCE, /^docs\/assets\//);
  const result = generateCoilingMaps();
  assert.deepEqual([result.width, result.height], [512, 512]);
  assert.equal(result.normalStrength, COILING_NORMAL_STRENGTH);
  assert.ok(result.reliefBounds.low < 0);
  assert.ok(result.reliefBounds.high > 0);
});

test('coiling height and OpenGL normal maps are lossless, non-flat 512 px assets', () => {
  const heightMap = load('coiling-rock-height.png');
  const normalMap = load('coiling-rock-normal.png');
  assert.deepEqual([heightMap.width, heightMap.height], [512, 512]);
  assert.deepEqual([normalMap.width, normalMap.height], [512, 512]);
  let minHeight = 255, maxHeight = 0, tilted = 0;
  let lengthSum = 0, minLength = Infinity, maxLength = 0;
  let xEnergy = 0, yEnergy = 0, xyEnergy = 0;
  for (let i = 0; i < 512 * 512; i++) {
    const o = i * 4;
    const h = heightMap.data[o];
    assert.equal(heightMap.data[o + 1], h);
    assert.equal(heightMap.data[o + 2], h);
    assert.equal(heightMap.data[o + 3], 255);
    assert.equal(normalMap.data[o + 3], 255);
    minHeight = Math.min(minHeight, h);
    maxHeight = Math.max(maxHeight, h);
    const nx = normalMap.data[o] / 127.5 - 1;
    const ny = normalMap.data[o + 1] / 127.5 - 1;
    const nz = normalMap.data[o + 2] / 127.5 - 1;
    const length = Math.hypot(nx, ny, nz);
    lengthSum += length;
    minLength = Math.min(minLength, length);
    maxLength = Math.max(maxLength, length);
    xEnergy += nx * nx;
    yEnergy += ny * ny;
    xyEnergy += nx * ny;
    if (Math.abs(nx) > 0.025 || Math.abs(ny) > 0.025) tilted++;
  }
  const pixels = 512 * 512;
  assert.ok(maxHeight - minHeight > 180, 'height map uses a broad detail range');
  assert.ok(tilted > pixels * 0.35, 'normal map contains widespread relief');
  assert.ok(minLength > 0.99 && maxLength < 1.01);
  assert.ok(Math.abs(lengthSum / pixels - 1) < 0.001);
  const trace = xEnergy + yEnergy;
  const discriminant = Math.sqrt((xEnergy - yEnergy) ** 2 + 4 * xyEnergy ** 2);
  const major = (trace + discriminant) * 0.5;
  const minor = (trace - discriminant) * 0.5;
  assert.ok(major / minor > 1.5, 'coiling relief retains a measurable directional grain');
});
