// Settings validation + persistence. Run with: npm test
// Uses an in-memory localStorage shim so SaveSystem persistence is exercised
// headlessly (node has no localStorage).
import { test, beforeEach } from 'node:test';
import assert from 'node:assert/strict';

// ---- localStorage shim (must exist before SettingsSystem touches it) ----
class MemStore {
  constructor() { this.m = new Map(); }
  getItem(k) { return this.m.has(k) ? this.m.get(k) : null; }
  setItem(k, v) { this.m.set(k, String(v)); }
  removeItem(k) { this.m.delete(k); }
  clear() { this.m.clear(); }
}
globalThis.localStorage = new MemStore();

const {
  SettingsSystem, DEFAULTS, clampSetting, coerceSettings,
} = await import('../src/platform/SettingsSystem.js');
const { TWO_BUTTONS, ONE_BUTTON } = await import('../src/core/constants.js');

beforeEach(() => globalThis.localStorage.clear());

test('defaults are all valid against their own schema', () => {
  for (const key of Object.keys(DEFAULTS)) {
    assert.equal(clampSetting(key, DEFAULTS[key]), DEFAULTS[key], `default for ${key} is invalid`);
  }
});

test('out-of-range numbers are clamped to bounds', () => {
  assert.equal(clampSetting('fov', 9999), 75);   // max
  assert.equal(clampSetting('fov', 0), 35);       // min
  assert.equal(clampSetting('brightness', 5), 1.5);
  assert.equal(clampSetting('volume', -3), 0);
  assert.equal(clampSetting('sensitivity', 100), 1.6);
});

test('non-finite / garbage values fall back to default', () => {
  assert.equal(clampSetting('fov', NaN), DEFAULTS.fov);
  assert.equal(clampSetting('fov', 'banana'), DEFAULTS.fov);
  assert.equal(clampSetting('quality', 7), DEFAULTS.quality); // invalid choice
  assert.equal(clampSetting('controlMode', 'nope'), DEFAULTS.controlMode);
});

test('toggles coerce to real booleans', () => {
  assert.equal(clampSetting('invertX', 1), true);
  assert.equal(clampSetting('invertX', 0), false);
  assert.equal(clampSetting('sound', ''), false);
});

test('choice values arriving as strings from the DOM are coerced', () => {
  assert.equal(clampSetting('controlMode', String(ONE_BUTTON)), ONE_BUTTON);
  assert.equal(clampSetting('quality', '1'), 1);
  assert.equal(clampSetting('touchHand', 'mirror'), 'mirror');
});

test('coerceSettings fills gaps, clamps, and drops unknown keys', () => {
  const out = coerceSettings({ fov: 999, bogus: 42 });
  assert.equal(out.fov, 75);
  assert.equal(out.controlMode, DEFAULTS.controlMode); // filled
  assert.ok(!('bogus' in out));
});

test('primitive, null and array settings records fall back to defaults without crashing', () => {
  for (const raw of [42, 'settings', null, []]) {
    const out = coerceSettings(raw);
    assert.deepEqual(out, DEFAULTS);
  }
});

test('settings construction repairs invalid persisted structures and values', () => {
  globalThis.localStorage.setItem('cave9.settings', JSON.stringify({
    fov: Infinity, sound: 'false', volume: 'not-a-number', bogus: 99,
  }));
  const settings = new SettingsSystem();
  assert.equal(settings.get('fov'), DEFAULTS.fov);
  assert.equal(settings.get('sound'), DEFAULTS.sound);
  assert.equal(settings.get('volume'), DEFAULTS.volume);
  const repaired = JSON.parse(globalThis.localStorage.getItem('cave9.settings'));
  assert.deepEqual(repaired, DEFAULTS);
});

test('set() clamps and returns the stored value', () => {
  const s = new SettingsSystem();
  assert.equal(s.set('fov', 9999), 75);
  assert.equal(s.get('fov'), 75);
});

test('save/load survives a reload (new instance reads persisted values)', () => {
  const a = new SettingsSystem();
  a.set('fov', 70);
  a.set('invertX', true);
  a.set('controlMode', ONE_BUTTON);
  const b = new SettingsSystem(); // simulates a page reload
  assert.equal(b.get('fov'), 70);
  assert.equal(b.get('invertX'), true);
  assert.equal(b.get('controlMode'), ONE_BUTTON);
});

test('a persisted out-of-range value is repaired on load', () => {
  // simulate a corrupt/tampered localStorage entry
  globalThis.localStorage.setItem('cave9.settings', JSON.stringify({ fov: 5000, volume: 9 }));
  const s = new SettingsSystem();
  assert.equal(s.get('fov'), 75);
  assert.equal(s.get('volume'), 1);
});

test('reset() restores defaults and persists them', () => {
  const a = new SettingsSystem();
  a.set('fov', 70);
  a.reset();
  assert.deepEqual(a.values, DEFAULTS);
  const b = new SettingsSystem();
  assert.equal(b.get('fov'), DEFAULTS.fov);
});

test('reset notifies listeners for every key', () => {
  const s = new SettingsSystem();
  const seen = new Set();
  s.onChange((k) => seen.add(k));
  s.reset();
  for (const k of Object.keys(DEFAULTS)) assert.ok(seen.has(k), `no notify for ${k}`);
});

test('first start honors reduced motion, while a saved explicit motion value wins', () => {
  const first = new SettingsSystem({ prefersReducedMotion: true });
  assert.equal(first.get('motion'), 0);
  const persisted = JSON.parse(globalThis.localStorage.getItem('cave9.settings'));
  assert.equal(persisted.motion, 0);
  first.set('motion', 0.8);
  const next = new SettingsSystem({ prefersReducedMotion: true });
  assert.equal(next.get('motion'), 0.8);
});

test('first-run help state persists and malformed values cannot mark it seen', () => {
  const settings = new SettingsSystem();
  assert.equal(settings.get('helpSeen'), false);
  settings.set('helpSeen', true);
  assert.equal(new SettingsSystem().get('helpSeen'), true);
  globalThis.localStorage.setItem('cave9.settings', JSON.stringify({ helpSeen: 'true' }));
  assert.equal(new SettingsSystem().get('helpSeen'), false);
});
