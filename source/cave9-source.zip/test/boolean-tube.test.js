import { test } from 'node:test';
import assert from 'node:assert/strict';

import { Game } from '../src/core/Game.js';
import { pathAt, pathFrameAt, tubeRadiusAt } from '../src/core/FlightPath.js';
import { FOG_END, SECTOR_COUNT, SEGMENT_COUNT, SEGMENT_LEN } from '../src/core/constants.js';
import { sightMul } from '../src/core/Difficulty.js';

const EPS = 1e-6;

function localRadius(seed, point) {
  const f = pathFrameAt(seed, point[2]);
  const dx = point[0] - f.center.x, dy = point[1] - f.center.y, dz = point[2] - f.center.z;
  const x = dx * f.right.x + dy * f.right.y + dz * f.right.z;
  const y = dx * f.up.x + dy * f.up.y + dz * f.up.z;
  return Math.hypot(x, y);
}

const mix = (a, b, t) => [
  a[0] + (b[0] - a[0]) * t,
  a[1] + (b[1] - a[1]) * t,
  a[2] + (b[2] - a[2]) * t,
];

function assertOutsideTube(seed, point, label) {
  const margin = localRadius(seed, point) - tubeRadiusAt(point[2], seed);
  assert.ok(margin >= -EPS, `${label}: wall entered tube by ${(-margin).toFixed(6)}m`);
}

test('ring centres and stable frames follow the analytic route exactly', () => {
  for (const seed of [1, 4096, 424242]) {
    const g = new Game().start({ seed, mode: 2 });
    for (let depth = 0; depth <= 10000; depth += 200) {
      g.player.pos[2] = depth;
      g._carve();
      let best = 0, gap = Infinity;
      for (let i = 0; i < g.cave.centers.length; i++) {
        const d = Math.abs(g.cave.centers[i][2] - depth);
        if (d < gap) { gap = d; best = i; }
      }
      const c = g.cave.centers[best], f = g.cave.frames[best], p = pathAt(seed, c[2]);
      assert.ok(Math.abs(c[0] - p.x) < EPS && Math.abs(c[1] - p.y) < EPS);
      const dotRU = f.right.x * f.up.x + f.right.y * f.up.y + f.right.z * f.up.z;
      const dotRT = f.right.x * f.tangent.x + f.right.y * f.tangent.y + f.right.z * f.tangent.z;
      const dotUT = f.up.x * f.tangent.x + f.up.y * f.tangent.y + f.up.z * f.tangent.z;
      assert.ok(Math.abs(dotRU) < EPS && Math.abs(dotRT) < EPS && Math.abs(dotUT) < EPS,
        `seed ${seed} depth ${depth}: frame lost orthogonality`);
    }
  }
});

test('wall triangles and the real three-start spiral stay outside the Boolean tube', () => {
  for (const seed of [1, 4096, 424242]) {
    const g = new Game().start({ seed, mode: 2 });
    for (let depth = 0; depth <= 10000; depth += 20) {
      g.player.pos[2] = depth;
      g._carve();
      let idx = 0, gap = Infinity;
      for (let i = 0; i < g.cave.centers.length; i++) {
        const d = Math.abs(g.cave.centers[i][2] - depth);
        if (d < gap) { gap = d; idx = i; }
      }
      const ring = g.cave.segs[idx].map((v) => [...v]);
      let previous = null, previousZ = -Infinity;
      for (let i = 0; i < g.cave.centers.length; i++) {
        const z = g.cave.centers[i][2];
        if (z < g.cave.centers[idx][2] && z > previousZ) {
          previousZ = z;
          previous = g.cave.segs[i];
        }
      }
      assert.ok(Math.abs(g.cave.innerRadii[idx] - tubeRadiusAt(g.cave.centers[idx][2], seed)) < EPS,
        'rooms may alter only the shell, never the protected radius');
      for (let j = 0; j < SECTOR_COUNT; j++) {
        const j1 = (j + 1) % SECTOR_COUNT;
        assertOutsideTube(seed, ring[j], `seed ${seed} ring vertex`);
        assertOutsideTube(seed, mix(ring[j], ring[j1], 0.5), `seed ${seed} sector edge`);
        if (previous) {
          assertOutsideTube(seed, mix(previous[j], ring[j], 0.5), `seed ${seed} axial edge`);
          const ab = mix(previous[j], ring[j], 0.5);
          const cd = mix(previous[j1], ring[j1], 0.5);
          assertOutsideTube(seed, mix(ab, cd, 0.5), `seed ${seed} triangle interior`);
        }
      }
    }
  }
});

test('the live ring buffer grows to cover unbounded post-floor sight', () => {
  const g = new Game().start({ seed: 2024, mode: 2 });
  const depth = 30000;
  g.player.pos[2] = g.player.start + depth;
  g._carve();
  const required = FOG_END * sightMul(depth);
  assert.ok(g.cave.len() >= required,
    `grown buffer ${g.cave.len().toFixed(1)}m < sight ${required.toFixed(1)}m`);
  assert.ok(g.cave.segs.length > SEGMENT_COUNT, 'the ring pool must grow beyond its initial size');
  assert.ok(g.cave.len() >= (g.cave.segs.length - 2) * SEGMENT_LEN);
});
