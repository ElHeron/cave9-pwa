import { test } from 'node:test';
import assert from 'node:assert/strict';

import { Game } from '../src/core/Game.js';
import {
  VisualScenarioV1,
  VisualSnapshotV1,
  normalizeVisualScenario,
} from '../src/dev/scenario/schema.mjs';
import {
  VisualScenarioRunner, crystalOrbitFrame,
  createVisualDevApi,
} from '../src/dev/scenario/VisualScenarioRunner.mjs';
import { VisualDebug3d, VISUAL_CLAY_LIGHT_RIG } from '../src/dev/lab/VisualDebug3d.mjs';

test('clay swaps real cave and landmark materials, then restores beauty state', () => {
  const beautyMaterial = { name: 'landmark-beauty' };
  const caveMaterial = { name: 'cave-beauty' };
  const mesh = { isMesh: true, material: beautyMaterial, userData: {} };
  const lights = Array.from({ length: 5 }, () => ({ visible: true }));
  const background = { name: 'beauty-background' };
  const fog = { name: 'beauty-fog' };
  const debug = Object.create(VisualDebug3d.prototype);
  debug.renderPass = 'beauty';
  debug.layers = { material: true, cave: true, fog: true, light: true };
  debug.scene = { background, fog };
  debug.r = { caveMesh: { material: caveMaterial, visible: true }, caveMat: caveMaterial,
    landmarkLayer: { group: { children: [{ children: [mesh] }] } },
    atmosphere: { fog }, ambient: lights[0], headlight: lights[1],
    forwardBeam: lights[2], hemi: lights[3], fill: lights[4] };
  debug.clayMaterial = { name: 'landmark-clay' };
  debug.clayCaveMaterial = { name: 'cave-clay', flatShading: true };
  debug.flatMaterial = { name: 'normal' };
  debug.silhouetteMaterial = { name: 'silhouette' };
  debug.neutralLandmarkMaterial = { name: 'neutral' };
  debug._beautyBackground = background;
  debug._clayBackground = { name: 'clay-background' };
  debug._silhouetteBackground = { name: 'silhouette-background' };
  debug.clayRig = { visible: false };
  debug.setRenderPass('clay');
  assert.equal(debug.r.caveMesh.material, debug.clayCaveMaterial);
  assert.equal(mesh.material, debug.clayMaterial);
  assert.equal(debug.scene.fog, null);
  assert.equal(debug.clayRig.visible, true);
  assert.ok(lights.every((light) => !light.visible));
  assert.equal(VISUAL_CLAY_LIGHT_RIG.key.intensity, 2);
  debug.setRenderPass('beauty');
  assert.equal(debug.r.caveMesh.material, caveMaterial);
  assert.equal(mesh.material, beautyMaterial);
  assert.equal(debug.scene.background, background);
  assert.equal(debug.scene.fog, fog);
  assert.equal(debug.clayRig.visible, false);
  assert.ok(lights.every((light) => light.visible));
});

test('VisualScenarioV1 normalizes to a bounded JSON-safe contract', () => {
  const scenario = normalizeVisualScenario({
    version: VisualScenarioV1,
    seed: '0',
    distance: '-40',
    placement: 'place',
    paused: 'false',
    ignored: { application: 'state' },
    settings: { landmarks: 'off', brightness: 99, fov: 2, motion: -1 },
  });
  assert.deepEqual(scenario, {
    version: VisualScenarioV1,
    name: 'visual-lab',
    seed: 1,
    mode: 2,
    distance: 0,
    steps: 0,
    family: 'auto',
    camera: 'hero',
    orthographicAxis: 'front',
    renderPass: 'beauty',
    orbitDegrees: 0,
    orbitScope: 'detail-bank',
    placement: 'place',
    control: 'autopilot',
    paused: false,
    viewport: { width: 1280, height: 720, dpr: 1 },
    settings: {
      readability: true,
      rockDetail: true,
      surfaceRelief: true,
      landmarks: false,
      cave: true,
      wireframe: false,
      landmarkMesh: true,
      collisionCapsules: false,
      booleanTube: false,
      playerHull: false,
      frames: false,
      fog: true,
      material: true,
      light: true,
      brightness: 2,
      fov: 45,
      motion: 0,
    },
  });
  assert.equal('ignored' in scenario, false);
  assert.doesNotThrow(() => JSON.stringify(scenario));
});

test('VisualScenarioRunner deterministically drives the real Game path', () => {
  const run = () => {
    const runner = new VisualScenarioRunner({ game: new Game() });
    runner.loadScenario({ seed: 4096, distance: 25, control: 'autopilot' });
    runner.step(12);
    return runner.snapshot({ includeImage: false });
  };
  const a = run();
  const b = run();
  assert.deepEqual(a, b);
  assert.equal(a.version, VisualSnapshotV1);
  assert.ok(a.distance >= 25);
  assert.equal(a.frame, b.frame);
  assert.equal(a.image, null);
});

test('placed scenarios use CaptureHarness placement and can reset exactly', () => {
  const runner = new VisualScenarioRunner({ game: new Game() });
  const loaded = runner.loadScenario({ seed: 256, distance: 500, placement: 'place' });
  assert.equal(loaded.distance, 500);
  assert.deepEqual(loaded.positioning, {
    requestedDistance: 500,
    actualDistance: 500,
    method: 'place',
    placed: true,
    flown: false,
    reached: true,
    crashed: false,
  });
  assert.ok(loaded.route.tangentDot > 0.999);
  assert.equal(loaded.frame, 0);
  runner.step(3);
  assert.equal(runner.inspect().frame, 3);
  assert.equal(runner.inspect().scenario.steps, 3);
  const reset = runner.reset();
  assert.equal(reset.distance, 500);
  assert.equal(reset.frame, 0);
});

test('dev API exposes loadScenario/step/setLayer/inspect/snapshot', () => {
  const calls = [];
  const renderer = {
    cameraCtl: {},
    canvas: { width: 320, height: 180, toDataURL: () => 'data:image/png;base64,frame' },
    setLandmarks: (v) => calls.push(['landmarks', v]),
    setRockDetail: (v) => calls.push(['rockDetail', v]),
    setSurfaceRelief: (v, profile) => calls.push(['surfaceRelief', v, profile]),
    setReadability: (v) => calls.push(['readability', v]),
    setBrightness: (v) => calls.push(['brightness', v]),
    setFov: (v) => calls.push(['fov', v]),
    setMotion: (v) => calls.push(['motion', v]),
    setSight: () => {},
    renderCapabilities: () => ({ rockDetailRequested: true, rockFacetActive: false,
      rockFacetSoftwareFallback: true,
      rockDetailSampleActive: false, rockDetailSoftwareFallback: true,
      surfaceReliefRequested: true, surfaceReliefActive: false,
      surfaceReliefProfile: null, surfaceReliefSoftwareFallback: true,
      landmarkMineralActive: false, landmarkRimActive: true, landmarkSoftwareFallback: true,
      landmarkLightingModel: 'lambert',
      coilingRimActive: true, coilingRimSoftwareFallback: false }),
    render: () => calls.push(['render']),
  };
  const app = {
    game: new Game(), renderer,
    canvas: renderer.canvas,
    state: 'menu', externalFrameDriver: false,
    AppState: { CAPTURE: 'capture', MENU: 'menu' },
    useExternalFrameDriver: () => { app.externalFrameDriver = true; calls.push(['external']); },
    releaseExternalFrameDriver: () => { app.externalFrameDriver = false; calls.push(['release']); },
    toMenu: () => { app.state = 'menu'; calls.push(['menu']); },
    input: { setEnabled: () => {} },
    audio: { stopLoops: () => {} },
    menu: { hideOverlay: () => {}, setFlightOverlayVisible: () => {}, setTouchVisible: () => {} },
    debug: { update: () => {} },
    holdCaptureFrame: () => {},
  };
  const api = createVisualDevApi(app);
  for (const method of ['loadScenario', 'step', 'setLayer', 'inspect', 'snapshot']) {
    assert.equal(typeof api[method], 'function', method);
  }
  api.loadScenario({ seed: 123, settings: { landmarks: true } });
  api.setLayer('landmarks', false);
  assert.equal(app.game.landmarksEnabled, false);
  assert.equal(api.inspect().layers.landmarks, false);
  api.setLayer('fog', false);
  assert.equal(api.inspect().layers.fog, false);
  api.setLayer('surfaceRelief', true);
  assert.equal(api.inspect().layers.surfaceRelief, true);
  assert.ok(calls.some(([name, enabled, profile]) => name === 'surfaceRelief'
    && enabled === true && profile === 'cave'));
  assert.throws(() => api.setLayer('not-a-layer', false), /Unsupported visual layer/);
  const shot = api.snapshot();
  assert.equal(shot.version, VisualSnapshotV1);
  assert.equal(shot.image.dataUrl, 'data:image/png;base64,frame');
  assert.equal(shot.renderCapabilities.rockDetailSampleActive, false);
  assert.equal(shot.renderCapabilities.rockDetailSoftwareFallback, true);
  assert.equal(shot.renderCapabilities.landmarkSoftwareFallback, true);
  assert.ok(calls.some(([name]) => name === 'render'));
  api.runner.dispose();
  assert.equal(app.state, 'menu');
  assert.equal(app.externalFrameDriver, false);
  assert.ok(calls.some(([name]) => name === 'release'));
});

test('scenario preserves family, camera, render pass and fixed capture viewport contract', () => {
  const scenario = normalizeVisualScenario({
    family: 'coiling', camera: 'orbit', orbitDegrees: 450,
    orthographicAxis: 'top', renderPass: 'silhouette',
    viewport: { width: 1920, height: 1080, dpr: 2 },
  });
  assert.equal(scenario.family, 'coiling');
  assert.equal(scenario.camera, 'orbit');
  assert.equal(scenario.orthographicAxis, 'top');
  assert.equal(scenario.renderPass, 'silhouette');
  assert.equal(scenario.orbitDegrees, 450);
  assert.deepEqual(scenario.viewport, { width: 1920, height: 1080, dpr: 2 });
  assert.equal(scenario.settings.fov, 45);
});

test('family off is an explicit VisualScenarioV1 state with no visible or lethal landmarks', () => {
  const normalized = normalizeVisualScenario({ family: 'off', placement: 'place', distance: 2140,
    settings: { landmarks: true } });
  assert.equal(normalized.family, 'off');
  assert.equal(normalized.settings.landmarks, false);
  const runner = new VisualScenarioRunner({ game: new Game() });
  const snapshot = runner.loadScenario(normalized);
  assert.equal(snapshot.family.requested, 'off');
  assert.deepEqual(snapshot.family.active, []);
  assert.equal(snapshot.layers.landmarks, false);
  assert.equal(runner.game.landmarksEnabled, false);
  assert.equal(runner.game.landmarkFamilyOverride, 'off');
  assert.equal(runner.game.cave.landmarkFamilyOverride, 'off',
    'off must be frozen before CaveStream prime');
});

test('orbit evidence fits the nearest real depth bank instead of shrinking the full axial family', () => {
  const runner = new VisualScenarioRunner({ game: new Game() });
  runner.scenario = { distance: 9050 };
  const comp = {
    typeName: 'crystal', z: 9100, frame: {
      right: { x: 1, y: 0, z: 0 }, up: { x: 0, y: 1, z: 0 },
      tangent: { x: 0, y: 0, z: 1 },
    },
    pieces: [
      { bank: 0, cz: 9000 }, { bank: 0, cz: 9002 },
      { bank: 1, cz: 9052 }, { bank: 1, cz: 9054 },
      { bank: 2, cz: 9120 },
    ],
  };
  const scoped = runner._orbitComposition(comp);
  assert.notEqual(scoped, comp);
  assert.equal(scoped.orbitScope, 'detail-bank');
  assert.deepEqual(scoped.pieces.map((piece) => piece.bank), [1, 1]);
  assert.equal(scoped.orbitRig, 'crystal-oblique-v1');
  assert.equal(scoped.orbitAxialWeight, 0.78);
  runner.scenario.orbitScope = 'complete-composition';
  const complete = runner._orbitComposition(comp);
  assert.equal(complete.orbitScope, 'complete-composition');
  assert.equal(complete.pieces.length, comp.pieces.length);
  assert.equal(complete.orbitRig, 'crystal-oblique-v1');
  const branching = { ...comp, typeName: 'branching',
    pieces: comp.pieces.map((piece, depthBand) => ({ ...piece, depthBand })) };
  assert.equal(runner._orbitComposition(branching), branching,
    'a connected Branching braid remains a complete-composition topology view');
  assert.equal(runner._orbitComposition({ ...comp, typeName: 'coiling', pieces: [] }).pieces.length, 0);
});

test('Crystal orbit rig exposes broad faces at every 60-degree evidence pose', () => {
  const frame = crystalOrbitFrame({
    right: { x: 1, y: 0, z: 0 },
    up: { x: 0, y: 1, z: 0 },
    tangent: { x: 0, y: 0, z: 1 },
  });
  const dot = (a, b) => a.x * b.x + a.y * b.y + a.z * b.z;
  for (const degrees of [0, 60, 120, 180, 240, 300]) {
    const angle = degrees * Math.PI / 180;
    const view = {
      x: frame.right.x * Math.cos(angle) + frame.up.x * Math.sin(angle),
      y: frame.right.y * Math.cos(angle) + frame.up.y * Math.sin(angle),
      z: frame.right.z * Math.cos(angle) + frame.up.z * Math.sin(angle),
    };
    assert.ok(Math.abs(dot(view, { x: 0, y: 0, z: 1 })) >= 0.389999,
      `${degrees} degrees retains an axial view of the real plates`);
  }
  assert.ok(Math.abs(dot(frame.right, frame.up)) < 1e-12);
  assert.ok(Math.abs(dot(frame.right, frame.tangent)) < 1e-12);
  assert.ok(Math.abs(dot(frame.up, frame.tangent)) < 1e-12);
});

test('Crystal orbit draw scope isolates real bank triangles and restores the original range', () => {
  const geometry = {
    drawRange: { start: 11, count: 997 },
    getIndex: () => ({ count: 36 * 36 }),
    setDrawRange(start, count) { this.drawRange = { start, count }; },
  };
  const mesh = { isMesh: true, geometry };
  const debug3d = Object.create(VisualDebug3d.prototype);
  debug3d._orbitDrawRanges = [];
  debug3d.r = { landmarkLayer: { built: new Map([['room', {
    roomKey: '2024:9:crystal', group: { visible: true, traverse: (visit) => visit(mesh) },
  }]]) } };
  const composition = { k: 9, typeName: 'crystal',
    pieces: Array.from({ length: 36 }, (_, gid) => ({ gid })) };
  const scope = debug3d.setOrbitPieceScope(composition, composition.pieces.slice(12, 24));
  assert.deepEqual(scope, { applied: true, meshCount: 1, pieceCount: 12,
    firstGid: 12, lastGid: 23 });
  assert.deepEqual(geometry.drawRange, { start: 12 * 36, count: 12 * 36 });
  debug3d.clearOrbitPieceScope();
  assert.deepEqual(geometry.drawRange, { start: 11, count: 997 });
  assert.equal(debug3d._orbitDrawRanges.length, 0);
});

test('Crystal orbit draw scope restores already changed meshes if setup throws', () => {
  const first = {
    drawRange: { start: 3, count: 700 }, getIndex: () => ({ count: 36 * 36 }),
    setDrawRange(start, count) { this.drawRange = { start, count }; },
  };
  const broken = {
    drawRange: { start: 0, count: Infinity }, getIndex: () => ({ count: 36 * 36 }),
    setDrawRange() { throw new Error('synthetic draw failure'); },
  };
  const debug3d = Object.create(VisualDebug3d.prototype);
  debug3d._orbitDrawRanges = [];
  debug3d.r = { landmarkLayer: { built: new Map([['room', {
    roomKey: '2024:9:crystal', group: { visible: true,
      traverse: (visit) => { visit({ isMesh: true, geometry: first }); visit({ isMesh: true, geometry: broken }); } },
  }]]) } };
  const composition = { k: 9, typeName: 'crystal',
    pieces: Array.from({ length: 36 }, (_, gid) => ({ gid })) };
  assert.throws(() => debug3d.setOrbitPieceScope(composition, composition.pieces.slice(0, 12)),
    /synthetic draw failure/);
  assert.deepEqual(first.drawRange, { start: 3, count: 700 });
  assert.equal(debug3d._orbitDrawRanges.length, 0);
});
