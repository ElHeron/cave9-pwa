import { test } from 'node:test';
import assert from 'node:assert/strict';
import { GameApp } from '../src/main.js';
import { AppState, IDLE_DEMO_MS } from '../src/app/AppState.js';
import { createRunContext } from '../src/app/RunContext.js';
import { SaveSystem } from '../src/platform/SaveSystem.js';

function appDouble() {
  const app = Object.create(GameApp.prototype);
  app.state = AppState.MENU;
  const values = { controlMode: 2, sensitivity: 1, landmarks: true, helpSeen: true };
  app.settings = {
    values,
    get: (key) => values[key],
    set(key, value) { values[key] = value; return value; },
  };
  app.audio = { resume() {}, stopLoops() {}, blip() {}, crash() {} };
  app.game = {
    player: {}, score: { breakCombo() {}, bestCombo: 0, distance: 100, maxSpeed: 10, grazeTime: 0 },
    start({ mode, seed }) { this.mode = mode; this.seed = seed; },
    scoreValue() { return 42; },
  };
  app.session = { reset() {} };
  app.input = { setMode(mode) { this.mode = mode; }, setEnabled() {}, bindTouch() {} };
  app.renderer = { setLandmarks(on) { this.landmarks = on; } };
  app.demo = { player: {}, landmarksEnabled: true };
  app.menu = {
    current: 'menu', hideOverlay() { this.current = null; }, showScreen(name) { this.current = name; },
    setFlightOverlayVisible() {}, setTouchVisible() {}, showDeath() {},
    setMenuBest() {}, setDailyInfo() {}, showSharedRun() {}, setMenuMessage() {}, showFirstRunHelp() {},
  };
  app.touch = true;
  app._portraitQuery = { matches: false };
  return app;
}

test('Enter respects the visible menu panel', () => {
  const app = appDouble();
  app.menu.current = 'settings';
  app.onConfirm();
  assert.equal(app.state, AppState.MENU);
  app.menu.current = 'menu';
  app.onConfirm();
  assert.equal(app.state, AppState.RUNNING);
});

test('a slow first load and returning from a run both give the menu a full idle interval', (t) => {
  let now = 60_000;
  t.mock.method(performance, 'now', () => now);
  const app = appDouble();
  app.lastInteract = 0;
  app.session.simulate = () => {};
  app.session.presentIdle = () => {};
  app.startDemo = () => { app.state = AppState.DEMO; };

  for (const previousState of [AppState.BOOT, AppState.DEAD]) {
    app.state = previousState;
    app.toMenu();
    app._stepMenu(0.016, now + IDLE_DEMO_MS - 1);
    assert.equal(app.state, AppState.MENU, 'the player has time to choose Play');
    app._stepMenu(0.016, now + IDLE_DEMO_MS + 1);
    assert.equal(app.state, AppState.DEMO, 'the idle demo still starts after the grace period');
    now += 60_000;
  }
});

test('Daily applies fixed rules while personal free settings survive the run', () => {
  const app = appDouble();
  Object.assign(app.settings.values, { controlMode: 1, sensitivity: 1.6, landmarks: false });
  app.startRun({ daily: true, date: new Date('2026-09-29T12:00:00Z') });
  assert.deepEqual(app.runContext.rules, {
    controlMode: 2, thrustScale: 1, landmarks: true, key: 'r1-m2-t1-l1',
  });
  assert.equal(app.game.mode, 2);
  assert.equal(app.game.player.thrustScale, 1);
  assert.equal(app.game.landmarksEnabled, true);
  assert.equal(app.renderer.landmarks, true);
  assert.equal(app.input.mode, 2);
  assert.deepEqual(app.settings.values, { controlMode: 1, sensitivity: 1.6, landmarks: false, helpSeen: true });

  app.toMenu();
  assert.equal(app.renderer.landmarks, false);
  assert.equal(app.input.mode, 1);
  assert.equal(app.game.player.thrustScale, 1.6);
  assert.deepEqual(app.settings.values, { controlMode: 1, sensitivity: 1.6, landmarks: false, helpSeen: true });
});

test('settings changes during a run cannot alter its frozen scored rules', () => {
  const app = appDouble();
  app.startRun({ seed: 123 });
  const rules = app.runContext.rules;
  app.onSettingChange('controlMode', 1);
  app.onSettingChange('sensitivity', 1.6);
  app.onSettingChange('landmarks', false);
  assert.equal(app.runContext.rules, rules);
  assert.equal(app.game.mode, 2);
  assert.equal(app.input.mode, 2);
  assert.equal(app.game.player.thrustScale, 1);
  assert.equal(app.game.landmarksEnabled, true);
  assert.equal(app.renderer.landmarks, true);
  app.toMenu();
  assert.equal(app.input.mode, 1);
  assert.equal(app.renderer.landmarks, false);
});

test('click and Enter retry preserve the same daily context and score day', async () => {
  const app = appDouble();
  const context = createRunContext({ daily: true, date: new Date('2026-09-29T23:59:59Z') });
  const previousRecordRun = SaveSystem.recordRun;
  const saved = [];
  SaveSystem.recordRun = (run, score) => { saved.push([run.dailyKey, score]); return { newBest: true }; };
  const previousDocument = globalThis.document;
  const PreviousDate = globalThis.Date;
  const buttons = new Map();
  globalThis.document = {
    getElementById(id) {
      if (!buttons.has(id)) buttons.set(id, {
        addEventListener(type, fn) { if (type === 'click') this.click = fn; },
      });
      return buttons.get(id);
    },
  };
  try {
    app._wireUI();
    app.startRun({ context });
    globalThis.Date = class extends PreviousDate {
      constructor(...args) { super(...(args.length ? args : ['2026-09-30T00:00:01Z'])); }
    };
    app.die();
    assert.deepEqual(saved, [['2026-09-29', 42]]);
    let seedText = '';
    app._copy = (text) => { seedText = text; return text; };
    assert.match(app._copyResult(), /Daily 2026-09-29/);
    await app._copySeed();
    assert.match(seedText, /day=2026-09-29/);

    buttons.get('btn-retry').click();
    assert.equal(app.runContext, context, 'click retry reuses the frozen object');
    assert.equal(app.game.seed, context.seed);
    app.die();

    app.onConfirm();
    assert.equal(app.runContext, context, 'Enter retry uses the same path');
    assert.equal(app.state, AppState.RUNNING);
    assert.deepEqual(saved.map(([day]) => day), ['2026-09-29', '2026-09-29']);
  } finally {
    globalThis.Date = PreviousDate;
    SaveSystem.recordRun = previousRecordRun;
    if (previousDocument === undefined) delete globalThis.document;
    else globalThis.document = previousDocument;
  }
});

test('portrait freezes a running game until an explicit landscape resume', () => {
  const app = appDouble();
  const media = { matches: false, addEventListener(type, fn) { this.change = fn; } };
  app._portraitQuery = media;
  const previousWindow = globalThis.window;
  const previousDocument = globalThis.document;
  globalThis.window = { addEventListener() {} };
  globalThis.document = { addEventListener() {} };
  try {
    app._bindWindow();
    app.startRun({ seed: 123 });
    media.matches = true;
    media.change({ matches: true });
    assert.equal(app.state, AppState.PAUSED);
    let steps = 0;
    let heldFrames = 0;
    app._stepRun = () => { steps++; };
    app.session.presentHeld = () => { heldFrames++; };
    app.input.update = () => {};
    app.debug = { tick() {} };
    app.externalFrameDriver = true;
    app.lastTime = 0;
    app.loop(16);
    assert.equal(steps, 0, 'portrait hint keeps the simulation frozen');
    assert.equal(heldFrames, 1);
    app.resume();
    assert.equal(app.state, AppState.PAUSED, 'rotate hint cannot hide a running simulation');
    media.matches = false;
    media.change({ matches: false });
    assert.equal(app.state, AppState.PAUSED, 'landscape return does not auto-resume');
    app.resume();
    assert.equal(app.state, AppState.RUNNING);
    app.loop(32);
    assert.equal(steps, 1);
  } finally {
    if (previousWindow === undefined) delete globalThis.window;
    else globalThis.window = previousWindow;
    if (previousDocument === undefined) delete globalThis.document;
    else globalThis.document = previousDocument;
  }
});
