import { beforeEach, test } from 'node:test';
import assert from 'node:assert/strict';

class MemStore {
  constructor() { this.values = new Map(); }
  getItem(key) { return this.values.has(key) ? this.values.get(key) : null; }
  setItem(key, value) { this.values.set(key, String(value)); }
  removeItem(key) { this.values.delete(key); }
  clear() { this.values.clear(); }
}

const store = new MemStore();
globalThis.localStorage = store;
const { SaveSystem, SAVE_FORMAT_VERSION } = await import('../src/platform/SaveSystem.js');
const { createRunContext } = await import('../src/app/RunContext.js');

beforeEach(() => store.clear());

test('malformed JSON, primitives, null and arrays safely fall back at the storage boundary', () => {
  store.setItem('cave9.settings', '42');
  assert.equal(SaveSystem.getSettings(), null);
  store.setItem('cave9.settings', 'null');
  assert.equal(SaveSystem.getSettings(), null);
  store.setItem('cave9.settings', '[]');
  assert.equal(SaveSystem.getSettings(), null);
  store.setItem('cave9.settings', '{broken');
  assert.equal(SaveSystem.getSettings(), null);

  store.setItem('cave9.best.2', JSON.stringify('100'));
  store.setItem('cave9.daily.2026-06-21', JSON.stringify([]));
  assert.equal(SaveSystem.getBest(2), 0);
  assert.equal(SaveSystem.getDailyBest('2026-06-21'), 0);
});

test('valid historical settings and scalar best scores remain readable', () => {
  const settings = { fov: 70, sound: false };
  store.setItem('cave9.settings', JSON.stringify(settings));
  store.setItem('cave9.best.1', JSON.stringify(9007199254740991));
  assert.deepEqual(SaveSystem.getSettings(), settings);
  assert.equal(SaveSystem.getBest(1), 9007199254740991);
});

test('unsafe numeric scores and seeds do not overflow into unrelated records', () => {
  store.setItem('cave9.best.2', JSON.stringify(2 ** 53));
  assert.equal(SaveSystem.getBest(2), 0);
  assert.equal(SaveSystem.setBest(2, 2 ** 53), false);
  assert.equal(SaveSystem.setSeedBest(2 ** 40, 5), false);
  assert.equal(SaveSystem.getSeedBest(2 ** 40), 0);
  assert.equal(SaveSystem.setLastSeed(2 ** 40), false);
  assert.equal(SaveSystem.getLastSeed(), null);
});

test('corrupt seed and unlock maps are filtered without prototype-key leakage', () => {
  store.setItem('cave9.seedBest', JSON.stringify({ '42': 200, '43': '300', '1.5': 4, '__proto__': 9 }));
  assert.equal(SaveSystem.getSeedBest(42), 200);
  assert.equal(SaveSystem.getSeedBest(43), 0);
  assert.equal(SaveSystem.getSeedBest(1), 0);
  assert.deepEqual(JSON.parse(store.getItem('cave9.seedBest')), { '42': 200 });
  assert.equal(SaveSystem.setSeedBest(44, 250), true);
  assert.deepEqual(JSON.parse(store.getItem('cave9.seedBest')), { '42': 200, '44': 250 });

  store.setItem('cave9.unlocks', JSON.stringify({ tunnel: true, broken: 'yes', '__proto__': true }));
  const unlocks = SaveSystem.getUnlocks();
  assert.equal(Object.getPrototypeOf(unlocks), null);
  assert.deepEqual({ ...unlocks }, { tunnel: true });
  assert.deepEqual(JSON.parse(store.getItem('cave9.unlocks')), { tunnel: true });
  assert.equal(SaveSystem.setUnlock('__proto__'), false);
  assert.equal(SaveSystem.setUnlock('tunnel', false), true);
});

test('writes establish a storage format marker without changing historical keys', () => {
  assert.equal(SaveSystem.formatVersion(), 0);
  assert.equal(SaveSystem.setDailyBest('2026-06-21', 123), true);
  assert.equal(SaveSystem.formatVersion(), SAVE_FORMAT_VERSION);
  assert.equal(JSON.parse(store.getItem('cave9.daily.2026-06-21')), 123);
});

test('a blocked storage implementation is safe and leaves the game-facing API usable', () => {
  const oldStorage = globalThis.localStorage;
  globalThis.localStorage = {
    getItem() { throw new Error('blocked'); },
    setItem() { throw new Error('blocked'); },
    removeItem() { throw new Error('blocked'); },
  };
  try {
    assert.equal(SaveSystem.available(), false);
    assert.equal(SaveSystem.getBest(2), 0);
    assert.equal(SaveSystem.setBest(2, 100), true);
    assert.equal(SaveSystem.setSettings({ fov: 70 }), false);
    assert.equal(SaveSystem.setSeedBest(12, 100), true);
  } finally {
    globalThis.localStorage = oldStorage;
  }
});

test('ranked scores use a new namespace and retain historical bests and version', () => {
  store.setItem('cave9.storageVersion', '1');
  store.setItem('cave9.best.2', '800');
  store.setItem('cave9.seedBest', '{"123":700}');
  store.setItem('cave9.daily.2026-09-29', '600');
  assert.equal(SaveSystem.formatVersion(), 1);
  const free = createRunContext({ seed: 123 });
  assert.equal(SaveSystem.getRunBest(free), 0);
  assert.deepEqual(SaveSystem.recordRun(free, 100), {
    newBest: true, newSeedBest: true, newDailyBest: false,
  });
  assert.equal(SaveSystem.getRunBest(free), 100);
  assert.equal(SaveSystem.getRunSeedBest(free), 100);
  assert.equal(SaveSystem.formatVersion(), SAVE_FORMAT_VERSION);
  assert.equal(SaveSystem.getBest(2), 800);
  assert.equal(SaveSystem.getSeedBest(123), 700);
  assert.equal(SaveSystem.getDailyBest('2026-09-29'), 600);
  assert.equal(store.getItem('cave9.best.2'), '800');
});

test('mode, exact thrust, obstacles and free/Daily status separate records', () => {
  const base = createRunContext({ seed: 123 });
  const mode = createRunContext({ seed: 123, rules: { controlMode: 1, thrustScale: 1, landmarks: true } });
  const thrust = createRunContext({ seed: 123, rules: { controlMode: 2, thrustScale: 1 + Number.EPSILON, landmarks: true } });
  const obstacles = createRunContext({ seed: 123, rules: { controlMode: 2, thrustScale: 1, landmarks: false } });
  SaveSystem.recordRun(base, 100);
  for (const context of [mode, thrust, obstacles]) {
    assert.equal(SaveSystem.getRunBest(context), 0);
    assert.equal(SaveSystem.getRunSeedBest(context), 0);
    SaveSystem.recordRun(context, 50);
  }
  assert.equal(SaveSystem.getRunBest(base), 100);
  assert.equal(SaveSystem.getRunSeedBest(base), 100);
  const daily = createRunContext({ daily: true, date: new Date('2026-09-29T12:00:00Z') });
  assert.equal(SaveSystem.getRunBest(daily), 0);
  assert.equal(SaveSystem.getRunDailyBest(daily), 0);
  SaveSystem.recordRun(daily, 75);
  assert.equal(SaveSystem.getRunBest(daily), 75);
  assert.equal(SaveSystem.getRunDailyBest(daily), 75);
  assert.equal(SaveSystem.getRunDailyBest(createRunContext({ daily: true, date: new Date('2026-09-30T12:00:00Z') })), 0);
});

test('ranked storage rejects inconsistent Daily identity and repairs corrupt seed maps', () => {
  const daily = createRunContext({ daily: true, date: new Date('2026-09-29T12:00:00Z') });
  assert.equal(SaveSystem.setRunDailyBest({ ...daily, seed: 42 }, 100), false);
  assert.equal(SaveSystem.setRunDailyBest({ ...daily, dailyKey: '2026-02-30' }, 100), false);
  assert.equal(SaveSystem.setRunBest({ ...daily, rules: { ...daily.rules, key: 'r1-m1-t1-l1' } }, 100), false);
  const free = createRunContext({ seed: 123 });
  const key = `cave9.ranked.v1.seedBest.free.${free.rules.key}`;
  store.setItem(key, '{"123":40,"bogus":100,"__proto__":900}');
  assert.equal(SaveSystem.getRunSeedBest(free), 40);
  assert.deepEqual(JSON.parse(store.getItem(key)), { '123': 40 });
});
