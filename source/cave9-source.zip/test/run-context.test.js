import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createRunContext } from '../src/app/RunContext.js';
import { dailySeed } from '../src/core/RNG.js';
import { DAILY_RULES, normalizeRunRules } from '../src/core/RunRules.js';

test('daily context freezes its UTC start day and derived seed', () => {
  const start = new Date('2026-09-29T23:59:59Z');
  const context = createRunContext({ daily: true, date: start });
  start.setUTCDate(30);
  assert.deepEqual(context, {
    seed: dailySeed(new Date('2026-09-29T12:00:00Z')),
    daily: true,
    dailyKey: '2026-09-29',
    rules: DAILY_RULES,
  });
  assert.equal(Object.isFrozen(context), true);
});

test('free context normalizes its seed to the one Game.start uses', () => {
  assert.deepEqual(createRunContext({ seed: 0 }), { seed: 1, daily: false, dailyKey: null, rules: normalizeRunRules() });
  assert.deepEqual(createRunContext({ seed: 0x100000002 }), { seed: 2, daily: false, dailyKey: null, rules: normalizeRunRules() });
});

test('Daily ignores personal gameplay settings; free runs snapshot their applied values', () => {
  const values = { controlMode: 1, sensitivity: 1.6, landmarks: false, brightness: 0.7 };
  const settings = { get: (key) => values[key] };
  const free = createRunContext({ seed: 123, settings });
  const daily = createRunContext({ daily: true, date: new Date('2026-09-29T12:00:00Z'), settings });
  values.sensitivity = 0.6;
  values.landmarks = true;
  assert.deepEqual(free.rules, normalizeRunRules({ controlMode: 1, sensitivity: 1.6, landmarks: false }));
  assert.equal(Object.isFrozen(free.rules), true);
  assert.equal(daily.rules, DAILY_RULES);
  assert.equal(Object.isFrozen(daily), true);
});

test('display and audio options do not create a new rule category', () => {
  const a = createRunContext({ seed: 123, settings: { controlMode: 2, sensitivity: 1, landmarks: true, brightness: 0.6 } });
  const b = createRunContext({ seed: 123, settings: { controlMode: 2, sensitivity: 1, landmarks: true, brightness: 1.5, sound: false } });
  assert.equal(a.rules.key, b.rules.key);
});
