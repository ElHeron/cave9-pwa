import { test } from 'node:test';
import assert from 'node:assert/strict';
import { makePiece } from '../src/core/landmarks/safety.js';
import { slabHullForPiece } from '../src/core/landmarks/SlabHull.js';
import { queryNearestSurface, closestTrianglePoint } from '../src/core/SurfaceQuery.js';
import { collision, sweptCollision } from '../src/core/CollisionSystem.js';
import { Ship } from '../src/core/Ship.js';
import { buildCompositionAccums } from '../src/render/landmarks/LandmarkMeshBuilder.js';
import { Game } from '../src/core/Game.js';
import { compositionAt, roomZ } from '../src/core/Landmarks.js';

const emptyCave = { centers: [], segs: [], frames: [] };

function plateScene() {
  const piece = makePiece('blade', { x: 0, y: 0, z: 15600 }, { x: 1, y: 0, z: 0 }, 12, 3);
  piece.gid = 'test-plate';
  Object.defineProperty(piece, 'slabHull', { value: slabHullForPiece(piece) });
  return { piece, comp: { typeName: 'crystal', pieces: [piece], collisionPieces: [piece] } };
}

function trianglePoint(hull, triangle) {
  return [0, 1, 2].map(axis => [0, 1, 2].reduce((sum, corner) =>
    sum + hull.vertices[hull.triangles[triangle * 3 + corner] * 3 + axis] / 3, 0));
}

test('the shared plate query removes capsule phantom hits for a real one-metre ship', () => {
  const { piece, comp } = plateScene();
  const coarsePiece = { ...piece };
  const coarse = { ...comp, pieces: [coarsePiece], collisionPieces: [coarsePiece] };
  for (const point of [[6, -2.4, 15600], [6, 2.4, 15600]]) {
    const old = queryNearestSurface(emptyCave, point, 1, [coarse]);
    const exact = queryNearestSurface(emptyCave, point, 1, [comp]);
    assert.ok(old.nearest.hullClearance < 0, 'the capsule would kill the ship');
    assert.ok(exact.nearest.hullClearance > 0.8, 'the visible plate leaves room for the whole ship');
    const ship = new Ship();
    ship.radius = 1;
    ship.pos.splice(0, 3, ...point);
    assert.ok(collision(emptyCave, ship, [comp]) > 0.8);
    assert.equal(ship.graced, false, 'clearance comes from geometry, not numeric grace');
  }
});

test('plate face contacts and interior use the signed shared body', () => {
  const { piece, comp } = plateScene();
  for (let triangle = 0; triangle < piece.slabHull.triangles.length / 3; triangle++) {
    const point = trianglePoint(piece.slabHull, triangle);
    const query = queryNearestSurface(emptyCave, point, 1, [comp]);
    assert.ok(Math.abs(query.landmark.surfaceDistance) < 1e-7);
    assert.ok(Math.abs(query.landmark.hullClearance + 1) < 1e-7);
    assert.strictEqual(query.landmark.piece, piece);
  }
  const inside = queryNearestSurface(emptyCave, [6, 0, 15600], 1, [comp]);
  assert.ok(inside.landmark.surfaceDistance < -0.3, 'interior is signed, not an outside clearance');
  assert.ok(inside.landmark.hullClearance < -1.3);
  const ship = new Ship();
  ship.radius = 1;
  ship.pos.splice(0, 3, 6, 3, 15600);
  assert.equal(sweptCollision(emptyCave, ship, [6, -3, 15600], [comp]), 0,
    'a fast step across the plate still touches its true surface');
});

test('rendered crystal triangles and collision give the same free-space distance', () => {
  const { comp } = plateScene();
  const mesh = buildCompositionAccums(comp).crystal;
  assert.equal(mesh.i.length, comp.pieces[0].slabHull.triangles.length);
  for (const point of [[6, -2.4, 15600], [6, 2.4, 15600], [13, 1, 15600], [-1, 0, 15600]]) {
    let distance = Infinity;
    for (let i = 0; i < mesh.i.length; i += 3) {
      const triangle = [0, 1, 2].map(corner => mesh.p.slice(mesh.i[i + corner] * 3,
        mesh.i[i + corner] * 3 + 3));
      distance = Math.min(distance, closestTrianglePoint(point, ...triangle).distance);
    }
    const exact = queryNearestSurface(emptyCave, point, 1, [comp]);
    assert.ok(Math.abs(exact.landmark.surfaceDistance - distance) < 1e-7,
      `render/query differ at ${point}: ${distance} vs ${exact.landmark.surfaceDistance}`);
  }
});

test('live crystal compositions cache exactly the world hulls submitted by the renderer', () => {
  for (const seed of [2024, 256, 4096]) {
    const game = new Game();
    game.start({ mode: 2, seed, family: 'crystal' });
    game.cave.generateThrough(roomZ(9) + 120);
    const comp = compositionAt(seed, game.cave, 9, 'crystal');
    const mesh = buildCompositionAccums(comp).crystal;
    assert.equal(mesh.i.length, comp.pieces.reduce((count, piece) =>
      count + piece.slabHull.triangles.length, 0));
    let renderIndexOffset = 0;
    for (let index = 0; index < comp.pieces.length; index++) {
      const piece = comp.pieces[index], hull = piece.slabHull;
      assert.ok(hull, `${seed}/${index}: final world piece owns its exact hull`);
      assert.equal(Object.getOwnPropertyDescriptor(piece, 'slabHull').enumerable, false);
      assert.ok(comp.collisionPieces.includes(piece), 'collision receives the same world piece');
      const isolated = { pieces: [piece], collisionPieces: [piece] };
      for (let corner = 0; corner < hull.triangles.length; corner++) {
        const renderVertex = mesh.i[renderIndexOffset + corner] * 3;
        const coreVertex = hull.triangles[corner] * 3;
        for (let axis = 0; axis < 3; axis++) {
          assert.equal(mesh.p[renderVertex + axis], hull.vertices[coreVertex + axis],
            `${seed}/${index}: renderer cannot introduce a separate plate surface`);
        }
      }
      for (let triangle = 0; triangle < hull.triangles.length / 3; triangle++) {
        const contact = trianglePoint(hull, triangle);
        const query = queryNearestSurface(game.cave, contact, 1, [isolated]);
        assert.ok(Math.abs(query.landmark.surfaceDistance) < 1e-7,
          `${seed}/${index}/${triangle}: live visible face is lethal on contact`);
        assert.ok(Math.abs(query.landmark.hullClearance + 1) < 1e-7);
      }
      assert.strictEqual(piece.slabHull, hull, 'rendering/querying reuse the cached hull');
      renderIndexOffset += hull.triangles.length;
    }
  }
});
