import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { mkdtemp, mkdir, readFile, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { basename, join, resolve, sep } from 'node:path';
import { test } from 'node:test';
import { buildServiceWorker, collectAssetManifest } from '../scripts/build-service-worker.mjs';
import { registerProductionServiceWorker, serviceWorkerUrls } from '../src/app/ServiceWorkerLifecycle.js';

test('the offline manifest changes when a same-name public asset changes', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'cave9-sw-'));
  try {
    await mkdir(join(dir, 'assets'));
    await writeFile(join(dir, 'index.html'), '<main>Cave9</main>');
    await writeFile(join(dir, 'assets', 'icon.png'), 'old bytes');
    const first = await buildServiceWorker(dir);
    const source = await readFile(join(dir, 'sw.js'), 'utf8');
    assert.equal(first.manifest.length, 2);
    assert.equal(first.manifest.find(item => item.path === 'assets/icon.png').hash,
      createHash('sha256').update('old bytes').digest('hex'));
    assert.match(source, /cache: 'no-store'/);
    assert.match(source, /Offline asset hash mismatch/);
    assert.doesNotMatch(source, /skipWaiting\s*\(/);
    assert.doesNotMatch(source, /clients\.claim\s*\(/);
    await writeFile(join(dir, 'assets', 'icon.png'), 'new bytes');
    const second = await collectAssetManifest(dir);
    assert.notEqual(second.buildId, first.buildId);
    assert.equal(second.manifest.length, 2); // generated sw.js is not an input
  } finally {
    assert.ok(resolve(dir).startsWith(resolve(tmpdir()) + sep) && basename(dir).startsWith('cave9-sw-'));
    await rm(dir, { recursive: true, force: true });
  }
});

test('relative worker URLs stay inside the deployed subpath', () => {
  assert.deepEqual(serviceWorkerUrls('./', 'https://example.test/Cave9/?c9=1'), {
    scope: 'https://example.test/Cave9/', script: 'https://example.test/Cave9/sw.js',
  });
  assert.deepEqual(serviceWorkerUrls('./', 'https://example.test/index.html'), {
    scope: 'https://example.test/', script: 'https://example.test/sw.js',
  });
});

test('dev never registers and production reports only a waiting worker', async () => {
  let calls = 0;
  const registration = new EventTarget();
  registration.waiting = null;
  registration.installing = null;
  registration.update = async () => {};
  const serviceWorker = new EventTarget();
  serviceWorker.register = async (script, options) => {
    calls++;
    assert.equal(script, 'https://example.test/sub/sw.js');
    assert.deepEqual(options, { scope: 'https://example.test/sub/', updateViaCache: 'none' });
    return registration;
  };
  const args = { base: './', pageUrl: 'https://example.test/sub/', serviceWorker };
  assert.equal(await registerProductionServiceWorker({ ...args, production: false }), null);
  assert.equal(calls, 0);
  const updates = [];
  await registerProductionServiceWorker({ ...args, production: true, onUpdate: ready => updates.push(ready) });
  assert.deepEqual(updates, [false]);
  registration.installing = new EventTarget();
  registration.dispatchEvent(new Event('updatefound'));
  registration.waiting = {};
  registration.installing.dispatchEvent(new Event('statechange'));
  assert.deepEqual(updates, [false, true]);
});
