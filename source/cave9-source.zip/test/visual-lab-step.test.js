import { test } from 'node:test';
import assert from 'node:assert/strict';

import { createVisualLabStepBridge } from '../src/dev/lab/VisualLab.mjs';

test('capture step preserves the runner result without rebuilding inspector UI', () => {
  let status = 0, atlas = 0;
  const result = { version: 'VisualSnapshotV1', frame: 8 };
  const api = { runner: { frame: 8 }, step: (count) => {
    assert.equal(count, 8);
    return result;
  } };
  const step = createVisualLabStepBridge(api, { captureMode: true,
    renderStatus: () => { status++; }, renderAtlas: () => { atlas++; },
    lastAtlasFrame: () => 0 });
  assert.equal(step(8), result);
  assert.equal(status, 0);
  assert.equal(atlas, 0);
});

test('interactive external steps refresh status and throttle atlas to six frames', () => {
  let status = 0, atlas = 0, lastAtlasFrame = 0;
  const api = { runner: { frame: 0 }, step: () => {
    api.runner.frame++;
    return api.runner.frame;
  } };
  const step = createVisualLabStepBridge(api, { captureMode: false,
    renderStatus: () => { status++; },
    renderAtlas: () => { atlas++; lastAtlasFrame = api.runner.frame; },
    lastAtlasFrame: () => lastAtlasFrame });
  for (let i = 1; i <= 12; i++) assert.equal(step(), i);
  assert.equal(status, 12);
  assert.equal(atlas, 2);
});

test('step bridge preserves runner errors without refreshing inspector UI', () => {
  let refreshes = 0;
  const error = new Error('runner failed');
  const api = { runner: { frame: 0 }, step: () => { throw error; } };
  const step = createVisualLabStepBridge(api, { captureMode: false,
    renderStatus: () => { refreshes++; }, renderAtlas: () => { refreshes++; },
    lastAtlasFrame: () => 0 });
  assert.throws(step, (actual) => actual === error);
  assert.equal(refreshes, 0);
});
