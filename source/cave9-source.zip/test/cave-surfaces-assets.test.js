import test from 'node:test';
import assert from 'node:assert/strict';
import { existsSync, readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { PNG } from 'pngjs';
import { buildCaveSurfaces } from '../scripts/build-cave-surfaces.mjs';

const ROOT = resolve(import.meta.dirname, '..');
const ASSETS = resolve(ROOT, 'public/assets');
const CONTACT_SHEET = resolve(ROOT, 'docs/assets/cave-surfaces-contact-sheet.png');

function pixelAt(png, x, y) {
  const offset = (y * png.width + x) * 4;
  return [...png.data.subarray(offset, offset + 4)];
}

test('Cave surface runtime asset contract is committed, source-independent and mip-safe', () => {
  const expected = buildCaveSurfaces({ checkOnly: true });
  const manifestPath = resolve(ASSETS, 'cave-surfaces.manifest.json');
  const sourcePath = resolve(ASSETS, 'cave-surfaces-source.png');
  assert.ok(existsSync(manifestPath), 'generated runtime manifest is committed');
  assert.ok(existsSync(sourcePath), 'generated transport PNG is committed');
  assert.ok(existsSync(CONTACT_SHEET), 'generated contact sheet is committed as a non-runtime preview');
  const actual = JSON.parse(readFileSync(manifestPath, 'utf8'));
  assert.ok(!('contactSheet' in actual), 'runtime manifest does not ship preview metadata');
  assert.deepEqual(actual, expected, 'check path validates and returns the committed runtime manifest');
  assert.equal(actual.version, 'CaveSurfaceRuntimeV1');
  assert.deepEqual([actual.width, actual.height, actual.layerCount, actual.columns, actual.rows], [128, 128, 53, 8, 7]);
  assert.equal(actual.layers.length, 53);
  assert.deepEqual(actual.layers.map(({ index }) => index), Array.from({ length: 53 }, (_, index) => index));
  assert.equal(new Set(actual.layers.map(({ id }) => id)).size, 53);
  assert.deepEqual(actual.layers.slice(0, 4).map(({ id }) => id), ['tunnel.v1.neutral', 'tunnel.v1.floor', 'tunnel.v1.sideWall', 'tunnel.v1.ceiling']);
  assert.deepEqual(actual.layers.slice(-7).map(({ id }) => id), ['family.coiling.layerA', 'family.coiling.layerB', 'family.coiling.layerC', 'family.coiling.lava', 'family.coiling.floor', 'family.coiling.sideWall', 'family.coiling.ceiling']);
  for (const layer of actual.layers) {
    assert.ok(layer.meanLinear.every((value) => Number.isFinite(value) && value >= 0 && value <= 1));
    assert.equal(layer.atlas.width, 128);
    assert.equal(layer.atlas.height, 128);
    assert.equal(layer.atlas.x, (layer.index % actual.columns) * actual.width,
      `${layer.id} has a pixel-aligned, isolated atlas column`);
    assert.equal(layer.atlas.y, Math.floor(layer.index / actual.columns) * actual.height,
      `${layer.id} has a pixel-aligned, isolated atlas row`);
  }
  const source = PNG.sync.read(readFileSync(sourcePath));
  const contact = PNG.sync.read(readFileSync(CONTACT_SHEET));
  assert.deepEqual([source.width, source.height], [1024, 896]);
  assert.deepEqual([contact.width, contact.height], [1024, 896]);
  for (const layer of actual.layers) {
    const x = layer.atlas.x;
    const y = layer.atlas.y;
    assert.match(layer.source, /^artifacts\/texture-concepts\//, `${layer.id} retains traceable source metadata`);
    assert.deepEqual(pixelAt(source, x, y), pixelAt(contact, x, y), `${layer.id} starts at its declared transport cell`);
    for (let row = 0; row < 128; row++) {
      assert.deepEqual(pixelAt(source, x, y + row), pixelAt(source, x + 127, y + row), `${layer.id} has a locked horizontal seam`);
    }
    for (let column = 0; column < 128; column++) {
      assert.deepEqual(pixelAt(source, x + column, y), pixelAt(source, x + column, y + 127), `${layer.id} has a locked vertical seam`);
    }
  }
});
