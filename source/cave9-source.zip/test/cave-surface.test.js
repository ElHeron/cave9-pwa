import { test } from 'node:test';
import assert from 'node:assert/strict';
import * as THREE from 'three';
import {
  applyCaveSurface, applyLandmarkSurface, CAVE_SURFACE_LAYER_COUNT,
  setCaveSurfaceUniforms, setCaveSurfaceArrayEnabled,
} from '../src/render/materials/caveSurface.js';
import { LandmarkLayer } from '../src/render/landmarks/LandmarkLayer.js';
import { MeshAccum } from '../src/render/landmarks/meshAccum.js';
import { buildSlab } from '../src/render/landmarks/primitives.js';

function shaderSource() {
  return {
    uniforms: {},
    vertexShader: '#include <common>\nvoid main(){\n#include <begin_vertex>\n}',
    fragmentShader: '#include <common>\n#include <clipping_planes_pars_fragment>\nvoid main(){\n#include <color_fragment>\n#include <opaque_fragment>\n}',
  };
}

test('cave surface retains geological coverage while blending four bounded sample slots', () => {
  const material = new THREE.MeshBasicMaterial();
  const uniforms = applyCaveSurface(material);
  const shader = shaderSource();
  material.onBeforeCompile(shader);
  assert.equal(uniforms.uCaveSurfaceMean.value.length, CAVE_SURFACE_LAYER_COUNT);
  for (const attribute of ['caveSurfaceLocal', 'caveSurfaceState', 'caveSurfaceMix']) {
    assert.ok(shader.vertexShader.includes(`attribute vec4 ${attribute};`));
  }
  assert.match(shader.vertexShader, /attribute float caveRoomWeight;/);
  const fragment = shader.fragmentShader;
  assert.match(fragment, /float previousShare = mix\(0\.30, 0\.05, regionProgress\);/);
  assert.match(fragment, /float nextShare = mix\(0\.05, 0\.30, regionProgress\);/);
  assert.match(fragment, /const float mainShare = 0\.65;/);
  assert.match(fragment, /MAIN-PREVIOUS-MAIN-NEXT-MAIN/);
  assert.match(fragment, /geologicalCoordinate = fract\(/);
  assert.match(fragment, /CaveSurfaceRecipe recipe = caveSurfaceRoom\(variant, family, vCaveRoomWeight, h, field\)/);
  const reader = fragment.slice(fragment.indexOf('vec3 caveSurfaceRead('), fragment.indexOf('float caveSurfaceTunnelVariant('));
  assert.equal((reader.match(/textureGrad\(uCaveSurfaceArray/g) || []).length, 1,
    'one lookup instruction inside the bounded four-slot reader');
  assert.match(reader, /for \(int i = 0; i < 4; i\+\+\)/);
  assert.match(reader, /if \(i < recipe.count && recipe.weights\[i\] > 0\.0\)/);
  assert.match(reader, /sampleColour \*= macro \/ max\(dot\(mean/,
    'each genuine texture sample is mean-normalized before blending');
  assert.doesNotMatch(fragment, /mix\(vec3\(macro\)/,
    'no grey residual is used at any material boundary');
  assert.match(fragment, /caveSurfaceGlow = vec3\(0\.07, 0\.17, 0\.04\) \* growth \* growth \* 0\.20 \* ceilingWeight/);
  assert.match(fragment, /outgoingLight = min\(outgoingLight \+ caveSurfaceGlow, vec3\(0\.75\)\)/);
});

test('roles retain both physical charts and keep projection blends in accent-free neutral strips', () => {
  const material = new THREE.MeshBasicMaterial();
  applyCaveSurface(material);
  const shader = shaderSource(); material.onBeforeCompile(shader);
  const fragment = shader.fragmentShader;
  assert.match(fragment, /rightUv = vec2\(axial \/ 10\.0, localRight \/ 8\.0\)/);
  assert.match(fragment, /sideUv = vec2\(axial \/ 10\.0, localUp \/ 8\.0\)/);
  assert.match(fragment, /floorWeight = 1\.0 - smoothstep\(-0\.575, -0\.555, h\)/);
  assert.match(fragment, /ceilingWeight = smoothstep\(0\.595, 0\.615, h\)/);
  assert.match(fragment, /smoothstep\(-0\.555, -0\.485, h\)/);
  assert.match(fragment, /1\.0 - smoothstep\(0\.525, 0\.595, h\)/);
  assert.match(fragment, /if \(neutral \|\| chart > 0\.0 && chart < 1\.0\) \{[\s\S]*?return recipe;/,
    'two-chart branch returns before any mineral accent is added');
  assert.ok(fragment.indexOf('vec2 rightDx = dFdx(rightUv)') < fragment.indexOf('float variant = caveSurfaceTunnelVariant(axial'),
    'both chart gradients are computed before categorical material branches');
});

test('shoulder phases have exact endpoints and use real texture recipe unions', () => {
  const material = new THREE.MeshBasicMaterial(); applyCaveSurface(material);
  const shader = shaderSource(); material.onBeforeCompile(shader);
  const fragment = shader.fragmentShader;
  assert.match(fragment, /if \(weight <= 0\.0\) return 0\.0;/);
  assert.match(fragment, /if \(weight >= 1\.0\) return 1\.0;/);
  assert.match(fragment, /return smoothstep\(field - width, field \+ width, position\)/);
  assert.match(fragment, /if \(roomWeight < 0\.25925926\)/);
  assert.match(fragment, /if \(roomWeight < 0\.74074074\)/);
  assert.match(fragment, /caveSurfaceWipe\(swapWeight, 1\.0 - field\)/);
  assert.match(fragment, /caveSurfaceWipe\(growWeight, field\)/);
  assert.doesNotMatch(fragment, /return step\(field|float roomLayer = mix/);
  assert.match(fragment, /recipe.layers\[i\] == layer && recipe.charts\[i\] == chart/,
    'base-layer slots shared by both phase endpoints are merged');
});

// Evaluate the emitted scalar GLSL body, not a separately maintained selector.
// This verifies its numeric boundary contract on CPU; actual GLSL compilation,
// texture sampling and image continuity still require the hardware review.
function emittedFunction(source, name, args) {
  const signature = new RegExp(`(?:float|vec3) ${name}\\([^)]*\\) \\{`);
  const match = signature.exec(source);
  assert.ok(match, name);
  let depth = 1, end = match.index + match[0].length;
  const begin = end;
  while (depth) { const c = source[end++]; if (c === '{') depth++; if (c === '}') depth--; }
  const body = source.slice(begin, end - 1).replace(/\bfloat\s+/g, 'const ').replace(/\babs\(/g, 'Math.abs(');
  return Function(...args, 'smoothstep', 'mix', 'vec3', body).bind(null);
}

test('emitted role and wipe equations are continuous at all neutral and phase endpoints', () => {
  const material = new THREE.MeshBasicMaterial(); applyCaveSurface(material);
  const shader = shaderSource(); material.onBeforeCompile(shader);
  const invoke = (name, args, values) => emittedFunction(shader.fragmentShader, name, args)(...values,
    (a, b, x) => { const t = Math.min(1, Math.max(0, (x - a) / (b - a))); return t * t * (3 - 2 * t); },
    (a, b, t) => a * (1 - t) + b * t, (...v) => v);
  for (const h of [-0.575, -0.555, -0.485, -0.465, 0.505, 0.525, 0.595, 0.615]) {
    const left = invoke('caveSurfaceRoleWeights', ['h'], [h - 1e-7]);
    const right = invoke('caveSurfaceRoleWeights', ['h'], [h + 1e-7]);
    assert.ok(left.every((value, i) => Math.abs(value - right[i]) < 1e-8), `role ${h}`);
    const chartLeft = invoke('caveSurfaceSideChart', ['h'], [h - 1e-7]);
    const chartRight = invoke('caveSurfaceSideChart', ['h'], [h + 1e-7]);
    assert.ok(Math.abs(chartLeft - chartRight) < 1e-8, `chart ${h}`);
  }
  for (const h of [-0.55, -0.52, -0.49, 0.53, 0.56, 0.59]) {
    assert.deepEqual(invoke('caveSurfaceRoleWeights', ['h'], [h]), [0, 0, 0],
      'chart blends cannot multiply the mineral sample count');
  }
  for (const field of [0, 0.001, 0.2, 0.5, 0.999, 1]) {
    const wipe = weight => invoke('caveSurfaceWipe', ['weight', 'field'], [weight, field]);
    assert.equal(wipe(0), 0); assert.equal(wipe(1), 1);
    assert.ok(wipe(1e-7) < 1e-8 && 1 - wipe(1 - 1e-7) < 1e-8,
      `exact endpoint is also continuous for field ${field}`);
    let previous = 0;
    for (let i = 0; i <= 100; i++) {
      const value = wipe(i / 100);
      assert.ok(value >= previous && value >= 0 && value <= 1);
      previous = value;
    }
  }
});

test('frontal body chart keeps exact E contact and merges layers through the existing reader', () => {
  const material = new THREE.MeshStandardMaterial(); applyLandmarkSurface(material);
  const shader = shaderSource(); material.onBeforeCompile(shader);
  const fragment = shader.fragmentShader;
  const weightFunction = emittedFunction(fragment, 'caveSurfaceFrontWeight', ['axialNormal', 'contact']);
  const weight = (normal, contact) => weightFunction(normal, contact,
    (a, b, x) => { const t = Math.min(1, Math.max(0, (x - a) / (b - a))); return t * t * (3 - 2 * t); });
  for (const normal of [-1, -0.75, -0.55, -0.35, 0, 0.35, 0.55, 0.75, 1]) {
    assert.equal(weight(normal, 0), 0, 'every wall-contact normal retains exactly E');
    assert.ok(weight(normal, 1e-7) < 1e-12, 'contact fade approaches E continuously');
    assert.equal(weight(normal, 0.35), weight(-normal, 1), 'front/back faces use geometric projection equally');
  }
  assert.equal(weight(0.35, 1), 0); assert.equal(weight(0.75, 1), 1);
  assert.ok(weight(0.55, 1) > 0 && weight(0.55, 1) < 1);
  const main = fragment.slice(fragment.lastIndexOf('#include <color_fragment>'));
  assert.match(main, /physicalLocal = vec3\(localRight, localUp, axial\)/);
  assert.match(main, /cross\(dFdx\(physicalLocal\), dFdy\(physicalLocal\)\)/);
  assert.match(main, /frontUv = vec2\(localRight \/ 10\.0, localUp \/ 8\.0\)/);
  assert.ok(main.indexOf('vec2 frontDx = dFdx(frontUv)') < main.indexOf('if (frontWeight < 1.0)'),
    'front gradients precede both non-uniform texture-read branches');
  assert.match(main, /if \(frontWeight < 1\.0\) \{[\s\S]*?caveSurfaceRead\(recipe/);
  assert.match(main, /if \(frontWeight > 0\.0\) \{[\s\S]*?caveSurfaceRead\(frontRecipe, frontUv, frontUv/);
  assert.match(fragment, /caveSurfaceAdd\(frontRecipe, bodyRecipe.layers\[i\],\s*bodyRecipe.weights\[i\], 0\.0, 0\.0\)/,
    'frontal chart uses the same layer weights and merges old-chart duplicates');
  assert.equal((fragment.match(/textureGrad\(uLandmarkSurfaceArray/g) || []).length, 1,
    'both body reads use the common mean-normalized reader, with no independent sampler implementation');
  const wall = new THREE.MeshStandardMaterial(); applyCaveSurface(wall);
  const wallShader = shaderSource(); wall.onBeforeCompile(wallShader);
  assert.doesNotMatch(wallShader.fragmentShader.slice(wallShader.fragmentShader.lastIndexOf('#include <color_fragment>')),
    /frontWeight|frontUv|caveSurfaceFrontRecipe/,
    'the wall still evaluates only its four-slot E recipe');
});

test('the array define relies on WebGL2 conversion and restores the fallback material', () => {
  const material = new THREE.MeshBasicMaterial();
  material.needsUpdate = false;
  setCaveSurfaceArrayEnabled(material, true);
  assert.equal(material.defines.CAVE_SURFACE_ARRAY, 1);
  assert.equal(material.glslVersion ?? null, null,
    'built-in materials rely on the renderer WebGL2 conversion aliases');
  setCaveSurfaceArrayEnabled(material, false);
  assert.equal('CAVE_SURFACE_ARRAY' in material.defines, false);
  assert.equal(material.glslVersion ?? null, null);
});

test('surface binder accepts manifest means without sharing mutable uniform bags', () => {
  const material = new THREE.MeshBasicMaterial();
  const uniforms = applyCaveSurface(material);
  const means = Array.from({ length: CAVE_SURFACE_LAYER_COUNT }, (_, i) => [i / 100, 0.2, 0.3]);
  setCaveSurfaceUniforms(uniforms, { means, strength: 0.6, seed: 123 });
  assert.equal(uniforms.uCaveSurfaceStrength.value, 0.6);
  assert.equal(uniforms.uCaveSurfaceSeed.value, 123);
  assert.ok(uniforms.uCaveSurfaceMean.value[7].isVector3);
  assert.equal(uniforms.uCaveSurfaceMean.value[7].x, 0.07);
});

test('wall and landmark share the complete blend recipe and retain body/contact coordinates', () => {
  const material = new THREE.MeshStandardMaterial(); applyLandmarkSurface(material);
  const shader = shaderSource(); material.onBeforeCompile(shader);
  const fragment = shader.fragmentShader;
  assert.match(fragment, /#ifdef LANDMARK_SURFACE_ARRAY/);
  assert.match(fragment, /uniform highp sampler2DArray uLandmarkSurfaceArray;/);
  assert.match(fragment, /textureGrad\(uLandmarkSurfaceArray/);
  assert.match(shader.vertexShader, /attribute float landmarkBodyChartOffset;/);
  assert.match(fragment, /float chartAxial = axial \+ vLandmarkBodyChartOffset/);
  assert.match(fragment, /caveSurfaceField\(caveSurfaceMineralCoordinates\(\s*axial, localRight, localUp\)/,
    'physical mineral field excludes the body unfolding offset');
  const gain = fragment.indexOf('macro = min(macro * 3.0, 0.32);');
  const contact = fragment.indexOf('macro = mix(contactMacro, macro, smoothstep(0.0, 0.35');
  assert.ok(gain > 0 && gain < contact);
  assert.match(fragment, /float contactMacro = vLandmarkSurfaceFamily < 0\.5 \? 0\.085\s*: \(vLandmarkSurfaceFamily < 1\.5 \? 0\.055 : 0\.09\)/);
  assert.doesNotMatch(fragment, /mix\(vec3\(macro\)/);
  const wall = new THREE.MeshStandardMaterial(); applyCaveSurface(wall);
  const wallShader = shaderSource(); wall.onBeforeCompile(wallShader);
  const shared = source => source.slice(source.indexOf('float caveSurfaceHash('), source.indexOf('vec3 caveSurfaceRead(')).trim();
  assert.equal(shared(fragment), shared(wallShader.fragmentShader),
    'entire role/mineral/shoulder recipe source is shared, not a second selector');
  for (const source of [fragment, wallShader.fragmentShader]) {
    assert.match(source, /float h = localUp \/ max\(0\.001, length\(vec2\(localRight, localUp\)\)\)/,
      'both shaders derive height from the same fragment-local radius');
  }
});

test('production Three standard shaders receive both material patches', () => {
  for (const [name, install, local] of [
    ['wall', applyCaveSurface, 'caveSurfaceLocal'],
    ['landmark', applyLandmarkSurface, 'landmarkSurfaceLocal'],
  ]) {
    const material = new THREE.MeshStandardMaterial();
    install(material);
    const shader = { uniforms: {}, vertexShader: THREE.ShaderLib.standard.vertexShader,
      fragmentShader: THREE.ShaderLib.standard.fragmentShader };
    material.onBeforeCompile(shader);
    assert.ok(shader.vertexShader.includes(`attribute vec4 ${local};`), name);
    assert.ok(shader.fragmentShader.includes('caveSurfaceMaterial('), name);
    assert.ok(shader.fragmentShader.includes('#include <opaque_fragment>'), name);
    if (name === 'wall') {
      assert.ok(shader.fragmentShader.includes('outgoingLight = min(outgoingLight + caveSurfaceGlow'),
        'ceiling glow must hook the real pre-tonemap opaque chunk');
    }
  }
});

test('landmark layer exposes a hardware-only surface binding API', () => {
  const scene = new THREE.Scene();
  const layer = new LandmarkLayer(scene, { softwareRenderer: true });
  assert.equal(layer.applySurfaceTexture({ texture: new THREE.DataTexture() }), false);
  layer.dispose();
});

test('array surface replaces the unrelated landmark grain map and restores fallback', () => {
  const layer = new LandmarkLayer(new THREE.Scene());
  const grain = new THREE.DataTexture();
  layer.applyTextures({ grainTex: grain });
  assert.equal(layer.rockMat.map, grain);
  const array = new THREE.DataArrayTexture(new Uint8Array(4 * 4 * 4), 2, 2, 4);
  layer.applySurfaceTexture({ texture: array });
  assert.equal(layer.rockMat.map, null);
  layer.applySurfaceTexture({ texture: null });
  assert.equal(layer.rockMat.map, grain);
  layer.dispose();
});

test('crystal slab broad faces have complete independent UV rectangles', () => {
  const acc = new MeshAccum();
  buildSlab(acc, {
    base: { x: 0, y: 0, z: 0 }, dir: { x: 0, y: 0, z: 1 }, length: 4,
    width: 1, tipWidth: 0.4, thickness: 0.2, roll: 0,
    cols: { cBase: [0.1, 0.1, 0.12], cInner: [0.2, 0.2, 0.3] },
  });
  const uv = acc.u;
  const faceUvs = [uv.slice(0, 8), uv.slice(8, 16)];
  for (const values of faceUvs) {
    const us = values.filter((_, i) => i % 2 === 0);
    const vs = values.filter((_, i) => i % 2 === 1);
    assert.deepEqual([...new Set(us)].sort(), [0, 1]);
    assert.deepEqual([...new Set(vs)].sort(), [0, 1]);
  }
  const rimUvs = uv.slice(16);
  assert.ok(new Set(rimUvs.filter((_, i) => i % 2 === 0)).size > 2,
    'rim has longitudinal rather than collapsed UVs');
});
