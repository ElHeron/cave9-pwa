// Predictive warning (Phase 4F / M1) — proves the look-ahead warning:
//   * rises when the heading leads into a wall,
//   * stays low on a safe (centred / straight) heading,
//   * is a PURE read — it never mutates the ship or changes the kill decision,
//   * combines with the reactive warning as max() (can only lead, never hide),
//   * is deterministic (same inputs → same output).
// Run with: npm test
import { test } from 'node:test';
import assert from 'node:assert/strict';

import { Game } from '../src/core/Game.js';
import { collision } from '../src/core/CollisionSystem.js';
import { predictiveWarn, finalWarn, warnFromMin, T_LEAD } from '../src/core/Predictive.js';
import { TWO_BUTTONS, SECTOR_COUNT, SHIP_RADIUS } from '../src/core/constants.js';

// A fresh seeded game parked mid-cave (centred, no death yet).
function midCaveGame(seed = 4242, steps = 60) {
  const g = new Game();
  g.start({ mode: TWO_BUTTONS, seed });
  for (let i = 0; i < steps; i++) { g.autopilot(); if (g.step()) break; }
  // centre the ship in its head ring so the baseline is genuinely safe
  const ring = g.cave.segs[g.cave.i];
  let cx = 0, cy = 0;
  for (let j = 0; j < SECTOR_COUNT; j++) { cx += ring[j][0]; cy += ring[j][1]; }
  g.player.pos[0] = cx / SECTOR_COUNT;
  g.player.pos[1] = cy / SECTOR_COUNT;
  return g;
}

test('warnFromMin mirrors the reactive HUD curve', () => {
  // min is centre-to-surface distance; hull clearance = min - R.
  assert.equal(warnFromMin(Number.MAX_VALUE, 1), 0, 'no wall sampled → 0');
  assert.equal(warnFromMin(SHIP_RADIUS, 1), 1, 'touching (clearance 0) → 1');
  assert.equal(warnFromMin(0.5 * SHIP_RADIUS, 1), 1, 'inside the surface (clearance<0) → 1');
  assert.equal(warnFromMin(3 * SHIP_RADIUS, 1), 0, 'clearance ≥ 2R → 0');
  // half-band
  assert.ok(Math.abs(warnFromMin(2 * SHIP_RADIUS, 1) - 0.5) < 1e-9, 'clearance=R → 0.5');
});

test('predictive warning RISES when the heading leads into a wall', () => {
  const g = midCaveGame();
  const p = g.player;

  // measure where the right wall is from the centred position
  collision(g.cave, p);
  const towardRight = p.rightClear < Number.MAX_VALUE;
  const sideClear = towardRight ? p.rightClear : p.leftClear;
  assert.ok(Number.isFinite(sideClear) && sideClear > 0 && sideClear < Number.MAX_VALUE,
    'at least one side wall measured');

  // SAFE heading: straight down the tunnel
  p.vel[0] = 0; p.vel[1] = 0;
  const safe = predictiveWarn(g.cave, p);

  // DANGER heading: lateral velocity that carries the look-ahead point onto the
  // the measured route-frame side wall in T_LEAD seconds. A concave section
  // can leave one directional probe open, so do not aim at its MAX_VALUE sentinel.
  let frameIndex = 0, frameGap = Infinity;
  for (let i = 0; i < g.cave.frames.length; i++) {
    const gap = Math.abs(g.cave.centers[i][2] - p.pos[2]);
    if (gap < frameGap) { frameGap = gap; frameIndex = i; }
  }
  const right = g.cave.frames[frameIndex].right;
  const sign = towardRight ? 1 : -1;
  p.vel[0] = right.x * sign * sideClear / T_LEAD;
  p.vel[1] = right.y * sign * sideClear / T_LEAD;
  p.vel[2] = right.z * sign * sideClear / T_LEAD;
  const danger = predictiveWarn(g.cave, p);

  assert.ok(danger.warn > safe.warn,
    `heading-into-wall warn ${danger.warn.toFixed(2)} should exceed safe ${safe.warn.toFixed(2)}`);
  assert.ok(danger.warn >= 0.5, `heading-into-wall warn should be high, got ${danger.warn.toFixed(2)}`);
});

test('predictive warning STAYS LOW on a safe straight heading', () => {
  const g = midCaveGame();
  const p = g.player;
  p.vel[0] = 0; p.vel[1] = 0; // straight ahead from the tunnel centre
  const pred = predictiveWarn(g.cave, p);
  assert.ok(pred.warn < 0.3, `centred straight heading should be calm, got ${pred.warn.toFixed(2)}`);
});

test('predictiveWarn is PURE — it mutates neither the ship nor the kill decision', () => {
  const g = midCaveGame();
  const p = g.player;
  p.vel[0] = 5; // some lateral heading

  // baseline kill-relevant state via the real collision path
  const distBefore = collision(g.cave, p);
  const snap = {
    dist: p.dist, leftClear: p.leftClear, rightClear: p.rightClear,
    pos: [...p.pos], vel: [...p.vel],
    probeInside: [...p.probeInside],
  };

  predictiveWarn(g.cave, p);
  predictiveWarn(g.cave, p, 0.5);

  // nothing the kill model reads may have changed
  assert.equal(p.dist, snap.dist, 'ship.dist untouched');
  assert.equal(p.leftClear, snap.leftClear, 'leftClear untouched');
  assert.equal(p.rightClear, snap.rightClear, 'rightClear untouched');
  assert.deepEqual([...p.pos], snap.pos, 'pos untouched');
  assert.deepEqual([...p.vel], snap.vel, 'vel untouched');
  assert.deepEqual([...p.probeInside], snap.probeInside, 'probes untouched');

  // and the kill decision re-probes identically
  const distAfter = collision(g.cave, p);
  assert.equal(distAfter, distBefore, 'collision result unchanged by predictive probing');
});

test('finalWarn = max(reactive, predictive) — leads, never hides', () => {
  assert.equal(finalWarn(0.2, 0.8), 0.8, 'predictive can lead');
  assert.equal(finalWarn(0.9, 0.3), 0.9, 'never drops below the true reactive level');
  assert.equal(finalWarn(0, 0), 0);
  // property: final ≥ reactive always
  for (const [a, b] of [[0.1, 0.9], [0.5, 0.5], [0.9, 0.0], [0.3, 0.31]]) {
    assert.ok(finalWarn(a, b) >= a, 'final never below reactive');
  }
});

test('predictive lead distance ≈ vel.z · T_LEAD', () => {
  const g = midCaveGame();
  const p = g.player;
  const pred = predictiveWarn(g.cave, p);
  assert.ok(Math.abs(pred.leadDist - p.vel[2] * T_LEAD) < 1e-9,
    `leadDist ${pred.leadDist} should equal vel.z·T_LEAD ${p.vel[2] * T_LEAD}`);
  assert.ok(pred.leadDist > 0, 'we always probe ahead of the ship');
});

test('predictiveWarn is deterministic', () => {
  const g = midCaveGame();
  const p = g.player;
  p.vel[0] = 4.2;
  const a = predictiveWarn(g.cave, p);
  const b = predictiveWarn(g.cave, p);
  assert.deepEqual(a, b, 'same cave + ship → identical result');
});

test('zero-lead prediction is the same nearest surface as reactive collision', () => {
  const g = midCaveGame(4096, 80);
  const p = g.player;
  collision(g.cave, p, g.landmarkCompositions);
  const pred = predictiveWarn(g.cave, p, 0, g.landmarkCompositions);
  assert.ok(Math.abs(pred.warn - warnFromMin(p.dist + p.radius, p.radius)) < 1e-12,
    'reactive and predictive adapters must read one SurfaceQuery result');
  assert.equal(pred.leftClear, p.leftClear);
  assert.equal(pred.rightClear, p.rightClear);
});

test('non-finite ship state yields a calm, safe prediction (no throw)', () => {
  const g = midCaveGame();
  const p = g.player;
  p.vel[0] = NaN;
  const pred = predictiveWarn(g.cave, p);
  assert.equal(pred.warn, 0, 'degenerate heading must not raise a phantom warning');
});
