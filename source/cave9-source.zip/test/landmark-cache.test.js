// LandmarkCache — the memo over compositionAt().
//
// The cache is a pure performance layer, so the tests that matter are the ones
// that pin it to the uncached API: same answers, and correctly invalidated when
// the cave ring a room is built from is recycled. Run with: npm test

import { test } from 'node:test';
import assert from 'node:assert/strict';
import { isDeepStrictEqual } from 'node:util';

import { DEFAULT_MAX_ROOMS, LandmarkCache } from '../src/core/LandmarkCache.js';
import {
  compositionAt, landmarksInView, nearestLandmarkDistance, landmarkPieceCount,
  roomRingIndex, visibleRoomRange, roomZ, FIRST_ROOM_K,
  compositionSurfaceRevision,
} from '../src/core/Landmarks.js';
import { ROOM_SPACING, SEGMENT_LEN } from '../src/core/constants.js';
import { Game } from '../src/core/Game.js';
import { placeAt } from '../src/app/CaptureHarness.js';
import { buildCompositionAccums } from '../src/render/landmarks/LandmarkMeshBuilder.js';
import { LandmarkSurfaceProjector } from '../src/render/landmarks/surfaceProjection.js';

// Isolated wall revision: the room anchor/annulus remains identical, while one
// actual ring is narrowed and receives a distinct selection depth.
function narrowedRootRing(cave, retained, depth) {
  const index = retained.centers.findIndex(c => c[2] === depth);
  assert.ok(index >= 0);
  const changed = { ...retained, centers: retained.centers.map(c => [...c]),
    segs: [...retained.segs] };
  changed.centers[index][2] += .001;
  const centre = retained.frames[index].center;
  const origin = [centre.x, centre.y, centre.z];
  changed.segs[index] = retained.segs[index].map(vertex => vertex.map((v, axis) =>
    origin[axis] + (v - origin[axis]) * .3));
  cave.landmarkRoomSurface = () => changed;
}

test('same child geometry receives a new surface when its earlier parent chart changes', () => {
  const game = new Game();
  game.start({ mode: 2, seed: 2024, family: 'branching' });
  const cave = game.cave;
  cave.generateThrough(roomZ(9) + 120);
  const retained = cave.landmarkRoomSurface(9);
  const previous = compositionAt(2024, cave, 9, 'branching');
  narrowedRootRing(cave, retained, 9114);
  const current = compositionAt(2024, cave, 9, 'branching', previous);
  sameCompIncludingRootSurfaces(current, compositionAt(2024, cave, 9, 'branching'));
  const gid = 'root-tree-0-branch-0';
  const oldChild = previous.rootSurfaces.find(s => s.gid === gid);
  const child = current.rootSurfaces.find(s => s.gid === gid);
  assert.deepEqual(child.vertices, oldChild.vertices, 'child geometry really remains identical');
  assert.notDeepEqual(current.rootSurfaces[0].vertices, previous.rootSurfaces[0].vertices);
  assert.notEqual(child, oldChild, 'both reuse passes must retain the parent revision dependency');
  const childPart = comp => ({ ...comp, pieces: comp.pieces.filter(p => p.gid === gid),
    rootChartPieces: comp.pieces, rootSurfaces: comp.rootSurfaces });
  const offsets = comp => buildCompositionAccums(childPart(comp)).rock
    .toGeometry(new LandmarkSurfaceProjector(2024, 9)).attributes.landmarkBodyChartOffset.array;
  assert.notDeepEqual(offsets(current), offsets(previous),
    'an earlier parent segment changes the child chart despite unchanged child triangles');
});

test('whole early-child rejection preserves later reuse slots and stable tree palettes', () => {
  const game = new Game();
  game.start({ mode: 2, seed: 2024, family: 'branching' });
  const cave = game.cave;
  cave.generateThrough(roomZ(9) + 120);
  const retained = cave.landmarkRoomSurface(9);
  const previous = compositionAt(2024, cave, 9, 'branching');
  narrowedRootRing(cave, retained, 9110);
  const current = compositionAt(2024, cave, 9, 'branching', previous);
  const fresh = compositionAt(2024, cave, 9, 'branching');
  sameCompIncludingRootSurfaces(current, fresh);
  assert.equal(current.pieces.some(p => p.gid === 'root-tree-0-branch-0'), false);
  assert.equal(current.pieces.length, previous.pieces.length - 5);
  assert.ok(current.pieces.every(Boolean), 'filter and reuse must leave no holes');
  for (const p of current.pieces) {
    const prior = previous.pieces.find(q => q.gid === p.gid && q.node === p.node);
    assert.equal(p.shade, prior.shade, 'tree palette is independent of a rejected earlier sibling');
  }
  for (const gid of ['root-tree-1', 'root-tree-2']) {
    assert.equal(current.rootSurfaces.find(s => s.gid === gid),
      previous.rootSurfaces.find(s => s.gid === gid), 'later unchanged forms reuse their correct slots');
  }
  delete cave.landmarkRoomSurface;
  const restored = compositionAt(2024, cave, 9, 'branching', current);
  sameCompIncludingRootSurfaces(restored, compositionAt(2024, cave, 9, 'branching'));
  assert.equal(restored.pieces.length, 49, 'rejected children can reappear after the wall revision');
});

// Carve a seed's cave until room k sits inside the live ring buffer.
function caveAtRoom(seed, k) {
  const g = new Game();
  g.start({ mode: 2, seed });
  const target = roomZ(k) + 40;
  g.cave.generateThrough(target, 2_000_000);
  return g;
}

// Compositions are plain data, so structural equality is the right comparison.
const sameComp = (a, b) => assert.deepEqual(a, b);
const sameCompIncludingRootSurfaces = (a, b) => {
  sameComp(a, b);
  assert.equal(a?.rootSurfaces?.length, b?.rootSurfaces?.length);
  assert.deepEqual(a?.rootSurfaces, b?.rootSurfaces,
    'the non-enumerable exact mesh/collision surface must also match');
  assert.deepEqual(a?.rootWallQueries, b?.rootWallQueries,
    'the next revision must validate the same queried wall depths');
};
const sameCompIncludingSlabHulls = (a, b) => {
  sameComp(a, b);
  assert.deepEqual(Object.getOwnPropertyDescriptor(a?.pieces || [], 'bounds'),
    Object.getOwnPropertyDescriptor(b?.pieces || [], 'bounds'),
    'local family bounds and their non-enumerable descriptor must survive copying');
  assert.equal(a?.pieces.length, b?.pieces.length);
  for (let i = 0; i < (a?.pieces.length || 0); i++) {
    const cached = a.pieces[i], fresh = b.pieces[i];
    assert.deepEqual(cached.slabAcross, fresh.slabAcross,
      `blade ${i} must retain its exact non-enumerable width direction`);
    assert.deepEqual(cached.slabHull, fresh.slabHull,
      `blade ${i} must retain its exact non-enumerable collision/render hull`);
  }
};

test('private family templates survive repeated mapping without mutating predecessors', () => {
  for (const family of ['branching', 'crystal']) {
    const game = new Game();
    game.start({ mode: 2, seed: 256, family });
    placeAt(game, 9010);
    let previous = compositionAt(256, game.cave, 9, family);
    assert.ok(previous);
    const compare = family === 'crystal' ? sameCompIncludingSlabHulls
      : sameCompIncludingRootSurfaces;
    for (let step = 0; step < 195; step++) {
      const before = structuredClone(previous);
      const surfaces = structuredClone(previous.rootSurfaces);
      const hulls = previous.pieces.map((piece) => structuredClone(piece.slabHull));
      game._carve(); game.player.pos[2] += 0.675;
      const current = compositionAt(256, game.cave, 9, family, previous);
      compare(current, compositionAt(256, game.cave, 9, family));
      assert.deepEqual(previous, before, 'mapping must leave the preceding composition unchanged');
      assert.deepEqual(previous.rootSurfaces, surfaces);
      assert.deepEqual(previous.pieces.map((piece) => piece.slabHull), hulls);
      if (current) previous = current;
    }
  }
});

test('crystal authoring is private from mutable public slabs and mapped pieces', () => {
  const game = caveAtRoom(256, 9);
  const previous = compositionAt(256, game.cave, 9, 'crystal');
  assert.ok(previous?.pieces.length);
  const fresh = compositionAt(256, game.cave, 9, 'crystal');
  previous.pieces[0].slab.baseLeft += 100;
  previous.pieces[0].radius *= 3;
  previous.pieces[0].cx += 100;
  previous.pieces.bounds.zMin -= 100;
  sameCompIncludingSlabHulls(
    compositionAt(256, game.cave, 9, 'crystal', previous), fresh);
});

test('authoring reuse respects seed, family, cave, frame, clearance and generation changes', () => {
  const game = caveAtRoom(256, 9);
  const cave = game.cave;
  let previous = compositionAt(256, cave, 9, 'crystal');
  const check = (seed, currentCave, family) => {
    const actual = compositionAt(seed, currentCave, 9, family, previous);
    const expected = compositionAt(seed, currentCave, 9, family);
    (family === 'crystal' ? sameCompIncludingSlabHulls
      : sameCompIncludingRootSurfaces)(actual, expected);
    assert.ok(actual);
    previous = actual;
  };
  check(2024, cave, 'crystal');
  check(2024, cave, 'branching');
  check(256, caveAtRoom(256, 9).cave, 'crystal');
  check(256, cave, 'crystal');
  const retained = cave.landmarkRoomSurface(9);
  const index = roomRingIndex(retained, 9);
  const changed = { ...retained, frames: [...retained.frames], segs: [...retained.segs] };
  cave.landmarkRoomSurface = () => changed;
  changed.frames[index] = { ...changed.frames[index] };
  check(256, cave, 'crystal');
  // Deliberately alter the centre-ring clearance in this isolated fixture.
  // A template authored for the former annulus must not be reused.
  const centre = changed.frames[index].center;
  changed.segs[index] = changed.segs[index].map((point) => [...point]);
  for (const vertex of changed.segs[index]) {
    vertex[0] = centre.x + (vertex[0] - centre.x) * 0.98;
    vertex[1] = centre.y + (vertex[1] - centre.y) * 0.98;
    vertex[2] = centre.z + (vertex[2] - centre.z) * 0.98;
  }
  const priorClearance = previous.clearance;
  check(256, cave, 'crystal');
  assert.notEqual(previous.clearance, priorClearance,
    'this fixture must change the actual authoring annulus');
  delete cave.landmarkRoomSurface;
  cave.reset(256, 'crystal');
  cave.generateThrough(roomZ(9) + 40);
  check(256, cave, 'crystal');
});

test('compositionAt: the cached result equals the pure result', () => {
  const cache = new LandmarkCache();
  let compared = 0;
  for (const seed of [4096, 424242, 555]) {
    const g = caveAtRoom(seed, FIRST_ROOM_K);
    const pure = compositionAt(seed, g.cave, FIRST_ROOM_K);
    sameComp(cache.compositionAt(seed, g.cave, FIRST_ROOM_K), pure);
    // and again, this time served from the memo
    sameComp(cache.compositionAt(seed, g.cave, FIRST_ROOM_K), pure);
    compared++;
  }
  assert.equal(compared, 3);
  assert.equal(cache.misses, 3);
  assert.equal(cache.hits, 3);
});

test('compositionAt: a repeat call returns the very same object (no rebuild)', () => {
  const cache = new LandmarkCache();
  const g = caveAtRoom(4096, FIRST_ROOM_K);
  const a = cache.compositionAt(4096, g.cave, FIRST_ROOM_K);
  const b = cache.compositionAt(4096, g.cave, FIRST_ROOM_K);
  assert.ok(a, 'seed 4096 room 2 has a composition');
  assert.equal(a, b, 'the memo hands back the same instance');
});

test('compositionAt: different seeds never share an entry', () => {
  const cache = new LandmarkCache();
  const a = caveAtRoom(4096, FIRST_ROOM_K);
  const b = caveAtRoom(360, FIRST_ROOM_K);
  const ca = cache.compositionAt(4096, a.cave, FIRST_ROOM_K);
  const cb = cache.compositionAt(360, b.cave, FIRST_ROOM_K);
  sameComp(ca, compositionAt(4096, a.cave, FIRST_ROOM_K));
  sameComp(cb, compositionAt(360, b.cave, FIRST_ROOM_K));
});

test('compositionAt: two caves on the same seed do not share an entry', () => {
  // The app runs the player's game and the menu demo at once. They are distinct
  // cave objects and must never be answered from each other's entry, even when
  // a capture or a seeded retry gives them the same seed.
  const cache = new LandmarkCache();
  const a = caveAtRoom(4096, FIRST_ROOM_K);
  const b = caveAtRoom(4096, FIRST_ROOM_K);
  const ca = cache.compositionAt(4096, a.cave, FIRST_ROOM_K);
  const cb = cache.compositionAt(4096, b.cave, FIRST_ROOM_K);
  assert.notEqual(ca, cb, 'each cave got its own entry');
  sameComp(ca, cb, 'the same seed still describes the same formation');
  assert.equal(cache.misses, 2);
});

test('compositionAt: an uncarved room is not cached', () => {
  const cache = new LandmarkCache();
  const g = new Game();
  g.start({ mode: 2, seed: 4096 });
  // room 40 is ~40 km down the tunnel — nowhere near the live buffer
  assert.equal(roomRingIndex(g.cave, 40), -1);
  assert.equal(cache.compositionAt(4096, g.cave, 40), null);
  assert.equal(cache.size, 0, 'nothing to key on, so nothing is stored');
});

test('compositionAt: recycling the ring buffer invalidates the entry', () => {
  const cache = new LandmarkCache();
  const g = caveAtRoom(4096, FIRST_ROOM_K);
  const first = cache.compositionAt(4096, g.cave, FIRST_ROOM_K);
  assert.ok(first);
  assert.equal(cache.misses, 1);

  // Carve a whole buffer's worth further on. Room 2's ring is overwritten, so
  // the room drops out of view and the stale entry must not be served.
  g.cave.generateThrough(g.cave.cursorDepth + 4000 * 0.05 * 30);
  assert.equal(roomRingIndex(g.cave, FIRST_ROOM_K), -1, 'room 2 scrolled out');
  assert.equal(cache.compositionAt(4096, g.cave, FIRST_ROOM_K), null);
});

test('branching cache ignores unrelated recycled rings while matching fresh visible surfaces', () => {
  const game = new Game();
  game.start({ mode: 2, seed: 256, family: 'branching' });
  placeAt(game, 9010);
  const k = 9, cache = game.landmarkCache;
  const first = cache.compositionAt(256, game.cave, k, 'branching');
  const initialHits = cache.hits, initialMisses = cache.misses;
  const firstBroad = compositionSurfaceRevision(game.cave, k);
  assert.equal(first.rootSurfaces.length, 8);
  for (let step = 1; step <= 90; step++) {
    game._carve();
    game.player.pos[2] += 0.675;
    const cached = cache.compositionAt(256, game.cave, k, 'branching');
    if (step % 15 === 0) {
      sameCompIncludingRootSurfaces(cached,
        compositionAt(256, game.cave, k, 'branching'));
    }
    assert.equal(cached, first, `step ${step} only recycled unrelated wall rings`);
  }
  assert.notEqual(compositionSurfaceRevision(game.cave, k), firstBroad,
    'the former broad key would have repeatedly rebuilt the same formation');
  assert.equal(cache.misses, initialMisses);
  assert.equal(cache.hits - initialHits, 90);

  for (let step = 91; step <= 150; step++) {
    game._carve();
    game.player.pos[2] += 0.675;
    const cached = cache.compositionAt(256, game.cave, k, 'branching');
    if (step % 3 === 0) sameCompIncludingRootSurfaces(cached,
      compositionAt(256, game.cave, k, 'branching'));
  }
  assert.equal(cache.misses, initialMisses,
    'retired live rings remain authoritative in the complete room surface');
});

test('branching cache tracks missing front samples, rear recycling, resize and reset', () => {
  const game = new Game();
  game.start({ mode: 2, seed: 256, family: 'branching' });
  const cave = game.cave, cache = game.landmarkCache, k = 9, z = roomZ(k);
  const check = () => {
    const cached = cache.compositionAt(256, cave, k, 'branching');
    sameCompIncludingRootSurfaces(cached, compositionAt(256, cave, k, 'branching'));
    return cached;
  };
  cave.generateThrough(z + 2);
  const incomplete = check();
  assert.ok(incomplete?.rootSurfaces?.length,
    'the front can be incomplete while the room centre is already carved');
  cave.generateThrough(z + 40);
  const complete = check();
  assert.notEqual(complete, incomplete,
    'newly emitted contact/shoulder rings must invalidate the fallback');

  const beforeResize = check();
  assert.equal(cave.ensureCapacityForDistance(450), true);
  assert.equal(check(), beforeResize,
    'index-only capacity growth retains exactly the same root geometry');

  cave.generateThrough(z + 245);
  check();
  cave.generateThrough(z + 275);
  check();
  cave.generateThrough(z + cave.len() + 120);
  assert.equal(check(), null, 'passing the complete form span removes the composition');

  cave.reset(256, 'branching');
  cave.generateThrough(z + 40);
  const afterReset = check();
  assert.ok(afterReset?.rootSurfaces?.length);
  assert.notEqual(afterReset, beforeResize,
    'new cave generation is not served from the old composition');
});

test('a root revision retains identical subform surfaces and pieces by identity', () => {
  const game = new Game();
  game.start({ mode: 2, seed: 256, family: 'branching' });
  game.cave.generateThrough(roomZ(9) + 2);
  game.player.pos[2] = 9010;
  const cache = game.landmarkCache, k = 9;
  let previous = cache.compositionAt(256, game.cave, k, 'branching');
  let partialRevisions = 0, stableCompositions = 0;
  for (let step = 1; step <= 195; step++) {
    game._carve(); game.player.pos[2] += 0.675;
    const current = cache.compositionAt(256, game.cave, k, 'branching');
    if (!current) continue;
    if (current === previous) { stableCompositions++; continue; }
    const fresh = compositionAt(256, game.cave, k, 'branching');
    sameCompIncludingRootSurfaces(current, fresh);
    const formerFrames = previous.rootRouteFrames;
    assert.ok(current.rootRouteFrames instanceof Map);
    assert.notEqual(current.rootRouteFrames, formerFrames,
      'a rebuilt composition must not mutate its predecessor\'s route-frame map');
    const formerFrameCount = formerFrames.size;
    const sameRoomAuthority = current.frame === previous.frame
      && current.rootGeneration === previous.rootGeneration
      && current.rootCave === previous.rootCave
      && current.inner === previous.inner && current.outer === previous.outer
      && current.clearance === previous.clearance;
    if (sameRoomAuthority) for (const [depth, frame] of formerFrames) {
      if (current.rootRouteFrames.has(depth)) {
        assert.equal(current.rootRouteFrames.get(depth), frame,
          'the same seed and exact depth must reuse its analytic frame');
      }
    }
    assert.equal(formerFrames.size, formerFrameCount);
    assert.ok(current.rootRouteFrames.size < 1024,
      'route-frame reuse stays bounded to the room\'s contact samples');
    let changed = 0;
    for (const surface of current.rootSurfaces) {
      const former = previous.rootSurfaces.find((candidate) => candidate.gid === surface.gid);
      const sameGeometry = isDeepStrictEqual(surface, former);
      const formerPiece = previous.pieces.find((piece) => piece.gid === surface.gid);
      const currentPiece = current.pieces.find((piece) => piece.gid === surface.gid);
      if (sameGeometry) {
        assert.equal(surface, former,
          `unchanged ${surface.gid} surface must keep its identity`);
        assert.equal(currentPiece, formerPiece,
          `unchanged ${surface.gid} world pieces must keep their identity`);
      } else {
        changed++;
        assert.notEqual(surface, former);
      }
    }
    if (changed > 0 && changed < current.rootSurfaces.length) partialRevisions++;
    previous = current;
  }
  assert.ok(partialRevisions > 0, 'the room must exercise bounded subform reuse');
  assert.ok(stableCompositions > 0,
    'completed retained contacts must preserve composition identity through recycling');
});

test('implicit family override belongs to the cache key', () => {
  const game = caveAtRoom(256, 9);
  const cache = new LandmarkCache();
  game.cave.landmarkFamilyOverride = 'branching';
  const branching = cache.compositionAt(256, game.cave, 9);
  assert.equal(branching?.typeName, 'branching');
  game.cave.landmarkFamilyOverride = 'off';
  assert.equal(cache.compositionAt(256, game.cave, 9), null);
  assert.equal(cache.misses, 2);
});

test('crystal cache matches fresh hulls through growth, recycle, resize and reset', () => {
  const game = new Game();
  game.start({ mode: 2, seed: 256, family: 'crystal' });
  const cave = game.cave, cache = game.landmarkCache, k = 9, z = roomZ(k);
  const check = (forcedType = null) => {
    const cached = cache.compositionAt(256, cave, k, forcedType);
    sameCompIncludingSlabHulls(cached, compositionAt(256, cave, k, forcedType));
    if (cached) {
      assert.equal(cached.rootWallQueries, undefined,
        'crystal walls use their own measured dependencies, not root queries');
      assert.ok(cached.pieces.some((piece) => piece.shape === 'blade' && piece.slabHull),
        'this fixture must exercise real cached blade hulls');
    }
    return cached;
  };
  cave.generateThrough(z + 2);
  const incomplete = check();
  assert.ok(incomplete.bladeWallQueries.some((query) =>
    query.kind === 'footprint' && query.value === null),
  'the unfinished front must contain a failed exact wall ray');
  cave.generateThrough(z + 40);
  const complete = check();
  assert.ok(complete);
  assert.notEqual(complete, incomplete,
    'newly emitted triangles must replace an earlier blade-wall fallback');
  assert.equal(cave.ensureCapacityForDistance(450), true);
  assert.equal(check(), complete,
    'index-only resize preserves the same exact blade wall values and hulls');
  cave.generateThrough(z + 245);
  check();
  cave.generateThrough(z + 275);
  check();
  cave.generateThrough(z + cave.len() + 120);
  assert.equal(check(), null);
  cave.reset(256, 'crystal');
  cave.generateThrough(z + 40);
  assert.notEqual(check(), complete,
    'a new cave generation must invalidate the former wall contacts');
  cave.landmarkFamilyOverride = 'branching';
  const branching = cache.compositionAt(256, cave, k);
  assert.equal(branching?.typeName, 'branching');
  sameCompIncludingRootSurfaces(branching, compositionAt(256, cave, k));
  check('crystal');
  cave.landmarkFamilyOverride = 'crystal';
  check();
});

test('crystal cache retains byte-identical compositions across unrelated emissions', () => {
  for (const seed of [2024, 256, 4096]) {
    const game = new Game();
    game.start({ mode: 2, seed, family: 'crystal' });
    placeAt(game, 9010);
    const cave = game.cave, cache = game.landmarkCache, k = 9;
    let previous = cache.compositionAt(seed, cave, k, 'crystal');
    let previousBroad = compositionSurfaceRevision(cave, k);
    let broadChanges = 0, retainedAcrossBroadChange = 0;
    let changedGeometry = 0, rolledOut = 0;
    assert.ok(previous?.bladeWallQueries?.length,
      'the production crystal records its actual radius and wall-ray dependencies');
    for (let step = 1; step <= 500; step++) {
      game._carve();
      game.player.pos[2] += 0.675;
      const cached = cache.compositionAt(seed, cave, k, 'crystal');
      const fresh = compositionAt(seed, cave, k, 'crystal');
      sameCompIncludingSlabHulls(cached, fresh);
      const broad = compositionSurfaceRevision(cave, k);
      if (broad !== previousBroad) {
        broadChanges++;
        if (cached === previous) retainedAcrossBroadChange++;
      }
      if (cached && previous && cached !== previous) {
        const sameHulls = cached.pieces.every((piece, i) =>
          isDeepStrictEqual(piece.slabHull, previous.pieces[i].slabHull));
        if (!sameHulls) changedGeometry++;
      }
      if (previous && !cached) rolledOut++;
      previous = cached;
      previousBroad = broad;
    }
    assert.ok(broadChanges >= 50, 'the flight must recycle many broad-key rings');
    assert.ok(retainedAcrossBroadChange >= 35,
      'unrelated ring emissions must preserve the complete cached composition');
    assert.equal(changedGeometry, 0,
      'complete retained contacts must not change as live rings recycle');
    assert.equal(rolledOut, 1, 'passing the complete form span invalidates the room');
    assert.ok(cache.misses < broadChanges / 2,
      'the actual query-value dependency must avoid most broad-key rebuilds');
  }
});

test('landmarksInView: cached and pure agree along a whole flight', () => {
  const cache = new LandmarkCache();
  const g = new Game();
  g.start({ mode: 2, seed: 4096 });
  let sampled = 0, sawLandmarks = 0;
  for (let step = 0; step < 8000; step++) {
    g.autopilot();
    if (g.step()) break;
    if (step % 37) continue; // sample; the full comparison is expensive
    const z = g.player.pos[2];
    const cached = cache.landmarksInView(g.cave, z, 128, g.seed);
    sameComp(cached, landmarksInView(g.cave, z, 128, g.seed));
    if (cached.length) sawLandmarks++;
    sampled++;
  }
  assert.ok(sampled > 20, `expected a decent sample, got ${sampled}`);
  assert.ok(sawLandmarks > 0, 'the flight should pass at least one room');
  // The sampled calls are deliberately 37 simulation steps apart. While a
  // long room enters the 288 m live buffer, more of its wall span is carved
  // between samples and the cache must miss/rebuild. Same-revision reuse is
  // asserted separately above; this flight test is about exact invalidation.
  assert.ok(cache.misses > 0, 'surface revisions should be observed and cached');
});

test('nearestLandmarkDistance / landmarkPieceCount match the pure helpers', () => {
  const cache = new LandmarkCache();
  const g = caveAtRoom(4096, FIRST_ROOM_K);
  const z = roomZ(FIRST_ROOM_K) - 40;
  assert.equal(
    cache.nearestLandmarkDistance(g.cave, z, 128, 4096),
    nearestLandmarkDistance(g.cave, z, 128, 4096));
  assert.equal(
    cache.landmarkPieceCount(g.cave, z, 128, 4096),
    landmarkPieceCount(g.cave, z, 128, 4096));
});

test('the cache is bounded and evicts least-recently-used rooms', () => {
  const cache = new LandmarkCache(4);
  const g = caveAtRoom(4096, FIRST_ROOM_K);
  // distinct seeds → distinct keys, all against the same carved cave
  for (let i = 0; i < 20; i++) cache.compositionAt(1000 + i, g.cave, FIRST_ROOM_K);
  assert.equal(cache.size, 4);
});

test('the production CPU cache retains at most six rooms and reports its lifecycle', () => {
  const cache = new LandmarkCache();
  const g = caveAtRoom(4096, FIRST_ROOM_K);
  for (let i = 0; i < 10; i++) cache.compositionAt(10_000 + i, g.cave, FIRST_ROOM_K);

  assert.equal(DEFAULT_MAX_ROOMS, 6);
  assert.deepEqual(cache.resourceMetrics(), {
    rooms: 6,
    maxRooms: 6,
    hits: 0,
    misses: 10,
    evictions: 4,
  });
});

test('clear() empties the cache and its counters', () => {
  const cache = new LandmarkCache();
  const g = caveAtRoom(4096, FIRST_ROOM_K);
  cache.compositionAt(4096, g.cave, FIRST_ROOM_K);
  cache.clear();
  assert.equal(cache.size, 0);
  assert.equal(cache.hits, 0);
  assert.equal(cache.misses, 0);
  assert.equal(cache.evictions, 0);
});

test('each Game owns an isolated landmark cache', () => {
  const a = new Game(), b = new Game();
  assert.ok(a.landmarkCache instanceof LandmarkCache);
  assert.notEqual(a.landmarkCache, b.landmarkCache);
});

// ---- the range helper the cached and pure paths both use -------------------

test('visibleRoomRange: covers the rooms between behind and range', () => {
  const behind = SEGMENT_LEN * 2;
  const z = roomZ(5) - 10;
  const { kFrom, kTo } = visibleRoomRange(z, 128, behind);
  assert.ok(kFrom <= 5 && 5 <= kTo, `room 5 should be in view, got ${kFrom}..${kTo}`);
  // one room ahead is a full ROOM_SPACING away and must not be
  assert.ok(kTo < 6);
});

test('visibleRoomRange: never returns rooms before the first one', () => {
  const { kFrom } = visibleRoomRange(0, 10_000);
  assert.equal(kFrom, FIRST_ROOM_K);
});

test('visibleRoomRange: a non-finite z or empty range yields no rooms', () => {
  for (const [z, r] of [[NaN, 128], [Infinity, 128], [100, 0], [100, -5]]) {
    const { kFrom, kTo } = visibleRoomRange(z, r);
    assert.ok(kFrom > kTo, `expected an empty range for z=${z} range=${r}`);
  }
});

test('visibleRoomRange: spans exactly one room per ROOM_SPACING of view', () => {
  const { kFrom, kTo } = visibleRoomRange(roomZ(FIRST_ROOM_K), ROOM_SPACING * 3);
  assert.equal(kTo - kFrom, 3);
});
