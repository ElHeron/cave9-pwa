// The layer contract, enforced.
//
// ARCHITECTURE.md describes which layer may depend on which. A description in a
// markdown file decays the first time someone adds a convenient import; this
// test is the same contract as something that fails.
//
// The rule that matters most is the first one: `core/` may not reach outward.
// The whole determinism story — a seed reproducing a cave, replay fixtures, the
// headless seed audit, every unit test that runs without a browser — depends on
// the simulation being reachable with no renderer, no DOM and no three.js.
//
// Run with: npm test

import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readdirSync, readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const SRC = fileURLToPath(new URL('../src', import.meta.url));

function jsFiles(dir) {
  return readdirSync(dir, { withFileTypes: true }).flatMap((e) => {
    const p = path.join(dir, e.name);
    return e.isDirectory() ? jsFiles(p)
      : (e.name.endsWith('.js') || e.name.endsWith('.mjs') ? [p] : []);
  });
}

// The top-level folder a file belongs to; main.js is its own entry layer.
function layerOf(absPath) {
  const rel = path.relative(SRC, absPath).split(path.sep);
  return rel.length > 1 ? rel[0] : 'entry';
}

// Every import in a file, as { layer } for relative specifiers or
// { pkg } for bare ones.
function moduleSpecifiers(src) {
  const out = [];
  const patterns = [
    /\b(?:import|export)\s+(?:[^'";]*?\s+from\s+)?["']([^"']+)["']/g,
    /\bimport\s*\(\s*["']([^"']+)["']\s*\)/g,
  ];
  for (const pattern of patterns) for (const match of src.matchAll(pattern)) out.push(match[1]);
  return [...new Set(out)];
}

function importsOf(file) {
  const out = [];
  for (const spec of moduleSpecifiers(readFileSync(file, 'utf8'))) {
    if (spec.startsWith('.')) out.push({ layer: layerOf(path.resolve(path.dirname(file), spec)), spec });
    else out.push({ pkg: spec, spec });
  }
  return out;
}

// layer → the layers it is allowed to import from (itself is always allowed).
const MAY_IMPORT = {
  core: [],                                // nothing: the simulation stands alone
  platform: ['core'],
  render: ['core'],
  ui: ['core', 'platform'],
  app: ['core', 'platform', 'render', 'ui'],
  // Development-only diagnostics may compose every production layer, but no
  // production layer may import back from dev/. main.js may load it lazily.
  dev: ['core', 'platform', 'render', 'ui', 'app'],
  entry: ['core', 'platform', 'render', 'ui', 'app', 'dev'],
};

// layer → the npm packages it may depend on.
const MAY_USE_PACKAGES = {
  core: [],                                // framework-free, so it runs headless
  platform: [],
  render: ['three'],
  ui: [],
  app: [],
  dev: ['three', 'three/examples/jsm/controls/OrbitControls.js'],
  entry: [],
};

const files = jsFiles(SRC);

test('the scanner covers quote styles, side effects, re-exports, and dynamic imports', () => {
  assert.deepEqual(moduleSpecifiers(`
    import value from "./double.js";
    import './side-effect.js';
    export { thing } from "./re-export.js";
    const lazy = import("three");
  `), ['./double.js', './side-effect.js', './re-export.js', 'three']);
});

test('the source tree is where the contract expects it', () => {
  assert.ok(files.length > 25, `only found ${files.length} modules`);
  for (const f of files) {
    assert.ok(MAY_IMPORT[layerOf(f)], `${path.relative(SRC, f)} is in an undeclared layer`);
  }
});

test('no layer imports from a layer above it', () => {
  const violations = [];
  for (const f of files) {
    const from = layerOf(f);
    for (const imp of importsOf(f)) {
      if (!imp.layer || imp.layer === from) continue;
      if (!MAY_IMPORT[from].includes(imp.layer)) {
        violations.push(`${path.relative(SRC, f)} (${from}) imports ${imp.spec} (${imp.layer})`);
      }
    }
  }
  assert.deepEqual(violations, []);
});

test('core/ is framework-free — no three.js, no npm dependency at all', () => {
  // This is what lets Game.step() run in node: the seed audit, the replay
  // fixtures and most of the test suite never construct a WebGL context.
  const violations = [];
  for (const f of files) {
    const from = layerOf(f);
    for (const imp of importsOf(f)) {
      if (!imp.pkg) continue;
      if (!MAY_USE_PACKAGES[from].includes(imp.pkg)) {
        violations.push(`${path.relative(SRC, f)} (${from}) imports package "${imp.pkg}"`);
      }
    }
  }
  assert.deepEqual(violations, []);
});

test('core/ never touches the DOM or the browser globals', () => {
  const banned = /\b(document|window|localStorage|navigator|requestAnimationFrame)\b/;
  const offenders = files
    .filter((f) => layerOf(f) === 'core')
    .filter((f) => {
      // ignore prose: only look at code lines
      const code = readFileSync(f, 'utf8')
        .split(/\r?\n/)
        .filter((l) => !l.trimStart().startsWith('//'))
        .join('\n');
      return banned.test(code);
    })
    .map((f) => path.relative(SRC, f));
  assert.deepEqual(offenders, []);
});

test('core/ is importable and steppable with no browser present', async () => {
  // The strongest form of the rule: actually run the simulation here.
  const { Game } = await import('../src/core/Game.js');
  const g = new Game();
  g.start({ mode: 2, seed: 4096 });
  for (let i = 0; i < 600; i++) { g.autopilot(); if (g.step()) break; }
  assert.ok(g.score.distance > 0, 'the sim advanced with no renderer or DOM');
});
