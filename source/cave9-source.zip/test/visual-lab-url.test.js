import { test } from 'node:test';
import assert from 'node:assert/strict';

import { VisualScenarioV1 } from '../src/dev/scenario/schema.mjs';
import { parseScenarioUrl, serializeScenarioUrl } from '../src/dev/lab/url.mjs';

test('visual-lab URL serialization round-trips scenario controls and layers', () => {
  const url = serializeScenarioUrl({
    name: 'danger look',
    seed: -2024,
    mode: 1,
    distance: 9010,
    steps: 17,
    family: 'crystal',
    camera: 'orbit',
    orthographicAxis: 'side',
    renderPass: 'clay',
    orbitDegrees: 135,
    orbitScope: 'complete-composition',
    placement: 'place',
    control: 'neutral',
    paused: false,
    viewport: { width: 1280, height: 720, dpr: 1 },
    settings: {
      readability: false,
      rockDetail: true,
      surfaceRelief: false,
      landmarks: false,
      brightness: 1.2,
      fov: 82,
      motion: 0.25,
    },
  }, 'https://example.test/game?capture=1#frame');

  const parsed = parseScenarioUrl(url);
  assert.equal(parsed.version, VisualScenarioV1);
  assert.equal(parsed.name, 'danger look');
  assert.equal(parsed.seed, -2024);
  assert.equal(parsed.mode, 1);
  assert.equal(parsed.distance, 9010);
  assert.equal(parsed.steps, 17);
  assert.equal(parsed.family, 'crystal');
  assert.equal(parsed.camera, 'orbit');
  assert.equal(parsed.orthographicAxis, 'side');
  assert.equal(parsed.renderPass, 'clay');
  assert.equal(parsed.orbitDegrees, 135);
  assert.equal(parsed.orbitScope, 'complete-composition');
  assert.equal(parsed.placement, 'place');
  assert.equal(parsed.control, 'neutral');
  assert.equal(parsed.paused, false);
  assert.deepEqual(parsed.settings, {
    readability: false,
    rockDetail: true,
    surfaceRelief: false,
    landmarks: false,
    cave: true,
    wireframe: false,
    landmarkMesh: true,
    collisionCapsules: false,
    booleanTube: false,
    playerHull: false,
    frames: false,
    fog: true,
    material: true,
    light: true,
    brightness: 1.2,
    fov: 82,
    motion: 0.25,
  });
  assert.deepEqual(parsed.viewport, { width: 1280, height: 720, dpr: 1 });
  assert.match(url, /visualLab=1/);
  assert.match(url, /capture=1/);
  assert.match(url, /#frame$/);
});

test('visual-lab URL parser accepts boolean aliases and safe defaults', () => {
  const parsed = parseScenarioUrl('/?seed=0&place=1&paused=no&landmarks=off&rockDetail=yes');
  assert.equal(parsed.seed, 1);
  assert.equal(parsed.placement, 'place');
  assert.equal(parsed.paused, false);
  assert.equal(parsed.settings.landmarks, false);
  assert.equal(parsed.settings.rockDetail, true);
  assert.equal(parsed.settings.surfaceRelief, true);
});
