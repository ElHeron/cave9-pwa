import { test } from 'node:test';
import assert from 'node:assert/strict';

import {
  pointAabbDistanceSquared, queryTriangleSurface,
} from '../src/core/landmarks/TriangleSurfaceQuery.js';

function boundsOf(vertices, triangles) {
  const bounds = { min: [Infinity, Infinity, Infinity], max: [-Infinity, -Infinity, -Infinity] };
  for (const index of triangles) for (let axis = 0; axis < 3; axis++) {
    const value = vertices[index * 3 + axis];
    bounds.min[axis] = Math.min(bounds.min[axis], value);
    bounds.max[axis] = Math.max(bounds.max[axis], value);
  }
  return bounds;
}

function strip(vertices, triangles, start, count) {
  return { start, count, bounds: boundsOf(vertices, triangles.subarray(start, start + count)) };
}

function cubeSurface() {
  const vertices = new Float64Array([
    0, 0, 0, 1, 0, 0, 1, 1, 0, 0, 1, 0,
    0, 0, 1, 1, 0, 1, 1, 1, 1, 0, 1, 1,
  ]);
  const visibleTriangles = new Uint32Array([
    0, 2, 1, 0, 3, 2, // -z
    4, 5, 6, 4, 6, 7, // +z
    0, 1, 5, 0, 5, 4, // -y
    3, 7, 6, 3, 6, 2, // +y
    0, 4, 7, 0, 7, 3, // -x
    1, 2, 6, 1, 6, 5, // +x
  ]);
  return {
    vertices, visibleVertexCount: 8, visibleTriangles,
    queryClosureTriangles: new Uint32Array(),
    strips: Array.from({ length: 6 }, (_, face) => strip(vertices, visibleTriangles, face * 6, 6)),
    bounds: boundsOf(vertices, visibleTriangles), gid: 'cube', piece: null,
  };
}

function curvedRootSurface(sectionCount = 20, radial = 16) {
  const vertices = [];
  const visibleTriangles = [];
  const strips = [];
  for (let ring = 0; ring < sectionCount; ring++) {
    const x = ring * 0.7;
    const cy = 0.13 * Math.sin(x * 0.36), cz = 0.09 * Math.sin(x * 0.27);
    const radius = 0.58 - ring / (sectionCount - 1) * 0.14;
    for (let sector = 0; sector < radial; sector++) {
      const angle = sector * Math.PI * 2 / radial;
      vertices.push(x, cy + Math.cos(angle) * radius, cz + Math.sin(angle) * radius);
    }
  }
  for (let ring = 0; ring < sectionCount - 1; ring++) {
    const start = visibleTriangles.length;
    for (let sector = 0; sector < radial; sector++) {
      const next = (sector + 1) % radial;
      const a = ring * radial + sector, b = ring * radial + next;
      const c = (ring + 1) * radial + next, d = (ring + 1) * radial + sector;
      visibleTriangles.push(a, b, c, a, c, d);
    }
    const typed = Uint32Array.from(visibleTriangles);
    strips.push(strip(Float64Array.from(vertices), typed, start, visibleTriangles.length - start));
  }
  const last = sectionCount - 1;
  const tip = vertices.length / 3;
  const tipX = last * 0.7 + 0.18;
  vertices.push(tipX, 0.13 * Math.sin(last * 0.7 * 0.36), 0.09 * Math.sin(last * 0.7 * 0.27));
  const tipStart = visibleTriangles.length;
  for (let sector = 0; sector < radial; sector++) {
    visibleTriangles.push(last * radial + sector, last * radial + (sector + 1) % radial, tip);
  }
  const worldVertices = Float64Array.from(vertices);
  const visible = Uint32Array.from(visibleTriangles);
  strips.push(strip(worldVertices, visible, tipStart, visible.length - tipStart));
  const visibleVertexCount = worldVertices.length / 3;
  const closureCenter = visibleVertexCount;
  const allVertices = Float64Array.from([...worldVertices, 0, 0, 0]);
  const closure = [];
  for (let sector = 0; sector < radial; sector++) {
    closure.push(closureCenter, (sector + 1) % radial, sector);
  }
  const queryClosureTriangles = Uint32Array.from(closure);
  return {
    vertices: allVertices, visibleVertexCount, visibleTriangles: visible,
    queryClosureTriangles, strips,
    bounds: boundsOf(allVertices, Uint32Array.from([...visible, ...queryClosureTriangles])),
    gid: 'curved-root', piece: null,
  };
}

function transformSurface(surface) {
  const vertices = new Float64Array(surface.vertices.length);
  const cz = Math.cos(0.71), sz = Math.sin(0.71);
  const cy = Math.cos(-0.38), sy = Math.sin(-0.38);
  const transform = (point) => {
    const zx = point[0] * cz - point[1] * sz;
    const zy = point[0] * sz + point[1] * cz;
    return [1000.25 + zx * cy + point[2] * sy,
      -2530.5 + zy, 15600.75 - zx * sy + point[2] * cy];
  };
  for (let index = 0; index < vertices.length / 3; index++) {
    vertices.set(transform(Array.from(surface.vertices.subarray(index * 3, index * 3 + 3))), index * 3);
  }
  const strips = surface.strips.map(({ start, count }) => strip(vertices, surface.visibleTriangles, start, count));
  return {
    surface: { ...surface, vertices, strips,
      bounds: boundsOf(vertices, Uint32Array.from([
        ...surface.visibleTriangles, ...surface.queryClosureTriangles,
      ])) },
    transform,
  };
}

function bruteForceSurface(surface) {
  return { ...surface, strips: [strip(surface.vertices, surface.visibleTriangles,
    0, surface.visibleTriangles.length)] };
}

test('closed cube returns exact signed face, edge and corner distances', () => {
  const cube = cubeSurface();
  for (const [point, expected, nearest] of [
    [[0.5, 0.5, 0.5], -0.5, null],
    [[1.5, 0.5, 0.5], 0.5, [1, 0.5, 0.5]],
    [[1.2, 1.3, 0.5], Math.hypot(0.2, 0.3), [1, 1, 0.5]],
    [[1.2, 1.3, 1.4], Math.hypot(0.2, 0.3, 0.4), [1, 1, 1]],
  ]) {
    const result = queryTriangleSurface(point, cube);
    assert.ok(Math.abs(result.distance - expected) < 1e-12,
      `${point} distance ${result.distance}`);
    assert.equal(result.inside, expected < 0);
    if (nearest) for (let axis = 0; axis < 3; axis++) {
      assert.ok(Math.abs([result.qx, result.qy, result.qz][axis] - nearest[axis]) < 1e-12);
    }
    assert.ok(Math.abs(Math.hypot(result.nx, result.ny, result.nz) - 1) < 1e-12);
  }
});

test('parity stays deterministic when the first ray crosses a shared edge or vertex', () => {
  const cube = cubeSurface();
  const dir = [1, 0.347291, 0.521731];
  for (const target of [[1, 1, 1], [1, 1, 0.5]]) {
    const inside = target.map((value, axis) => value - dir[axis] * 0.2);
    const a = queryTriangleSurface(inside, cube);
    const b = queryTriangleSurface(inside, cube);
    assert.equal(a.inside, true, `${inside} remains inside after ray-edge retry`);
    assert.ok(a.distance < 0);
    assert.ok(a.parityRaysTried > 1,
      `${inside} must reject the first degenerate edge/vertex ray`);
    assert.deepEqual(a, b);
  }
});

test('curved root uses closure for sign but excludes the invisible foot from distance', () => {
  const root = curvedRootSurface();
  const insideNearFoot = queryTriangleSurface([0.1, 0, 0], root);
  assert.equal(insideNearFoot.inside, true);
  assert.ok(insideNearFoot.distance < -0.4,
    `visible side is ${insideNearFoot.distance} m away, not the 0.1 m closure`);
  const outsideFoot = queryTriangleSurface([-0.1, 0, 0], root);
  assert.equal(outsideFoot.inside, false);
  assert.ok(outsideFoot.distance > 0.4,
    'query-only closure creates no invisible collision face behind the foot');
  const middle = queryTriangleSurface([6.3, 0.13 * Math.sin(6.3 * 0.36),
    0.09 * Math.sin(6.3 * 0.27)], root);
  assert.equal(middle.inside, true);
  assert.ok(middle.distance < -0.3);
});

test('strip pruning preserves brute-force closest point and cuts far triangle work', () => {
  const root = curvedRootSurface(36);
  const brute = bruteForceSurface(root);
  const points = [[0.1, 0, 0], [5.2, 0.3, 0.6], [12.4, -0.2, 0.7], [23.8, 0, 0], [27, 1, 1]];
  for (const point of points) {
    const fast = queryTriangleSurface(point, root);
    const slow = queryTriangleSurface(point, brute);
    assert.ok(Math.abs(fast.distance - slow.distance) < 1e-12,
      `${point}: pruned ${fast.distance} vs brute ${slow.distance}`);
    for (const field of ['qx', 'qy', 'qz']) {
      assert.ok(Math.abs(fast[field] - slow[field]) < 1e-12, `${point}: ${field}`);
    }
  }
  const nearTip = queryTriangleSurface([24.3, 0.1, 0.2], root);
  assert.ok(nearTip.trianglesTested < root.visibleTriangles.length / 3 / 4,
    `${nearTip.trianglesTested} of ${root.visibleTriangles.length / 3} triangles tested`);
  assert.ok(nearTip.stripsTested < root.strips.length / 4,
    `${nearTip.stripsTested} of ${root.strips.length} strips tested`);
  assert.equal(pointAabbDistanceSquared([0.5, 0.5, 0.5], cubeSurface().bounds), 0);
});

test('large oblique coordinates preserve signed distances and reusable outputs', () => {
  const local = curvedRootSurface();
  const { surface: deep, transform } = transformSurface(local);
  // Off-axis probes have a unique closest triangle; centreline probes may
  // legitimately switch between equally distant ring facets after rotation.
  const probes = [[0.1, 0.07, 0.03], [6.3, 0.17, -0.08],
    [11.7, 1.1, 0.2], [-0.1, 0.1, 0.2]];
  const reusable = {};
  for (const probe of probes) {
    const a = queryTriangleSurface(probe, local);
    const b = queryTriangleSurface(transform(probe), deep, reusable);
    assert.strictEqual(b, reusable);
    assert.ok(Math.abs(a.distance - b.distance) < 1e-8,
      `${probe}: local ${a.distance}, deep ${b.distance}`);
    assert.equal(a.inside, b.inside);
    const expected = transform([a.qx, a.qy, a.qz]);
    for (let axis = 0; axis < 3; axis++) {
      assert.ok(Math.abs([b.qx, b.qy, b.qz][axis] - expected[axis]) < 1e-8);
    }
  }
  const original = { ...queryTriangleSurface(transform([6.3, 0, 0]), deep, reusable) };
  queryTriangleSurface(transform([11.7, 1.1, 0.2]), deep, reusable);
  assert.deepEqual(queryTriangleSurface(transform([6.3, 0, 0]), deep, reusable), original,
    'a reused result restores the independently saved first probe');
});
