import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createRunContext } from '../src/app/RunContext.js';
import { makeRunLink, parseRunLink, parseSeed } from '../src/app/RunLink.js';

test('shared free link preserves the seed and exact applied rules under a static subpath', () => {
  const context = createRunContext({ seed: -123, rules: { controlMode: 1, thrustScale: 1 + Number.EPSILON, landmarks: false } });
  const href = makeRunLink(context, 'https://example.test/cave9/index.html?capture=1&perf=1#old');
  const url = new URL(href);
  assert.equal(url.pathname, '/cave9/index.html');
  assert.equal(url.searchParams.has('capture'), false);
  assert.equal(url.searchParams.has('perf'), false);
  assert.equal(url.hash, '');
  assert.deepEqual(parseRunLink(url.search), { status: 'valid', context });
});

test('shared Daily link retains its UTC day and fixed profile', () => {
  const context = createRunContext({ daily: true, date: new Date('2026-09-29T23:59:59Z') });
  const url = new URL(makeRunLink(context, 'https://example.test/game/'));
  assert.deepEqual(parseRunLink(url.search), { status: 'valid', context });
  url.searchParams.set('seed', '123');
  assert.equal(parseRunLink(url.search).status, 'invalid');
  url.searchParams.set('seed', String(context.seed));
  url.searchParams.set('day', '2026-02-30');
  assert.equal(parseRunLink(url.search).status, 'invalid');
});

test('ordinary query flags are not game links; malformed and forged profiles are rejected', () => {
  assert.equal(parseRunLink('?capture=1&visualLab=1&perf=1').status, 'none');
  const context = createRunContext({ seed: 42 });
  const url = new URL(makeRunLink(context, 'https://example.test/'));
  url.searchParams.set('profile', 'r1-m1-t1-l1');
  assert.equal(parseRunLink(url.search).status, 'invalid');
  url.searchParams.set('profile', context.rules.key);
  url.searchParams.append('seed', '42');
  assert.equal(parseRunLink(url.search).status, 'invalid');
});

test('seed input accepts only nonzero signed 32-bit decimal integers', () => {
  assert.equal(parseSeed(' -2147483648 '), -2147483648);
  assert.equal(parseSeed('2147483647'), 2147483647);
  for (const bad of ['', '0', '1.5', '1e3', '4294967297', '__proto__', '01']) assert.equal(parseSeed(bad), null);
});
