import { test } from 'node:test';
import assert from 'node:assert/strict';
import * as THREE from 'three';

import { Game, RunPhase } from '../src/core/Game.js';
import {
  VisualScenarioRunner, createVisualDevApi,
} from '../src/dev/scenario/VisualScenarioRunner.mjs';
import { VisualDebug3d } from '../src/dev/lab/VisualDebug3d.mjs';

function classList(initial = []) {
  const values = new Set(initial);
  return {
    contains: (name) => values.has(name),
    toggle(name, force) {
      if (force === undefined ? !values.has(name) : force) values.add(name);
      else values.delete(name);
    },
    add: (name) => values.add(name),
  };
}

function audioParam(value) {
  return { value, setValueAtTime(next) { this.value = next; } };
}

test('runtime errors are JSON-safe, finite-validated and cleared for each loaded run', () => {
  const runner = new VisualScenarioRunner({ game: new Game() });
  runner.loadScenario({ seed: 4096, placement: 'place', distance: 40 });
  runner.recordRuntimeError('browser-error', new Error('synthetic browser failure'), {
    source: 'test', fatal: false,
  });
  runner.cameraState = { requested: 'free', active: 'free', supported: true,
    position: [NaN, 2, 3] };
  let snapshot = runner.snapshot({ includeImage: false });
  assert.equal(snapshot.errorStatus, 'error');
  assert.ok(snapshot.errors.some((entry) => entry.type === 'browser-error'
    && entry.message === 'synthetic browser failure'));
  assert.ok(snapshot.errors.some((entry) => entry.type === 'non-finite'
    && entry.path === 'snapshot.camera.position[0]' && entry.value === 'NaN'));
  assert.doesNotThrow(() => JSON.stringify(snapshot.errors));

  runner.loadScenario({ seed: 4096, placement: 'place', distance: 40 });
  snapshot = runner.inspect();
  assert.equal(snapshot.errorStatus, 'ok');
  assert.deepEqual(snapshot.errors, []);

  runner.game.phase = RunPhase.DEAD;
  snapshot = runner.inspect();
  assert.ok(snapshot.errors.some((entry) => entry.type === 'crash' && entry.fatal));
});

test('snapshot and public API expose recording and clearing failures', () => {
  const game = new Game();
  const canvas = { width: 16, height: 9, toDataURL: () => { throw new Error('tainted'); } };
  const gl = { NO_ERROR: 0, isContextLost: () => false, getError: () => 0 };
  const app = { game, canvas, renderer: { canvas, renderer: { getContext: () => gl } },
    state: 'menu', externalFrameDriver: true };
  const api = createVisualDevApi(app);
  assert.equal(typeof api.recordRuntimeError, 'function');
  assert.equal(typeof api.clearRuntimeErrors, 'function');
  api.runner.scenario = { version: 'VisualScenarioV1', name: 'test', seed: 1, mode: 2,
    distance: 0, steps: 0, family: 'auto', camera: 'hero', orthographicAxis: 'front',
    renderPass: 'beauty', orbitDegrees: 0, placement: 'place', control: 'neutral', paused: true,
    viewport: { width: 320, height: 180, dpr: 1 }, settings: {
      readability: true, rockDetail: true, surfaceRelief: true, landmarks: true,
      cave: true, wireframe: false, landmarkMesh: true, collisionCapsules: false,
      booleanTube: false, playerHull: false, frames: false, fog: true, material: true,
      light: true, brightness: 1, fov: 45, motion: 0,
    } };
  const snapshot = api.snapshot();
  assert.equal(snapshot.image, null);
  assert.ok(snapshot.errors.some((entry) => entry.type === 'snapshot-error'));
  assert.deepEqual(api.clearRuntimeErrors(), []);
  assert.deepEqual(api.inspect().errors, []);
});

test('WebGL inspection fails closed for a missing context and records non-zero errors', () => {
  const missing = new VisualScenarioRunner({ app: { renderer: { renderer: {
    getContext: () => null,
  } } }, game: new Game() });
  missing._recordWebglContextState();
  assert.deepEqual(missing.runtimeErrors.map(({ type, fatal }) => ({ type, fatal })), [
    { type: 'webgl-context-missing', fatal: true },
  ]);

  const gl = { NO_ERROR: 0, isContextLost: () => false, getError: () => 0x0502 };
  const invalidOperation = new VisualScenarioRunner({ app: { renderer: { renderer: {
    getContext: () => gl,
  } } }, game: new Game() });
  invalidOperation._recordWebglContextState();
  assert.deepEqual(invalidOperation.runtimeErrors.map(({ type, value, fatal }) => (
    { type, value, fatal })), [
    { type: 'webgl-error', value: '1282', fatal: false },
  ]);
});

test('runner dispose restores every app, input, audio, menu and renderer value it mutates', () => {
  const previousDocument = globalThis.document;
  const bodyClasses = classList(['preexisting']);
  globalThis.document = { body: { classList: bodyClasses } };
  try {
    const listeners = new Map();
    const win = {
      addEventListener: (name, fn) => listeners.set(`window:${name}`, fn),
      removeEventListener: (name, fn) => {
        if (listeners.get(`window:${name}`) === fn) listeners.delete(`window:${name}`);
      },
    };
    const canvas = {
      ownerDocument: { defaultView: win },
      addEventListener: (name, fn) => listeners.set(`canvas:${name}`, fn),
      removeEventListener: (name, fn) => {
        if (listeners.get(`canvas:${name}`) === fn) listeners.delete(`canvas:${name}`);
      },
    };
    const input = {
      enabled: true, left: true, right: false,
      setEnabled(value) { this.enabled = value; if (!value) this.left = this.right = false; },
    };
    const audio = {
      ctx: { currentTime: 12 },
      _thrustSrc: {}, _thrustGain: { gain: audioParam(0.27) },
      _proxGain: { gain: audioParam(0.14) }, _proxOsc: { frequency: audioParam(333) },
      _proxPan: { pan: audioParam(-0.4) },
      stopLoops() { this._thrustSrc = null; this._thrustGain = null; this._proxGain.gain.value = 0; },
      thrust(active) {
        if (active) { this._thrustSrc = {}; this._thrustGain = { gain: audioParam(0) }; }
      },
    };
    const menu = {
      current: 'pause', overlay: { classList: classList() },
      flightOverlay: { classList: classList(['hidden']) }, touch: { classList: classList() },
      hideOverlay() { this.overlay.classList.add('hidden'); this.current = null; },
      setFlightOverlayVisible(value) { this.flightOverlay.classList.toggle('hidden', !value); },
      setTouchVisible(value) { this.touch.classList.toggle('hidden', !value); },
    };
    const renderer = {
      canvas, landmarks: false, readability: false, rockDetail: false,
      surfaceReliefRequested: false, surfaceReliefProfile: 'cave', brightness: 0.63,
      sight: 1.7, baseFov: 73,
      cameraCtl: { motion: 0.35, shakeEnabled: true, _t: 9 },
      setLandmarks(value) { this.landmarks = value; },
      setReadability(value) { this.readability = value; },
      setRockDetail(value) { this.rockDetail = value; },
      setSurfaceRelief(value, profile) { this.surfaceReliefRequested = value; this.surfaceReliefProfile = profile; },
      setBrightness(value) { this.brightness = value; }, setFov(value) { this.baseFov = value; },
      setMotion(value) { this.cameraCtl.motion = value; this.cameraCtl.shakeEnabled = value > 0.01; },
      setSight(value) { this.sight = value; },
    };
    const held = { original: true };
    const reducedMotionCalls = [];
    const app = {
      renderer, canvas, input, audio, menu, state: 'running', externalFrameDriver: false,
      _held: held, AppState: { CAPTURE: 'capture' },
      useExternalFrameDriver() { this.externalFrameDriver = true; },
      releaseExternalFrameDriver() { this.externalFrameDriver = false; },
      setReducedMotion(value) { reducedMotionCalls.push(value); bodyClasses.toggle('reduced-motion', value < 0.05); },
    };
    const runner = new VisualScenarioRunner({ app, game: new Game() });
    runner._takeAppControl();
    assert.equal(app.state, 'capture');
    assert.equal(input.enabled, false);
    assert.equal(listeners.size, 4);
    listeners.get('window:error')({ message: 'browser event', filename: 'test.js' });

    renderer.setLandmarks(true); renderer.setReadability(true); renderer.setRockDetail(true);
    renderer.setSurfaceRelief(true, 'coiling'); renderer.setBrightness(2); renderer.setFov(45);
    renderer.setMotion(0); renderer.setSight(0.5); renderer.cameraCtl._t = 0;
    app.setReducedMotion(0); app._held = { changed: true };
    runner.dispose();

    assert.equal(app.state, 'running');
    assert.equal(app.externalFrameDriver, false);
    assert.equal(app._held, held);
    assert.deepEqual({ enabled: input.enabled, left: input.left, right: input.right },
      { enabled: true, left: true, right: false });
    assert.equal(audio._thrustSrc != null, true);
    assert.equal(audio._thrustGain.gain.value, 0.27);
    assert.equal(audio._proxGain.gain.value, 0.14);
    assert.equal(audio._proxOsc.frequency.value, 333);
    assert.equal(audio._proxPan.pan.value, -0.4);
    assert.equal(menu.current, 'pause');
    assert.equal(menu.overlay.classList.contains('hidden'), false);
    assert.equal(menu.flightOverlay.classList.contains('hidden'), true);
    assert.equal(menu.touch.classList.contains('hidden'), false);
    assert.equal(bodyClasses.contains('reduced-motion'), false);
    assert.equal(reducedMotionCalls.at(-1), 0.35,
      'dispose restores reduced motion through the app API using the captured motion value');
    assert.deepEqual({ landmarks: renderer.landmarks, readability: renderer.readability,
      rockDetail: renderer.rockDetail, relief: renderer.surfaceReliefRequested,
      profile: renderer.surfaceReliefProfile, brightness: renderer.brightness,
      sight: renderer.sight, fov: renderer.baseFov, motion: renderer.cameraCtl.motion,
      shake: renderer.cameraCtl.shakeEnabled, time: renderer.cameraCtl._t }, {
      landmarks: false, readability: false, rockDetail: false, relief: false, profile: 'cave',
      brightness: 0.63, sight: 1.7, fov: 73, motion: 0.35, shake: true, time: 9,
    });
    assert.equal(listeners.size, 0);
  } finally {
    globalThis.document = previousDocument;
  }
});

test('VisualDebug3d disposes clay and restores exact captured render state once', () => {
  const hero = { name: 'hero' }, free = { name: 'free' }, ortho = { name: 'ortho' };
  const originalMaterial = { name: 'original-cave' };
  const beautyMaterial = { name: 'original-landmark' };
  const lightA = { visible: false }, lightB = { visible: true };
  let clayDisposed = 0, clayCaveDisposed = 0;
  const clayMaterial = { dispose() { clayDisposed++; } };
  const clayCaveMaterial = { dispose() { clayCaveDisposed++; } };
  const scene = new THREE.Scene();
  const landmarkGroup = new THREE.Group();
  const room = new THREE.Group();
  const mesh = new THREE.Mesh(new THREE.BufferGeometry(), new THREE.MeshBasicMaterial());
  mesh.userData.visualBeautyMaterial = beautyMaterial;
  mesh.material = clayMaterial;
  room.add(mesh); landmarkGroup.add(room); scene.add(landmarkGroup);
  const debug = Object.create(VisualDebug3d.prototype);
  Object.assign(debug, {
    r: { camera: hero, scene, caveMesh: { material: clayCaveMaterial, visible: true },
      landmarkLayer: { group: landmarkGroup } },
    scene, freeCamera: free, orthoCamera: ortho, cameraMode: 'hero', _disposed: false,
    _orbitDrawRanges: [], group: new THREE.Group(), tubeGroup: new THREE.Group(),
    frameGroup: new THREE.Group(), capsuleGroup: new THREE.Group(),
    clayRig: new THREE.Group(), clayMaterial, clayCaveMaterial,
    freeControls: { removeEventListener() {}, dispose() {} },
    orthoControls: { removeEventListener() {}, dispose() {} },
    _onFreeChange: () => {}, _onOrthoChange: () => {},
    playerHull: { geometry: { dispose() {} } }, playerMaterial: { dispose() {} },
    wireMaterial: { dispose() {} }, flatMaterial: { dispose() {} },
    neutralLandmarkMaterial: { dispose() {} }, silhouetteMaterial: { dispose() {} },
    _originalRenderState: { caveMaterial: originalMaterial, caveVisible: false,
      landmarkVisible: false, fog: { original: 'fog' }, background: { original: 'background' },
      lights: new Map([[lightA, false], [lightB, true]]) },
  });
  scene.add(debug.group, debug.clayRig);
  debug.clayRig.visible = true;

  assert.equal(debug.activeCamera, hero);
  debug.cameraMode = 'free'; assert.equal(debug.getActiveCamera(), free);
  debug.cameraMode = 'orthographic'; assert.equal(debug.activeCamera, ortho);
  scene.fog = { changed: true }; scene.background = { changed: true };
  lightA.visible = true; lightB.visible = false; landmarkGroup.visible = true;
  debug.dispose();
  debug.dispose();

  assert.equal(debug.r.caveMesh.material, originalMaterial);
  assert.equal(debug.r.caveMesh.visible, false);
  assert.equal(landmarkGroup.visible, false);
  assert.deepEqual(scene.fog, { original: 'fog' });
  assert.deepEqual(scene.background, { original: 'background' });
  assert.equal(lightA.visible, false);
  assert.equal(lightB.visible, true);
  assert.equal(mesh.material, beautyMaterial);
  assert.equal('visualBeautyMaterial' in mesh.userData, false);
  assert.equal(scene.children.includes(debug.group), false);
  assert.equal(scene.children.includes(debug.clayRig), false);
  assert.equal(clayDisposed, 1);
  assert.equal(clayCaveDisposed, 1);
  mesh.geometry.dispose();
});
