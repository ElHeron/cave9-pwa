import { expect } from '@playwright/test';

export async function installRuntimeObservers(page) {
  await page.addInitScript(() => {
    window.__cave9BrowserRuntimeIssues = [];
    const record = (kind, detail) => window.__cave9BrowserRuntimeIssues.push({ kind, detail: String(detail) });
    window.addEventListener('error', (event) => record('window-error', event.error?.stack || event.message));
    window.addEventListener('unhandledrejection', (event) => record('unhandled-rejection', event.reason?.stack || event.reason));

    const observedCanvases = new WeakSet();
    const observeCanvas = (canvas) => {
      if (observedCanvases.has(canvas)) return;
      observedCanvases.add(canvas);
      canvas.addEventListener('webglcontextlost', (event) => record('webgl-context-lost-event', event.statusMessage || 'no status message'));
      canvas.addEventListener('webglcontextrestored', () => record('webgl-context-restored', 'restored'));
    };
    for (const prototype of [window.WebGLRenderingContext?.prototype, window.WebGL2RenderingContext?.prototype]) {
      if (!prototype || prototype.__cave9GetErrorObserved) continue;
      const getError = prototype.getError;
      Object.defineProperty(prototype, '__cave9GetErrorObserved', { value: true });
      prototype.getError = function observedGetError(...args) {
        const error = getError.call(this, ...args);
        if (error !== this.NO_ERROR) record('webgl-error', error);
        return error;
      };
    }
    const getContext = HTMLCanvasElement.prototype.getContext;
    HTMLCanvasElement.prototype.getContext = function observedCanvasContext(...args) {
      const context = getContext.call(this, ...args);
      if (context && /^webgl/.test(String(args[0]))) observeCanvas(this);
      return context;
    };
  });
}

export function collectPageIssues(page) {
  const issues = [];
  page.on('console', (message) => {
    if (message.type() === 'error') issues.push({ kind: 'console-error', detail: message.text() });
  });
  page.on('pageerror', (error) => issues.push({ kind: 'page-error', detail: error.stack || error.message }));
  page.on('requestfailed', (request) => issues.push({ kind: 'request-failed', detail: `${request.method()} ${request.url()} — ${request.failure()?.errorText || 'unknown failure'}` }));
  page.on('response', (response) => {
    if (response.status() >= 400) issues.push({ kind: 'http-error', detail: `${response.status()} ${response.url()}` });
  });
  return issues;
}

export async function waitForGameApp(page) {
  await page.goto('/', { waitUntil: 'domcontentloaded' });
  await page.waitForFunction(() => window.__cave9?.state === 'menu'
    && document.querySelector('#loading')?.classList.contains('hidden'));
}

export async function assertHealthyRuntime(page, pageIssues) {
  const runtime = await page.evaluate(() => {
    const app = window.__cave9;
    const canvas = app?.renderer?.renderer?.domElement || app?.renderer?.canvas || document.querySelector('#game-canvas');
    // Inspect the exact context owned by Three, including its loss state.
    const gl = app?.renderer?.renderer?.getContext?.() || canvas?.getContext?.('webgl2') || canvas?.getContext?.('webgl');
    const diagnostics = {
      userAgent: navigator.userAgent,
      rendererIdentity: app?.renderer?.gpuIdentity ?? null,
      contextAttributes: gl?.getContextAttributes?.() ?? null,
      contextLost: gl?.isContextLost?.() ?? null,
    };
    if (!app) return { issues: [{ kind: 'app-init', detail: 'window.__cave9 is unavailable' }], diagnostics };
    if (!gl) return { issues: [{ kind: 'webgl-unavailable', detail: 'No WebGL context on the game canvas' }], diagnostics };
    if (gl.isContextLost()) return { issues: [{ kind: 'webgl-context-lost', detail: 'Game canvas WebGL context is lost' }, ...(window.__cave9BrowserRuntimeIssues || [])], diagnostics };
    gl.getError();
    return { issues: window.__cave9BrowserRuntimeIssues || [], diagnostics };
  });
  expect([...pageIssues, ...runtime.issues], `runtime issues: ${JSON.stringify([...pageIssues, ...runtime.issues])}; diagnostics: ${JSON.stringify(runtime.diagnostics)}`).toEqual([]);
}

export async function appSnapshot(page) {
  return page.evaluate(() => ({
    state: window.__cave9?.state,
    screen: window.__cave9?.menu?.current,
    context: window.__cave9?.runContext
      ? { daily: window.__cave9.runContext.daily, dailyKey: window.__cave9.runContext.dailyKey, seed: window.__cave9.runContext.seed, rules: window.__cave9.runContext.rules }
      : null,
    settings: window.__cave9?.settings
      ? { controlMode: window.__cave9.settings.get('controlMode'), sensitivity: window.__cave9.settings.get('sensitivity'), landmarks: window.__cave9.settings.get('landmarks') }
      : null,
  }));
}

export async function forceDeterministicCrash(page) {
  await page.evaluate(() => {
    // The simulation remains the authority for the crash: put this run far
    // outside its generated tube and let its next fixed step detect the hit.
    window.__cave9.game.player.pos[0] += 1_000_000;
    window.__cave9.game.player.vel[0] = 0;
  });
  await page.waitForFunction(() => window.__cave9?.state === 'dead');
}
