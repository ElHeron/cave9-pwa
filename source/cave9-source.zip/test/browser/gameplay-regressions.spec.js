import { expect, test } from '@playwright/test';
import {
  appSnapshot,
  assertHealthyRuntime,
  collectPageIssues,
  forceDeterministicCrash,
  installRuntimeObservers,
  waitForGameApp,
} from './runtime-observers.mjs';

test.describe('production browser regressions', () => {
  let pageIssues;

  test.beforeEach(async ({ page }) => {
    pageIssues = collectPageIssues(page);
    await installRuntimeObservers(page);
    await waitForGameApp(page);
  });

  test.afterEach(async ({ page }) => {
    await assertHealthyRuntime(page, pageIssues);
  });

  test('keeps a WebGL context through an idle production page and a fresh browser document', async ({ page }) => {
    await page.waitForTimeout(300);
    await assertHealthyRuntime(page, pageIssues);
    await page.reload({ waitUntil: 'domcontentloaded' });
    await page.waitForFunction(() => window.__cave9?.state === 'menu');
    await page.waitForTimeout(300);
  });

  test('starts a run, pauses with the keyboard, and resumes through the visible control', async ({ page }) => {
    await page.locator('#btn-play').click();
    await expect.poll(() => appSnapshot(page).then(({ state }) => state)).toBe('running');
    expect(await page.evaluate(() => window.__cave9.renderer.renderer.getContext().isContextLost())).toBe(false);
    await page.keyboard.press('Escape');
    await expect(page.locator('#screen-pause')).not.toHaveClass(/hidden/);
    await expect.poll(() => appSnapshot(page).then(({ state }) => state)).toBe('paused');
    await page.locator('#btn-resume').click();
    await expect.poll(() => appSnapshot(page).then(({ state }) => state)).toBe('running');
  });

  test('Enter in settings does not start a run while a settings control has focus', async ({ page }) => {
    await page.locator('#btn-settings').click();
    const control = page.locator('#settings-list input, #settings-list button').first();
    await control.focus();
    await page.keyboard.press('Enter');
    await expect(page.locator('#screen-settings')).not.toHaveClass(/hidden/);
    await expect.poll(() => appSnapshot(page).then(({ state, screen }) => ({ state, screen }))).toEqual({ state: 'menu', screen: 'settings' });
  });

  test('a gamepad Start press pauses and A resumes a running game', async ({ page }) => {
    await page.addInitScript(() => {
      const state = { start: false, confirm: false };
      window.__cave9Gamepad = state;
      Object.defineProperty(navigator, 'getGamepads', { configurable: true, value: () => [{
        axes: [0], buttons: Array.from({ length: 10 }, (_, index) => ({ pressed: index === 9 ? state.start : index === 0 ? state.confirm : false })),
      }] });
    });
    // A new document is needed because the gamepad stub must exist before the InputAdapter is constructed.
    await page.reload({ waitUntil: 'domcontentloaded' });
    await page.waitForFunction(() => window.__cave9?.state === 'menu');
    await page.locator('#btn-play').click();
    await page.evaluate(() => { window.__cave9Gamepad.start = true; });
    await page.waitForFunction(() => window.__cave9?.state === 'paused');
    await page.evaluate(() => { window.__cave9Gamepad.start = false; });
    await page.evaluate(() => new Promise((resolve) => requestAnimationFrame(resolve)));
    await page.evaluate(() => { window.__cave9Gamepad.start = true; });
    await page.waitForFunction(() => window.__cave9?.state === 'running');
    await page.evaluate(() => { window.__cave9Gamepad.start = false; });
    await page.evaluate(() => new Promise((resolve) => requestAnimationFrame(resolve)));
    await page.evaluate(() => { window.__cave9Gamepad.start = true; });
    await page.waitForFunction(() => window.__cave9?.state === 'paused');
    await page.evaluate(() => { window.__cave9Gamepad.start = false; window.__cave9Gamepad.confirm = true; });
    await page.waitForFunction(() => window.__cave9?.state === 'running');
  });

  test('daily rules override personal settings, persist under the start day, and both retries survive midnight', async ({ page }) => {
    await page.addInitScript(() => {
      const NativeDate = Date;
      let now = NativeDate.parse('2042-07-14T23:59:00.000Z');
      class ControlledDate extends NativeDate {
        constructor(...args) { super(...(args.length ? args : [now])); }
        static now() { return now; }
      }
      window.Date = ControlledDate;
      window.__cave9AdvanceClock = () => { now = NativeDate.parse('2042-07-15T00:01:00.000Z'); };
    });
    await page.reload({ waitUntil: 'domcontentloaded' });
    await page.waitForFunction(() => window.__cave9?.state === 'menu');
    await page.locator('#btn-settings').click();
    await page.getByRole('button', { name: 'One button (easier)' }).click();
    await page.locator('#settings-list input[type="range"]').first().fill('1.4');
    await page.locator('#setting-landmarks').click();
    await page.locator('#btn-settings-back').click();
    expect((await appSnapshot(page)).settings).toEqual({ controlMode: 1, sensitivity: 1.4, landmarks: false });
    await page.locator('#btn-daily').click();
    await expect.poll(() => appSnapshot(page).then(({ state }) => state)).toBe('running');
    const daily = await appSnapshot(page);
    expect(daily.context?.daily).toBe(true);
    expect(daily.context?.dailyKey).toBe('2042-07-14');
    expect(daily.context?.rules).toEqual({ controlMode: 2, thrustScale: 1, landmarks: true, key: 'r1-m2-t1-l1' });
    await page.evaluate(() => window.__cave9AdvanceClock());
    await page.evaluate(() => { window.__cave9.game.score.scored = 1; });
    await forceDeterministicCrash(page);
    expect(await page.evaluate(() => Number(localStorage.getItem('cave9.ranked.v1.daily.2042-07-14.r1-m2-t1-l1')))).toBeGreaterThanOrEqual(1);
    await page.locator('#btn-retry').click();
    await expect.poll(() => appSnapshot(page).then(({ state }) => state)).toBe('running');
    const retry = await appSnapshot(page);
    expect(retry.context).toEqual(daily.context);
    expect(retry.settings).toEqual({ controlMode: 1, sensitivity: 1.4, landmarks: false });
    await forceDeterministicCrash(page);
    await page.keyboard.press('Enter');
    await expect.poll(() => appSnapshot(page).then(({ state }) => state)).toBe('running');
    expect((await appSnapshot(page)).context).toEqual(daily.context);
  });
});
