import { expect, test } from '@playwright/test';
import { appSnapshot, assertHealthyRuntime, collectPageIssues, installRuntimeObservers, waitForGameApp } from './runtime-observers.mjs';

test.beforeEach(async ({ page }) => {
  await installRuntimeObservers(page);
  await waitForGameApp(page);
});

test('four route stations remain visible, separate and touch sized across landscape screens', async ({ page }) => {
  const issues = collectPageIssues(page);
  for (const viewport of [{ width: 1920, height: 1080 }, { width: 1280, height: 720 }, { width: 844, height: 390 }, { width: 640, height: 360 }]) {
    await page.setViewportSize(viewport);
    const boxes = [];
    for (const id of ['btn-play', 'btn-daily', 'btn-seed-select', 'btn-demo', 'btn-settings', 'btn-credits']) {
      await expect(page.locator(`#${id}`)).toBeInViewport({ ratio: 1 });
      const box = await page.locator(`#${id}`).boundingBox();
      expect(box.height, `${id}: usable touch target`).toBeGreaterThanOrEqual(48);
      boxes.push({ id, ...box });
    }
    for (let i = 0; i < boxes.length; i++) for (let j = i + 1; j < boxes.length; j++) {
      const a = boxes[i], b = boxes[j];
      const overlaps = a.x < b.x + b.width && a.x + a.width > b.x && a.y < b.y + b.height && a.y + a.height > b.y;
      expect(overlaps, `${viewport.width}×${viewport.height}: ${a.id} overlaps ${b.id}`).toBe(false);
    }
    await expect.poll(() => page.locator('#menu-route-path').getAttribute('d')).toMatch(/^M.+C/);
  }
  await assertHealthyRuntime(page, issues);
});

test('settings categories support keyboard navigation, all twelve fields, persistence and reset', async ({ page }) => {
  const issues = collectPageIssues(page);
  await page.setViewportSize({ width: 844, height: 390 });
  await page.locator('#btn-settings').click();
  const gameplay = page.getByRole('tab', { name: 'Gameplay', exact: true });
  await expect(gameplay).toBeFocused();
  await expect(gameplay).toHaveAttribute('aria-selected', 'true');
  await page.locator('#setting-sensitivity').fill('1.2');
  await gameplay.focus();
  await page.keyboard.press('ArrowRight');
  await expect(page.getByRole('tab', { name: 'Display', exact: true })).toBeFocused();
  await expect(page.locator('#setting-sensitivity')).toBeHidden();
  await page.locator('#setting-motion').fill('0.3');
  await page.getByRole('tab', { name: 'Display', exact: true }).focus();
  await page.keyboard.press('End');
  await expect(page.getByRole('tab', { name: 'Audio / Touch', exact: true })).toBeFocused();
  await page.locator('#setting-volume').fill('0.4');
  await page.getByRole('button', { name: 'Right / Left (mirrored)', exact: true }).click();
  expect(await page.locator('.settings-row').count()).toBe(12);
  await page.locator('#btn-settings-reset').click();
  await expect(page.getByRole('tab', { name: 'Audio / Touch', exact: true })).toHaveAttribute('aria-selected', 'true');
  await expect(page.locator('#setting-volume')).toHaveValue('0.7');
  await expect(page.getByRole('button', { name: 'Left / Right', exact: true })).toHaveAttribute('aria-pressed', 'true');
  await page.getByRole('tab', { name: 'Gameplay', exact: true }).click();
  await expect(page.locator('#setting-sensitivity')).toHaveValue('1');
  await page.keyboard.press('Escape');
  await expect(page.locator('#btn-play')).toBeFocused();
  expect((await appSnapshot(page)).state).toBe('menu');
  await assertHealthyRuntime(page, issues);
});

test('seed station has an explicit start, accessible validation and a keyboard return', async ({ page }) => {
  const issues = collectPageIssues(page);
  await page.locator('#btn-seed-select').click();
  await expect(page.locator('#seed-input')).toBeFocused();
  expect((await appSnapshot(page)).state).toBe('menu');
  await page.locator('#seed-input').fill('2147483648');
  await page.locator('#seed-input').press('Enter');
  await expect(page.locator('#seed-message')).toBeVisible();
  expect((await appSnapshot(page)).state).toBe('menu');
  await page.keyboard.press('Escape');
  await expect(page.locator('#btn-play')).toBeFocused();
  await page.locator('#btn-seed-select').click();
  await expect(page.locator('#seed-message')).toBeHidden();
  await page.locator('#seed-input').fill('-1234');
  await page.locator('#btn-seed-play').click();
  expect((await appSnapshot(page)).context.seed).toBe(-1234);
  await expect(page.locator('#game-canvas')).toBeFocused();
  await assertHealthyRuntime(page, issues);
});
