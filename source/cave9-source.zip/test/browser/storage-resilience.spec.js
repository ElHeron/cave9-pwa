import { expect, test } from '@playwright/test';
import { appSnapshot, assertHealthyRuntime, collectPageIssues, installRuntimeObservers, waitForGameApp } from './runtime-observers.mjs';

async function bootWithStorage(page, setup) {
  const pageIssues = collectPageIssues(page);
  await installRuntimeObservers(page);
  await page.addInitScript(setup);
  await waitForGameApp(page);
  return pageIssues;
}

test('a primitive persisted settings value does not prevent a production browser start', async ({ page }) => {
  const pageIssues = await bootWithStorage(page, () => localStorage.setItem('cave9.settings', '42'));
  await page.locator('#btn-play').click();
  await expect.poll(() => appSnapshot(page).then(({ state }) => state)).toBe('running');
  await assertHealthyRuntime(page, pageIssues);
});

test('blocked localStorage still permits a production browser start', async ({ page }) => {
  const pageIssues = await bootWithStorage(page, () => {
    for (const method of ['getItem', 'setItem', 'removeItem']) {
      Object.defineProperty(Storage.prototype, method, { configurable: true, value: () => { throw new DOMException('blocked', 'SecurityError'); } });
    }
  });
  await page.locator('#btn-play').click();
  await expect.poll(() => appSnapshot(page).then(({ state }) => state)).toBe('running');
  await assertHealthyRuntime(page, pageIssues);
});
