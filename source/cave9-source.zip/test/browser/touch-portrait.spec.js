import { expect, test } from '@playwright/test';
import { appSnapshot, assertHealthyRuntime, collectPageIssues, installRuntimeObservers, waitForGameApp } from './runtime-observers.mjs';

test.use({ viewport: { width: 844, height: 390 }, hasTouch: true, isMobile: true });

async function selectTouchLayout(page, name) {
  await page.locator('#btn-settings').tap();
  await page.getByRole('tab', { name: 'Audio / Touch', exact: true }).tap();
  await page.getByRole('button', { name }).tap();
  await page.locator('#btn-settings-back').tap();
}

async function holdTouchZone(page, expected, source = 'touch') {
  const zone = page.locator('#touch-left');
  const box = await zone.boundingBox();
  if (!box) throw new Error('touch-left has no screen bounds');
  const x = box.x + box.width / 2;
  const y = box.y + box.height / 2;
  let cdp;
  if (source === 'touch') {
    cdp = await page.context().newCDPSession(page);
    await cdp.send('Input.dispatchTouchEvent', {
      type: 'touchStart', touchPoints: [{ x, y, id: 1, radiusX: 1, radiusY: 1, force: 1 }],
    });
  } else {
    await page.mouse.move(x, y);
    await page.mouse.down();
  }
  await expect.poll(() => page.evaluate(() => ({ left: window.__cave9.input.left, right: window.__cave9.input.right }))).toEqual(expected);
  if (cdp) {
    await cdp.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] });
    await cdp.detach();
  } else {
    await page.mouse.up();
  }
  await expect.poll(() => page.evaluate(() => ({ left: window.__cave9.input.left, right: window.__cave9.input.right }))).toEqual({ left: false, right: false });
}

test('touch mapping changes once per layout, settings reset restores split, and portrait freezes simulation', async ({ page }) => {
  const pageIssues = collectPageIssues(page);
  await installRuntimeObservers(page);
  await waitForGameApp(page);

  // Default split maps the physical left zone to the right thruster.
  await page.locator('#btn-play').tap();
  await expect.poll(() => appSnapshot(page).then(({ state }) => state)).toBe('running');
  await holdTouchZone(page, { left: false, right: true });
  await holdTouchZone(page, { left: false, right: true }, 'mouse');
  await page.keyboard.press('Escape');
  await page.locator('#btn-pause-menu').tap();

  // Reconfigure through the real settings controls and verify the held zone
  // changed exactly once instead of accumulating the old listener mapping.
  await selectTouchLayout(page, 'Right / Left (mirrored)');
  await page.locator('#btn-play').tap();
  await expect.poll(() => appSnapshot(page).then(({ state }) => state)).toBe('running');
  await holdTouchZone(page, { left: true, right: false });
  await page.keyboard.press('Escape');
  await page.locator('#btn-pause-menu').tap();

  // Reset via the visible button, then verify the default split mapping again.
  await page.locator('#btn-settings').tap();
  await page.locator('#btn-settings-reset').tap();
  await page.locator('#btn-settings-back').tap();
  await page.locator('#btn-play').tap();
  await expect.poll(() => appSnapshot(page).then(({ state }) => state)).toBe('running');
  await holdTouchZone(page, { left: false, right: true });

  await page.setViewportSize({ width: 390, height: 844 });
  await expect(page.locator('#rotate-hint')).toBeVisible();
  await expect.poll(() => appSnapshot(page).then(({ state }) => state)).toBe('paused');
  const frozen = await page.evaluate(() => ({ time: window.__cave9.game.time, score: window.__cave9.game.scoreValue() }));
  await page.waitForTimeout(300);
  expect(await page.evaluate(() => ({ time: window.__cave9.game.time, score: window.__cave9.game.scoreValue() }))).toEqual(frozen);

  await page.setViewportSize({ width: 844, height: 390 });
  await expect.poll(() => appSnapshot(page).then(({ state }) => state)).toBe('paused');
  await page.locator('#btn-resume').tap();
  await expect.poll(() => appSnapshot(page).then(({ state }) => state)).toBe('running');
  await assertHealthyRuntime(page, pageIssues);
});
