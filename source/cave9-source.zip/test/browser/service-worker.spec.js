import { expect, test } from '@playwright/test';
import { createServer } from 'node:http';
import { cp, mkdtemp, readFile, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { basename, extname, join, resolve, sep } from 'node:path';
import { buildServiceWorker } from '../../scripts/build-service-worker.mjs';
import { assertHealthyRuntime, collectPageIssues, installRuntimeObservers } from './runtime-observers.mjs';

const TYPES = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.json': 'application/json',
  '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg',
  '.ogg': 'audio/ogg', '.mp3': 'audio/mpeg', '.txt': 'text/plain; charset=utf-8',
};

async function fixtureServer() {
  const root = await mkdtemp(join(tmpdir(), 'cave9-sw-browser-'));
  const paths = {};
  for (const name of ['old', 'broken', 'new']) {
    const dir = join(root, name);
    await cp('dist', dir, { recursive: true });
    await writeFile(join(dir, 'public-version.txt'), name === 'old' ? 'old public bytes' : 'new public bytes');
    await buildServiceWorker(dir);
    paths[name] = dir;
  }
  // The advertised hash no longer matches what the server actually returns.
  await writeFile(join(paths.broken, 'public-version.txt'), 'tampered public bytes');
  let deployed = 'old';
  const server = createServer(async (request, response) => {
    try {
      const pathname = decodeURIComponent(new URL(request.url, 'http://localhost').pathname);
      const relativePath = pathname.replace(/^\/nested\//, '/').replace(/^\//, '') || 'index.html';
      if (relativePath.split('/').includes('..')) { response.writeHead(400).end(); return; }
      const bytes = await readFile(join(paths[deployed], relativePath));
      response.writeHead(200, {
        'content-type': TYPES[extname(relativePath)] || 'application/octet-stream',
        'cache-control': 'no-store',
      });
      response.end(bytes);
    } catch {
      response.writeHead(404, { 'cache-control': 'no-store' }).end('missing');
    }
  });
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const origin = `http://127.0.0.1:${server.address().port}`;
  return {
    origin,
    deploy: name => { deployed = name; },
    close: async () => {
      await new Promise(resolve => server.close(resolve));
      if (!resolve(root).startsWith(resolve(tmpdir()) + sep) || !basename(root).startsWith('cave9-sw-browser-')) {
        throw new Error('Refusing to remove an unexpected fixture path');
      }
      await rm(root, { recursive: true, force: true });
    },
  };
}

async function loadControlled(page, url) {
  await page.goto(url, { waitUntil: 'domcontentloaded' });
  await page.waitForFunction(() => window.__cave9?.state === 'menu');
  await page.waitForFunction(async () => {
    const registration = await navigator.serviceWorker.getRegistration(location.href);
    return registration?.active?.state === 'activated'
      && registration.scope === new URL('./', location.href).href;
  });
  await page.evaluate(() => navigator.serviceWorker.ready);
  try {
    const expected = new URL('sw.js', url).href;
    for (let attempt = 0; attempt < 3; attempt++) {
      await page.reload({ waitUntil: 'domcontentloaded' });
      await page.waitForFunction(() => window.__cave9 && document.querySelector('#loading')?.classList.contains('hidden'));
      if (await page.evaluate(expectedUrl => navigator.serviceWorker.controller?.scriptURL === expectedUrl, expected)) break;
      await page.waitForTimeout(250);
    }
    await page.waitForFunction(expectedUrl => navigator.serviceWorker.controller?.scriptURL === expectedUrl,
      expected, { timeout: 3_000 });
    await page.waitForFunction(() => window.__cave9 && document.querySelector('#loading')?.classList.contains('hidden'));
    await page.evaluate(() => { if (window.__cave9.state === 'demo') window.__cave9.demoToMenu(); });
    await page.waitForFunction(() => window.__cave9.state === 'menu');
  } catch (error) {
    const diagnostics = await page.evaluate(async () => ({
      url: location.href,
      state: window.__cave9?.state,
      loadingHidden: document.querySelector('#loading')?.classList.contains('hidden'),
      controller: navigator.serviceWorker.controller?.scriptURL,
      registration: (await navigator.serviceWorker.getRegistration(location.href))?.scope,
      active: (await navigator.serviceWorker.getRegistration(location.href))?.active?.state,
    }));
    throw new Error(`${error.message}: ${JSON.stringify(diagnostics)}`);
  }
}

const publicBytes = page => page.evaluate(() => fetch('public-version.txt').then(response => response.text()));

test('production worker waits across two tabs, rejects a bad update, then supports offline restart', async ({ browser }) => {
  test.setTimeout(120_000);
  const site = await fixtureServer();
  const context = await browser.newContext({ serviceWorkers: 'allow' });
  try {
    const runningTab = await context.newPage();
    await loadControlled(runningTab, site.origin);
    const menuTab = await context.newPage();
    await menuTab.goto(site.origin, { waitUntil: 'domcontentloaded' });
    await menuTab.waitForFunction(() => window.__cave9?.state === 'menu' && navigator.serviceWorker.controller);
    expect(await publicBytes(menuTab)).toBe('old public bytes');

    await runningTab.evaluate(() => window.__cave9.useExternalFrameDriver());
    await runningTab.locator('#btn-play').click();
    await expect.poll(() => runningTab.evaluate(() => window.__cave9.state)).toBe('running');

    site.deploy('broken');
    await menuTab.evaluate(async () => {
      const registration = await navigator.serviceWorker.getRegistration();
      await new Promise(resolve => {
        registration.addEventListener('updatefound', () => {
          const worker = registration.installing;
          worker.addEventListener('statechange', () => {
            if (worker.state === 'redundant') resolve();
          });
        }, { once: true });
        void registration.update().catch(() => {});
      });
    });
    expect(await menuTab.evaluate(async () => (await navigator.serviceWorker.getRegistration()).waiting)).toBeNull();
    expect(await publicBytes(menuTab)).toBe('old public bytes');
    await expect(menuTab.locator('#menu-update-notice')).toBeHidden();

    site.deploy('new');
    await menuTab.evaluate(async () => (await navigator.serviceWorker.getRegistration()).update());
    await menuTab.waitForFunction(async () => Boolean((await navigator.serviceWorker.getRegistration()).waiting));
    await expect(menuTab.locator('#menu-update-notice')).toBeVisible();
    await expect(runningTab.locator('#menu-update-notice')).toBeHidden();
    expect(await runningTab.evaluate(() => window.__cave9.state)).toBe('running');
    expect(await publicBytes(menuTab)).toBe('old public bytes');
    expect(await publicBytes(runningTab)).toBe('old public bytes');

    await menuTab.close();
    expect(await runningTab.evaluate(async () => Boolean((await navigator.serviceWorker.getRegistration()).waiting))).toBe(true);
    expect(await runningTab.evaluate(() => window.__cave9.state)).toBe('running');
    await runningTab.close();
    await new Promise(resolve => setTimeout(resolve, 500));

    const newTab = await context.newPage();
    await newTab.goto(site.origin, { waitUntil: 'domcontentloaded' });
    await newTab.waitForFunction(() => window.__cave9?.state === 'menu' && navigator.serviceWorker.controller);
    expect(await publicBytes(newTab)).toBe('new public bytes');
    await expect(newTab.locator('#menu-update-notice')).toBeHidden();
    await newTab.close();

    await context.setOffline(true);
    const offlineTab = await context.newPage();
    await installRuntimeObservers(offlineTab);
    const offlineIssues = collectPageIssues(offlineTab);
    await offlineTab.goto(site.origin, { waitUntil: 'domcontentloaded' });
    await offlineTab.waitForFunction(() => window.__cave9?.state === 'menu');
    expect(await publicBytes(offlineTab)).toBe('new public bytes');
    await offlineTab.locator('#btn-play').click();
    await offlineTab.waitForFunction(() => window.__cave9?.state === 'running' && window.__cave9.game.score.distance > 0);
    await assertHealthyRuntime(offlineTab, offlineIssues.filter(issue => !(
      issue.kind === 'console-error' && /sw\.js.*ERR_INTERNET_DISCONNECTED/.test(issue.detail)
    )));
  } finally {
    await context.close();
    await site.close();
  }
});

test('root and nested deployments keep separate offline caches', async ({ browser }) => {
  test.setTimeout(90_000);
  const site = await fixtureServer();
  const context = await browser.newContext({ serviceWorkers: 'allow' });
  try {
    const rootTab = await context.newPage();
    await loadControlled(rootTab, `${site.origin}/`);
    const nestedTab = await context.newPage();
    await loadControlled(nestedTab, `${site.origin}/nested/`);
    const registrations = await nestedTab.evaluate(async () => (await navigator.serviceWorker.getRegistrations()).map(r => r.scope));
    expect(registrations).toContain(`${site.origin}/`);
    expect(registrations).toContain(`${site.origin}/nested/`);
    const names = await nestedTab.evaluate(() => caches.keys());
    expect(names.filter(name => name.startsWith('cave9-offline-v1:'))).toHaveLength(2);
    expect(await publicBytes(rootTab)).toBe('old public bytes');
    expect(await publicBytes(nestedTab)).toBe('old public bytes');
    await rootTab.close();
    await nestedTab.close();
    await context.setOffline(true);
    const offlineRoot = await context.newPage();
    await installRuntimeObservers(offlineRoot);
    const rootIssues = collectPageIssues(offlineRoot);
    await offlineRoot.goto(`${site.origin}/`, { waitUntil: 'domcontentloaded' });
    await offlineRoot.waitForFunction(() => window.__cave9?.state === 'menu');
    expect(await publicBytes(offlineRoot)).toBe('old public bytes');
    await assertHealthyRuntime(offlineRoot, rootIssues.filter(issue => !(
      issue.kind === 'console-error' && /sw\.js.*ERR_INTERNET_DISCONNECTED/.test(issue.detail)
    )));
    const offlineNested = await context.newPage();
    await installRuntimeObservers(offlineNested);
    const nestedIssues = collectPageIssues(offlineNested);
    await offlineNested.goto(`${site.origin}/nested/`, { waitUntil: 'domcontentloaded' });
    await offlineNested.waitForFunction(() => window.__cave9?.state === 'menu');
    expect(await publicBytes(offlineNested)).toBe('old public bytes');
    await assertHealthyRuntime(offlineNested, nestedIssues.filter(issue => !(
      issue.kind === 'console-error' && /sw\.js.*ERR_INTERNET_DISCONNECTED/.test(issue.detail)
    )));
  } finally {
    await context.close();
    await site.close();
  }
});
