import { expect, test } from '@playwright/test';
import {
  appSnapshot, assertHealthyRuntime, collectPageIssues, forceDeterministicCrash,
  installRuntimeObservers, waitForGameApp,
} from './runtime-observers.mjs';

test.beforeEach(async ({ page }) => {
  await installRuntimeObservers(page);
  await waitForGameApp(page);
});

test('Skip Help is explicit and remains dismissed after reload', async ({ page }) => {
  const issues = collectPageIssues(page);
  await expect(page.locator('#first-run-help')).toBeVisible();
  await page.locator('#btn-help-skip').click();
  await expect(page.locator('#first-run-help')).toBeHidden();
  await page.reload({ waitUntil: 'domcontentloaded' });
  await page.waitForFunction(() => window.__cave9?.state === 'menu');
  await expect(page.locator('#first-run-help')).toBeHidden();
  await assertHealthyRuntime(page, issues);
});

test('first-run help stays out of Play, and result focus, telemetry and comparable best are visible', async ({ page }) => {
  const issues = collectPageIssues(page);
  await expect(page.locator('#first-run-help')).toBeVisible();
  const creditsBounds = await page.locator('#btn-credits').boundingBox();
  expect(creditsBounds).not.toBeNull();
  expect(creditsBounds.y + creditsBounds.height).toBeLessThanOrEqual(720);
  await page.locator('#btn-play').click();
  await expect.poll(() => appSnapshot(page).then(({ state }) => state)).toBe('running');
  await expect(page.locator('#game-canvas')).toBeFocused();
  await page.keyboard.press('Escape');
  await expect(page.locator('#btn-resume')).toBeFocused();
  await page.locator('#btn-resume').click();
  await expect(page.locator('#game-canvas')).toBeFocused();
  await page.evaluate(() => {
    const context = window.__cave9.runContext;
    localStorage.setItem(`cave9.ranked.v1.seedBest.free.${context.rules.key}`, JSON.stringify({ [context.seed]: 500 }));
  });
  await forceDeterministicCrash(page);
  await expect(page.locator('#btn-retry')).toBeFocused();
  await expect(page.locator('#death-best')).toContainText('500');
  await expect(page.locator('#death-rules')).toContainText('Two thrusters');
  for (const id of ['death-distance', 'death-speed', 'death-graze', 'death-combo']) {
    await expect(page.locator(`#${id}`)).not.toBeEmpty();
  }
  await page.locator('#btn-death-menu').click();
  await expect(page.locator('#first-run-help')).toBeHidden();
  await assertHealthyRuntime(page, issues);
});

test('short landscape viewport keeps the complete result and actions in view', async ({ page }) => {
  const issues = collectPageIssues(page);
  await page.setViewportSize({ width: 844, height: 390 });
  for (const selector of ['#btn-play', '#btn-help-skip', '#seed-input', '#btn-settings']) {
    const bounds = await page.locator(selector).boundingBox();
    expect(bounds, `${selector} should have visible bounds`).not.toBeNull();
    expect(bounds.y, `${selector} should be above the bottom edge`).toBeGreaterThanOrEqual(0);
    expect(bounds.y + bounds.height, `${selector} should fit in the viewport`).toBeLessThanOrEqual(390);
  }
  await page.locator('#btn-play').click();
  await forceDeterministicCrash(page);
  for (const selector of ['#death-title', '#death-score', '#death-distance', '#death-rules', '#btn-retry', '#btn-share-result']) {
    const bounds = await page.locator(selector).boundingBox();
    expect(bounds, `${selector} should have visible bounds`).not.toBeNull();
    expect(bounds.y, `${selector} should be above the bottom edge`).toBeGreaterThanOrEqual(0);
    expect(bounds.y + bounds.height, `${selector} should fit in the viewport`).toBeLessThanOrEqual(390);
  }
  await assertHealthyRuntime(page, issues);
});

test('update notice, first-run help, rules and best remain inside the visible menu panel', async ({ page }) => {
  const issues = collectPageIssues(page);
  for (const viewport of [{ width: 1280, height: 720 }, { width: 844, height: 390 }]) {
    await page.setViewportSize(viewport);
    await page.evaluate(() => window.__cave9.menu.setUpdateReady(true));
    await expect(page.locator('#menu-update-notice')).toBeVisible();
    const layout = await page.evaluate(() => {
      const panel = document.querySelector('#screen-menu');
      const panelRect = panel.getBoundingClientRect();
      const top = panelRect.top + panel.clientTop;
      const bottom = top + panel.clientHeight;
      const selectors = ['#btn-play', '#btn-help-skip', '#menu-update-notice', '#btn-daily',
        '.daily-rules', '#seed-input', '#btn-settings', '#btn-credits', '#menu-best', '#menu-hint'];
      return {
        scrollHeight: panel.scrollHeight, clientHeight: panel.clientHeight,
        items: selectors.map(selector => {
          const rect = panel.querySelector(selector).getBoundingClientRect();
          return { selector, top: rect.top, bottom: rect.bottom, visibleTop: top, visibleBottom: bottom };
        }),
      };
    });
    expect(layout.scrollHeight, `${viewport.width}×${viewport.height}: panel should not scroll`)
      .toBeLessThanOrEqual(layout.clientHeight + 1);
    for (const item of layout.items) {
      expect(item.top, `${viewport.width}×${viewport.height}: ${item.selector} clipped at top`)
        .toBeGreaterThanOrEqual(item.visibleTop - 1);
      expect(item.bottom, `${viewport.width}×${viewport.height}: ${item.selector} clipped at bottom`)
        .toBeLessThanOrEqual(item.visibleBottom + 1);
    }
  }
  await page.locator('#btn-play').click();
  await forceDeterministicCrash(page);
  await page.evaluate(() => window.__cave9.menu.setUpdateReady(true));
  await expect(page.locator('#death-update-notice')).toBeVisible();
  const deathLayout = await page.evaluate(() => {
    const panel = document.querySelector('#screen-death');
    const panelRect = panel.getBoundingClientRect();
    const top = panelRect.top + panel.clientTop;
    const bottom = top + panel.clientHeight;
    const selectors = ['#death-title', '#death-score', '#death-rules', '#death-update-notice',
      '#btn-retry', '#btn-share-result'];
    return {
      scrollHeight: panel.scrollHeight, clientHeight: panel.clientHeight,
      items: selectors.map(selector => {
        const rect = panel.querySelector(selector).getBoundingClientRect();
        return { selector, top: rect.top, bottom: rect.bottom, visibleTop: top, visibleBottom: bottom };
      }),
    };
  });
  expect(deathLayout.scrollHeight, '844×390: death panel should not scroll')
    .toBeLessThanOrEqual(deathLayout.clientHeight + 1);
  for (const item of deathLayout.items) {
    expect(item.top, `844×390: ${item.selector} clipped at top`).toBeGreaterThanOrEqual(item.visibleTop - 1);
    expect(item.bottom, `844×390: ${item.selector} clipped at bottom`).toBeLessThanOrEqual(item.visibleBottom + 1);
  }
  await assertHealthyRuntime(page, issues);
});

test('seed entry and shared link reproduce exact free rules without changing personal settings', async ({ page }) => {
  const issues = collectPageIssues(page);
  await page.locator('#seed-input').fill('0');
  await page.locator('#btn-seed-play').click();
  await expect(page.locator('#menu-message')).toContainText('nonzero');
  await expect.poll(() => appSnapshot(page).then(({ state }) => state)).toBe('menu');

  await page.locator('#btn-settings').click();
  await page.getByRole('button', { name: 'One button (easier)' }).click();
  await page.locator('#setting-sensitivity').fill('1.35');
  await page.locator('#setting-landmarks').click();
  await expect(page.locator('#setting-landmarks')).toHaveAttribute('aria-pressed', 'false');
  await expect(page.locator('label[for="setting-sensitivity"]')).toHaveText('Thruster sensitivity');
  await page.locator('#btn-settings-back').click();

  await page.locator('#seed-input').fill('1234');
  await page.locator('#seed-input').press('Enter');
  const original = await appSnapshot(page);
  expect(original.context.seed).toBe(1234);
  expect(original.context.rules).toEqual({ controlMode: 1, thrustScale: 1.35, landmarks: false, key: 'r1-m1-t1.35-l0' });
  await forceDeterministicCrash(page);
  await page.evaluate(() => {
    Object.defineProperty(navigator, 'clipboard', {
      configurable: true,
      value: { writeText: async (text) => { window.__copiedRunLink = text; } },
    });
  });
  await page.locator('#btn-share').click();
  await expect(page.locator('#copy-status')).toContainText('Copied');
  const link = await page.evaluate(() => window.__copiedRunLink);
  expect(link).toContain('c9=1');

  await page.locator('#btn-death-menu').click();
  await page.locator('#btn-settings').click();
  await page.getByRole('button', { name: 'Two thrusters' }).click();
  await page.locator('#setting-sensitivity').fill('1');
  await page.locator('#setting-landmarks').click();
  await page.locator('#btn-settings-back').click();
  const personal = (await appSnapshot(page)).settings;

  await page.goto(link, { waitUntil: 'domcontentloaded' });
  await page.waitForFunction(() => window.__cave9?.state === 'menu');
  await expect(page.locator('#shared-run')).toBeVisible();
  expect((await appSnapshot(page)).settings).toEqual(personal);
  await page.locator('#btn-shared-play').click();
  await expect.poll(() => appSnapshot(page).then(({ state }) => state)).toBe('running');
  const shared = await appSnapshot(page);
  expect(shared.context).toEqual(original.context);
  expect(shared.settings).toEqual(personal);
  await assertHealthyRuntime(page, issues);
});

test('malformed shared link stays in the menu with a visible error', async ({ page }) => {
  const issues = collectPageIssues(page);
  await page.goto('/?c9=1&seed=42', { waitUntil: 'domcontentloaded' });
  await page.waitForFunction(() => window.__cave9?.state === 'menu');
  await expect(page.locator('#menu-message')).toContainText('invalid');
  await expect(page.locator('#shared-run')).toBeHidden();
  await expect(page.locator('#btn-play')).toBeVisible();
  await assertHealthyRuntime(page, issues);
});

test('system reduced motion applies on first start and explicit user choice survives reload', async ({ page }) => {
  const issues = collectPageIssues(page);
  await page.emulateMedia({ reducedMotion: 'reduce' });
  await page.evaluate(() => localStorage.clear());
  await page.reload({ waitUntil: 'domcontentloaded' });
  await page.waitForFunction(() => window.__cave9?.state === 'menu');
  expect(await page.evaluate(() => window.__cave9.settings.get('motion'))).toBe(0);
  await expect(page.locator('body')).toHaveClass(/reduced-motion/);
  await page.locator('#btn-settings').click();
  await page.locator('#setting-motion').fill('0.8');
  await page.reload({ waitUntil: 'domcontentloaded' });
  await page.waitForFunction(() => window.__cave9?.state === 'menu');
  expect(await page.evaluate(() => window.__cave9.settings.get('motion'))).toBe(0.8);
  await expect(page.locator('body')).not.toHaveClass(/reduced-motion/);
  await assertHealthyRuntime(page, issues);
});
