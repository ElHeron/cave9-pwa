import { test } from 'node:test';
import assert from 'node:assert/strict';

import { CaveStream } from '../src/core/CaveStream.js';
import { Game } from '../src/core/Game.js';
import { pathFrameAt } from '../src/core/FlightPath.js';
import { placeAt } from '../src/app/CaptureHarness.js';
import {
  LandmarkSurfaceProjector, MAX_SURFACE_PROJECTION_FRAMES,
  MAX_SURFACE_PROJECTION_INTERVALS, SURFACE_PROJECTION_FRAME_STEP,
  projectLandmarkSurfacePoint,
} from '../src/render/landmarks/surfaceProjection.js';

const near = (actual, expected, tolerance = 1e-6) =>
  assert.ok(Math.abs(actual - expected) <= tolerance,
    `${actual} differs from ${expected} by more than ${tolerance}`);

function worldPoint(frame, localRight, localUp) {
  return {
    x: frame.center.x + frame.right.x * localRight + frame.up.x * localUp,
    y: frame.center.y + frame.right.y * localRight + frame.up.y * localUp,
    z: frame.center.z + frame.right.z * localRight + frame.up.z * localUp,
  };
}

// Approximate spacing between representable float32 axial values at a depth.
// These coordinates will ultimately be GPU vertex attributes, so an inverse
// error far below this spacing cannot move the sampled 14 m cave atlas visibly.
const float32UlpAt = (value) => 2 ** (Math.floor(Math.log2(Math.max(1, Math.abs(value)))) - 23);

function compareFastWithExact(projector, seed, point, contact = 0) {
  const exact = projectLandmarkSurfacePoint(seed, point, contact);
  const fast = projector.project(point, contact);
  const axialTolerance = Math.max(1e-6, float32UlpAt(exact.axialDepth) / 2);
  near(fast.axialDepth, exact.axialDepth, axialTolerance);
  near(fast.localRight, exact.localRight, 1e-5);
  near(fast.localUp, exact.localUp, 1e-5);
  assert.equal(fast.contact, contact);
  assert.deepEqual(projector.project(point, contact), fast,
    'cached projection is deterministic');
}

test('inverts tilted path frames without treating world z as axial depth', () => {
  for (const seed of [17, 256, 2024, 4096]) {
    for (const depth of [0, 250, 2050, 6050, 9070, 9120, 15600, 19998]) {
      const frame = pathFrameAt(seed, depth);
      for (const [right, up] of [[-80, -45], [40, -20], [0, 0], [50, 70], [100, -80]]) {
        const point = worldPoint(frame, right, up);
        const result = projectLandmarkSurfacePoint(seed, point, 0.625);
        near(result.axialDepth, depth);
        near(result.localRight, right);
        near(result.localUp, up);
        assert.equal(result.contact, 0.625);
        assert.deepEqual(projectLandmarkSurfacePoint(seed, point, 0.625), result,
          'reprojection is deterministic');
      }
    }
  }
  const tilted = worldPoint(pathFrameAt(4096, 6050), -80, -45);
  assert.ok(Math.abs(tilted.z - 6050) > 0.01,
    'fixture actually exercises a tilted local frame');
});

test('matches route-local coordinates of submitted cave wall vertices', () => {
  const seed = 2024;
  const cave = new CaveStream();
  cave.reset(seed, 'branching');
  cave.generateThrough(9120);
  const capacity = cave.segs.length;
  const ring = (cave.i - 1 + capacity) % capacity;
  const frame = cave.frames[ring];
  const centre = cave.centers[ring];
  near(frame.center.z, 9120);
  for (const sector of [0, 3, 8, 15, 23, 31]) {
    const vertex = cave.segs[ring][sector];
    const dx = vertex[0] - centre[0];
    const dy = vertex[1] - centre[1];
    const dz = vertex[2] - centre[2];
    const expectedRight = dx * frame.right.x + dy * frame.right.y + dz * frame.right.z;
    const expectedUp = dx * frame.up.x + dy * frame.up.y + dz * frame.up.z;
    const projected = projectLandmarkSurfacePoint(seed,
      { x: vertex[0], y: vertex[1], z: vertex[2] }, 1);
    near(projected.axialDepth, centre[2]);
    near(projected.localRight, expectedRight);
    near(projected.localUp, expectedUp);
    assert.equal(projected.contact, 1);
  }
});

test('rejects invalid points and contact weights before GPU attribute creation', () => {
  assert.throws(() => projectLandmarkSurfacePoint(1, { x: 0, y: 0, z: NaN }), RangeError);
  assert.throws(() => projectLandmarkSurfacePoint(1, { x: 0, y: 0, z: 0 }, 1.01), RangeError);
});

test('bounded 2 m projector tracks real route frames from the first cave to 20 km', () => {
  assert.equal(SURFACE_PROJECTION_FRAME_STEP, 2);
  for (const seed of [17, 256, 2024, 4096]) {
    const projector = new LandmarkSurfaceProjector(seed, 9);
    for (const depth of [0, 100, 250, 2050, 6050, 9070, 9120, 15600, 19998]) {
      const frame = pathFrameAt(seed, depth);
      for (const [right, up] of [[-100, -100], [-50, 15], [0, 0], [50, 70], [100, -80]]) {
        compareFastWithExact(projector, seed, worldPoint(frame, right, up), 0.35);
      }
    }
    assert.ok(projector.frameCount <= MAX_SURFACE_PROJECTION_FRAMES);
    assert.ok(projector.intervalCount <= MAX_SURFACE_PROJECTION_INTERVALS);
    projector.dispose();
  }
});

test('cached projection matches current authoritative RootSurface and BladeHull vertices', () => {
  for (const [seed, depth, roomIndex, family] of [
    [256, 9010, 9, 'branching'],
    [2024, 6050, 6, 'branching'],
    [2024, 2050, 2, 'crystal'],
    [4096, 9070, 9, 'crystal'],
  ]) {
    const game = new Game();
    game.start({ mode: 2, seed, family });
    placeAt(game, depth);
    const comp = game.landmarkCache.compositionAt(seed, game.cave, roomIndex, family);
    assert.ok(comp, `${seed}:${roomIndex}:${family} exists`);
    const projector = new LandmarkSurfaceProjector(seed, roomIndex);
    let sampled = 0;
    const surfaces = family === 'branching'
      ? comp.rootSurfaces.map((surface) => [surface.vertices, surface.visibleVertexCount])
      : comp.pieces.map((piece) => [piece.slabHull.vertices, piece.slabHull.vertices.length / 3]);
    for (const [vertices, count] of surfaces) for (let i = 0; i < count; i++) {
      const at = i * 3;
      compareFastWithExact(projector, seed,
        { x: vertices[at], y: vertices[at + 1], z: vertices[at + 2] }, 0.8);
      sampled++;
    }
    assert.ok(sampled > 100, `${family} samples actual surface vertices`);
    assert.ok(projector.frameCount <= MAX_SURFACE_PROJECTION_FRAMES);
    assert.ok(projector.intervalCount <= MAX_SURFACE_PROJECTION_INTERVALS);
  }
});

test('room cache is bounded, survives repeat use and clears on reset/seed switch', () => {
  const projector = new LandmarkSurfaceProjector(256, 9);
  const first = worldPoint(pathFrameAt(256, 9070), 42, -18);
  const before = projector.project(first, 0.25);
  // This intentionally exceeds the room window to exercise eviction. A real
  // LandmarkLayer retains one such projector per room, never one per frame.
  for (let depth = 100; depth <= 20000; depth += 16) {
    projector.project(worldPoint(pathFrameAt(256, depth), 20, -10));
  }
  assert.ok(projector.frameCount <= MAX_SURFACE_PROJECTION_FRAMES);
  assert.ok(projector.intervalCount <= MAX_SURFACE_PROJECTION_INTERVALS);
  assert.deepEqual(projector.project(first, 0.25), before,
    'eviction changes cost, not coordinates');

  projector.reset(17, 2);
  assert.equal(projector.frameCount, 0);
  assert.equal(projector.intervalCount, 0);
  compareFastWithExact(projector, 17,
    worldPoint(pathFrameAt(17, 2050), -30, 20), 0.6);
  projector.reset(17, 2);
  assert.equal(projector.frameCount, 0, 'same-seed game reset also clears caches');
  projector.dispose();
  assert.equal(projector.frameCount, 0);
  assert.throws(() => projector.project(first), /disposed/);
});
