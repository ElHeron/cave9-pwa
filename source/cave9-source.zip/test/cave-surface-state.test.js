import { test } from 'node:test';
import assert from 'node:assert/strict';

import { CaveStream } from '../src/core/CaveStream.js';
import { ROOM_FADE_LEN, ROOM_LEN, ROOM_MUL, ROOM_SPACING, ROOM_START } from '../src/core/constants.js';
import { roomShellAt } from '../src/core/RoomState.js';
import { LANDMARK_TYPES, landmarkType } from '../src/core/landmarks/rng.js';
import {
  FAMILY_IDS,
  SURFACE_ROLES,
  TUNNEL_STRETCH_MAX,
  TUNNEL_STRETCH_MIN,
  TUNNEL_TRANSITION_LENGTH,
  TUNNEL_EDGE_SHARE,
  TUNNEL_MAIN_SHARE,
  TUNNEL_VARIANT_NEIGHBOURS,
  familyIdAt,
  familyLayerNeedsSeparator,
  familyNameAt,
  isTunnelVariantTransitionAllowed,
  roomMaterialPhaseAt,
  surfaceRoleAt,
  surfaceStretchAt,
  tunnelVariantSharesAt,
} from '../src/render/materials/caveSurfaceState.js';

test('roomShellAt exactly matches CaveStream physical room multiplier', () => {
  const cave = new CaveStream();
  for (const depth of [
    -1, 0, ROOM_START - 0.1, ROOM_START, ROOM_START + 2,
    ROOM_START + ROOM_FADE_LEN, ROOM_START + ROOM_LEN / 2,
    ROOM_START + ROOM_LEN - ROOM_FADE_LEN, ROOM_START + ROOM_LEN,
    ROOM_START + ROOM_LEN + 0.1, ROOM_START + ROOM_SPACING,
  ]) {
    cave._updateWallState(depth);
    const shell = roomShellAt(depth);
    assert.equal(cave.roomMul, 1 + (ROOM_MUL - 1) * shell.weight, `depth ${depth}`);
    assert.equal(shell.weight >= 0 && shell.weight <= 1, true, `weight bounds at ${depth}`);
  }
  assert.equal(roomShellAt(ROOM_START - 1).weight, 0, 'no shell before first room');
  assert.equal(roomShellAt(ROOM_START).weight, 0, 'the shell begins smoothly');
  assert.equal(roomShellAt(ROOM_START + ROOM_FADE_LEN).weight, 1, 'core reaches full shell');
  assert.equal(roomShellAt(ROOM_START + ROOM_LEN - ROOM_FADE_LEN).weight, 1, 'core ends full shell');
  assert.equal(roomShellAt(ROOM_START + ROOM_LEN).weight, 0, 'the shell ends smoothly');
});

test('tunnel stretches are deterministic, bounded and have only allowed neighbours', () => {
  for (let seed = 1; seed <= 100; seed++) {
    let previous = null;
    // 50 m cadence still visits every 350 m minimum-length region across the
    // required 20 km audit, while keeping the property test quick enough for
    // the normal unit-test suite.
    for (let depth = 0; depth <= 20_000; depth += 50) {
      const state = surfaceStretchAt(seed, depth);
      assert.ok(state.to - state.from >= TUNNEL_STRETCH_MIN && state.to - state.from <= TUNNEL_STRETCH_MAX,
        `seed ${seed} has invalid length at ${depth}`);
      assert.ok(state.transition >= 0 && state.transition <= 1, `transition bounds at ${depth}`);
      assert.ok(state.regionProgress >= 0 && state.regionProgress <= 1, `region progress bounds at ${depth}`);
      assert.ok(isTunnelVariantTransitionAllowed(state.previousVariant, state.currentVariant),
        `forbidden predecessor ${state.previousVariant} -> ${state.currentVariant}`);
      assert.notEqual(state.currentVariant, state.nextVariant, `self transition at seed ${seed}, ${depth}`);
      assert.ok(isTunnelVariantTransitionAllowed(state.currentVariant, state.nextVariant),
        `forbidden ${state.currentVariant} -> ${state.nextVariant}`);
      if (!previous || previous.from !== state.from) {
        if (previous) assert.equal(state.currentVariant, previous.nextVariant,
          `region continuity at seed ${seed}, ${state.from}`);
        if (previous) assert.equal(state.previousVariant, previous.currentVariant,
          `previous continuity at seed ${seed}, ${state.from}`);
        previous = state;
      }
    }
  }
});

test('tunnel predecessor, successor and linear region progress are query-order independent', () => {
  for (let seed = 1; seed <= 100; seed++) {
    const seen = new Map();
    for (let depth = 0; depth < 20_000;) {
      const state = surfaceStretchAt(seed, depth);
      const length = state.to - state.from;
      assert.ok(length >= TUNNEL_STRETCH_MIN && length <= TUNNEL_STRETCH_MAX);
      assert.equal(state.regionProgress, (depth - state.from) / length);
      assert.deepEqual(surfaceStretchAt(seed, state.from), {
        ...state,
        transition: 0,
        regionProgress: 0,
      }, `start state seed ${seed}, region ${state.from}`);
      const nearEnd = surfaceStretchAt(seed, state.to - 1e-6);
      assert.ok(nearEnd.regionProgress > 0.99999999, `end progress seed ${seed}, region ${state.from}`);
      assert.ok(isTunnelVariantTransitionAllowed(state.previousVariant, state.currentVariant));
      assert.ok(isTunnelVariantTransitionAllowed(state.currentVariant, state.nextVariant));
      seen.set(state.from, state);
      depth = state.to;
    }
    for (const state of [...seen.values()].reverse()) {
      const probe = surfaceStretchAt(seed, state.from + (state.to - state.from) * 0.371);
      assert.equal(probe.previousVariant, state.previousVariant);
      assert.equal(probe.currentVariant, state.currentVariant);
      assert.equal(probe.nextVariant, state.nextVariant);
      assert.ok(Math.abs(probe.regionProgress - 0.371) < 1e-12);
    }
  }
});

test('tunnel variant shares preserve a 65 percent main layer and hand off the remainder', () => {
  assert.equal(TUNNEL_MAIN_SHARE, 0.65);
  assert.equal(TUNNEL_EDGE_SHARE, 0.05);
  assert.deepEqual(tunnelVariantSharesAt(0), { previous: 0.30, current: 0.65, next: 0.05 });
  assert.deepEqual(tunnelVariantSharesAt(0.5), { previous: 0.175, current: 0.65, next: 0.175 });
  assert.deepEqual(tunnelVariantSharesAt(1), { previous: 0.05, current: 0.65, next: 0.30 });
  for (let step = -10; step <= 110; step++) {
    const shares = tunnelVariantSharesAt(step / 100);
    assert.ok(shares.previous >= TUNNEL_EDGE_SHARE && shares.previous <= 0.30);
    assert.ok(shares.next >= TUNNEL_EDGE_SHARE && shares.next <= 0.30);
    assert.equal(shares.current, TUNNEL_MAIN_SHARE);
    assert.ok(Math.abs(shares.previous + shares.current + shares.next - 1) < 1e-12);
  }
});

test('tunnel resolver is independent of query order and transition is exactly 36m', () => {
  const seed = 424242;
  const ordered = new Map();
  for (let depth = 0; depth <= 20_000; depth += 17) ordered.set(depth, surfaceStretchAt(seed, depth));
  const queryOrder = [...ordered.keys()].reverse().concat([1337.5, 7, 19_999.9, 0]);
  for (const depth of queryOrder) {
    const state = surfaceStretchAt(seed, depth);
    if (ordered.has(depth)) assert.deepEqual(state, ordered.get(depth), `query order changed ${depth}`);
    assert.equal(surfaceStretchAt(seed, depth).transition, state.transition, `repeat changed ${depth}`);
  }

  for (let depth = 0; depth < 20_000;) {
    const state = surfaceStretchAt(seed, depth);
    const begin = surfaceStretchAt(seed, state.to - TUNNEL_TRANSITION_LENGTH);
    const end = surfaceStretchAt(seed, state.to - 1e-6);
    assert.equal(begin.transition, 0, `transition begins at exact 36m band for ${state.from}`);
    assert.ok(end.transition > 0.999999, `transition reaches one at ${state.to}`);
    depth = state.to;
  }
});

test('forced tunnel variants disable incompatible random transitions', () => {
  for (const variant of Object.keys(TUNNEL_VARIANT_NEIGHBOURS)) {
    for (const depth of [0, 349, 2000, 20_000]) {
      const state = surfaceStretchAt(5, depth, variant);
      assert.equal(state.currentVariant, variant);
      assert.equal(state.previousVariant, variant);
      assert.equal(state.nextVariant, variant);
      assert.equal(state.transition, 0);
      assert.equal(state.regionProgress, 0.5);
    }
  }
});

test('family resolver shares landmarkType, honours overrides and is room-only', () => {
  for (let seed = 1; seed <= 30; seed++) {
    for (let room = 2; room < 20; room++) {
      const depth = room * ROOM_SPACING + ROOM_LEN / 2;
      assert.equal(familyIdAt(seed, depth), landmarkType(seed, room));
      assert.equal(familyIdAt(seed, depth, 'auto'), landmarkType(seed, room));
      assert.equal(familyNameAt(seed, depth), LANDMARK_TYPES[landmarkType(seed, room)]);
      for (const [name, id] of Object.entries(FAMILY_IDS)) {
        assert.equal(familyIdAt(seed, depth, name), id, `override ${name}`);
      }
    }
  }
  assert.equal(familyIdAt(1, ROOM_START - 1, 'coiling'), -1);
  assert.equal(familyNameAt(1, ROOM_START - 1, 'coiling'), null);
});

test('local surface roles keep warm/cool zones separated without world coordinates', () => {
  const roles = new Set();
  for (let depth = 0; depth <= 100; depth += 1) {
    roles.add(surfaceRoleAt(-9, 10, depth, 12));
    roles.add(surfaceRoleAt(-5, 10, depth, 12));
    roles.add(surfaceRoleAt(0, 10, depth, 12));
    roles.add(surfaceRoleAt(6, 10, depth, 12));
    roles.add(surfaceRoleAt(9, 10, depth, 12));
  }
  assert.deepEqual([...roles].sort(), [...SURFACE_ROLES].sort());
  assert.equal(surfaceRoleAt(-10, 10, 0), 'floor');
  assert.equal(surfaceRoleAt(10, 10, 0), 'ceiling');
  assert.equal(familyLayerNeedsSeparator('branching', 'layerB', 'layerC'), true);
  assert.equal(familyLayerNeedsSeparator('crystal', 'layerA', 'layerB'), false);
  assert.equal(familyLayerNeedsSeparator('coiling', 'floor', 'sideWall'), true);
});

test('room material shoulder phases are tied to the physical 30m shell', () => {
  const start = ROOM_START;
  assert.equal(roomMaterialPhaseAt(start - 1).phase, 'tunnel');
  assert.equal(roomMaterialPhaseAt(start + 5).phase, 'neutralize');
  assert.equal(roomMaterialPhaseAt(start + 15).phase, 'swap');
  assert.equal(roomMaterialPhaseAt(start + 25).phase, 'grow');
  assert.equal(roomMaterialPhaseAt(start + ROOM_FADE_LEN).phase, 'family');
  assert.equal(roomMaterialPhaseAt(start + ROOM_LEN - 5).phase, 'neutralize');
});
