import test from 'node:test';
import assert from 'node:assert/strict';

import {
  coilingRimPolicyPass, perfScenarioContractPass, textureBudgetMetrics,
  releaseEvidenceContractPass, RELEASE_FAMILIES, RELEASE_MODES, RELEASE_SCENARIOS,
  RELEASE_VIEWPORT, textureStorageBytes, withTextureStorageEstimate,
} from '../scripts/perf-scenario-contract.mjs';

const releaseOptions = () => ({
  releaseRequested: true, warmupSeconds: 30, sampleSeconds: 90,
  repetitions: 3, flySpanMeters: 1200,
  families: [...RELEASE_FAMILIES], modes: [...RELEASE_MODES],
  scenarios: RELEASE_SCENARIOS.map((s) => ({ ...s })),
  scenarioFilterRequested: false, checkpointOverrideRequested: false,
  pairSweep: false, rockDetail: true, surfaceRelief: true,
  landmarks: true, cave: true, quality: 2,
  viewport: { ...RELEASE_VIEWPORT },
});

test('release evidence requires the exact standard matrix and render settings', () => {
  const valid = releaseOptions();
  assert.equal(releaseEvidenceContractPass(valid), true);
  const invalid = [
    { scenarios: valid.scenarios.slice(0, 1), scenarioFilterRequested: true },
    { scenarios: [{ name: 'depth-9010', seed: 2024, distance: 9010 }], checkpointOverrideRequested: true },
    { families: [...valid.families, 'auto'] },
    { families: ['off', 'branching', 'crystal', 'crystal'] },
    { modes: ['static', 'static', 'flythrough'] },
    { viewport: { width: 1280, height: 720, dpr: 1 } },
    { viewport: { width: 1920, height: 1080, dpr: 2 } },
    { quality: 1 }, { surfaceRelief: false }, { pairSweep: true },
    { flySpanMeters: 1100 }, { repetitions: 1 }, { sampleSeconds: 10 },
  ];
  for (const change of invalid) {
    assert.equal(releaseEvidenceContractPass({ ...valid, ...change }), false,
      JSON.stringify(change));
  }
});

const scenario = (family, active = [], extra = {}) => ({
  family,
  mode: 'static',
  captureApi: 'window.__cave9.visual.loadScenario+step+inspect',
  loadedSnapshot: {
    version: 'VisualSnapshotV1',
    scenario: { settings: { landmarks: family !== 'off' } },
    family: { requested: family, active },
  },
  ...extra,
});

test('forced family contract permits a corridor with no active room', () => {
  assert.equal(perfScenarioContractPass(scenario('crystal')), true);
  assert.equal(perfScenarioContractPass(scenario('crystal', ['crystal'])), true);
});

test('forced family contract rejects a different or ambiguous active family', () => {
  assert.equal(perfScenarioContractPass(scenario('crystal', ['branching'])), false);
  assert.equal(perfScenarioContractPass(scenario('crystal', ['crystal', 'crystal'])), false);
});

test('off and flythrough retain their strict state and target checks', () => {
  assert.equal(perfScenarioContractPass(scenario('off')), true);
  assert.equal(perfScenarioContractPass(scenario('off', ['crystal'])), false);
  assert.equal(perfScenarioContractPass(scenario('coiling', [], {
    mode: 'flythrough', flyTo: 600, endDistance: 600,
  })), true);
  assert.equal(perfScenarioContractPass(scenario('coiling', [], {
    mode: 'flythrough', flyTo: 600, endDistance: 599.9,
  })), false);
});

test('Coiling rim policy distinguishes a forced request from visible C3 rings', () => {
  const withCapabilities = (active, coilingRimActive) => scenario('coiling', active, {
    loadedSnapshot: {
      version: 'VisualSnapshotV1',
      scenario: { settings: { landmarks: true } },
      family: { requested: 'coiling', active },
      renderCapabilities: { coilingRimActive, coilingRimSoftwareFallback: false },
    },
  });
  assert.equal(coilingRimPolicyPass(withCapabilities([], true), false), true,
    'hardware keeps the already-compiled constant-cost branch warm');
  assert.equal(coilingRimPolicyPass(withCapabilities([], false), true), true,
    'software corridors omit a requested-but-invisible C3 branch');
  assert.equal(coilingRimPolicyPass(withCapabilities(['coiling'], true), true), true,
    'software enables the branch when real C3 rings enter the live window');
  assert.equal(coilingRimPolicyPass(withCapabilities([], true), true), false,
    'a request alone must not masquerade as visible software C3 work');
});

test('texture budgets include shader-uniform maps listed by resource snapshots', () => {
  assert.deepEqual(textureBudgetMetrics([
    {
      estimatedTextureBytes: 1024,
      textures: [{ width: 256, height: 128 }],
    },
    {
      estimatedTextureBytes: 5_592_400,
      textures: [
        { name: 'caveReliefNormal', width: 512, height: 512 },
        { name: 'caveReliefHeight', width: 512, height: 512 },
      ],
    },
  ]), {
    maxTextureDimension: 512,
    maxEstimatedTextureBytes: 5_592_400,
  });
  assert.deepEqual(textureBudgetMetrics(), {
    maxTextureDimension: 0,
    maxEstimatedTextureBytes: 0,
  });
});

test('texture storage includes every array layer and mip with the uploaded channel format', () => {
  const array = { width: 128, height: 128, layers: 53, format: 1023,
    type: 1009, generateMipmaps: true };
  const normal = { width: 512, height: 512, layers: 1, format: 1023,
    type: 1009, generateMipmaps: true };
  const height = { ...normal, format: 1028 };
  assert.equal(textureStorageBytes(array), 4_631_140);
  assert.equal(textureStorageBytes(normal), 1_398_100);
  assert.equal(textureStorageBytes(height), 349_525);
  assert.equal(textureStorageBytes({ ...height, generateMipmaps: false }), 262_144);
  assert.equal(textureStorageBytes({ ...height, width: 1, height: 1 }), 1);
  const snapshot = withTextureStorageEstimate({ textures: [array, normal, height] });
  assert.equal(snapshot.estimatedTextureBytes, 6_378_765);
  assert.equal(textureBudgetMetrics([snapshot]).maxEstimatedTextureBytes, 6_378_765);
});
