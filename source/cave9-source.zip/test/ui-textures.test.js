import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import test from 'node:test';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const BOUND_TEXTURES = [
  'panel.png',
  'button-neutral.png',
  'button-hover.png',
  'button-primary.png',
  'button-disabled.png',
  'button-danger.png',
  'toggle-off.png',
  'toggle-on.png',
  'slider-rail.png',
  'slider-hinge.png',
  'slider-lever.png',
  'divider.png',
  'crash-plate.png',
  'success-badge.png',
  'success-medallion.png',
];

test('menu CSS binds every texture and keeps a keyboard focus treatment', () => {
  const css = fs.readFileSync(path.join(ROOT, 'src', 'ui', 'styles.css'), 'utf8');
  for (const name of BOUND_TEXTURES) assert.match(css, new RegExp(name.replace('.', '\\.')));
  assert.match(css, /:focus-visible/);
  assert.match(
    css,
    /background-image:\s*var\(--ui-slider-lever\),\s*var\(--ui-slider-hinge\)/,
  );
});

test('visible credits describe cave9 as inspiration rather than a remake', () => {
  const menu = fs.readFileSync(path.join(ROOT, 'src', 'ui', 'MenuSystem.js'), 'utf8');
  assert.match(menu, /inspired by the classic/);
  assert.doesNotMatch(menu, /This remake|web &amp; mobile remake/);
});
