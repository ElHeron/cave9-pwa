import { test } from 'node:test';
import assert from 'node:assert/strict';
import { PUBLIC_GAME_URL, shareBaseUrl, sourceDownloadUrl } from '../src/platform/NativeApp.js';
import { bindNativeApp, handleAndroidBack, pauseNativeApp } from '../src/app/NativeLifecycle.js';
import { AppState } from '../src/app/AppState.js';
import packageInfo from '../package.json' with { type: 'json' };

function appDouble(state, panel = 'menu') {
  const calls = [];
  return {
    state, calls, menu: { current: panel },
    togglePause() { calls.push('pause'); this.state = AppState.PAUSED; },
    demoToMenu() { calls.push('demo-menu'); this.state = AppState.MENU; },
    toMenu() { calls.push('menu'); this.state = AppState.MENU; },
    audio: { stopLoops() { calls.push('stop-audio'); }, ctx: { async suspend() { calls.push('suspend-audio'); } } },
  };
}

test('Android Back pauses a flight, dismisses submenus and exits only from the main menu', async () => {
  for (const [state, panel, expected] of [
    [AppState.RUNNING, null, 'pause'], [AppState.DEMO, null, 'demo-menu'],
    [AppState.PAUSED, 'pause', 'menu'], [AppState.DEAD, 'death', 'menu'],
    [AppState.MENU, 'settings', 'menu'], [AppState.MENU, 'seed', 'menu'], [AppState.MENU, 'menu', 'exit'],
  ]) {
    const app = appDouble(state, panel);
    await handleAndroidBack(app, async () => app.calls.push('exit'));
    assert.deepEqual(app.calls, [expected]);
  }
});

test('backgrounding pauses active play and suspends audio without resuming an already paused run', () => {
  const running = appDouble(AppState.RUNNING);
  pauseNativeApp(running);
  assert.equal(running.state, AppState.PAUSED);
  assert.deepEqual(running.calls, ['pause', 'stop-audio', 'suspend-audio']);
  const paused = appDouble(AppState.PAUSED);
  paused.audio.ctx = null;
  pauseNativeApp(paused);
  assert.deepEqual(paused.calls, ['stop-audio']);
});

test('native listeners invoke lifecycle behavior while the web app does not register them', async () => {
  const listeners = new Map();
  const app = appDouble(AppState.RUNNING);
  const api = { async addListener(name, callback) { listeners.set(name, callback); return { remove() {} }; }, async exitApp() { app.calls.push('exit'); } };
  assert.deepEqual(await bindNativeApp(app, { native: false, api }), []);
  assert.equal(listeners.size, 0);
  assert.equal((await bindNativeApp(app, { native: true, api })).length, 2);
  listeners.get('pause')();
  assert.equal(app.state, AppState.PAUSED);
  listeners.get('backButton')();
  assert.equal(app.state, AppState.MENU);
  listeners.get('backButton')();
  assert.equal(app.calls.at(-1), 'exit');
});

test('Android shares playable public URLs and offers the matching Android source download', () => {
  assert.equal(shareBaseUrl('https://localhost/', true), PUBLIC_GAME_URL);
  assert.equal(shareBaseUrl('https://example.com/game/', false), 'https://example.com/game/');
  const version = packageInfo.version;
  assert.equal(sourceDownloadUrl(true), `https://github.com/ElHeron/cave9-pwa/releases/download/android-v${version}/cave9-${version}-source.zip`);
  assert.equal(sourceDownloadUrl(false), './source/cave9-source.zip');
});
