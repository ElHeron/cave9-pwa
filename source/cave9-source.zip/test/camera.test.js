// Camera behaviour. Run with: npm test
// THREE's PerspectiveCamera is pure JS (no WebGL), so the FOV setting, the
// player-relative placement and reduced-motion (motion === 0) are all testable
// headlessly.
import { test } from 'node:test';
import assert from 'node:assert/strict';

import * as THREE from 'three';
import { CameraController } from '../src/render/CameraController.js';

function makeShip() {
  return {
    pos: [3, 4, 100],
    vel: [0, 0, 30],
    lookAt: [0, 0, 30],
    roll: 0,
    lefton: false, righton: false,
    radius: 1,
    repulsion: [0, 1, 0],
  };
}

test('setFov updates the camera FOV', () => {
  const cam = new THREE.PerspectiveCamera(45, 1, 0.1, 100);
  const ctl = new CameraController(cam);
  ctl.setFov(67);
  assert.equal(cam.fov, 67);
});

test('camera stays at the player (no shake at motion 0)', () => {
  const cam = new THREE.PerspectiveCamera(50, 1, 0.05, 200);
  const ctl = new CameraController(cam);
  ctl.motion = 0; // reduced motion -> no shake, no bob
  const ship = makeShip();
  ctl.update(ship, 0);
  assert.ok(Math.abs(cam.position.x - ship.pos[0]) < 1e-9);
  assert.ok(Math.abs(cam.position.y - ship.pos[1]) < 1e-9);
  assert.ok(Math.abs(cam.position.z - ship.pos[2]) < 1e-9);
});

test('reduced motion (0) yields a deterministic, shake-free frame', () => {
  const cam = new THREE.PerspectiveCamera(50, 1, 0.05, 200);
  const ctl = new CameraController(cam);
  ctl.motion = 0;
  const ship = makeShip();
  ctl.update(ship, 1); // even with a full "hit", motion 0 must not displace
  const p1 = cam.position.clone();
  ctl.update(ship, 1);
  const p2 = cam.position.clone();
  assert.ok(p1.equals(p2), 'positions must be identical across frames at motion 0');
});

test('bobOffset is exactly 0 when motion is 0, non-zero otherwise', () => {
  const cam = new THREE.PerspectiveCamera(50, 1, 0.05, 200);
  const ctl = new CameraController(cam);
  const ship = makeShip();
  ctl.motion = 0;
  assert.equal(ctl.bobOffset(ship), 0);
  ctl.motion = 1;
  ctl._t = Math.PI / 16; // a phase where sin(8t) != 0
  assert.notEqual(ctl.bobOffset(ship), 0);
});
