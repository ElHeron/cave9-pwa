import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

import {
  FAMILY_FORM_APPROACHES,
  FAMILY_FORM_BASELINE_APPROACH_DEPTHS,
  FAMILY_FORM_FIXED_DEPTHS,
  FAMILY_FORM_ORBITS,
  familyFormFramingCheck,
  familyFormHeroDifferenceCheck,
  familyFormSuiteDefinition,
  familyFormTemplates,
  resolvedFamilyOffControlScenario,
  resolvedFamilyScenario,
} from '../scripts/visual/family-form-config.mjs';
import { exactFamilyFormMatrix, familyFormAuthorityChecks } from '../scripts/visual/family-form-verification.mjs';
import { buildFamilyFormReport, familyFormReportHtml } from '../scripts/visual/family-form-report.mjs';

const resolution = {
  family: 'crystal', seed: 2024, compositionCount: 1, compositionRoom: 2,
  roomKey: '2024:2:crystal', meshCount: 1, pieceCount: 36,
  bankGroups: [0, 1, 2].map((bank) => ({ bank, pieceCount: 12,
    firstGid: bank * 12, lastGid: bank * 12 + 11 })),
  surfaceRevision: 'surface-a', surfaceRevisions: ['surface-a'],
  visibleGeometryBounds: { frontDepth: 9040.5, reviewFrontDepth: 9052.5,
    reviewFrontQuantile: 0.2, backDepth: 9200, vertexCount: 288 },
};

test('family-form suite is separate and contains the exact supported review matrix', () => {
  const suite = familyFormSuiteDefinition(['crystal']);
  assert.equal(suite.name, 'family-form-review');
  assert.deepEqual(suite.approaches, [100, 70, 45, 25]);
  assert.deepEqual(suite.orbitDegrees, [0, 60, 120, 180, 240, 300]);
  assert.equal(suite.templates.length, 41);
  assert.deepEqual(suite.fixedDepths, FAMILY_FORM_FIXED_DEPTHS);
  assert.deepEqual(suite.templates.filter((entry) => entry.kind === 'hero').map((entry) => entry.approachMeters),
    FAMILY_FORM_APPROACHES);
  assert.deepEqual(suite.templates.filter((entry) => entry.kind === 'orbit').map((entry) => entry.orbitDegrees),
    FAMILY_FORM_ORBITS);
  for (const key of ['orthoFront', 'orthoSide', 'orthoTop', 'neutralFamilyMaterial', 'silhouetteFamilyMaterial']) {
    assert.equal(suite.capabilities[key].supported, true);
    assert.ok(suite.capabilities[key].authority);
  }
  assert.equal(suite.capabilities.coilingShellReview.supported, true);
  assert.equal(suite.templates.filter((entry) => entry.kind === 'orbit-complete').length, 6);
  assert.equal(suite.templates.filter((entry) => entry.kind === 'orbit-detail-clay').length, 2);
  assert.equal(suite.templates.filter((entry) => entry.kind === 'clay-hero').length, 4);
  assert.deepEqual(suite.baselineApproachDepths.crystal,
    [...FAMILY_FORM_BASELINE_APPROACH_DEPTHS.crystal]);
});

test('family-only framing rejects tiny or clipped evidence and accepts a useful inset form', () => {
  const good = { foreground: { fraction: 0.08, bbox: {
    widthFraction: 0.5, heightFraction: 0.3, touchesEdge: false,
  } } };
  assert.equal(familyFormFramingCheck('orbit', good).pass, true);
  assert.equal(familyFormFramingCheck('ortho-side', good).pass, true);
  assert.equal(familyFormFramingCheck('hero', {}).pass, true);
  assert.equal(familyFormFramingCheck('orbit', { foreground: { fraction: 0.001,
    bbox: { widthFraction: 0.5, heightFraction: 0.3, touchesEdge: false } } }).pass, false);
  assert.equal(familyFormFramingCheck('orbit', { foreground: { fraction: 0.0019,
    bbox: { widthFraction: 0.4, heightFraction: 0.2, touchesEdge: false } } }).pass, false,
  'a wide bounding box made from a few thin lines is not useful orbit evidence');
  assert.equal(familyFormFramingCheck('ortho-side', { foreground: { fraction: 0.002,
    bbox: { widthFraction: 0.5, heightFraction: 0.3, touchesEdge: false } } }).pass, true,
  'edge-on orthographic topology has a lower content floor than Orbit');
  assert.equal(familyFormFramingCheck('ortho-top', { foreground: { fraction: 0.08,
    bbox: { widthFraction: 0.5, heightFraction: 0.3, touchesEdge: true } } }).pass, false);
});

test('Hero depth is resolved from the first 20% of actual visible vertex mass', () => {
  const template = familyFormTemplates('crystal').find((entry) => entry.approachMeters === 70);
  const scenario = resolvedFamilyScenario(template, { family: 'crystal', seed: 2024 }, resolution);
  assert.equal(scenario.distance, 8982.5);
  assert.equal(scenario.resolvedFrontDepth - scenario.distance, 70);
  assert.equal(scenario.absoluteFrontDepth, 9040.5);
  assert.equal(scenario.captureOptions.distance, scenario.distance);
  assert.equal(scenario.captureOptions.family, 'crystal');
  assert.equal(scenario.captureOptions.placement, 'place');
  assert.throws(() => resolvedFamilyScenario(template, { family: 'crystal', seed: 2024 }, {}),
    /visible family front depth is missing/);
  const control = resolvedFamilyOffControlScenario(scenario);
  assert.equal(control.family, 'off');
  assert.equal(control.captureOptions.family, 'off');
  assert.equal(control.captureOptions.distance, scenario.captureOptions.distance);
  assert.deepEqual(control.captureOptions.viewport, scenario.captureOptions.viewport);
  assert.throws(() => resolvedFamilyOffControlScenario({ kind: 'orbit' }), /Hero scenario/);
});

test('fixed A/B depth remains independent of geometry-front changes', () => {
  const template = familyFormTemplates('crystal').find((entry) => entry.id === 'crystal-fixed-9070-clay');
  const first = resolvedFamilyScenario(template, { family: 'crystal', seed: 2024 }, resolution);
  const second = resolvedFamilyScenario(template, { family: 'crystal', seed: 2024 }, {
    ...resolution, visibleGeometryBounds: { ...resolution.visibleGeometryBounds,
      frontDepth: 9010, reviewFrontDepth: 9025 },
  });
  assert.equal(first.distance, 9070);
  assert.equal(second.distance, 9070);
  assert.equal(first.captureOptions.renderPass, 'clay');
  assert.equal(first.captureOptions.settings.fov, 45);
  const baseline = familyFormTemplates('crystal').find((entry) => entry.id === 'crystal-baseline-a70-beauty');
  assert.equal(resolvedFamilyScenario(baseline, { family: 'crystal', seed: 2024 }, resolution).distance,
    9014.190);
});

test('Hero difference gate rejects cave-only pairs and requires distributed family pixels', () => {
  const visible = {
    pass: true, fraction: 0.025, meanChangedDelta: 0.2,
    bbox: { widthFraction: 0.7, heightFraction: 0.6, touchesEdge: true },
    angularBinCount: 9, quadrantCount: 4, radialBinCount: 3,
  };
  assert.equal(familyFormHeroDifferenceCheck('branching', 70, visible).pass, true);
  assert.equal(familyFormHeroDifferenceCheck('crystal', 25, visible).pass, true);
  assert.equal(familyFormHeroDifferenceCheck('branching', 70,
    { ...visible, fraction: 0 }).pass, false);
  assert.equal(familyFormHeroDifferenceCheck('branching', 70,
    { ...visible, angularBinCount: 2 }).pass, false);
  assert.equal(familyFormHeroDifferenceCheck('branching', 70,
    { ...visible, quadrantCount: 1 }).pass, false);
  assert.equal(familyFormHeroDifferenceCheck('branching', 70,
    { ...visible, bbox: null }).pass, false);
  const onset = familyFormHeroDifferenceCheck('crystal', 100, {});
  assert.equal(onset.pass, true);
  assert.equal(onset.required, false);
  assert.equal(onset.diagnosticPass, false);
});

test('authority checks require real debug objects and one bound composition', () => {
  const template = familyFormTemplates('crystal').find((entry) => entry.kind === 'collision');
  const scenario = resolvedFamilyScenario(template, { family: 'crystal', seed: 2024 }, resolution);
  const frame = { family: 'crystal', debugGeometry: { collisionCapsules: 24, booleanTubeObjects: 0 },
    snapshot: { distance: scenario.distance,
      camera: { requested: 'hero', active: 'hero', supported: true },
      layers: { collisionCapsules: true, booleanTube: false } } };
  assert.equal(familyFormAuthorityChecks(frame, scenario, resolution).collisionLayer.pass, true);
  assert.equal(familyFormAuthorityChecks({ ...frame,
    debugGeometry: { ...frame.debugGeometry, collisionCapsules: 0 } }, scenario, resolution).collisionLayer.pass, false);
  assert.equal(familyFormAuthorityChecks(frame, scenario,
    { ...resolution, compositionCount: 2 }).geometryAuthority.pass, false);
  assert.equal(familyFormAuthorityChecks(frame, scenario,
    { ...resolution, surfaceRevisions: ['a', 'b'] }).geometryAuthority.pass, false);
  assert.equal(familyFormAuthorityChecks(frame, scenario,
    { ...resolution, roomKey: 'wrong' }).geometryAuthority.pass, false);

  const tubeTemplate = familyFormTemplates('crystal').find((entry) => entry.kind === 'boolean-tube');
  const tubeScenario = resolvedFamilyScenario(tubeTemplate, { family: 'crystal', seed: 2024 }, resolution);
  const tubeFrame = { ...frame, debugGeometry: { collisionCapsules: 0, booleanTubeObjects: 1 },
    snapshot: { ...frame.snapshot, layers: { collisionCapsules: false, booleanTube: true } } };
  assert.equal(familyFormAuthorityChecks(tubeFrame, tubeScenario, resolution).booleanTubeLayer.pass, true);
  assert.equal(familyFormAuthorityChecks({ ...tubeFrame,
    debugGeometry: { ...tubeFrame.debugGeometry, booleanTubeObjects: 0 } }, tubeScenario, resolution).booleanTubeLayer.pass, false);
});

test('authority checks bind orthographic axis and actual render-pass materials', () => {
  const orthoTemplate = familyFormTemplates('crystal').find((entry) => entry.kind === 'ortho-side');
  const orthoScenario = resolvedFamilyScenario(orthoTemplate, { family: 'crystal', seed: 2024 }, resolution);
  const orthoFrame = { family: 'crystal', debugGeometry: {},
    renderPassEvidence: { active: 'beauty', familyMeshCount: 1, matchedMaterialCount: 1,
      caveVisible: true, backgroundHex: null },
    snapshot: { distance: orthoScenario.distance,
      camera: { requested: 'orthographic', active: 'orthographic', supported: true,
        projection: 'orthographic', axis: 'side' },
      renderPass: { requested: 'beauty', active: 'beauty', supported: true }, layers: {} } };
  assert.equal(familyFormAuthorityChecks(orthoFrame, orthoScenario, resolution).cameraAuthority.pass, true);
  assert.equal(familyFormAuthorityChecks({ ...orthoFrame,
    snapshot: { ...orthoFrame.snapshot, camera: { ...orthoFrame.snapshot.camera, axis: 'top' } } },
  orthoScenario, resolution).cameraAuthority.pass, false);

  const silhouetteTemplate = familyFormTemplates('crystal').find((entry) => entry.kind === 'silhouette');
  const silhouetteScenario = resolvedFamilyScenario(silhouetteTemplate,
    { family: 'crystal', seed: 2024 }, resolution);
  const silhouetteFrame = { ...orthoFrame,
    renderPassEvidence: { active: 'silhouette', familyMeshCount: 1, matchedMaterialCount: 1,
      caveVisible: false, backgroundHex: 'ffffff' },
    snapshot: { ...orthoFrame.snapshot,
      camera: { requested: 'hero', active: 'hero', supported: true },
      renderPass: { requested: 'silhouette', active: 'silhouette', supported: true } } };
  assert.equal(familyFormAuthorityChecks(silhouetteFrame,
    silhouetteScenario, resolution).renderPassAuthority.pass, true);
  assert.equal(familyFormAuthorityChecks({ ...silhouetteFrame,
    renderPassEvidence: { ...silhouetteFrame.renderPassEvidence, caveVisible: true } },
  silhouetteScenario, resolution).renderPassAuthority.pass, false);
});

test('Crystal orbit authority distinguishes real bank detail from complete composition', () => {
  const template = familyFormTemplates('crystal').find((entry) => entry.kind === 'orbit');
  const scenario = resolvedFamilyScenario(template, { family: 'crystal', seed: 2024 }, resolution);
  const frame = { family: 'crystal', debugGeometry: {},
    snapshot: { distance: scenario.distance, layers: {},
      camera: { requested: 'orbit', active: 'orbit', supported: true,
        scope: 'detail-bank', isolation: 'landmark-only', pieceCount: 12,
        rig: 'crystal-oblique-v1', axialViewComponent: 0.39,
        pieceScope: { applied: true, meshCount: 1, pieceCount: 12, firstGid: 0, lastGid: 11 } } } };
  assert.equal(familyFormAuthorityChecks(frame, scenario, resolution).cameraAuthority.pass, true);
  const fullTemplate = familyFormTemplates('crystal').find((entry) => entry.kind === 'orbit-complete');
  const fullScenario = resolvedFamilyScenario(fullTemplate, { family: 'crystal', seed: 2024 }, resolution);
  const fullFrame = { ...frame, snapshot: { ...frame.snapshot, camera: {
    ...frame.snapshot.camera, scope: 'complete-composition', pieceCount: 36,
    pieceScope: { applied: false, meshCount: 0, pieceCount: 36 },
  } } };
  assert.equal(familyFormAuthorityChecks(fullFrame, fullScenario, resolution).cameraAuthority.pass, true);
  assert.equal(familyFormAuthorityChecks({ ...frame,
    snapshot: { ...frame.snapshot, camera: { ...frame.snapshot.camera,
      scope: 'complete-composition', pieceCount: 36 } } }, scenario, resolution).cameraAuthority.pass, false);
  assert.equal(familyFormAuthorityChecks({ ...frame,
    snapshot: { ...frame.snapshot, camera: { ...frame.snapshot.camera,
      pieceScope: { ...frame.snapshot.camera.pieceScope, applied: false } } } }, scenario, resolution)
  .cameraAuthority.pass, false);
  assert.equal(familyFormAuthorityChecks({ ...frame,
    snapshot: { ...frame.snapshot, camera: { ...frame.snapshot.camera,
      pieceScope: { ...frame.snapshot.camera.pieceScope, lastGid: 12 } } } }, scenario, resolution)
  .cameraAuthority.pass, false);
});

test('family-form exact matrix rejects legacy APIs and missing captures independently of form-release', () => {
  const suite = familyFormSuiteDefinition(['crystal']);
  const frames = suite.templates.map((template) => ({
    id: template.id, family: template.family, captureApi: suite.captureApi,
    snapshot: { version: 'VisualSnapshotV1' },
    ...(template.kind === 'hero' ? {
      control: { file: `frames/${template.id}-control-off.png`, snapshot: {
        version: 'VisualSnapshotV1', family: { requested: 'off', active: [] },
      } },
      difference: { file: `frames/${template.id}-family-diff.png` },
    } : {}),
  }));
  assert.equal(exactFamilyFormMatrix({ suite, frames }).pass, true);
  assert.equal(exactFamilyFormMatrix({ suite, frames: frames.slice(1) }).pass, false);
  assert.equal(exactFamilyFormMatrix({ suite, frames: frames.map((frame, index) => index
    ? frame : { ...frame, captureApi: 'window.__cave9.captureScenario' }) }).pass, false);
});

test('review report exposes bounds, clay capability, and original frame links', () => {
  const suite = familyFormSuiteDefinition(['crystal']);
  const manifest = {
    runId: 'family-review', suite, source: { git: {}, runtime: {} },
    resolutions: { crystal: resolution },
    blockedPasses: [{ pass: 'orthoSide', status: 'capability-blocked', reason: 'unsupported' }],
    frames: [{ id: 'crystal-hero-a70', family: 'crystal', kind: 'hero', file: 'frames/crystal.png',
      status: 'pass', requestedDepth: 8970.5, resolvedFrontDepth: 9040.5,
      resolvedApproachMeters: 70, snapshot: { distance: 8970.5, camera: { active: 'hero' }, layers: {} },
      runtimeErrors: [] }],
  };
  const report = buildFamilyFormReport(manifest);
  const html = familyFormReportHtml(report);
  assert.equal(report.manualStatus, 'pending');
  assert.match(html, /Capability truth/);
  assert.match(html, /litClayWallAndForm/);
  assert.match(html, /frames\/crystal\.png/);
  assert.match(html, /front 9040\.500 m/);
});

test('capture implementation fails closed on missing composition and contains no legacy call', async () => {
  const source = await readFile(new URL('../scripts/visual/capture-family-form.mjs', import.meta.url), 'utf8');
  assert.match(source, /expected exactly one active/);
  assert.match(source, /has missing or wrong active family/);
  assert.doesNotMatch(source, /__cave9\.captureScenario\s*\(/);
});
