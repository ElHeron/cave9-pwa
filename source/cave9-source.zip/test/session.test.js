// SessionRunner — the one place that says what a frame does.
//
// The three sessions (player run / attract demo / menu background) used to be
// three copies of the same 30 lines, and they had already drifted apart on their
// crash policy. These tests pin both the shared frame contract and the
// deliberately-different crash behaviours. Run with: npm test

import { test } from 'node:test';
import assert from 'node:assert/strict';
import { SessionRunner, CRASH_ENDS_FRAME, CRASH_CONTINUES_FRAME } from '../src/app/SessionRunner.js';
import { Game, DT } from '../src/core/Game.js';

// Collaborators that record the calls they receive, in order.
function spies() {
  const calls = [];
  const log = (name) => (...args) => calls.push([name, ...args]);
  return {
    calls,
    renderer: { speedFx: 0.4, setSight: log('setSight'), render: log('render'), renderIdle: log('renderIdle') },
    menu: { setSpeedFx: log('setSpeedFx') },
    audio: { thrust: log('thrust'), proximity: log('proximity') },
    debug: { update: log('debug.update') },
  };
}

const newSession = () => {
  const s = spies();
  return { ...s, session: new SessionRunner(s) };
};

const runningGame = (seed = 4096) => new Game().start({ mode: 2, seed });

// ---- simulate --------------------------------------------------------------

test('simulate: runs the whole steps owed and applies control each one', () => {
  const { session } = newSession();
  const game = runningGame();
  let controlled = 0;
  const crashed = session.simulate(game, DT * 3, () => { controlled++; }, () => CRASH_ENDS_FRAME);
  assert.equal(crashed, false);
  assert.equal(controlled, 3);
  assert.ok(Math.abs(game.time - DT * 3) < 1e-9);
});

test('simulate: reports a crash', () => {
  const { session } = newSession();
  const game = runningGame();
  // fly straight into a wall: full thrust up, every step, until it dies
  let crashed = false;
  for (let i = 0; i < 2000 && !crashed; i++) {
    crashed = session.simulate(game, DT, (g) => { g.player.lefton = g.player.righton = true; },
      () => CRASH_ENDS_FRAME);
  }
  assert.equal(crashed, true, 'holding both thrusters should eventually hit the ceiling');
  assert.equal(game.phase, 'dead');
});

test('simulate: CRASH_ENDS_FRAME stops the frame there', () => {
  const { session } = newSession();
  const game = runningGame();
  let steps = 0, crashes = 0;
  // a game that "crashes" on its second step
  const fake = { player: game.player, score: game.score, step: () => (++steps === 2) };
  session.simulate(fake, DT * 4, () => {}, () => { crashes++; return CRASH_ENDS_FRAME; });
  assert.equal(steps, 2, 'stopped at the crashing step');
  assert.equal(crashes, 1);
});

test('simulate: CRASH_CONTINUES_FRAME keeps spending the frame on the restart', () => {
  const { session } = newSession();
  let steps = 0, restarts = 0;
  const fake = { step: () => (++steps === 2) }; // crashes once, on step 2
  session.simulate(fake, DT * 4, () => {}, () => { restarts++; return CRASH_CONTINUES_FRAME; });
  assert.equal(steps, 4, 'the frame ran all four steps it was owed');
  assert.equal(restarts, 1);
});

test('simulate: the crashing step never consumes its time', () => {
  const { session } = newSession();
  let steps = 0;
  const fake = { step: () => (++steps === 1) }; // crashes immediately
  session.simulate(fake, DT * 3, () => {}, () => CRASH_ENDS_FRAME);
  assert.ok(Math.abs(session.ticker.accumulator - DT * 3) < 1e-12,
    'a frame that crashes on its first step spends none of its time');
});

// ---- present ---------------------------------------------------------------

test('present: runs the frame contract in order', () => {
  const { session, calls } = newSession();
  const game = runningGame();
  session.simulate(game, DT, () => {}, () => CRASH_ENDS_FRAME);
  session.present(game, 0);
  assert.deepEqual(calls.map((c) => c[0]),
    ['thrust', 'proximity', 'setSight', 'render', 'setSpeedFx', 'debug.update']);
});

test('present: flight UI receives only the speed vignette amount', () => {
  const { session, calls } = newSession();
  const game = runningGame();
  session.simulate(game, DT * 30, () => {}, () => CRASH_ENDS_FRAME);
  session.present(game, 0);
  const ui = calls.filter((c) => c[0] === 'setSpeedFx');
  assert.deepEqual(ui, [['setSpeedFx', 0.4]]);
  assert.equal(calls.some((c) => c[0] === 'updateHud'), false,
    'score/distance/warning are not presented during flight');
});

test('present: the renderer is handed the game and the hit factor', () => {
  const { session, calls } = newSession();
  const game = runningGame();
  session.simulate(game, DT * 10, () => {}, () => CRASH_ENDS_FRAME);
  session.present(game, 0.5);
  const render = calls.find((c) => c[0] === 'render');
  assert.equal(render[1], game);
  assert.equal(render[2], 0.5, 'the hit factor is passed through');
});

test('presentIdle: draws quietly — no flight UI, no audio, no debug', () => {
  const { session, calls } = newSession();
  const game = runningGame();
  session.presentIdle(game);
  assert.deepEqual(calls.map((c) => c[0]), ['renderIdle']);
});

test('presentHeld: redraws the frozen frame only', () => {
  const { session, calls } = newSession();
  const game = runningGame();
  session.presentHeld(game, 1);
  assert.deepEqual(calls.map((c) => c[0]), ['render']);
  assert.equal(calls[0][2], 1);
});

// ---- the warning level -----------------------------------------------------

test('trackWarn: remembers the frame state on the session, not on the game', () => {
  // The core Game stays plain simulation data; derived per-frame state belongs
  // to whoever owns the frame.
  const { session } = newSession();
  const game = runningGame();
  session.simulate(game, DT * 20, () => {}, () => CRASH_ENDS_FRAME);
  const warn = session.trackWarn(game);
  assert.equal(session.lastWarn, warn);
  assert.equal(game._warn, undefined, 'no private stash left on the core object');
  assert.equal(game._predict, undefined);
});

test('present: computes the warning once and gives every consumer the same one', () => {
  const { session, calls } = newSession();
  const game = runningGame();
  session.simulate(game, DT * 40, () => {}, () => CRASH_ENDS_FRAME);
  const warn = session.present(game, 0);

  const by = (n) => calls.find((c) => c[0] === n);
  assert.equal(by('proximity')[1], warn.final, 'audio level');
  assert.equal(by('proximity')[2], warn.pan, 'audio pan');
  assert.equal(by('render')[3], warn.final, 'scene warning tint');
  assert.equal(by('debug.update')[2], warn, 'the overlay gets the snapshot itself');
});

// ---- hit factor ------------------------------------------------------------

test('hitOf: a crash frame is always full shake', () => {
  const { session } = newSession();
  const game = runningGame();
  assert.equal(session.hitOf(game, true), 1);
});

test('hitOf: a normal frame reports wall proximity', () => {
  const { session } = newSession();
  const game = runningGame();
  session.simulate(game, DT * 10, () => {}, () => CRASH_ENDS_FRAME);
  const hit = session.hitOf(game, false);
  assert.ok(hit >= 0 && hit <= 1, `expected a 0..1 proximity, got ${hit}`);
});
