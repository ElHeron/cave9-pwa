import { test } from 'node:test';
import assert from 'node:assert/strict';
import { SECTOR_COUNT } from '../src/core/constants.js';
import { CaveStream } from '../src/core/CaveStream.js';
import { queryNearestSurface, bracketingRingIndices, closestTrianglePoint } from '../src/core/SurfaceQuery.js';

function tiltedCave() {
  const centers = [0, 2, 4, 6].map(z => [0, 0, z]);
  const frames = centers.map(c => ({ center: { x: 0, y: 0, z: c[2] },
    right: { x: 0.6, y: 0, z: -0.8 }, up: { x: 0, y: 1, z: 0 },
    tangent: { x: 0.8, y: 0, z: 0.6 } }));
  const segs = centers.map(c => Array.from({ length: SECTOR_COUNT }, (_, j) => {
    const angle = j * Math.PI * 2 / SECTOR_COUNT;
    return [6 * Math.cos(angle), 10 * Math.sin(angle), c[2] - 8 * Math.cos(angle)];
  }));
  return { centers, frames, segs, i: 0, count: 4 };
}

function sampleTriangle(cave, a, b, sector, weights = [0.29, 0.37, 0.34]) {
  const vertices = [cave.segs[a][sector], cave.segs[b][sector], cave.segs[a][(sector + 1) % SECTOR_COUNT]];
  return [0, 1, 2].map(axis => vertices.reduce((sum, vertex, i) => sum + weights[i] * vertex[axis], 0));
}

test('triangle projection preserves all seven regions with caller-owned scratch storage', () => {
  const a = [0, 0, 0], b = [4, 0, 0], c = [0, 3, 0];
  const cases = [
    [[-1, -1, 2], [0, 0, 0]],
    [[5, -1, 2], [4, 0, 0]],
    [[-1, 4, 2], [0, 3, 0]],
    [[2, -1, 2], [2, 0, 0]],
    [[-1, 1.5, 2], [0, 1.5, 0]],
    [[3.2, 2.4, 2], [2.336, 1.248, 0]],
    [[1, 1, 2], [1, 1, 0]],
  ];
  const scratch = {};
  const owned = [];
  for (const [point, expected] of cases) {
    const result = closestTrianglePoint(point, a, b, c);
    owned.push([result, { ...result }]);
    assert.strictEqual(closestTrianglePoint(point, a, b, c, scratch), scratch);
    assert.deepEqual(scratch, result);
    for (const [axis, field] of ['qx', 'qy', 'qz'].entries()) {
      assert.ok(Math.abs(result[field] - expected[axis]) < 1e-12);
    }
    assert.ok(Math.abs(result.distance - Math.hypot(...point.map((v, i) => v - expected[i]))) < 1e-12);
  }
  for (const [result, snapshot] of owned) assert.deepEqual(result, snapshot);
});

test('tilted visible triangles remain queryable outside their centre-z bracket', () => {
  const cave = tiltedCave();
  const point = sampleTriangle(cave, 2, 3, 0);
  assert.ok(point[2] < 0, 'the actual visible surface precedes all ring centres');
  assert.deepEqual(bracketingRingIndices(cave, point[2]), [0, 0], 'old centre-only lookup misses this strip');
  const wall = queryNearestSurface(cave, point, 0).wall;
  assert.ok(wall.surfaceDistance < 1e-10, `visible contact was ${wall.surfaceDistance} m away`);
  for (let pair = 0; pair < 3; pair++) for (let sector = 0; sector < SECTOR_COUNT; sector++) {
    const p = sampleTriangle(cave, pair, pair + 1, sector);
    assert.ok(queryNearestSurface(cave, p, 0).wall.surfaceDistance < 1e-9,
      `missing visible contact at pair ${pair}, sector ${sector}`);
  }
});

test('a ship sphere touching a tilted neighbour uses the same submitted surface', () => {
  const cave = tiltedCave();
  const surface = sampleTriangle(cave, 2, 3, 0);
  const point = [surface[0] + 0.2, surface[1], surface[2]];
  let brute = Infinity;
  for (let a = 0; a < 3; a++) for (let j = 0; j < SECTOR_COUNT; j++) {
    const k = (j + 1) % SECTOR_COUNT;
    brute = Math.min(brute,
      closestTrianglePoint(point, cave.segs[a][j], cave.segs[a + 1][j], cave.segs[a][k]).distance,
      closestTrianglePoint(point, cave.segs[a][k], cave.segs[a + 1][j], cave.segs[a + 1][k]).distance);
  }
  const wall = queryNearestSurface(cave, point, 0.3).wall;
  assert.ok(Math.abs(wall.surfaceDistance - brute) < 1e-10);
  assert.ok(wall.hullClearance < 0, 'the touching ship cannot miss the real triangle');
});

test('cached production bounds follow ring reuse, reset and capacity growth', () => {
  const cave = new CaveStream();
  const verify = () => {
    const head = cave.count < cave.segs.length ? 0 : cave.i;
    for (const offset of [3, 12, 40]) {
      const a = (head + offset) % cave.segs.length, b = (a + 1) % cave.segs.length;
      const point = sampleTriangle(cave, a, b, 5);
      assert.ok(queryNearestSurface(cave, point, 0).wall.surfaceDistance < 1e-8);
    }
  };
  cave.reset(2024); cave.prime(); verify();
  cave.generateThrough(cave._lastRingDepth + 22); verify();
  cave.ensureCapacityForDistance(400); cave.fill(); verify();
  cave.reset(4096); cave.prime(); verify();
});

test('synthetic surfaces can be edited without a production generation counter', () => {
  const cave = tiltedCave();
  queryNearestSurface(cave, sampleTriangle(cave, 2, 3, 0));
  for (const ring of cave.segs) for (const vertex of ring) vertex[2] -= 30;
  const point = sampleTriangle(cave, 2, 3, 0);
  assert.ok(queryNearestSurface(cave, point, 0).wall.surfaceDistance < 1e-9);
});
