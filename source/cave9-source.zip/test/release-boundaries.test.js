// Executable checks for release edges that previously lived only in prose.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { existsSync, readFileSync, readdirSync } from 'node:fs';
import { resolve, relative } from 'node:path';
import { PNG } from 'pngjs';

import { SURFACE_RELIEF_REQUESTED_DEFAULT } from '../src/render/Renderer.js';

const PUBLIC = resolve('public');

function filesBelow(dir) {
  return readdirSync(dir, { withFileTypes: true }).flatMap((entry) => {
    const file = resolve(dir, entry.name);
    return entry.isDirectory() ? filesBelow(file) : [file];
  });
}

test('public assets are referenced by production or explicitly justified', () => {
  const productionText = [
    resolve('index.html'),
    ...filesBelow(resolve('src')).filter((file) => /\.(?:js|mjs|css)$/i.test(file)),
    ...filesBelow(PUBLIC).filter((file) => /\.(?:json|webmanifest|html|css)$/i.test(file)),
  ].map((file) => readFileSync(file, 'utf8')).join('\n');
  const allowlist = new Map([
    ['assets/hud.ttf', 'licensed original font retained for the documented HUD-font follow-up'],
  ]);
  const unaccounted = [];
  for (const file of filesBelow(PUBLIC)) {
    const rel = relative(PUBLIC, file).replace(/\\/g, '/');
    const basename = rel.split('/').at(-1);
    const referenced = productionText.includes(rel) || productionText.includes(`./${rel}`)
      || productionText.includes(`'${basename}'`) || productionText.includes(`"${basename}"`);
    const reason = allowlist.get(rel);
    if (!referenced && !reason) unaccounted.push(rel);
    if (reason) assert.ok(reason.length >= 20, `${rel} needs a meaningful allowlist reason`);
  }
  assert.deepEqual(unaccounted, [], 'public/ contains unreferenced shipped bytes');
  assert.ok(!productionText.includes('assets/wall.jpg'));
  assert.ok(!productionText.includes('assets/wall-normal.png'));
});

test('documentation states the same hardware relief default as code', () => {
  assert.equal(SURFACE_RELIEF_REQUESTED_DEFAULT, true);
  const docs = [readFileSync(resolve('ARCHITECTURE.md'), 'utf8'),
    readFileSync(resolve('RELEASE_CHECKLIST.md'), 'utf8')].join('\n');
  assert.match(docs, /Hardware gameplay enables `surfaceRelief` by default/);
  assert.doesNotMatch(docs, /default-off `surfaceRelief`|surfaceRelief[^\n]*default-off/i);
});

test('install manifest retains the PNG fallback and supplies maskable scalable icons', () => {
  const manifest = JSON.parse(readFileSync(resolve(PUBLIC, 'manifest.webmanifest'), 'utf8'));
  assert.equal(manifest.orientation, 'landscape');
  const bySource = new Map(manifest.icons.map((icon) => [icon.src, icon]));
  assert.deepEqual(bySource.get('./assets/icon.png'), {
    src: './assets/icon.png', sizes: '64x64', type: 'image/png', purpose: 'any',
  });
  assert.deepEqual(bySource.get('./assets/icon.svg'), {
    src: './assets/icon.svg', sizes: 'any', type: 'image/svg+xml', purpose: 'any maskable',
  });
  for (const size of [192, 512]) {
    const icon = bySource.get(`./assets/icon-${size}.png`);
    assert.equal(icon?.sizes, `${size}x${size}`);
    assert.equal(icon?.type, 'image/png');
    assert.equal(icon?.purpose, 'any maskable');
    const image = PNG.sync.read(readFileSync(resolve(PUBLIC, `assets/icon-${size}.png`)));
    assert.deepEqual([image.width, image.height], [size, size]);
  }
  const svgPath = resolve(PUBLIC, 'assets/icon.svg');
  assert.ok(existsSync(svgPath));
  assert.match(readFileSync(svgPath, 'utf8'), /viewBox="0 0 512 512"/);
});
