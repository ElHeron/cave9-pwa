import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

import {
  buildHeroExperiment,
  measureHeroComposition,
  minimumTubeMargin,
} from '../scripts/prototypes/hero-composition-core.mjs';

function pointSegmentDistance(point, a, b) {
  const dx = b.x - a.x, dy = b.y - a.y, dz = b.z - a.z;
  const length2 = dx * dx + dy * dy + dz * dz || 1;
  const t = Math.max(0, Math.min(1,
    ((point.x - a.x) * dx + (point.y - a.y) * dy + (point.z - a.z) * dz) / length2));
  return Math.hypot(point.x - (a.x + dx * t), point.y - (a.y + dy * t), point.z - (a.z + dz * t));
}

test('hero composition prototype stays isolated from renderer and browser dependencies', async () => {
  const source = await readFile(new URL('../scripts/prototypes/hero-composition-core.mjs', import.meta.url), 'utf8');
  assert.doesNotMatch(source, /from\s+['"](?:three|canvas|playwright|puppeteer)/i);
  assert.doesNotMatch(source, /src[\\/]render|src[\\/]core/i);
});

test('hero candidates are deterministic and improve the eight screen-space gates', () => {
  const first = buildHeroExperiment();
  const second = buildHeroExperiment();
  assert.deepEqual(
    first.map((entry) => entry.candidate.metrics),
    second.map((entry) => entry.candidate.metrics),
  );

  for (const experiment of first) {
    assert.ok(experiment.candidate.target.passed >= experiment.baseline.target.passed,
      `${experiment.family}: ${experiment.baseline.target.passed} -> ${experiment.candidate.target.passed}`);
    assert.ok(experiment.candidate.target.passed >= 7,
      `${experiment.family}: ${JSON.stringify(experiment.candidate.target.gates)}`);
  }
});

test('all visible candidate geometry has matching collision authority and tube reserve', () => {
  for (const experiment of buildHeroExperiment()) {
    const { result, context } = experiment;
    assert.ok(result.pieces.length > 0);
    assert.ok(result.collisionCapsules.length > 0);
    assert.equal(result.pieces.every((piece) => piece.kind === 'capsule' || piece.collisionCapsule), true);
    assert.ok(minimumTubeMargin(result, context) >= 0.15,
      `${result.variant}: ${minimumTubeMargin(result, context)} m`);
    if (result.family === 'blades') {
      assert.equal(result.pieces.length, 24, 'one authoritative plate per spoke, eight per bank');
      assert.equal(new Set(result.pieces.map((piece) => piece.depthBand)).size, 3);
      for (const piece of result.pieces) for (const vertex of piece.vertices) {
        assert.ok(pointSegmentDistance(vertex, piece.collisionCapsule.a, piece.collisionCapsule.b)
          <= piece.collisionCapsule.radius + 1e-9,
        `${piece.id}: visible vertex escaped its authoritative capsule`);
      }
    }
  }
});

test('composition metrics expose the intended central aperture and radial structure', () => {
  for (const { result } of buildHeroExperiment()) {
    const metrics = measureHeroComposition(result);
    const clearanceFloor = { roots: 0.04, blades: 0.055, ribs: 0.03 }[result.family];
    const centreDiskFloor = { roots: 0.58, blades: 0.70, ribs: 0.45 }[result.family];
    assert.ok(metrics.H2_centreClearance >= clearanceFloor, `${result.variant}: centre clearance`);
    assert.ok(metrics.H3_centreDiskFree >= centreDiskFloor, `${result.variant}: centre disk`);
    assert.ok(metrics.H4_radialCoverage >= 0.75, `${result.variant}: radial coverage`);
    assert.ok(metrics.H7_quadrantBalance >= 0.42, `${result.variant}: quadrant balance`);
  }
});
