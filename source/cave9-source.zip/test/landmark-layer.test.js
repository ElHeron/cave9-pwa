// LandmarkLayer GPU-cache contract. Core compositions may change while the far
// half of a long room enters the circular cave buffer; a changed surface
// revision must replace, not coexist with, the previously rendered mesh.

import { test } from 'node:test';
import assert from 'node:assert/strict';
import * as THREE from 'three';
import { Game } from '../src/core/Game.js';
import { compositionAt, roomZ } from '../src/core/Landmarks.js';
import { placeAt } from '../src/app/CaptureHarness.js';
import { LandmarkSurfaceProjector } from '../src/render/landmarks/surfaceProjection.js';

import {
  LandmarkLayer, MAX_CACHED_ROOMS, MAX_CACHED_GEOMETRY_BYTES, compositionFrontDepth,
  geometryByteLength,
} from '../src/render/landmarks/LandmarkLayer.js';

function composition(surfaceRevision) {
  return { k: 2, z: 0, typeName: 'branching', surfaceRevision, pieces: [] };
}

test('shared landmark materials preserve a restrained but measurable visibility floor', () => {
  const layer = new LandmarkLayer(new THREE.Scene());
  assert.equal(layer.rockMat.emissive.getHex(), 0x07090c);
  assert.equal(layer.crystalMat.emissive.getHex(), 0x07090d);
  assert.equal(layer.crystalMat.map, null, 'crystal visibility must not add a texture sampler');
  layer.emberMask.dispose();
  layer.rockMat.dispose();
  layer.crystalMat.dispose();
});

test('hardware landmark meshes carry bounded route-local surface coordinates', () => {
  for (const family of ['branching', 'crystal']) {
    const game = new Game();
    game.start({ mode: 2, seed: 2024, family });
    placeAt(game, 9010);
    const comp = game.landmarkCache.compositionAt(2024, game.cave, 9, family);
    const layer = new LandmarkLayer(new THREE.Scene());
    const projector = new LandmarkSurfaceProjector(2024, 9);
    const group = layer._buildGroup(comp, projector);
    const geometry = group.children[0].geometry;
    const position = geometry.attributes.position;
    const local = geometry.attributes.landmarkSurfaceLocal;
    const familyAttribute = geometry.attributes.landmarkSurfaceFamily;
    assert.equal(local.itemSize, 4);
    assert.equal(local.count, position.count);
    assert.equal(familyAttribute.count, position.count);
    assert.ok(geometryByteLength(geometry) < MAX_CACHED_GEOMETRY_BYTES / 4,
      `${family} must fit within the four-room retained geometry budget`);
    for (const i of [0, Math.floor(position.count / 2), position.count - 1]) {
      const point = { x: position.getX(i), y: position.getY(i), z: position.getZ(i) };
      const expected = projector.project(point, local.getW(i));
      assert.ok(Math.abs(local.getX(i) - expected.axialDepth) < 0.001);
      assert.ok(Math.abs(local.getY(i) - expected.localRight) < 0.0001);
      assert.ok(Math.abs(local.getZ(i) - expected.localUp) < 0.0001);
      assert.equal(familyAttribute.getX(i), family === 'crystal' ? 1 : 0);
    }
    for (const child of group.children) child.geometry.dispose();
    projector.dispose();
    layer.dispose();
  }
});

test('composition front is derived from authoritative capsule reach', () => {
  assert.equal(compositionFrontDepth({ z: 100, pieces: [] }), 100);
  assert.equal(compositionFrontDepth({ z: 100, pieces: [
    { cz: 120, dz: 0.8, length: 20, radius: 3 },
    { cz: 90, dz: 0.2, length: 10, radius: 2 },
  ] }), 87);
});

test('a new core surface revision rebuilds and disposes the old room mesh', () => {
  const scene = new THREE.Scene();
  const layer = new LandmarkLayer(scene);
  let current = composition('surface-a');
  let builds = 0, disposals = 0;

  layer._buildGroup = () => {
    builds++;
    const group = new THREE.Group();
    const geometry = new THREE.BufferGeometry();
    geometry.dispose = () => { disposals++; };
    group.add(new THREE.Mesh(geometry));
    return group;
  };
  const cache = { landmarksInView: () => [current] };

  layer.update({}, 0, 128, 4096, cache);
  layer.update({}, 0, 128, 4096, cache);
  assert.equal(builds, 1, 'an unchanged revision reuses its mesh');
  assert.equal(disposals, 0);
  assert.equal(layer.built.size, 1);

  current = composition('surface-b');
  layer.update({}, 0, 128, 4096, cache);
  assert.equal(builds, 2, 'the changed visible surface is rebuilt');
  assert.equal(disposals, 1, 'the superseded GPU geometry is disposed immediately');
  assert.equal(layer.built.size, 1, 'revisions never accumulate as cache growth');
  assert.ok([...layer.built.keys()][0].endsWith(':surface-b'));

  layer.emberMask.dispose();
  layer.rockMat.dispose();
  layer.crystalMat.dispose();
});

test('generated landmark grain is used directly without a runtime canvas downscale', () => {
  const scene = new THREE.Scene();
  const layer = new LandmarkLayer(scene);
  const grain = new THREE.Texture();

  layer.applyTextures({ grainTex: grain, anisotropy: 9 });

  assert.equal(layer.rockMat.map, grain);
  assert.equal(grain.wrapS, THREE.MirroredRepeatWrapping);
  assert.equal(grain.wrapT, THREE.MirroredRepeatWrapping);
  assert.equal(grain.colorSpace, THREE.SRGBColorSpace);
  assert.equal(grain.anisotropy, 4);
  assert.deepEqual(grain.repeat.toArray(), [2.4, 2.4]);
  assert.equal(layer.crystalMat.map, null, 'crystal stays sampler-free');
  assert.equal(layer.crystalMat.emberMask, undefined, 'crystal has no hidden custom-uniform texture');
  assert.equal(layer.rockMat.normalMap, null, 'no extra normal-map sample');

  layer.applyTextures({ grainTex: grain, anisotropy: 9 });
  assert.equal(layer.resourceMetrics().textureApplications, 1,
    'the session texture is configured only once');
  assert.equal(layer.resourceMetrics().textureReuses, 1,
    'a repeated application is a measured warm reuse');

  grain.dispose();
  layer.emberMask.dispose();
  layer.rockMat.dispose();
  layer.crystalMat.dispose();
});

test('software renderer keeps lit landmark geometry but skips mineral and texture work', () => {
  const scene = new THREE.Scene();
  const layer = new LandmarkLayer(scene, { softwareRenderer: true });
  const grain = new THREE.Texture();

  layer.applyTextures({ grainTex: grain, anisotropy: 4 });

  assert.equal(layer.softwareRenderer, true);
  assert.equal(layer.rockMat.isMeshLambertMaterial, true,
    'fallback retains lighting and the authoritative mesh presentation without PBR cost');
  assert.equal(layer.crystalMat.isMeshLambertMaterial, true);
  assert.equal(layer.rockMat.map, null, 'software fallback removes the grain sample');
  assert.equal(layer.emberMask, null, 'software fallback does not allocate the ember sample');
  assert.equal(layer.rockMat.emberMask, undefined);
  assert.equal(layer.resourceMetrics().textureSkips, 1);

  grain.dispose();
  layer.dispose();
});

function byteSizedGroup(bytes, onDispose = () => {}) {
  const group = new THREE.Group();
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.BufferAttribute(new Float32Array(bytes / 4), 3));
  geometry.dispose = onDispose;
  group.add(new THREE.Mesh(geometry));
  return group;
}

test('GPU cache retains at most current/next/previous/spare and disposes each eviction once', () => {
  const scene = new THREE.Scene();
  const layer = new LandmarkLayer(scene);
  let current = composition('surface-0');
  let disposals = 0;
  layer._buildGroup = () => byteSizedGroup(12 * 1024, () => { disposals++; });
  const cache = { landmarksInView: () => [current] };

  layer.update({}, 0, 128, 4096, cache);
  const first = [...layer.built.values()][0];
  for (let k = 1; k < 9; k++) {
    current = { ...composition(`surface-${k}`), k: 2 + k };
    layer.update({}, 0, 128, 4096, cache);
  }

  const metrics = layer.resourceMetrics();
  assert.equal(MAX_CACHED_ROOMS, 4);
  assert.equal(metrics.rooms, 4);
  assert.equal(metrics.peakRooms, 4, 'published cache never transiently exceeds the limit');
  assert.equal(metrics.builds, 9);
  assert.equal(metrics.evictions, 5);
  assert.equal(metrics.disposedGeometries, 5);
  assert.equal(disposals, 5);
  assert.equal(layer._evict(first), false, 'an already evicted entry cannot be disposed twice');
  assert.equal(disposals, 5);
  assert.equal(metrics.overBudget, false);

  layer.dispose();
});

test('hidden prewarm geometry becomes visible without a cold rebuild', () => {
  const scene = new THREE.Scene();
  const layer = new LandmarkLayer(scene);
  const current = composition('surface-prewarm');
  let visible = false;
  let builds = 0;
  layer._buildGroup = () => { builds++; return byteSizedGroup(12 * 1024); };
  const cache = {
    landmarksInView: (_cave, _z, range) => (visible || range > 128 ? [current] : []),
    compositionAt: () => current,
  };
  const cave = { centers: [[0, 0, 2000], [0, 0, 2280]] };

  layer.update(cave, 1900, 128, 4096, cache, null, 224);
  const entry = [...layer.built.values()][0];
  assert.equal(builds, 1);
  assert.equal(entry.group.visible, false, 'prewarm must not expose geometry before visible range');
  assert.equal(layer.resourceMetrics().prewarmBuilds, 1);
  assert.equal(layer.resourceMetrics().coldVisibleBuilds, 0);

  let compileCalls = 0;
  layer.prepareHiddenPrograms(() => { compileCalls++; });
  assert.equal(compileCalls, 1);
  assert.equal(entry.group.visible, false, 'program prewarm must restore hidden state');
  assert.equal(layer.resourceMetrics().programPrewarms, 1);
  layer.prepareHiddenPrograms(() => { compileCalls++; });
  assert.equal(compileCalls, 1, 'prepared programs are not compiled twice');

  visible = true;
  layer.update(cave, 1900, 128, 4096, cache, null, 224);
  assert.equal(builds, 1, 'visible activation reuses the prebuilt group');
  assert.equal(entry.group.visible, true);
  assert.equal(layer.resourceMetrics().prewarmActivations, 1);
  assert.equal(layer.resourceMetrics().coldVisibleBuilds, 0);
  layer.dispose();
});

test('failed hidden program prewarm restores visibility and remains retryable', () => {
  const scene = new THREE.Scene();
  const layer = new LandmarkLayer(scene);
  layer._buildGroup = () => byteSizedGroup(12 * 1024);
  const cache = { landmarksInView: (_cave, _z, range) =>
    (range > 128 ? [composition('surface-compile-fail')] : []),
  compositionAt: () => composition('surface-compile-fail') };
  layer.update({ centers: [[0, 0, 2000], [0, 0, 2280]] }, 1900, 128, 4096, cache, null, 224);
  const entry = [...layer.built.values()][0];
  layer.prepareHiddenPrograms(() => { throw new Error('driver compile failed'); });
  assert.equal(entry.group.visible, false);
  assert.equal(entry.programPrepared, undefined);
  assert.equal(layer.resourceMetrics().programPrewarmFailures, 1);
  layer.dispose();
});

test('GPU cache evicts stale geometry before exceeding its one-MiB retained budget', () => {
  const scene = new THREE.Scene();
  const layer = new LandmarkLayer(scene);
  let current = composition('surface-0');
  layer._buildGroup = () => byteSizedGroup(360 * 1024);
  const cache = { landmarksInView: () => [current] };

  for (let k = 0; k < 6; k++) {
    current = { ...composition(`surface-${k}`), k: 20 + k };
    layer.update({}, 0, 128, 4096, cache);
  }

  const metrics = layer.resourceMetrics();
  assert.equal(MAX_CACHED_GEOMETRY_BYTES, 1024 * 1024);
  assert.equal(metrics.rooms, 2);
  assert.equal(metrics.geometryBytes, 720 * 1024);
  assert.ok(metrics.peakGeometryBytes <= MAX_CACHED_GEOMETRY_BYTES);
  assert.equal(metrics.overBudget, false);

  layer.dispose();
});

test('dispose tears down retained GPU entries and shared resources once', () => {
  const scene = new THREE.Scene();
  const layer = new LandmarkLayer(scene);
  let geometryDisposals = 0;
  layer._buildGroup = () => byteSizedGroup(12 * 1024, () => { geometryDisposals++; });
  const cache = { landmarksInView: () => [composition('surface-a')] };
  layer.update({}, 0, 128, 4096, cache);

  layer.dispose();
  layer.dispose();
  assert.equal(geometryDisposals, 1);
  assert.equal(layer.built.size, 0);
  assert.equal(layer.geometryBytes, 0);
  assert.equal(scene.children.includes(layer.group), false);
});

function assertGroupBuffersEqual(actual, expected) {
  assert.equal(actual.children.length, expected.children.length);
  for (let i = 0; i < actual.children.length; i++) {
    const a = actual.children[i].geometry, b = expected.children[i].geometry;
    assert.deepEqual(a.index.array, b.index.array, 'triangle topology');
    assert.deepEqual(Object.keys(a.attributes), Object.keys(b.attributes));
    for (const name of Object.keys(a.attributes)) {
      assert.deepEqual(a.attributes[name].array, b.attributes[name].array, `${name} bytes`);
    }
  }
}

test('live root revisions refresh one retained mesh exactly like independent fresh builds', () => {
  const game = new Game();
  game.start({ mode: 2, seed: 256, family: 'branching' });
  // Start with genuinely missing front contacts, rather than treating rear
  // render-slot recycling as a change to an already emitted room surface.
  game.cave.generateThrough(roomZ(9) + 2);
  game.player.pos[2] = 9010;
  const layer = new LandmarkLayer(new THREE.Scene());
  let current = game.landmarkCache.compositionAt(256, game.cave, 9, 'branching');
  const cache = { landmarksInView: () => current ? [current] : [] };
  let originalGeometry, revisions = 0, topologyChanges = 0, previous;
  const verify = () => {
    current = game.landmarkCache.compositionAt(256, game.cave, 9, 'branching');
    if (!current || current === previous) return;
    layer.update(game.cave, game.player.pos[2], 128, 256, cache);
    const entry = [...layer.built.values()][0];
    originalGeometry ??= entry.group.children[0].geometry;
    assert.equal(entry.group.children.length, 1, 'all roots remain one draw call');
    const topology = comp => comp.rootSurfaces.map(s =>
      `${s.gid}:${s.visibleTriangles.join(',')}`).join('|');
    const topologyChanged = previous && topology(current) !== topology(previous);
    if (topologyChanged) {
      assert.notEqual(entry.group.children[0].geometry, originalGeometry,
        'whole-child rejection or arrival replaces the changed topology');
      originalGeometry = entry.group.children[0].geometry;
      topologyChanges++;
    } else assert.equal(entry.group.children[0].geometry, originalGeometry,
      'a revision with unchanged topology retains the GPU buffer');
    const fresh = layer._buildGroup(compositionAt(256, game.cave, 9, 'branching'),
      entry.projector);
    assertGroupBuffersEqual(entry.group, fresh);
    for (const child of fresh.children) child.geometry.dispose();
    assert.equal(layer.built.size, 1);
    assert.equal(layer.resourceMetrics().overBudget, false);
    previous = current;
    revisions++;
  };
  verify();
  const initialRings = game.cave.landmarkRoomSurface(9).count;
  for (let depth = roomZ(9) + 4; depth <= roomZ(9) + 112; depth += 2) {
    game.cave.generateThrough(depth);
    verify();
  }
  assert.ok(game.cave.landmarkRoomSurface(9).count > initialRings,
    'revision fixture emits previously missing authoritative front rings');
  const complete = current;
  for (let step = 0; step < 300; step++) {
    game._carve();
    game.player.pos[2] += 0.675;
    verify();
    assert.equal(current, complete, 'complete wall authority survives rear render-slot recycling');
  }
  assert.ok(revisions > 10, 'new authoritative front contacts must cause real revisions');
  assert.equal(layer.metrics.builds, 1 + topologyChanges);
  assert.equal(layer.metrics.revisionUpdates, revisions - 1 - topologyChanges);
  assert.equal(layer.metrics.disposedGeometries, topologyChanges);
  assert.ok(layer.metrics.updatedRootForms < (revisions - 1) * 8,
    'unchanged root identities avoid rebuilding all eight forms');

  game.cave.ensureCapacityForDistance(650);
  verify();
  game.cave.reset(256, 'branching');
  game.cave.generateThrough(9120);
  verify();
  layer.dispose();
  assert.equal(layer.metrics.disposedGeometries, topologyChanges + 1);
});

test('metadata-only root revisions perform no buffer upload; topology changes rebuild safely', () => {
  const game = new Game();
  game.start({ mode: 2, seed: 2024, family: 'branching' });
  placeAt(game, 9010);
  let current = compositionAt(2024, game.cave, 9, 'branching');
  const layer = new LandmarkLayer(new THREE.Scene());
  const cache = { landmarksInView: () => [current] };
  layer.update(game.cave, 9010, 128, 2024, cache);
  const firstEntry = [...layer.built.values()][0];
  const old = firstEntry.group.children[0].geometry;
  const projector = firstEntry.projector;
  let projections = 0;
  const project = projector.project.bind(projector);
  projector.project = (...args) => { projections++; return project(...args); };
  const versions = Object.fromEntries(Object.entries(old.attributes)
    .map(([name, attribute]) => [name, attribute.version]));
  current = { ...current, rootSurfaces: current.rootSurfaces, surfaceRevision: 'metadata-only' };
  layer.update(game.cave, 9010, 128, 2024, cache);
  for (const [name, version] of Object.entries(versions)) {
    assert.equal(old.attributes[name].version, version, 'unchanged buffers are never uploaded');
  }
  assert.equal(layer.metrics.updatedRootForms, 0);
  assert.equal(projections, 0, 'metadata-only revision does not reproject retained roots');
  const firstGid = current.pieces[0].gid;
  current = { ...current, surfaceRevision: 'changed-topology',
    pieces: current.pieces.filter((piece) => piece.gid !== firstGid && piece.parentGid !== firstGid),
    rootSurfaces: current.rootSurfaces.filter((surface) => surface.gid !== firstGid
      && surface.piece.parentGid !== firstGid) };
  layer.update(game.cave, 9010, 128, 2024, cache);
  const entry = [...layer.built.values()][0];
  assert.notEqual(entry.group.children[0].geometry, old);
  assert.equal(layer.metrics.revisionReplacements, 1);
  assert.equal(layer.metrics.disposedGeometries, 1);
  assert.equal(projector.disposed, true, 'replaced room releases its bounded frame cache');
  const fresh = layer._buildGroup(current, entry.projector);
  assertGroupBuffersEqual(entry.group, fresh);
  for (const child of fresh.children) child.geometry.dispose();
  layer.dispose();
});
