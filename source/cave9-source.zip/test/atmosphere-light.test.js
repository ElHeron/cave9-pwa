import { test } from 'node:test';
import assert from 'node:assert/strict';
import * as THREE from 'three';

import { Atmosphere, CORRIDOR, EARLY_ROOM_COLOR_WEIGHT, ROOM } from '../src/render/Atmosphere.js';
import { visibilityAt } from '../src/render/VisibilityProfile.js';
import { roomAt } from '../src/core/RoomState.js';
import { styleAt } from '../src/core/Difficulty.js';
import { Renderer } from '../src/render/Renderer.js';

test('early-room colour is independent of the unchanged fog visibility planes', () => {
  const scene = new THREE.Scene();
  const air = new Atmosphere(scene);
  const roomColor = new THREE.Color(ROOM.color);
  const corridorColor = new THREE.Color(CORRIDOR.color);

  for (const sight of [0.7, 1, 1.3]) {
    air.setSight(sight);
    for (const depth of [0, 1750, 2050, 2500, 6050, 9250, 12000]) {
      const presence = roomAt(depth).t;
      const styled = presence * styleAt(depth);
      const colorWeight = Math.max(styled, EARLY_ROOM_COLOR_WEIGHT * presence);
      air.setRoom(styled, colorWeight);
      const expected = visibilityAt({ sight, room: styled, readability: true });
      assert.equal(air.fog.near, expected.near, `near at ${depth} m`);
      assert.equal(air.fog.far, expected.far, `far at ${depth} m`);
      assert.ok(air.fog.color.equals(corridorColor.clone().lerp(roomColor, colorWeight)));
      assert.ok(scene.background.equals(air.fog.color));
    }
  }

  // The first physical room gains a clear distant-air cue even while the style curve
  // deliberately keeps the original full corridor draw distance at 2050 m.
  const early = roomAt(2050).t;
  assert.ok(early > 0);
  assert.equal(styleAt(2050), 0);
  air.setRoom(0, EARLY_ROOM_COLOR_WEIGHT * early);
  // The 0.70 tint was selected from fixed-camera early-room originals.
  assert.ok(air.fog.color.equals(corridorColor.clone().lerp(roomColor, 0.70 * early)));
  assert.deepEqual([air.fog.near, air.fog.far],
    Object.values(visibilityAt({ sight: air.sight, room: 0, readability: true })));

  air.setRoom(0, 0);
  assert.ok(air.fog.color.equals(corridorColor));
  air.setReadability(false);
  const baseline = visibilityAt({ sight: air.sight, room: 0, readability: false });
  assert.equal(air.fog.near, baseline.near);
  assert.equal(air.fog.far, baseline.far);
  assert.ok(air.fog.color.equals(corridorColor));
});

test('existing directional fill is unchanged at corridor zero and modest in early rooms', () => {
  const r = {
    brightness: 1,
    renderer: { toneMappingExposure: 0 },
    ambient: { intensity: 0, color: new THREE.Color() },
    headlight: { intensity: 0 },
    forwardBeam: { intensity: 0 },
    hemi: { intensity: 0, color: new THREE.Color(), groundColor: new THREE.Color() },
    fill: { intensity: 0, color: new THREE.Color() },
    _corridorAmbientColor: new THREE.Color(0x33384a),
    _roomAmbientColor: new THREE.Color(0xe0ddd6),
    _corridorHemiSky: new THREE.Color(0x6678a0),
    _corridorHemiGround: new THREE.Color(0x05060a),
    _roomHemiSky: new THREE.Color(0xb4b5b6),
    _roomHemiGround: new THREE.Color(0x30343a),
    _corridorFillColor: new THREE.Color(0x4060a0),
    _roomFillColor: new THREE.Color(0x9ca3a8),
    caveMat: { color: new THREE.Color() },
  };
  Renderer.prototype._applyRoomLighting.call(r, 0, 0);
  assert.equal(r.fill.intensity, 0.25);
  assert.equal(r.fill.color.getHex(), 0x4060a0);
  assert.equal(r.renderer.toneMappingExposure, 2);
  assert.equal(r.ambient.intensity, 0.5);
  assert.equal(r.ambient.color.getHex(), 0x33384a);
  assert.equal(r.headlight.intensity, 3);
  assert.equal(r.forwardBeam.intensity, 6.5);
  assert.equal(r.hemi.intensity, 0.9);
  assert.equal(r.hemi.color.getHex(), 0x6678a0);
  assert.equal(r.hemi.groundColor.getHex(), 0x05060a);
  assert.equal(r.caveMat.color.getHex(), 0xffffff);

  Renderer.prototype._applyRoomLighting.call(r, 0, 1);
  assert.ok(r.fill.intensity > 0.25 && r.fill.intensity < 0.35);
  assert.ok(r.fill.color.r > r._corridorFillColor.r);
  assert.equal(r.caveMat.color.getHex(), 0xffffff);
  assert.ok(r.ambient.intensity > 0.5 && r.ambient.intensity < 1);
  assert.ok(r.ambient.color.r > r._corridorAmbientColor.r);
  assert.equal(r.hemi.intensity, 1.08);
  assert.ok(r.hemi.color.equals(r._corridorHemiSky.clone().lerp(r._roomHemiSky, 0.60)));
  assert.ok(r.hemi.groundColor.equals(
    r._corridorHemiGround.clone().lerp(r._roomHemiGround, 0.60)));

  Renderer.prototype._applyRoomLighting.call(r, 1, 1);
  assert.ok(r.fill.intensity <= 0.43);
  assert.equal(r.fill.color.getHex(), 0x9ca3a8);
  assert.equal(r.ambient.intensity, 1.4);
  assert.equal(r.ambient.color.getHex(), 0xe0ddd6);
  assert.equal(r.hemi.intensity, 1.2);
  assert.equal(r.hemi.color.getHex(), 0xb4b5b6);
  assert.equal(r.hemi.groundColor.getHex(), 0x30343a);

  r.brightness = 0.7;
  Renderer.prototype._applyRoomLighting.call(r, 1, 1);
  assert.ok(Math.abs(r.ambient.intensity - 0.98) < 1e-12);
  assert.ok(Math.abs(r.hemi.intensity - 0.84) < 1e-12);
  Renderer.prototype._applyRoomLighting.call(r, 0, 0);
  assert.equal(r.ambient.intensity, 0.35);
  assert.equal(r.ambient.color.getHex(), 0x33384a);
  assert.equal(r.hemi.intensity, 0.63);
  assert.equal(r.hemi.color.getHex(), 0x6678a0);
  assert.equal(r.hemi.groundColor.getHex(), 0x05060a);
});

test('readability baseline restores original ambient and fill after a lit room', () => {
  const r = {
    brightness: 1,
    readability: true,
    _roomPresence: 1,
    renderer: { toneMappingExposure: 0, toneMapping: null },
    atmosphere: { roomT: 1, setReadability() {}, setBrightness() {} },
    ambient: { intensity: 0, color: new THREE.Color() },
    headlight: { intensity: 0 },
    forwardBeam: { intensity: 0, visible: true },
    hemi: { intensity: 0, visible: true,
      color: new THREE.Color(), groundColor: new THREE.Color() },
    fill: { intensity: 0, color: new THREE.Color() },
    _corridorAmbientColor: new THREE.Color(0x33384a),
    _roomAmbientColor: new THREE.Color(0xe0ddd6),
    _corridorHemiSky: new THREE.Color(0x6678a0),
    _corridorHemiGround: new THREE.Color(0x05060a),
    _roomHemiSky: new THREE.Color(0xb4b5b6),
    _roomHemiGround: new THREE.Color(0x30343a),
    _corridorFillColor: new THREE.Color(0x4060a0),
    _roomFillColor: new THREE.Color(0x9ca3a8),
    caveMat: { color: new THREE.Color() },
    _applyReadabilityProfile: Renderer.prototype._applyReadabilityProfile,
    _applyRoomLighting: Renderer.prototype._applyRoomLighting,
    setBrightness: Renderer.prototype.setBrightness,
  };
  Renderer.prototype._applyRoomLighting.call(r, 1, 1);
  assert.equal(r.ambient.color.getHex(), 0xe0ddd6);
  Renderer.prototype.setReadability.call(r, false);
  assert.equal(r.ambient.intensity, 0.7);
  assert.equal(r.ambient.color.getHex(), 0x33384a);
  assert.equal(r.fill.intensity, 0.25);
  assert.equal(r.fill.color.getHex(), 0x4060a0);
  assert.equal(r.hemi.intensity, 0);
  assert.equal(r.hemi.color.getHex(), 0x6678a0);
  assert.equal(r.hemi.groundColor.getHex(), 0x05060a);
  Renderer.prototype.setReadability.call(r, true);
  assert.equal(r.ambient.intensity, 1.4);
  assert.equal(r.ambient.color.getHex(), 0xe0ddd6);
  assert.equal(r.fill.color.getHex(), 0x9ca3a8);
  assert.equal(r.hemi.intensity, 1.2);
  assert.equal(r.hemi.color.getHex(), 0xb4b5b6);
  assert.equal(r.hemi.groundColor.getHex(), 0x30343a);
});
