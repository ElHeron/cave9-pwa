// settingsBindings — the single key→effect table.
//
// The point of the table is that "apply the stored settings at boot" and "apply
// one setting the player just changed" can no longer drift apart, and that every
// schema key with a runtime effect has exactly one. Run with: npm test

import { test } from 'node:test';
import assert from 'node:assert/strict';

import {
  SETTINGS_BINDINGS, applySetting, applyAllSettings,
} from '../src/app/settingsBindings.js';
import { SETTINGS_SCHEMA, DEFAULTS } from '../src/platform/SettingsSystem.js';

// A context that records every effect a binding performs.
function ctx() {
  const calls = [];
  const log = (name) => (...args) => calls.push([name, ...args]);
  const games = [{ player: {} }, { player: {} }];
  return {
    calls, games,
    renderer: {
      setBrightness: log('setBrightness'), setFov: log('setFov'), setMotion: log('setMotion'),
      setQuality: log('setQuality'), setRockDetail: log('setRockDetail'), setLandmarks: log('setLandmarks'),
    },
    audio: { setEnabled: log('setEnabled'), setVolume: log('setVolume') },
    input: { setMode: log('setMode'), setTouchHand: log('setTouchHand'), setInvertX: log('setInvertX') },
    setReducedMotion: log('setReducedMotion'),
  };
}

const names = (c) => c.calls.map((x) => x[0]);

test('every settings key with a runtime effect has exactly one binding', () => {
  for (const key of Object.keys(SETTINGS_BINDINGS)) {
    assert.ok(key in DEFAULTS, `binding "${key}" is not a real setting`);
  }
  for (const field of SETTINGS_SCHEMA) {
    assert.ok(SETTINGS_BINDINGS[field.key],
      `schema field "${field.key}" is shown in the menu but nothing applies it`);
  }
});

test('applying a setting performs its effect', () => {
  const c = ctx();
  applySetting('brightness', 1.3, c);
  assert.deepEqual(c.calls, [['setBrightness', 1.3]]);
});

test('an unknown key is ignored rather than throwing', () => {
  const c = ctx();
  assert.equal(applySetting('nonesuch', 1, c), false);
  assert.deepEqual(c.calls, []);
});

test('motion drives both the renderer and the reduced-motion body class', () => {
  const c = ctx();
  applySetting('motion', 0, c);
  assert.deepEqual(names(c), ['setMotion', 'setReducedMotion']);
});

test('sensitivity reaches every live game, not just the player run', () => {
  const c = ctx();
  applySetting('sensitivity', 1.4, c);
  for (const g of c.games) assert.equal(g.player.thrustScale, 1.4);
});

test('landmark visibility and lethal geometry toggle together', () => {
  const c = ctx();
  applySetting('landmarks', false, c);
  assert.deepEqual(c.calls, [['setLandmarks', false]]);
  for (const g of c.games) assert.equal(g.landmarksEnabled, false);
});

test('gameplay bindings preserve the active run profile while personal values change', () => {
  const c = ctx();
  const rules = { controlMode: 2, thrustScale: 1, landmarks: true };
  c.activeRunRules = () => rules;
  applySetting('controlMode', 1, c, true);
  applySetting('sensitivity', 1.6, c, true);
  applySetting('landmarks', false, c, true);
  assert.deepEqual(c.calls, [['setMode', 2], ['setLandmarks', true]]);
  assert.equal(c.games[0].player.thrustScale, 1);
  assert.equal(c.games[1].player.thrustScale, 1.6);
  assert.equal(c.games[0].landmarksEnabled, true);
  assert.equal(c.games[1].landmarksEnabled, false);
});

test('touchHand updates the mapping without re-binding zones', () => {
  const live = ctx();
  applySetting('touchHand', 'mirror', live, true);
  assert.deepEqual(names(live), ['setTouchHand']);

  const boot = ctx();
  applySetting('touchHand', 'mirror', boot, false);
  assert.deepEqual(names(boot), ['setTouchHand']);
});

test('applyAllSettings reads and applies every bound key', () => {
  const c = ctx();
  const read = [];
  applyAllSettings({ get: (k) => { read.push(k); return DEFAULTS[k]; } }, c);
  assert.deepEqual(read.sort(), Object.keys(SETTINGS_BINDINGS).sort());
  assert.ok(!names(c).includes('rebindTouch'), 'boot never re-binds touch');
});

test('applyAllSettings passes each binding its own value', () => {
  const c = ctx();
  applyAllSettings({ get: (k) => DEFAULTS[k] }, c);
  const byName = Object.fromEntries(c.calls.map(([n, v]) => [n, v]));
  assert.equal(byName.setBrightness, DEFAULTS.brightness);
  assert.equal(byName.setFov, DEFAULTS.fov);
  assert.equal(byName.setVolume, DEFAULTS.volume);
  assert.equal(byName.setEnabled, DEFAULTS.sound);
  assert.equal(byName.setMode, DEFAULTS.controlMode);
});
