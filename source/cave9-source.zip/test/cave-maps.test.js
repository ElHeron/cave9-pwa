import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { PNG } from 'pngjs';
import { deriveCaveMaps } from '../scripts/make-cave-maps.mjs';

function syntheticRamp(width, height) {
  const rgba = Buffer.alloc(width * height * 4);
  for (let y = 0; y < height; y++) for (let x = 0; x < width; x++) {
    const i = (y * width + x) * 4;
    const value = Math.round(40 + x / (width - 1) * 180);
    rgba[i] = rgba[i + 1] = rgba[i + 2] = value;
    rgba[i + 3] = 255;
  }
  return rgba;
}

test('height and OpenGL normal derivation is deterministic and dimension preserving', () => {
  const width = 17, height = 13;
  const rgba = syntheticRamp(width, height);
  const a = deriveCaveMaps(rgba, width, height);
  const b = deriveCaveMaps(rgba, width, height);
  assert.deepEqual(a.heightPng, b.heightPng);
  assert.deepEqual(a.normalPng, b.normalPng);
  const heightMap = PNG.sync.read(a.heightPng);
  const normalMap = PNG.sync.read(a.normalPng);
  assert.deepEqual([heightMap.width, heightMap.height], [width, height]);
  assert.deepEqual([normalMap.width, normalMap.height], [width, height]);
  const centre = (Math.floor(height / 2) * width + Math.floor(width / 2)) * 4;
  assert.ok(normalMap.data[centre] < 128, 'surface rising toward +U tilts the normal toward -X');
  assert.ok(normalMap.data[centre + 2] > 128, 'normal remains outward-facing');
});

test('committed cave maps are lossless 512 px assets with useful signal', () => {
  const heightMap = PNG.sync.read(readFileSync('public/assets/cave-wall-height.png'));
  const normalMap = PNG.sync.read(readFileSync('public/assets/cave-wall-normal.png'));
  assert.deepEqual([heightMap.width, heightMap.height], [512, 512]);
  assert.deepEqual([normalMap.width, normalMap.height], [512, 512]);
  let minHeight = 255, maxHeight = 0, tilted = 0;
  let normalLengthSum = 0, normalLengthMin = Infinity, normalLengthMax = 0;
  for (let i = 0; i < 512 * 512; i++) {
    const o = i * 4;
    const h = heightMap.data[o];
    assert.equal(heightMap.data[o + 1], h);
    assert.equal(heightMap.data[o + 2], h);
    assert.equal(heightMap.data[o + 3], 255);
    assert.equal(normalMap.data[o + 3], 255);
    minHeight = Math.min(minHeight, h);
    maxHeight = Math.max(maxHeight, h);
    if (Math.abs(normalMap.data[o] - 128) > 3 || Math.abs(normalMap.data[o + 1] - 128) > 3) tilted++;
    const nx = normalMap.data[o] / 127.5 - 1;
    const ny = normalMap.data[o + 1] / 127.5 - 1;
    const nz = normalMap.data[o + 2] / 127.5 - 1;
    const length = Math.hypot(nx, ny, nz);
    normalLengthSum += length;
    normalLengthMin = Math.min(normalLengthMin, length);
    normalLengthMax = Math.max(normalLengthMax, length);
  }
  assert.ok(maxHeight - minHeight > 180, 'height map uses a broad lossless range');
  assert.ok(tilted > 512 * 512 * 0.35, 'normal map contains widespread relief rather than flat blue');
  assert.ok(normalLengthMin > 0.99 && normalLengthMax < 1.01, 'quantized normal vectors remain unit length');
  assert.ok(Math.abs(normalLengthSum / (512 * 512) - 1) < 0.001, 'mean normal length remains one');
});
