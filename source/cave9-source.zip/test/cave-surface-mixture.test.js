import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

import {
  surfaceStretchAt,
  tunnelGeologicalCoordinateAt,
  tunnelVariantBandAt,
  tunnelVariantSharesAt,
} from '../src/render/materials/caveSurfaceState.js';

test('ordinary stretches always expose three distinct adjacent generations', () => {
  for (let seed = 0; seed < 100; seed++) {
    for (let depth = 0; depth < 20_000; depth += 113) {
      const state = surfaceStretchAt(seed, depth);
      assert.equal(new Set([
        state.previousVariant,
        state.currentVariant,
        state.nextVariant,
      ]).size, 3, `${seed}:${depth}`);
    }
  }
});

function sampledCoverage(progress) {
  const counts = { previous: 0, current: 0, next: 0 };
  let samples = 0;
  for (let axial = 0; axial < 500; axial += 1) {
    for (let sector = 0; sector < 180; sector++) {
      const angle = sector * Math.PI * 2 / 180;
      const h = Math.sin(angle);
      const localRight = Math.cos(angle) * 10;
      const coordinate = tunnelGeologicalCoordinateAt(axial, h, localRight);
      counts[tunnelVariantBandAt(coordinate, progress)]++;
      samples++;
    }
  }
  return Object.fromEntries(Object.entries(counts).map(([name, count]) => [name, count / samples]));
}

test('three-generation shares move 30/65/5 through 17.5/65/17.5 to 5/65/30', () => {
  assert.deepEqual(tunnelVariantSharesAt(0), { previous: 0.30, current: 0.65, next: 0.05 });
  assert.deepEqual(tunnelVariantSharesAt(0.5), { previous: 0.175, current: 0.65, next: 0.175 });
  assert.deepEqual(tunnelVariantSharesAt(1), { previous: 0.05, current: 0.65, next: 0.30 });
  for (const progress of [-1, 0, 0.25, 0.5, 0.75, 1, 2, NaN]) {
    const shares = tunnelVariantSharesAt(progress);
    assert.ok(Math.abs(shares.previous + shares.current + shares.next - 1) < 1e-12);
    assert.ok(shares.current >= 0.60 && shares.current <= 0.70);
  }
});

test('the real geological coordinate produces the requested regional surface coverage', () => {
  const start = sampledCoverage(0);
  const middle = sampledCoverage(0.5);
  const end = sampledCoverage(1);

  for (const coverage of [start, middle, end]) {
    assert.ok(coverage.current >= 0.63 && coverage.current <= 0.67,
      `dominant surface share ${coverage.current}`);
  }
  assert.ok(start.previous >= 0.28 && start.previous <= 0.32);
  assert.ok(start.next >= 0.035 && start.next <= 0.065);
  assert.ok(middle.previous >= 0.15 && middle.previous <= 0.20);
  assert.ok(middle.next >= 0.15 && middle.next <= 0.20);
  assert.ok(end.previous >= 0.035 && end.previous <= 0.065);
  assert.ok(end.next >= 0.28 && end.next <= 0.32);
});

test('the cyclic geological partition always puts current material between both neighbours', () => {
  for (const progress of [0, 0.25, 0.5, 0.75, 1]) {
    const bands = [];
    for (let index = 0; index < 100_000; index++) {
      bands.push(tunnelVariantBandAt(index / 100_000, progress));
    }
    for (let index = 0; index < bands.length; index++) {
      const a = bands[index];
      const b = bands[(index + 1) % bands.length];
      assert.notEqual(new Set([a, b]).size === 2 && a !== 'current' && b !== 'current', true,
        `forbidden ${a}/${b} contact at progress ${progress}`);
    }
  }
});

test('GLSL keeps variant identities flat and mirrors the audited geological coordinate', () => {
  const source = readFileSync(new URL('../src/render/materials/caveSurface.js', import.meta.url), 'utf8');
  assert.equal((source.match(/flat varying vec4 vCaveSurfaceMix;/g) || []).length, 2);
  assert.match(source, /fract\(axial \/ 72\.0 \+ \(h \+ 1\.0\) \* 0\.46/);
  assert.match(source, /float previousShare = mix\(0\.30, 0\.05, regionProgress\)/);
  assert.match(source, /float nextShare = mix\(0\.05, 0\.30, regionProgress\)/);
  assert.match(source, /const float mainShare = 0\.65/);
});
