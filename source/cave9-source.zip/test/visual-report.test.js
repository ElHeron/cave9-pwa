import test from 'node:test';
import assert from 'node:assert/strict';

import { aggregateSimilarity, reportHtml } from '../scripts/visual/reference-report-lib.mjs';

test('similarity aggregation is explicitly diagnostic and family-balanced', () => {
  const report = aggregateSimilarity([
    { family: 'branching', bestPrimaryMatch: { similarity: 80 } },
    { family: 'branching', bestPrimaryMatch: { similarity: 100 } },
    { family: 'crystal', bestPrimaryMatch: { similarity: 70 } },
  ]);
  assert.equal(report.diagnosticOnly, true);
  assert.equal(report.releaseGate, false);
  assert.deepEqual(report.families.branching, {
    frames: 2, meanBestSimilarity: 90, minBestSimilarity: 80, maxBestSimilarity: 100,
  });
  assert.equal(report.overallMeanOfFamilyMeans, 80);
});

test('HTML report labels similarity as diagnostic and escapes evidence names', () => {
  const shape = {
    D7_centralOpening: { areaRatio: 0.1 },
    D8_angularSilhouette: { entropy: 0.9 },
    D9_quadrantMass: { imbalance: 0.2 },
    D10_dominantForms: { top3Share: 0.7 },
    D11_tipDistance: { median: 0.3 },
    D12_projectedOcclusion: { meanCrossings: 2.5 },
  };
  const html = reportHtml({
    runId: '<unsafe>',
    captures: [{ id: 'branching-<x>', frame: 'frames/a.png', family: 'branching', offset: 0,
      composition: shape, bestPrimaryMatch: { similarity: 88.5, reference: 'claw&reach.png' } }],
    aggregateSimilarity: { overallMeanOfFamilyMeans: 88.5,
      families: { branching: { frames: 1, meanBestSimilarity: 88.5,
        minBestSimilarity: 88.5, maxBestSimilarity: 88.5 } } },
  });
  assert.match(html, /Diagnostic only/);
  assert.doesNotMatch(html, /<unsafe>/);
  assert.match(html, /claw&amp;reach\.png/);
});
