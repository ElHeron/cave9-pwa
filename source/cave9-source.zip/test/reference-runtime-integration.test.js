import { test } from 'node:test';
import assert from 'node:assert/strict';

import { Game } from '../src/core/Game.js';
import { compositionAt, roomZ } from '../src/core/Landmarks.js';
import { pathFrameAt, tubeRadiusAt } from '../src/core/FlightPath.js';

function roomGame(seed, k = 2, family = 'auto') {
  const game = new Game();
  game.start({ mode: 2, seed, family });
  const target = roomZ(k) + 120;
  game.cave.generateThrough(target);
  return game;
}

function routeReserve(seed, point, radius) {
  const frame = pathFrameAt(seed, point.z);
  const dx = point.x - frame.center.x;
  const dy = point.y - frame.center.y;
  const dz = point.z - frame.center.z;
  const x = dx * frame.right.x + dy * frame.right.y + dz * frame.right.z;
  const y = dx * frame.up.x + dy * frame.up.y + dz * frame.up.z;
  return Math.hypot(x, y) - radius - tubeRadiusAt(point.z, seed);
}

test('reference families follow the curved route and clear the dynamic tube', () => {
  for (const seed of [1, 256, 2024]) {
    for (const family of ['branching', 'crystal', 'coiling']) {
      const game = roomGame(seed, 2, family);
      const comp = compositionAt(seed, game.cave, 2, family);
      assert.ok(comp, `${family} composition for seed ${seed}`);
      if (family === 'coiling') {
        assert.equal(comp.surfaceResident, true);
        assert.equal(comp.collisionPieces.length, 0);
      }
      for (const piece of comp.collisionPieces) {
        const half = piece.length / 2;
        for (const sign of [-1, 0, 1]) {
          const point = {
            x: piece.cx + piece.dx * half * sign,
            y: piece.cy + piece.dy * half * sign,
            z: piece.cz + piece.dz * half * sign,
          };
          assert.ok(routeReserve(seed, point, piece.radius) >= -1e-6,
            `${family} enters dynamic tube at ${point.z.toFixed(2)}m`);
        }
      }
    }
  }
});

test('piece families keep physical roots while C3 stays entirely in the wall rings', () => {
  for (const family of ['branching', 'crystal', 'coiling']) {
    const game = roomGame(2024, 2, family);
    const comp = compositionAt(2024, game.cave, 2, family);
    let contacts = 0;
    for (const piece of comp.pieces) {
      const parent = piece.parentGid && comp.pieces.find((p) => p.gid === piece.parentGid);
      assert.ok(piece.wallRooted || piece.wallContact || (family === 'branching' && parent?.wallRooted),
        `${family} piece lost its wall authority`);
      const local = piece.local, half = piece.localLength / 2;
      for (const [sign, wall] of [[-1, piece.wallRadiusBase], [1, piece.wallRadiusTip]]) {
        const radius = Math.hypot(
          local.cx + local.dx * half * sign,
          local.cy + local.dy * half * sign,
        );
        if (radius + piece.radius >= wall - 1e-6) contacts++;
      }
    }

    const requiredContacts = family === 'crystal' ? 18 : family === 'coiling' ? 0 : 3;
    assert.ok(contacts >= requiredContacts,
      `${family} has ${contacts} physical wall endpoints, expected ${requiredContacts}`);

    if (family === 'branching') {
      const trunks = comp.pieces.filter((p) => p.wallRooted && p.node === 0);
      const children = comp.pieces.filter((p) => p.parentGid && p.node === 0);
      assert.equal(trunks.length, 3);
      assert.equal(children.length, 5);
      assert.equal(comp.pieces.length, 49);
      for (const child of children) {
        const parent = comp.pieces.find((p) => p.gid === child.parentGid
          && p.node === child.parentNode);
        assert.ok(parent?.wallRooted);
        assert.equal(child.wallRooted, false);
        assert.equal(child.rootFootprint, undefined);
        for (const axis of ['x', 'y', 'z']) {
          assert.ok(Math.abs(child['c' + axis] - child['d' + axis] * child.length / 2
            - (parent['c' + axis] - parent['d' + axis] * parent.length / 2)) < 1e-8);
        }
      }
      assert.equal(comp.pieces.some((p) => p.role === 'shoulder-buttress'), false);
      assert.equal(new Set(comp.pieces.filter((p) => p.role === 'wall-spine')
        .map((p) => p.side)).size, 0);
    } else if (family === 'crystal') {
      assert.deepEqual([...new Set(comp.pieces.map((p) => p.bank))].sort(), [0, 1, 2]);
      for (let bank = 0; bank < 3; bank++) {
        const plates = comp.pieces.filter((p) => p.bank === bank).length;
        assert.equal(plates, [7, 6, 5][bank]);
      }
    } else {
      assert.equal(comp.surfaceResident, true);
      assert.deepEqual(comp.pieces, []);
      assert.deepEqual(comp.collisionPieces, []);
      assert.equal(comp.coilingContract.version, 'coiling-shell-v2');
    }
  }
});

test('mapped branching chains share exact world and local nodes after live-wall attachment', () => {
  for (const seed of [256, 2024, 4096]) {
    const game = roomGame(seed, 9, 'branching');
    const comp = compositionAt(seed, game.cave, 9, 'branching');
    assert.ok(comp);
    const forms = new Map();
    for (const p of comp.pieces) {
      if (!forms.has(p.gid)) forms.set(p.gid, []);
      forms.get(p.gid).push(p);
    }
    for (const form of forms.values()) {
      form.sort((a, b) => a.node - b.node);
      for (let i = 1; i < form.length; i++) {
        const prev = form[i - 1], next = form[i];
        const worldTip = {
          x: prev.cx + prev.dx * prev.length / 2,
          y: prev.cy + prev.dy * prev.length / 2,
          z: prev.cz + prev.dz * prev.length / 2,
        };
        const worldBase = {
          x: next.cx - next.dx * next.length / 2,
          y: next.cy - next.dy * next.length / 2,
          z: next.cz - next.dz * next.length / 2,
        };
        assert.ok(Math.hypot(worldTip.x - worldBase.x, worldTip.y - worldBase.y,
          worldTip.z - worldBase.z) < 1e-8, `${seed}/${prev.gid}: world seam`);
        const localTip = {
          x: prev.local.cx + prev.local.dx * prev.localLength / 2,
          y: prev.local.cy + prev.local.dy * prev.localLength / 2,
          z: prev.local.cz + prev.local.dz * prev.localLength / 2,
        };
        const localBase = {
          x: next.local.cx - next.local.dx * next.localLength / 2,
          y: next.local.cy - next.local.dy * next.localLength / 2,
          z: next.local.cz - next.local.dz * next.localLength / 2,
        };
        assert.ok(Math.hypot(localTip.x - localBase.x, localTip.y - localBase.y,
          localTip.z - localBase.z) < 1e-8, `${seed}/${prev.gid}: local seam`);
        assert.ok(Math.abs(prev.wallRadiusTip - next.wallRadiusBase) < 1e-8,
          `${seed}/${prev.gid}: same sampled wall`);
      }
    }
  }
});
