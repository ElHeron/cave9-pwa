import { test } from 'node:test';
import assert from 'node:assert/strict';

import { Game } from '../src/core/Game.js';
import { pathFrameAt } from '../src/core/FlightPath.js';
import { placeAt } from '../src/app/CaptureHarness.js';

test('placed hero captures look down the route, not fixed world Z', () => {
  const game = new Game();
  game.start({ mode: 2, seed: 256 });
  placeAt(game, 9000);

  const tangent = pathFrameAt(game.seed, 9000).tangent;
  assert.ok(Math.abs(game.player.lookAt[0] - tangent.x) < 1e-12);
  assert.ok(Math.abs(game.player.lookAt[1] - tangent.y) < 1e-12);
  assert.ok(Math.abs(game.player.lookAt[2] - tangent.z) < 1e-12);
  assert.equal(game.player.roll, 0);
});
