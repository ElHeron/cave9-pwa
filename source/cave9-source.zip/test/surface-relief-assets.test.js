import test from 'node:test';
import assert from 'node:assert/strict';
import * as THREE from 'three';
import { Renderer } from '../src/render/Renderer.js';
import { SurfaceReliefAssets } from '../src/render/SurfaceReliefAssets.js';

const deferred = () => {
  let resolve, reject;
  const promise = new Promise((yes, no) => { resolve = yes; reject = no; });
  return { promise, resolve, reject };
};

function texture() {
  const value = new THREE.Texture();
  value.image = { width: 512, height: 512 };
  let disposals = 0;
  value.addEventListener('dispose', () => { disposals++; });
  return { value, get disposals() { return disposals; } };
}

function metrics() {
  return { reliefLoads: 0, reliefLoadFailures: 0, reliefTextureBytes: 0 };
}

test('relief asset loader deduplicates concurrent profiles, configures R8 heights and prewarms once', async () => {
  const loads = [];
  const prewarmed = [];
  const byPath = new Map();
  const stats = metrics();
  const assets = new SurfaceReliefAssets({
    loadTexture: (path) => {
      loads.push(path);
      if (!byPath.has(path)) byPath.set(path, texture().value);
      return Promise.resolve(byPath.get(path));
    },
    anisotropy: 16, webgl2: true,
    prewarm: (value) => prewarmed.push(value),
    metrics: stats,
  });
  const first = assets.load('cave');
  assert.equal(assets.load('cave'), first);
  const [cave, same] = await Promise.all([first, assets.load('cave')]);
  assert.equal(cave, same);
  assert.equal(await assets.load('cave'), cave);
  assert.equal(loads.length, 2);
  assert.equal(prewarmed.length, 2);
  assert.equal(cave.normal.format, THREE.RGBAFormat);
  assert.equal(cave.height.format, THREE.RedFormat);
  assert.equal(cave.height.unpackAlignment, 1);
  assert.equal(cave.height.colorSpace, THREE.NoColorSpace);
  assert.equal(cave.normal.anisotropy, 2);
  assert.equal(stats.reliefLoads, 1);
  assert.ok(Math.abs(stats.reliefTextureBytes - (512 * 512 * 5) * 4 / 3) < 1e-6);
});

test('partial partner failure disposes successful texture and permits retry', async () => {
  const normalFirst = texture();
  const heightFirst = deferred();
  const secondNormal = texture(), secondHeight = texture();
  let attempt = 0;
  const stats = metrics();
  const assets = new SurfaceReliefAssets({
    loadTexture: (path) => {
      if (path.endsWith('normal.png')) return Promise.resolve(attempt++ === 0
        ? normalFirst.value : secondNormal.value);
      return attempt === 1 ? heightFirst.promise : Promise.resolve(secondHeight.value);
    },
    metrics: stats,
  });
  const failed = assets.load('cave');
  heightFirst.reject(new Error('height unavailable'));
  await assert.rejects(failed, /height unavailable/);
  assert.equal(normalFirst.disposals, 1);
  assert.equal(assets.get('cave'), undefined);
  assert.equal(assets.promises.size, 0);
  assert.equal(stats.reliefLoadFailures, 1);
  const recovered = await assets.load('cave');
  assert.equal(recovered.normal, secondNormal.value);
  assert.equal(recovered.height, secondHeight.value);
  assert.equal(stats.reliefLoads, 1);
  assert.equal(secondNormal.disposals, 0);
  assert.equal(secondHeight.disposals, 0);
});

function stubRenderer(load) {
  const renderer = Object.create(Renderer.prototype);
  renderer.gpuIdentity = { software: false };
  renderer.surfaceRelief = false;
  renderer.surfaceReliefRequested = false;
  renderer.surfaceReliefProfile = 'cave';
  renderer.assetMetrics = { reliefProfile: null };
  renderer.caveFacet = {
    reliefNormalMap: { value: null }, reliefHeightMap: { value: null },
    reliefStrength: { value: 0 },
  };
  renderer.caveMat = { defines: {}, needsUpdate: false };
  renderer._surfaceReliefAssets = new Map();
  renderer._loadSurfaceRelief = load;
  return renderer;
}

test('older failed request cannot disable a newer successful profile', async () => {
  const old = deferred();
  const coiling = { normal: texture().value, height: texture().value };
  const renderer = stubRenderer((profile) => profile === 'cave'
    ? old.promise : Promise.resolve(coiling));
  const first = renderer.setSurfaceRelief(true, 'cave');
  assert.equal(await renderer.setSurfaceRelief(true, 'coiling'), true);
  old.reject(new Error('old cave failure'));
  assert.equal(await first, false);
  assert.equal(renderer.surfaceRelief, true);
  assert.equal(renderer.surfaceReliefProfile, 'coiling');
  assert.equal(renderer.assetMetrics.reliefProfile, 'coiling');
  assert.equal(renderer.caveFacet.reliefNormalMap.value, coiling.normal);
  assert.equal(renderer.caveFacet.reliefStrength.value, 1);
});

test('off/on and cave authority cancel stale pending profile activation', async () => {
  const old = deferred();
  const cave = { normal: texture().value, height: texture().value };
  const coiling = { normal: texture().value, height: texture().value };
  const renderer = stubRenderer((profile) => profile === 'coiling'
    ? old.promise : Promise.resolve(cave));
  const pending = renderer.setSurfaceRelief(true, 'coiling');
  assert.equal(await renderer.setSurfaceRelief(false), false);
  assert.equal(await renderer.setSurfaceRelief(true, 'cave'), true);
  old.resolve(coiling);
  assert.equal(await pending, false);
  assert.equal(renderer.assetMetrics.reliefProfile, 'cave');
  renderer._surfaceReliefAssets.set('cave', cave);
  const next = deferred();
  renderer._loadSurfaceRelief = (profile) => profile === 'coiling'
    ? next.promise : Promise.resolve(cave);
  renderer._syncSurfaceReliefProfile({ coilingStrengths: new Float32Array([1]) });
  renderer._syncSurfaceReliefProfile({ coilingStrengths: new Float32Array([0]) });
  next.resolve(coiling);
  await Promise.resolve();
  await Promise.resolve();
  assert.equal(renderer.assetMetrics.reliefProfile, 'cave');
  assert.equal(renderer.caveFacet.reliefNormalMap.value, cave.normal);
});
