// CaveMetrics unit tests — the analysis primitives themselves behave sanely.
// Run with: npm test
import { test } from 'node:test';
import assert from 'node:assert/strict';

import { caveGeometryMetrics, flightMetrics } from '../src/core/CaveMetrics.js';
import { ONE_BUTTON, TWO_BUTTONS } from '../src/core/constants.js';

test('geometry metrics expose the documented fields', () => {
  const m = caveGeometryMetrics(42, { maxDepth: 2000 });
  for (const k of ['minRadius', 'avgRadius', 'maxRadius', 'minClearance',
    'avgClearance', 'avgCurvature', 'maxCurvature', 'maxNarrowing',
    'minReactionWindow', 'avgReactionWindow', 'narrowDensity', 'samples']) {
    assert.ok(k in m, `missing field ${k}`);
    assert.ok(Number.isFinite(m[k]), `field ${k} not finite: ${m[k]}`);
  }
  assert.ok(m.minRadius <= m.avgRadius && m.avgRadius <= m.maxRadius, 'radius ordering');
  assert.ok(m.minClearance <= m.avgClearance, 'clearance ordering');
});

test('deeper walks never lose the already-observed minimum radius', () => {
  const shallow = caveGeometryMetrics(42, { maxDepth: 1500 });
  const deep = caveGeometryMetrics(42, { maxDepth: 9000 });
  // The Boolean tube reaches a fixed floor, and the real coil can already
  // produce that shell minimum early. A deeper superset may equal the earlier
  // minimum; requiring strict inequality incorrectly makes phase the oracle.
  assert.ok(deep.minRadius <= shallow.minRadius + 1e-9,
    `deep ${deep.minRadius.toFixed(3)} must preserve shallow ${shallow.minRadius.toFixed(3)}`);
  assert.ok(deep.depthReached > shallow.depthReached);
});

test('flight metrics report a crash or step-limit, with a non-negative score', () => {
  const f = flightMetrics(1337, { maxSteps: 2000 });
  assert.ok(f.steps > 0 && f.steps <= 2000);
  assert.ok(f.score >= 0);
  assert.ok(f.depthReached > 0);
  assert.equal(f.falseDeaths, 0);
});

test('one-button mode scores less per metre than two-button (easier => lower)', () => {
  const two = flightMetrics(99, { maxSteps: 1500, mode: TWO_BUTTONS });
  const one = flightMetrics(99, { maxSteps: 1500, mode: ONE_BUTTON });
  // same pilot window; one-button applies a 0.5 score factor (see ScoreSystem)
  if (Math.abs(two.depthReached - one.depthReached) < 50) {
    assert.ok(one.score < two.score, 'one-button should score lower for similar depth');
  }
});
