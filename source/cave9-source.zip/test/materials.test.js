// Landmark material shaders.
//
// These exist because a shader module can be badly broken while every other test
// stays green: nothing else imports render/materials/, GLSL lives inside template
// literals (so a stray backtick is a JS syntax error), and the injection points
// are three.js chunk names that silently do nothing if they are misspelled. Both
// failure modes have already happened here — a backtick in a comment, and a
// uniform that only exists in the vertex stage.
//
// Run with: npm test

import { test } from 'node:test';
import assert from 'node:assert/strict';
import * as THREE from 'three';

import {
  applyCaveMineral, applyCaveRim, MINERAL_DEFAULTS,
} from '../src/render/materials/caveMineral.js';
import { applySpeedWarp } from '../src/render/materials/speedWarp.js';
import { applyCaveFacet } from '../src/render/materials/caveFacet.js';
import { applyLandmarkSurface } from '../src/render/materials/caveSurface.js';
import { makeEmberMask } from '../src/render/landmarks/LandmarkLayer.js';

// A stand-in for the shader three would hand onBeforeCompile. Only the two
// source strings and the uniform bag matter.
function fakeShader() {
  return {
    uniforms: {},
    vertexShader: [
      '#include <common>',
      'void main() {',
      '  #include <begin_vertex>',
      '}',
    ].join('\n'),
    fragmentShader: [
      '#include <common>',
      '#include <clipping_planes_pars_fragment>',
      'void main() {',
      '  #include <normal_fragment_maps>',
      '  #include <emissivemap_fragment>',
      '  #include <opaque_fragment>',
      '  #include <tonemapping_fragment>',
      '  #include <colorspace_fragment>',
      '  #include <fog_fragment>',
      '  #include <dithering_fragment>',
      '}',
    ].join('\n'),
  };
}

function compiled(opts) {
  const mat = new THREE.MeshStandardMaterial();
  const uniforms = applyCaveMineral(mat, opts);
  const shader = fakeShader();
  mat.onBeforeCompile(shader);
  return { mat, uniforms, shader };
}

test('the module loads at all (guards the template-literal backtick trap)', () => {
  assert.equal(typeof applyCaveMineral, 'function');
  assert.ok(MINERAL_DEFAULTS.cragStrength > 0);
});

test('applying it installs an onBeforeCompile hook and flags a rebuild', () => {
  const mat = new THREE.MeshStandardMaterial();
  mat.needsUpdate = false;
  applyCaveMineral(mat);
  assert.equal(typeof mat.onBeforeCompile, 'function');
});

test('rim-only fallback preserves the edge cue without noise, pow, or texture samples', () => {
  const mat = new THREE.MeshStandardMaterial();
  const uniforms = applyCaveRim(mat, { rimCurve: 'quartic', rimStrength: 0.4 });
  const shader = fakeShader();
  mat.onBeforeCompile(shader);

  assert.equal(shader.uniforms.uRimStrength.value, 0.4);
  assert.match(shader.fragmentShader, /uniform vec3 uRimColor;/);
  assert.match(shader.fragmentShader, /uniform float uRimStrength;/);
  assert.match(shader.fragmentShader, /float rim2 = rimBase \* rimBase; float rim = rim2 \* rim2;/);
  assert.match(shader.fragmentShader,
    /outgoingLight \+= diffuseColor\.rgb \* uRimColor \* rim \* uRimStrength/);
  assert.ok(shader.fragmentShader.indexOf('outgoingLight += diffuseColor.rgb * uRimColor')
    < shader.fragmentShader.indexOf('#include <opaque_fragment>'));
  assert.doesNotMatch(shader.fragmentShader, /gl_FragColor\.rgb \+= uRimColor/);
  assert.doesNotMatch(shader.vertexShader + shader.fragmentShader,
    /lmFbm2|lmNoise|texture2D|uCrag|uEmber|\bpow\s*\(/);

  const linearMat = new THREE.MeshStandardMaterial();
  applyCaveRim(linearMat, { rimCurve: 'linear' });
  const linearShader = fakeShader();
  linearMat.onBeforeCompile(linearShader);
  assert.match(linearShader.fragmentShader, /float rim = rimBase;/);
});

test('every uniform the GLSL reads is actually declared', () => {
  const { uniforms, shader } = compiled();
  const declared = new Set(Object.keys(shader.uniforms));
  const used = new Set(
    [...shader.fragmentShader.matchAll(/\bu[A-Z]\w*/g)].map((m) => m[0]),
  );
  for (const name of used) {
    assert.ok(declared.has(name), `GLSL reads ${name} but no uniform supplies it`);
  }
  // and the bag we handed back is the same one the shader got
  for (const k of Object.keys(uniforms)) assert.equal(shader.uniforms[k], uniforms[k]);
});

test('crag, baked embers and pre-fog rim are injected without fragment FBM', () => {
  const { shader } = compiled();
  const f = shader.fragmentShader;
  assert.match(f, /uCragStrength/, 'crag');
  assert.doesNotMatch(f, /lmFbm2\(/, 'no fragment FBM');
  assert.match(f, /texture2D\(uEmberMask, emberUv\)/, 'one baked ember sample');
  assert.match(f, /vLmWorld\.x \* 0\.73 \+ vLmWorld\.z \* 0\.19/, 'world projection');
  assert.match(f, /uRimStrength/, 'rim');
  assert.match(f, /outgoingLight \+= diffuseColor\.rgb \* uRimColor \* rim \* uRimStrength/);
  assert.ok(f.indexOf('outgoingLight += diffuseColor.rgb * uRimColor')
    < f.indexOf('#include <opaque_fragment>'));
  assert.doesNotMatch(f, /gl_FragColor\.rgb \+= uRimColor/);
  // each injection must keep the chunk it hooks, or three's own code is lost
  for (const chunk of ['<normal_fragment_maps>', '<emissivemap_fragment>', '<opaque_fragment>', '<dithering_fragment>', '<common>']) {
    assert.ok(f.includes(`#include ${chunk}`), `dropped #include ${chunk}`);
  }
});

test('ember-disabled mineral variant compiles without an ember sampler or texture fetch', () => {
  const { shader, uniforms } = compiled({ emberEnabled: false });
  assert.doesNotMatch(shader.fragmentShader, /uEmberMask|emberUv|texture2D\(uEmberMask/);
  assert.equal(uniforms.uEmberMask, undefined);
  assert.match(shader.fragmentShader, /uRimStrength/);
  assert.match(shader.fragmentShader, /vLmCrag/);
});

test('the world-position varying is declared in both stages and written once', () => {
  const { shader } = compiled();
  assert.match(shader.vertexShader, /varying vec3 vLmWorld;/);
  assert.match(shader.fragmentShader, /varying vec3 vLmWorld;/);
  assert.match(shader.vertexShader, /vLmWorld = \(modelMatrix \* vec4\(transformed, 1\.0\)\)\.xyz;/);
});

test('the crag term uses no vertex-stage-only uniform', () => {
  // normalMatrix is declared for the vertex shader only; reaching for it in the
  // fragment stage is a compile error that no unit test would otherwise see.
  const { shader } = compiled();
  const frag = shader.fragmentShader;
  for (const vertexOnly of ['normalMatrix', 'modelViewMatrix', 'position', 'normalScale']) {
    const inInjected = frag.split('#include <common>')[1] || '';
    assert.ok(!new RegExp(`\\b${vertexOnly}\\b`).test(inInjected.split('void main')[0] || ''),
      `fragment stage reaches for ${vertexOnly}`);
  }
  assert.match(frag, /viewMatrix \* vec4\(g, 0\.0\)/, 'gradient is rotated into view space');
});

test('options override the defaults and reach the uniforms', () => {
  const { uniforms } = compiled({ cragStrength: 0.11, emberStrength: 7, rimPower: 2 });
  assert.equal(uniforms.uCragStrength.value, 0.11);
  assert.equal(uniforms.uEmberStrength.value, 7);
  assert.equal(uniforms.uRimPower.value, 2);
  // untouched ones keep their default
  assert.equal(uniforms.uCragScale.value, MINERAL_DEFAULTS.cragScale);
});

test('rim and mineral hooks target real Three standard and Lambert shader chunks', () => {
  for (const [kind, apply, options] of [
    ['standard', applyCaveMineral, { emberEnabled: false }],
    ['lambert', applyCaveRim, { rimCurve: 'quartic' }],
  ]) {
    const material = kind === 'standard'
      ? new THREE.MeshStandardMaterial() : new THREE.MeshLambertMaterial();
    apply(material, options);
    const lib = THREE.ShaderLib[kind];
    const shader = {
      uniforms: {}, vertexShader: lib.vertexShader, fragmentShader: lib.fragmentShader,
    };
    assert.ok(shader.fragmentShader.includes('#include <opaque_fragment>'));
    material.onBeforeCompile(shader);
    const f = shader.fragmentShader;
    assert.equal((f.match(/outgoingLight \+= diffuseColor\.rgb \* uRimColor \* rim \* uRimStrength/g) || []).length, 1);
    assert.ok(f.indexOf('outgoingLight += diffuseColor.rgb * uRimColor')
      < f.indexOf('#include <opaque_fragment>'));
    assert.ok(f.indexOf('#include <opaque_fragment>') < f.indexOf('#include <tonemapping_fragment>'));
    assert.ok(f.indexOf('#include <tonemapping_fragment>') < f.indexOf('#include <fog_fragment>'));
    assert.doesNotMatch(f.split('#include <fog_fragment>')[1], /uRimColor/);
  }
});

test('landmark surface projection reaches the albedo-bound rim before opaque output', () => {
  const mat = new THREE.MeshStandardMaterial({ vertexColors: true });
  applyCaveMineral(mat, { emberEnabled: false });
  applyLandmarkSurface(mat, { family: 'branching' });
  const shader = {
    uniforms: {},
    vertexShader: THREE.ShaderLib.standard.vertexShader,
    fragmentShader: THREE.ShaderLib.standard.fragmentShader,
  };
  mat.onBeforeCompile(shader);
  const f = shader.fragmentShader;
  assert.ok(f.indexOf('diffuseColor.rgb = mix(diffuseColor.rgb, landmarkSurface')
    < f.indexOf('outgoingLight += diffuseColor.rgb * uRimColor'));
  assert.ok(f.indexOf('outgoingLight += diffuseColor.rgb * uRimColor')
    < f.indexOf('#include <opaque_fragment>'));
  assert.doesNotMatch(f, /outgoingLight \+= uRimColor \* rim/,
    'the rim must carry surface albedo, not constant grey light');
});

test('colour options become THREE.Color instances', () => {
  const { uniforms } = compiled({ emberColor: 0x112233 });
  assert.ok(uniforms.uEmberColor.value.isColor);
  assert.equal(uniforms.uEmberColor.value.getHex(), 0x112233);
  assert.ok(uniforms.uRimColor.value.isColor);
});

test('the two-octave noise helpers live in the vertex stage only', () => {
  const { vertexShader: v, fragmentShader: f } = compiled().shader;
  assert.ok(v.indexOf('float lmFbm2') < v.indexOf('lmFbm2(wp'));
  assert.match(v, /for \(int i = 0; i < 2; i\+\+\)/);
  assert.doesNotMatch(f, /float lmNoise|lmFbm2\(/);
});

test('GLSL braces balance in both stages', () => {
  const { shader } = compiled();
  for (const [name, src] of [['vertex', shader.vertexShader], ['fragment', shader.fragmentShader]]) {
    const open = (src.match(/\{/g) || []).length;
    const close = (src.match(/\}/g) || []).length;
    assert.equal(open, close, `${name} shader braces unbalanced`);
  }
});

test('speed warp composes with mineral shader and bounds offscreen vertices', () => {
  const mat = new THREE.MeshStandardMaterial();
  applyCaveMineral(mat);
  const speed = applySpeedWarp(mat);
  const shader = fakeShader();
  shader.vertexShader = shader.vertexShader.replace(
    '#include <begin_vertex>', '#include <begin_vertex>\n#include <project_vertex>');
  mat.onBeforeCompile(shader);
  assert.equal(shader.uniforms.uSpeedWarp, speed);
  assert.match(shader.vertexShader, /min\(dot\(speedNdc, speedNdc\), 2\.0\)/);
  assert.match(shader.vertexShader, /float lmFbm2/);
});

test('baked ember mask is deterministic, sparse and non-empty', () => {
  const a = makeEmberMask(64, 1234);
  const b = makeEmberMask(64, 1234);
  assert.deepEqual(a, b);
  let lit = 0;
  for (let i = 0; i < a.length; i += 4) if (a[i] > 8) lit++;
  assert.ok(lit > 10, 'mask has warm pockets');
  assert.ok(lit < 64 * 64 * 0.13, 'pockets stay sparse');
});

test('cave facet shader bounds its single generated sample to the near field and composes with warp', () => {
  const mat = new THREE.MeshBasicMaterial();
  const strength = applyCaveFacet(mat);
  applySpeedWarp(mat);
  const shader = fakeShader();
  shader.fragmentShader = shader.fragmentShader.replace(
    '#include <normal_fragment_maps>', '#include <normal_fragment_maps>\n#include <color_fragment>');
  shader.vertexShader = shader.vertexShader.replace(
    '#include <begin_vertex>', '#include <begin_vertex>\n#include <project_vertex>');
  mat.onBeforeCompile(shader);
  assert.equal(shader.uniforms.uCaveFacetStrength, strength);
  assert.equal(shader.uniforms.uCaveDetailMap, strength.detailMap);
  assert.equal(shader.uniforms.uCaveDetailStrength, strength.detailStrength);
  assert.equal((shader.fragmentShader.match(/uniform float uCaveFacetStrength;/g) || []).length, 1);
  assert.match(shader.vertexShader, /varying float vCaveFacet;/);
  assert.match(shader.vertexShader, /#ifdef CAVE_FACET[\s\S]*varying float vCaveFacet/);
  assert.match(shader.vertexShader, /#ifdef CAVE_DETAIL_MAPS/);
  assert.match(shader.vertexShader, /attribute float coilingCrest;/);
  assert.match(shader.vertexShader, /vCaveCoilingCrest = coilingCrest;/);
  assert.match(shader.vertexShader, /#ifdef CAVE_COILING_RIM[\s\S]*attribute float coilingCrest/);
  assert.match(shader.vertexShader, /floor\(abs\(caveWorld\) \* 1\.37\)/);
  assert.match(shader.vertexShader, /vCaveFacet = fract\(dot\(caveCell/);
  assert.doesNotMatch(shader.vertexShader, /attribute vec2 uv;/,
    'Three owns the built-in uv declaration; injecting it again breaks WebGL compilation');
  assert.match(shader.fragmentShader, /floor\(vCaveFacet \* 8\.0\)/);
  assert.match(shader.fragmentShader, /#ifdef CAVE_FACET[\s\S]*float caveWarm/);
  assert.match(shader.fragmentShader, /float facetShade = 0\.38 \+ 0\.72 \* facet2;/);
  assert.match(shader.vertexShader,
    /#if defined\(CAVE_FACET\) && defined\(CAVE_SURFACE_ARRAY\)[\s\S]*varying vec3 vCaveFaceWorld/);
  assert.match(shader.vertexShader, /vCaveFaceWorld = caveWorld/);
  assert.match(shader.fragmentShader,
    /#ifdef CAVE_SURFACE_ARRAY[\s\S]*cross\(dFdx\(vCaveFaceWorld\), dFdy\(vCaveFaceWorld\)\)/);
  assert.match(shader.fragmentShader, /diffuseColor\.rgb \*= 0\.84 \+ 0\.20 \* caveFaceKey/);
  assert.match(shader.fragmentShader, /#ifdef CAVE_COILING_RIM[\s\S]*float caveCoilingRim/);
  assert.match(shader.fragmentShader,
    /outgoingLight \*= 1\.0 \+ 0\.35 \* caveCoilingRim/,
    'the sampler-free C3 crest modulates the graded wall before fog');
  assert.ok(shader.fragmentShader.indexOf('outgoingLight *= 1.0 + 0.35')
    < shader.fragmentShader.indexOf('#include <opaque_fragment>'));
  assert.doesNotMatch(shader.fragmentShader, /facet2 \* facet2/,
    'facet contrast must not return to the near-black fourth-power ramp');
  assert.match(shader.fragmentShader, /float caveWarm = max\(diffuseColor\.r - diffuseColor\.b, 0\.0\)/);
  assert.equal((shader.fragmentShader.match(/texture2D\(uCaveDetailMap/g) || []).length, 1);
  assert.match(shader.fragmentShader, /#ifdef CAVE_DETAIL_MAPS/,
    'software fallback can compile the complete colour-detail path out');
  assert.match(shader.fragmentShader,
    /#if defined\(CAVE_DETAIL_MAPS\) \|\| defined\(CAVE_RELIEF_MAPS\)[\s\S]*varying vec2 vCaveDetailUv/,
    'the shared relief UV must remain declared when the array surface replaces the legacy detail map');
  assert.match(shader.fragmentShader, /vCaveDetailFade > 0\.001/);
  assert.match(shader.vertexShader, /smoothstep\(14\.0, 32\.0, distance\(caveWorld, cameraPosition\)\)/);
  assert.match(shader.vertexShader,
    /#if defined\(CAVE_DETAIL_MAPS\) \|\| defined\(CAVE_RELIEF_MAPS\)[\s\S]*vCaveDetailUv = uv/);
  assert.doesNotMatch(shader.fragmentShader, /normalize|\bpow\s*\(/);
  assert.match(shader.vertexShader, /uSpeedWarp/);
});

test('face-key and crest hooks are compatible with the real Three basic shader', () => {
  const mat = new THREE.MeshBasicMaterial();
  applyCaveFacet(mat);
  const shader = {
    uniforms: {},
    vertexShader: THREE.ShaderLib.basic.vertexShader,
    fragmentShader: THREE.ShaderLib.basic.fragmentShader,
  };
  mat.onBeforeCompile(shader);
  const f = shader.fragmentShader;
  assert.equal((f.match(/dFdx\(vCaveFaceWorld\)/g) || []).length, 1);
  assert.match(f, /#if defined\(CAVE_FACET\) && defined\(CAVE_SURFACE_ARRAY\)/);
  assert.ok(f.indexOf('outgoingLight *= 1.0 + 0.35') < f.indexOf('#include <opaque_fragment>'));
  assert.ok(f.indexOf('#include <opaque_fragment>') < f.indexOf('#include <fog_fragment>'));
  assert.doesNotMatch(f.split('#include <fog_fragment>')[1], /caveCoilingRim/);
});
