import { test } from 'node:test';
import assert from 'node:assert/strict';

import { buildReferenceBlades } from '../src/core/landmarks/families/blades.js';
import { slabHullForPiece } from '../src/core/landmarks/SlabHull.js';
import { hash2, mulberry32 } from '../src/core/landmarks/rng.js';
import { LANDMARK_MAX_PIECES, pieceSafe } from '../src/core/landmarks/safety.js';
import { buildCompositionAccums } from '../src/render/landmarks/LandmarkMeshBuilder.js';
import { Game } from '../src/core/Game.js';
import { compositionAt, roomZ } from '../src/core/Landmarks.js';
import { queryNearestSurface } from '../src/core/SurfaceQuery.js';
import { pathFrameAt, tubeRadiusAt } from '../src/core/FlightPath.js';

const INNER = 3, OUTER = 20.24, WALL = 22;
const build = (seed) => buildReferenceBlades(mulberry32(seed), 0, 0, 0, INNER, OUTER, WALL);

function endpoints(piece) {
  const h = piece.length / 2;
  return [-1, 1].map((s) => ({
    x: piece.cx + s * piece.dx * h,
    y: piece.cy + s * piece.dy * h,
    z: piece.cz + s * piece.dz * h,
  }));
}

function distance(a, b) {
  return Math.hypot(a.x - b.x, a.y - b.y, a.z - b.z);
}

function capsuleDistance(x, y, z, piece) {
  const [a, b] = endpoints(piece);
  const dx = b.x - a.x, dy = b.y - a.y, dz = b.z - a.z;
  const t = Math.max(0, Math.min(1, ((x - a.x) * dx + (y - a.y) * dy
    + (z - a.z) * dz) / (dx * dx + dy * dy + dz * dz)));
  return Math.hypot(x - a.x - t * dx, y - a.y - t * dy, z - a.z - t * dz);
}

function projectedArea(crystal, cameraZ = null, firstTriangle = 0,
  triangleCount = crystal.i.length / 3) {
  let area = 0;
  for (let triangle = firstTriangle * 3;
    triangle < (firstTriangle + triangleCount) * 3; triangle += 3) {
    const points = [0, 1, 2].map((offset) => {
      const at = crystal.i[triangle + offset] * 3;
      const depth = cameraZ == null ? 1 : crystal.p[at + 2] - cameraZ;
      return [crystal.p[at] / depth, crystal.p[at + 1] / depth];
    });
    area += Math.abs((points[1][0] - points[0][0]) * (points[2][1] - points[0][1])
      - (points[1][1] - points[0][1]) * (points[2][0] - points[0][0])) / 2;
  }
  return area;
}

test('the fractured grammar is deterministic and has five visually dominant anchors', () => {
  assert.deepEqual(build(256), build(256));
  assert.notDeepEqual(build(256), build(257));
  for (let seed = 1; seed <= 64; seed++) {
    const pieces = build(seed);
    assert.equal(pieces.length, 18, `seed ${seed}`);
    assert.ok(pieces.length <= LANDMARK_MAX_PIECES);
    assert.deepEqual([1, 2, 3].map((tier) => pieces.filter((p) => p.tier === tier).length),
      [5, 8, 5]);
    assert.deepEqual(pieces.map((p) => p.gid), pieces.map((_, i) => i),
      'one consecutive orbit-addressable draw range per plate');
    const radii = [1, 2, 3].map((tier) => pieces.filter((p) => p.tier === tier)
      .map((p) => p.radius));
    assert.ok(Math.max(...radii[0]) + 0.6 < Math.min(...radii[1]),
      'small fractures have a distinct silhouette scale');
    assert.ok(Math.max(...radii[1]) + 1.1 < Math.min(...radii[2]),
      'five anchors are substantially heavier than every middle plate');
  }
});

test('three unequal banks remain depth-distinct and overlap in the approach image', () => {
  for (let seed = 1; seed <= 64; seed++) {
    const pieces = build(seed);
    const banks = [0, 1, 2].map((bank) => pieces.filter((p) => p.bank === bank));
    assert.deepEqual(banks.map((bank) => bank.length), [7, 6, 5]);
    assert.deepEqual(banks.map((bank) => bank.filter((p) => p.tier === 3).length), [2, 2, 1]);
    const centers = banks.map((bank) => bank[0].bankZ);
    assert.ok(centers[1] - centers[0] >= 33 && centers[1] - centers[0] <= 43);
    assert.ok(centers[2] - centers[1] >= 35 && centers[2] - centers[1] <= 45);
    const allZs = pieces.flatMap((piece) => endpoints(piece).map((point) => point.z));
    const span = Math.max(...allZs) - Math.min(...allZs);
    assert.ok(span >= 76 && span <= 100, `seed ${seed}: ${span.toFixed(2)} m depth span`);
    const cameraZ = Math.min(...allZs) - 45;
    const projected = banks.map((bank) => {
      const intervals = bank.flatMap((piece) => endpoints(piece).map((point) => {
        const depth = point.z - cameraZ, radius = Math.hypot(point.x, point.y);
        return [(radius - piece.radius) / depth, (radius + piece.radius) / depth];
      }));
      return { min: Math.min(...intervals.map((i) => i[0])),
        max: Math.max(...intervals.map((i) => i[1])) };
    });
    for (let bank = 0; bank < 2; bank++) {
      const overlap = Math.min(projected[bank].max, projected[bank + 1].max)
        - Math.max(projected[bank].min, projected[bank + 1].min);
      assert.ok(overlap >= 0.10, `seed ${seed}: depth layers ${bank}/${bank + 1}`);
    }
  }
});

test('each bank shares a wall sector with differently directed, asymmetrically rolled ends', () => {
  for (let seed = 1; seed <= 64; seed++) {
    for (let bank = 0; bank < 3; bank++) {
      const layer = build(seed).filter((p) => p.bank === bank);
      const anchors = layer.filter((piece) => piece.tier === 3);
      for (const piece of layer.filter((member) => member.tier < 3)) {
        assert.ok(anchors.some((anchor) =>
          distance(endpoints(piece)[0], endpoints(anchor)[0])
            < 1.6 * (piece.radius + anchor.radius)),
        `seed ${seed}, bank ${bank}: secondary plate must share an anchor wall sector`);
      }
      const azimuths = layer.map((piece) => {
        const [base] = endpoints(piece);
        return (Math.atan2(base.y, base.x) + 2 * Math.PI) % (2 * Math.PI);
      }).sort((a, b) => a - b);
      const gaps = azimuths.map((value, i) => azimuths[(i + 1) % azimuths.length]
        + (i === azimuths.length - 1 ? 2 * Math.PI : 0) - value);
      assert.ok(Math.max(...gaps) >= Math.PI / 2,
        `seed ${seed}, bank ${bank}: intentional open sector`);
      assert.ok(new Set(layer.map((p) => p.roll.toFixed(4))).size >= layer.length - 1);
      assert.ok(layer.some((p) => p.orbitTwist < 0) && layer.some((p) => p.orbitTwist > 0));
    }
  }
});

test('the fracture groups share a broad base then diverge through three-dimensional bodies', () => {
  for (let seed = 1; seed <= 128; seed++) {
    for (let bank = 0; bank < 3; bank++) {
      const group = build(seed).filter((piece) => piece.bank === bank);
      const depth = group.map((piece) => piece.cz);
      assert.ok(Math.max(...depth) - Math.min(...depth) < 9.5,
        `seed ${seed}, bank ${bank}: pieces spread into a depth ladder`);
      const anchors = group.filter((piece) => piece.tier === 3);
      if (anchors.length === 2) {
        const [baseA, baseB] = anchors.map((piece) => endpoints(piece)[0]);
        const [tipA, tipB] = anchors.map((piece) => endpoints(piece)[1]);
        const baseDistance = distance(baseA, baseB);
        const tipDistance = distance(tipA, tipB);
        assert.ok(baseDistance < 0.55 * (anchors[0].radius + anchors[1].radius),
          `seed ${seed}, bank ${bank}: dominant plates lack a shared broad wall base`);
        assert.ok(tipDistance > baseDistance + 1.5,
          `seed ${seed}, bank ${bank}: tips still converge into a fan point`);
      }
    }
  }
});

function interiorOverlapStations(piece, other) {
  const hull = piece.slabHull, vertices = hull.vertices;
  const width = [vertices[21] - vertices[0], vertices[22] - vertices[1],
    vertices[23] - vertices[2]];
  const widthLength = Math.hypot(...width);
  const N = width.map((value) => value / widthLength);
  const T = [piece.dx, piece.dy, piece.dz];
  const B = [T[1] * N[2] - T[2] * N[1], T[2] * N[0] - T[0] * N[2],
    T[0] * N[1] - T[1] * N[0]];
  const base = endpoints(piece)[0];
  const origin = [base.x, base.y, base.z];
  const stations = [];
  for (const t of [0.10, 0.25, 0.40, 0.55, 0.70, 0.85]) {
    const axial = t * piece.length, intersections = [];
    for (let i = 0; i < 8; i++) {
      const a = hull.outline[i], b = hull.outline[(i + 1) % 8];
      if (axial >= Math.min(a[0], b[0]) && axial <= Math.max(a[0], b[0])
          && a[0] !== b[0]) {
        intersections.push(a[1] + (b[1] - a[1]) * (axial - a[0]) / (b[0] - a[0]));
      }
    }
    if (intersections.length < 2) continue;
    const low = Math.min(...intersections), high = Math.max(...intersections);
    const halfThickness = piece.radius * (piece.slab.baseThickness
      + (piece.slab.tipThickness - piece.slab.baseThickness) * t) / 2;
    let found = false;
    for (const u of [0.1, 0.3, 0.5, 0.7, 0.9]) for (const w of [-0.6, 0, 0.6]) {
      const across = low + (high - low) * u;
      const point = [0, 1, 2].map((axis) => origin[axis] + T[axis] * axial
        + N[axis] * across + B[axis] * halfThickness * w);
      let inside = true;
      for (let face = 0; face < other.slabHull.planes.length; face += 4) {
        const planes = other.slabHull.planes;
        if (planes[face] * point[0] + planes[face + 1] * point[1]
            + planes[face + 2] * point[2] - planes[face + 3] > 1e-7) {
          inside = false; break;
        }
      }
      if (inside) { found = true; break; }
    }
    if (found) stations.push(t);
  }
  return stations;
}

test('live fracture groups interlock along their bodies, including the five anchors', () => {
  for (const [seed, k] of [[2024, 9], [256, 9], [4096, 9], [2024, 2]]) {
    const game = new Game();
    game.start({ mode: 2, seed, family: 'crystal' });
    game.cave.generateThrough(roomZ(k) + 120);
    const comp = compositionAt(seed, game.cave, k, 'crystal');
    for (let bank = 0; bank < 3; bank++) {
      const group = comp.pieces.filter((piece) => piece.bank === bank);
      let bodyPairs = 0, anchorPairs = 0;
      for (let i = 0; i < group.length; i++) for (let j = i + 1; j < group.length; j++) {
        const a = interiorOverlapStations(group[i], group[j]);
        const b = interiorOverlapStations(group[j], group[i]);
        if (!a.some((t) => t >= 0.25 && t <= 0.70)
            && !b.some((t) => t >= 0.25 && t <= 0.70)) continue;
        if (a.length < 2 && b.length < 2) continue;
        bodyPairs++;
        if (group[i].tier === 3 || group[j].tier === 3) anchorPairs++;
      }
      assert.ok(bodyPairs >= 1 && anchorPairs >= 1,
        `seed ${seed}, room ${k}, bank ${bank}: no extended anchor-body overlap`);
    }
  }
});

test('blade wall mapping preserves authored proportions and tube reserve across live rooms', () => {
  for (const [seed, k] of [
    ...Array.from({ length: 64 }, (_, index) => [index + 1, 2]),
    [2024, 9], [256, 9], [4096, 9],
  ]) {
    const game = new Game();
    game.start({ mode: 2, seed, family: 'crystal' });
    game.cave.generateThrough(roomZ(k) + 120);
    const comp = compositionAt(seed, game.cave, k, 'crystal');
    const rng = mulberry32(hash2(seed, k));
    rng();
    const authored = buildReferenceBlades(rng, 0, 0, 0,
      comp.inner, comp.outer, comp.clearance);
    assert.equal(comp.pieces.length, authored.length);
    for (const piece of comp.pieces) {
      const source = authored[piece.gid], scale = piece.liveWallScale;
      assert.ok(Number.isFinite(scale) && scale > 0);
      assert.ok(Math.abs(piece.radius / source.radius - scale) < 1e-8);
      assert.ok(Math.abs(piece.localLength / source.length - scale) < 1e-8);
      assert.ok(Math.abs((piece.length / piece.radius)
        / (source.length / source.radius) - 1) < 0.015,
      `seed ${seed}, room ${k}, gid ${piece.gid}: world plate lost authored proportions`);
      const localTip = {
        x: piece.local.cx + piece.local.dx * piece.localLength / 2,
        y: piece.local.cy + piece.local.dy * piece.localLength / 2,
      };
      assert.ok(Math.hypot(localTip.x, localTip.y) <= piece.wallRadiusTip + 1e-6,
        `seed ${seed}, room ${k}, gid ${piece.gid}: scaled tip crossed live wall`);
      const vertices = piece.slabHull.vertices;
      for (let i = 0; i < vertices.length; i += 3) {
        const z = vertices[i + 2], frame = pathFrameAt(seed, z);
        const dx = vertices[i] - frame.center.x;
        const dy = vertices[i + 1] - frame.center.y;
        const dz = z - frame.center.z;
        const x = dx * frame.right.x + dy * frame.right.y + dz * frame.right.z;
        const y = dx * frame.up.x + dy * frame.up.y + dz * frame.up.z;
        assert.ok(Math.hypot(x, y) - tubeRadiusAt(z, seed) > 1,
          `seed ${seed}, room ${k}, gid ${piece.gid}: visible vertex entered ship tube`);
      }
    }
  }
});

test('every shared hull stays in its unchanged safety capsule and clears the flight tube', () => {
  for (let seed = 1; seed <= 64; seed++) for (const piece of build(seed)) {
    assert.ok(pieceSafe(piece, 0, 0, INNER, WALL), `seed ${seed}: unsafe capsule`);
    assert.equal(piece.wallRooted, true);
    const [base, tip] = endpoints(piece);
    assert.ok(Math.hypot(base.x, base.y) <= OUTER + 1e-9);
    assert.ok(Math.hypot(base.x, base.y) + piece.radius >= WALL);
    assert.ok(Math.hypot(tip.x, tip.y) - piece.radius >= INNER + 1.0);
    const hull = slabHullForPiece(piece);
    assert.equal(hull.vertices.length / 3, 18);
    assert.equal(hull.triangles.length / 3, 32);
    const tipEdge = Math.hypot(...[0, 1, 2].map((axis) =>
      hull.vertices[4 * 3 + axis] - hull.vertices[3 * 3 + axis]));
    if (piece.tier === 3) assert.ok(tipEdge >= 2.2,
      'dominant plates have a visibly broken-off, broad end instead of a needle tip');
    assert.ok(piece.slab.rootOverhang > 0);
    assert.notEqual(piece.slab.baseLeft, piece.slab.baseRight);
    assert.ok(piece.slab.baseThickness > piece.slab.tipThickness);
    for (let i = 0; i < hull.vertices.length; i += 3) {
      const x = hull.vertices[i], y = hull.vertices[i + 1], z = hull.vertices[i + 2];
      assert.ok(capsuleDistance(x, y, z, piece) <= piece.radius + 1e-8);
      assert.ok(Math.hypot(x, y) >= INNER - 1e-8,
        `seed ${seed}, gid ${piece.gid}: hull crossed no-entry tube`);
    }
  }
});

test('the renderer consumes precisely the Core hull positions at uniform orbit cost', () => {
  for (const seed of [1, 256, 2024, 4096]) {
    const pieces = build(seed);
    const { rock, crystal } = buildCompositionAccums({
      typeName: 'crystal', cx: 0, cy: 0, inner: INNER, clearance: WALL, pieces,
    });
    assert.ok(rock.empty());
    assert.equal(crystal.vcount(), 18 * 80, 'independent fracture facets duplicate the shared 18 positions');
    assert.equal(crystal.i.length / 3, 18 * 32);
    for (let plate = 0; plate < pieces.length; plate++) {
      const hull = slabHullForPiece(pieces[plate]);
      for (let vertex = plate * 80; vertex < (plate + 1) * 80; vertex++) {
        const at = vertex * 3;
        let found = false;
        for (let hv = 0; hv < hull.vertices.length; hv += 3) {
          if (Math.hypot(crystal.p[at] - hull.vertices[hv],
            crystal.p[at + 1] - hull.vertices[hv + 1],
            crystal.p[at + 2] - hull.vertices[hv + 2]) <= 1e-9) { found = true; break; }
        }
        assert.ok(found, `seed ${seed}, gid ${plate}: renderer-only vertex`);
      }
    }
  }
});

test('fewer plates retain substantial actual Hero and A45 projected mass', () => {
  for (let seed = 1; seed <= 64; seed++) {
    const pieces = build(seed);
    const { crystal } = buildCompositionAccums({
      typeName: 'crystal', cx: 0, cy: 0, inner: INNER, clearance: WALL, pieces,
    });
    const heroMass = projectedArea(crystal);
    assert.ok(heroMass >= 1600, `seed ${seed}: ${heroMass.toFixed(1)} m2 Hero projection`);
    const zs = crystal.p.filter((_, i) => i % 3 === 2);
    const a45Mass = projectedArea(crystal, Math.min(...zs) - 45);
    assert.ok(a45Mass >= 0.245, `seed ${seed}: ${a45Mass.toFixed(3)} A45 projection`);
    const tierAreas = [1, 2, 3].map((tier) => pieces.flatMap((piece, index) =>
      piece.tier === tier ? [projectedArea(crystal, null, index * 32, 32)] : []));
    const means = tierAreas.map((areas) => areas.reduce((sum, area) => sum + area, 0) / areas.length);
    assert.ok(means[1] >= means[0] * 1.40,
      `seed ${seed}: medium forms must carry more real projected area than chips`);
    assert.ok(means[2] >= means[1] * 1.24,
      `seed ${seed}: five anchors must dominate in actual rendered silhouette`);
  }
});

function signedWallOffset(cave, seed, hull, corner) {
  const i = corner * 3;
  const point = [hull.vertices[i], hull.vertices[i + 1], hull.vertices[i + 2]];
  const wall = queryNearestSurface(cave, point, 0, []).wall;
  assert.ok(wall, 'the complete live cave has triangles beside each plate');
  const frame = pathFrameAt(seed, point[2]);
  const rx = wall.qx - frame.center.x;
  const ry = wall.qy - frame.center.y;
  const rz = wall.qz - frame.center.z;
  const radialLength = Math.hypot(rx, ry, rz);
  assert.ok(radialLength > 0);
  return ((point[0] - wall.qx) * rx + (point[1] - wall.qy) * ry
    + (point[2] - wall.qz) * rz) / radialLength;
}

test('every live plate visibly crosses the exact wall mesh at its broad root', () => {
  for (const [seed, k] of [[2024, 9], [256, 9], [4096, 9], [2024, 2]]) {
    const game = new Game();
    game.start({ mode: 2, seed, family: 'crystal' });
    game.cave.generateThrough(roomZ(k) + 120);
    const comp = compositionAt(seed, game.cave, k, 'crystal');
    assert.equal(comp.pieces.length, 18);
    for (const piece of comp.pieces) {
      const hull = piece.slabHull;
      assert.ok(hull, 'world-mapped plate caches its shared visible body');
      if (piece.tier === 3) {
        const frame = pathFrameAt(seed, roomZ(k) + piece.local.cz);
        const routeFacing = Array.from({ length: 8 }, (_, facet) => {
          const at = facet * 4;
          return Math.abs(hull.planes[at] * frame.tangent.x
            + hull.planes[at + 1] * frame.tangent.y + hull.planes[at + 2] * frame.tangent.z);
        }).reduce((sum, value) => sum + value, 0) / 8;
        assert.ok(routeFacing >= 0.84,
          `seed ${seed}, gid ${piece.gid}: dominant broad face turns edge-on (${routeFacing.toFixed(3)})`);
      }
      const rootOut = Math.max(...[0, 7, 8, 15].map((corner) =>
        signedWallOffset(game.cave, seed, hull, corner)));
      const tipIn = Math.min(...[3, 4, 11, 12].map((corner) =>
        signedWallOffset(game.cave, seed, hull, corner)));
      assert.ok(rootOut > 0.06,
        `seed ${seed}, gid ${piece.gid}: visible broad root misses real wall by ${rootOut.toFixed(3)} m`);
      assert.ok(tipIn < -1.5,
        `seed ${seed}, gid ${piece.gid}: plate does not re-enter the room`);
    }
  }
});
