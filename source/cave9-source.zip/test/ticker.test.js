// RunTicker — the fixed-timestep accumulator that used to be written inline in
// three separate step loops. Run with: npm test

import { test } from 'node:test';
import assert from 'node:assert/strict';

import { RunTicker, MAX_STEPS_PER_FRAME } from '../src/app/RunTicker.js';

const DT = 1 / 60;
const counter = () => { const c = { n: 0 }; c.step = () => { c.n++; }; return c; };

test('a frame worth of time runs exactly one step', () => {
  const t = new RunTicker(DT), c = counter();
  assert.equal(t.advance(DT, c.step), 1);
  assert.equal(c.n, 1);
});

test('a partial frame runs nothing but keeps the time', () => {
  const t = new RunTicker(DT), c = counter();
  assert.equal(t.advance(DT * 0.4, c.step), 0);
  assert.equal(c.n, 0);
  // the leftover is not lost: two more partial frames add up to a whole step
  t.advance(DT * 0.4, c.step);
  assert.equal(t.advance(DT * 0.4, c.step), 1);
  assert.equal(c.n, 1);
});

test('three frames of time run three steps', () => {
  const t = new RunTicker(DT), c = counter();
  assert.equal(t.advance(DT * 3, c.step), 3);
});

test('a long stall is capped so the sim never spirals catching up', () => {
  const t = new RunTicker(DT), c = counter();
  assert.equal(t.advance(10, c.step), MAX_STEPS_PER_FRAME);
  assert.equal(c.n, MAX_STEPS_PER_FRAME);
});

test('stopping early leaves that step time unspent', () => {
  const t = new RunTicker(DT);
  let calls = 0;
  // stop on the 2nd step of a 3-step frame
  const ran = t.advance(DT * 3, () => { calls++; return calls === 2 ? false : true; });
  assert.equal(ran, 1, 'only the first step counted');
  assert.equal(calls, 2, 'the stopping step still ran');
  // one step was consumed, the stopping step's time and the third remain
  assert.ok(Math.abs(t.accumulator - DT * 2) < 1e-12,
    `expected 2 steps of time left, got ${t.accumulator / DT}`);
});

test('a step that returns undefined keeps going (only false stops)', () => {
  const t = new RunTicker(DT);
  let n = 0;
  assert.equal(t.advance(DT * 3, () => { n++; }), 3);
  assert.equal(n, 3);
});

test('reset() drops the pending time', () => {
  const t = new RunTicker(DT), c = counter();
  t.advance(DT * 0.9, c.step);
  assert.ok(t.accumulator > 0);
  t.reset();
  assert.equal(t.accumulator, 0);
  assert.equal(t.advance(DT * 0.5, c.step), 0, 'the dropped time does not come back');
});

test('the step budget is configurable', () => {
  const t = new RunTicker(DT, 2), c = counter();
  assert.equal(t.advance(DT * 10, c.step), 2);
});
