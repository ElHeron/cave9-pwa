import { test } from 'node:test';
import assert from 'node:assert/strict';

import { FOG_END } from '../src/core/constants.js';
import { sightMul, SPEED_REFERENCE_DEPTH } from '../src/core/Difficulty.js';
import { VISIBILITY, visibilityAt } from '../src/render/VisibilityProfile.js';

test('visibility uses the exact difficulty sight distance in corridors', () => {
  const sight = sightMul(SPEED_REFERENCE_DEPTH);
  const v = visibilityAt({ sight, room: 0, readability: true });
  assert.equal(v.far, FOG_END * sight);
  assert.ok(v.far > 270 && v.far < 272);
  assert.equal(v.near, VISIBILITY.corridorNear);
});

test('visibility keeps growing after the 15 km reference point', () => {
  assert.ok(sightMul(30000) > sightMul(SPEED_REFERENCE_DEPTH));
});

test('room haze only closes visibility and brightness cannot extend it', () => {
  const corridor = visibilityAt({ sight: 2, room: 0 });
  const room = visibilityAt({ sight: 2, room: 1 });
  assert.equal(room.far, corridor.far * VISIBILITY.roomFarScale);
  assert.equal(room.near, VISIBILITY.roomNear);
  assert.ok(!('brightness' in room));
});
