// Difficulty curve — proves the scaling is intentional and monotonic, with no
// hidden unfair peaks, and that the reaction window (the fairness lever) never
// collapses. Run with: npm test
import { test } from 'node:test';
import assert from 'node:assert/strict';

import {
  speedMul, forwardSpeedAt, sightMul, scoreMul,
  reactionWindow, difficultyAt, tierAt,
  SPEED_FLOOR_MUL, SIGHT_FLOOR_MUL, SCORE_MAX_MUL, SPEED_RAMP_DEPTH,
  SPEED_RAMP_STEPS, SPEED_RAMP_STEP_LEN, SPEED_PLATEAU_FRAC,
  SPEED_STEP_START, SPEED_STEP_LEN, SPEED_STEP_GAIN,
  SPEED_REFERENCE_DEPTH, SPEED_REFERENCE_MUL,
} from '../src/core/Difficulty.js';
import { VELOCITY, FOG_END } from '../src/core/constants.js';

const depths = Array.from({ length: 200 }, (_, i) => i * 100); // 0..19900 m

function assertMonotonic(fn, { increasing }) {
  let prev = fn(depths[0]);
  for (const d of depths.slice(1)) {
    const v = fn(d);
    if (increasing) assert.ok(v >= prev - 1e-9, `expected non-decreasing at ${d}: ${v} < ${prev}`);
    else assert.ok(v <= prev + 1e-9, `expected non-increasing at ${d}: ${v} > ${prev}`);
    prev = v;
  }
}

test('speed alternates exact plateaus and monotone linear ramps without waves', () => {
  assert.equal(speedMul(0), 1);
  let prev = speedMul(0);
  for (let d = 100; d <= SPEED_STEP_START; d += 100) {
    assert.ok(speedMul(d) >= prev - 1e-9); prev = speedMul(d);
  }
  assert.ok(Math.abs(speedMul(SPEED_RAMP_DEPTH) - SPEED_FLOOR_MUL) < 1e-9);

  for (let step = 0; step < SPEED_RAMP_STEPS; step++) {
    const from = step * SPEED_RAMP_STEP_LEN;
    const expected = 1 + (SPEED_FLOOR_MUL - 1) * step / SPEED_RAMP_STEPS;
    assert.equal(speedMul(from), expected);
    for (const fraction of [0.001, 0.1, 0.5, 0.8]) {
      assert.equal(speedMul(from + SPEED_RAMP_STEP_LEN * fraction), expected,
        `early plateau ${step} changed at ${(fraction * 100).toFixed(4)}%`);
    }
    assert.ok(Math.abs(speedMul(from + SPEED_RAMP_STEP_LEN * SPEED_PLATEAU_FRAC) - expected) < 1e-12);
    const gain = (SPEED_FLOOR_MUL - 1) / SPEED_RAMP_STEPS;
    assert.ok(Math.abs(speedMul(from + SPEED_RAMP_STEP_LEN * 0.90) - (expected + gain / 3)) < 1e-9);
    assert.ok(Math.abs(speedMul(from + SPEED_RAMP_STEP_LEN * 0.95) - (expected + gain * 2 / 3)) < 1e-9);
    assert.ok(Math.abs(speedMul(from + SPEED_RAMP_STEP_LEN)
      - (expected + gain)) < 1e-9);
  }
  assert.equal(speedMul(SPEED_RAMP_DEPTH + 999.999), SPEED_FLOOR_MUL,
    'the floor-speed plateau must continue to the deep staircase');

  for (let step = 0; step <= 20; step++) {
    const boundary = SPEED_STEP_START + step * SPEED_STEP_LEN;
    const expected = SPEED_FLOOR_MUL + SPEED_STEP_GAIN * step;
    assert.ok(Math.abs(speedMul(boundary) - expected) < 1e-9,
      `step ${step} must begin at ${expected.toFixed(2)}×`);
    for (const fraction of [0.001, 0.1, 0.5, 0.8]) {
      assert.equal(speedMul(boundary + SPEED_STEP_LEN * fraction), expected,
        `deep plateau ${step} changed at ${(fraction * 100).toFixed(4)}%`);
    }
    assert.ok(Math.abs(speedMul(boundary + SPEED_STEP_LEN * SPEED_PLATEAU_FRAC) - expected) < 1e-12);
    assert.ok(Math.abs(speedMul(boundary + SPEED_STEP_LEN * 0.90)
      - (expected + SPEED_STEP_GAIN / 3)) < 1e-9);
    assert.ok(Math.abs(speedMul(boundary + SPEED_STEP_LEN * 0.95)
      - (expected + SPEED_STEP_GAIN * 2 / 3)) < 1e-9);
    assert.ok(Math.abs(speedMul(boundary + SPEED_STEP_LEN) - (expected + SPEED_STEP_GAIN)) < 1e-9,
      `deep boundary ${step + 1} must arrive at the next plateau`);
  }
  assert.ok(Math.abs(speedMul(SPEED_REFERENCE_DEPTH) - SPEED_REFERENCE_MUL) < 1e-9);
  assert.ok(speedMul(SPEED_REFERENCE_DEPTH + 100000) > SPEED_REFERENCE_MUL + 10,
    'the staircase must never acquire a later ceiling');
});

test('sight follows speed after the tube floor', () => {
  assert.equal(sightMul(0), 1);
  assert.ok(Math.abs(sightMul(SPEED_RAMP_DEPTH) - SIGHT_FLOOR_MUL) < 1e-9);
  for (let d = SPEED_STEP_START; d <= 20000; d += 137) {
    assert.ok(Math.abs(sightMul(d) / speedMul(d) - SIGHT_FLOOR_MUL / SPEED_FLOOR_MUL) < 1e-9);
  }
});

test('forwardSpeedAt is the single absolute-speed conversion', () => {
  for (const d of [0, 849, 900, 1000, 8000, 9000, 10020, 10110, 15000]) {
    assert.equal(forwardSpeedAt(d), VELOCITY * speedMul(d));
  }
});

test('score multiplier ramps 1→SCORE_MAX_MUL monotonically', () => {
  assert.equal(scoreMul(0), 1);
  assertMonotonic(scoreMul, { increasing: true });
  assert.ok(scoreMul(1e9) <= SCORE_MAX_MUL + 1e-9);
});

test('reaction window never collapses — fairness floor holds at every depth', () => {
  // sight and speed ramp together, so seconds-of-warning stays in a tight band.
  const surface = FOG_END / VELOCITY;
  let min = Infinity, max = 0;
  for (const d of depths) {
    const rw = reactionWindow(d);
    min = Math.min(min, rw); max = Math.max(max, rw);
  }
  assert.ok(min > 3.0, `reaction window floor too low: ${min.toFixed(2)}s`);
  // the window must not drift far from the surface value (no creeping unfairness)
  assert.ok(Math.abs(max - surface) < 0.5 && Math.abs(min - surface) < 0.6,
    `reaction window drifted: ${min.toFixed(2)}..${max.toFixed(2)} vs surface ${surface.toFixed(2)}`);
});

test('difficultyAt bundles consistent, finite values', () => {
  for (const d of [0, 1000, 5000, 20000]) {
    const x = difficultyAt(d);
    for (const k of Object.keys(x)) {
      if (typeof x[k] === 'number') assert.ok(Number.isFinite(x[k]), `${k} non-finite at ${d}`);
    }
    assert.equal(x.speed, VELOCITY * speedMul(d));
  }
});

test('tiers advance with depth and never regress', () => {
  const order = ['CRUISE', 'DESCENT', 'TIGHT', 'DEEP', 'ABYSS'];
  let lastIdx = 0;
  for (const d of depths) {
    const idx = order.indexOf(tierAt(d));
    assert.ok(idx >= lastIdx, `tier regressed at ${d}`);
    lastIdx = idx;
  }
  assert.equal(tierAt(0), 'CRUISE');
  assert.equal(tierAt(20000), 'ABYSS');
});

test('negative/garbage depth is clamped to the surface, never NaN', () => {
  assert.equal(speedMul(-100), 1);
  assert.ok(Number.isFinite(difficultyAt(-1).reactionWindow));
});
