import { test } from 'node:test';
import assert from 'node:assert/strict';
import { DAILY_RULES, RULE_PROFILE_VERSION, normalizeRunRules, isNormalizedRunRules } from '../src/core/RunRules.js';

test('Daily profile is versioned and uses the fixed scored rules', () => {
  assert.equal(RULE_PROFILE_VERSION, 1);
  assert.deepEqual(DAILY_RULES, {
    controlMode: 2, thrustScale: 1, landmarks: true, key: 'r1-m2-t1-l1',
  });
  assert.equal(Object.isFrozen(DAILY_RULES), true);
});

test('profile identity includes every applied scoring option without rounding thrust', () => {
  const baseline = normalizeRunRules({ controlMode: 2, sensitivity: 1, landmarks: true });
  const changedMode = normalizeRunRules({ controlMode: 1, sensitivity: 1, landmarks: true });
  const changedThrust = normalizeRunRules({ controlMode: 2, sensitivity: 1 + Number.EPSILON, landmarks: true });
  const changedObstacles = normalizeRunRules({ controlMode: 2, sensitivity: 1, landmarks: false });
  assert.equal(new Set([baseline.key, changedMode.key, changedThrust.key, changedObstacles.key]).size, 4);
  assert.equal(isNormalizedRunRules(changedThrust), true);
  assert.equal(isNormalizedRunRules({ ...baseline, key: changedMode.key }), false);
});
