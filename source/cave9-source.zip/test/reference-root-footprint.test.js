import { test } from 'node:test';
import assert from 'node:assert/strict';

import { Game } from '../src/core/Game.js';
import { compositionAt, roomZ } from '../src/core/Landmarks.js';
import { pathFrameAt, tubeRadiusAt } from '../src/core/FlightPath.js';
import { queryNearestSurface } from '../src/core/SurfaceQuery.js';
import { growTubeForm } from '../src/render/landmarks/LandmarkMeshBuilder.js';
import { MeshAccum } from '../src/render/landmarks/MeshAccum.js';

const sub = (a, b) => a.map((v, i) => v - b[i]);
const dot = (a, b) => a.reduce((v, x, i) => v + x * b[i], 0);
const cross = (a, b) => [a[1] * b[2] - a[2] * b[1],
  a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
const length = (v) => Math.hypot(...v);

function distanceToCapsule(point, p) {
  const h = p.length / 2;
  const a = [p.cx - p.dx * h, p.cy - p.dy * h, p.cz - p.dz * h];
  const b = [p.cx + p.dx * h, p.cy + p.dy * h, p.cz + p.dz * h];
  const ab = sub(b, a);
  const t = Math.max(0, Math.min(1, dot(sub(point, a), ab) / dot(ab, ab)));
  return length(sub(point, a.map((v, i) => v + ab[i] * t)));
}

function routeReserve(seed, point, radius, inner) {
  const frame = pathFrameAt(seed, point[2]);
  const delta = sub(point, [frame.center.x, frame.center.y, frame.center.z]);
  return Math.hypot(dot(delta, [frame.right.x, frame.right.y, frame.right.z]),
    dot(delta, [frame.up.x, frame.up.y, frame.up.z]))
    - radius - Math.max(inner, tubeRadiusAt(point[2], seed));
}

test('wall-rooted shoulders are exact Core footprints with embedded, unfolded mesh seams', () => {
  for (const seed of [2024, 256, 4096]) {
    const game = new Game();
    game.start({ mode: 2, seed, family: 'branching' });
    game.cave.generateThrough(roomZ(9) + 120);
    const comp = compositionAt(seed, game.cave, 9, 'branching');
    assert.ok(comp);
    for (let gid = 0; gid < 3; gid++) {
      const form = comp.pieces.filter((p) => p.gid === `root-tree-${gid}`)
        .sort((a, b) => a.node - b.node);
      const root = form[0];
      const label = `${seed}/${gid}`;
      assert.equal(form.length, 8, `${label}: complete claw`);
      assert.equal(root.wallFootprint?.length, 16, `${label}: no point-contact fallback`);
      assert.equal(root.wallFootprintSurface?.length, 16);
      assert.ok(root.wallFootprintScale >= 0.7, `${label}: wide shoulder`);
      assert.ok(root.wallFootprintInset > 0 && root.wallFootprintInset <= 0.4);

      const h = root.length / 2;
      for (const q of [
        [root.cx - root.dx * h, root.cy - root.dy * h, root.cz - root.dz * h],
        [root.cx, root.cy, root.cz],
        [root.cx + root.dx * h, root.cy + root.dy * h, root.cz + root.dz * h],
      ]) assert.ok(routeReserve(seed, q, root.radius, comp.inner) > 0.05,
        `${label}: enlarged capsule remains outside flight tube`);

      for (let j = 0; j < 16; j++) {
        const contact = root.wallFootprintSurface[j];
        const embedded = root.wallFootprint[j];
        assert.ok(queryNearestSurface(game.cave, [contact.x, contact.y, contact.z])
          .wall.surfaceDistance < 1e-6, `${label}/${j}: exact live triangle`);
        assert.ok(Math.abs(length(sub([embedded.x, embedded.y, embedded.z],
          [contact.x, contact.y, contact.z])) - root.wallFootprintInset) < 1e-6,
        `${label}/${j}: directed finite embed`);
        assert.ok(distanceToCapsule([embedded.x, embedded.y, embedded.z], root)
          <= root.radius + 1e-6, `${label}/${j}: Core capsule covers contact`);
      }

      const mesh = new MeshAccum();
      growTubeForm(mesh, comp, form, 'limb', root.shade);
      const at = (i) => mesh.p.slice(i * 3, i * 3 + 3);
      const first = Array.from({ length: 16 }, (_, i) => at(i));
      const second = Array.from({ length: 16 }, (_, i) => at(i + 17));
      const axisA = [root.cx - root.dx * h, root.cy - root.dy * h, root.cz - root.dz * h];
      const axisB = [root.cx + root.dx * h, root.cy + root.dy * h, root.cz + root.dz * h];
      const axis = sub(axisB, axisA);
      const axisRadial = (point) => {
        const t = Math.max(0, Math.min(1, dot(sub(point, axisA), axis) / dot(axis, axis)));
        return sub(point, axisA.map((v, i) => v + axis[i] * t));
      };
      for (const point of first) {
        assert.ok(root.wallFootprint.some((p) =>
          length(sub(point, [p.x, p.y, p.z])) < 1e-7), `${label}: renderer uses Core contact`);
      }
      for (let j = 0; j < 16; j++) {
        const a = first[j], b = at(j + 1), c = second[j], d = at(j + 18);
        const triangles = [mesh.i.slice(j * 6, j * 6 + 3).map(at),
          mesh.i.slice(j * 6 + 3, j * 6 + 6).map(at)];
        const [n0, n1] = triangles.map(tri => cross(sub(tri[1], tri[0]), sub(tri[2], tri[0])));
        assert.ok(dot(n0, n1) > 0 && length(n0) > 0.01 && length(n1) > 0.01,
          `${label}/${j}: no folded transition quad`);
        for (const [index, tri] of triangles.entries()) {
          const normal = [n0, n1][index];
          const mid = tri[0].map((v, i) => (v + tri[1][i] + tri[2][i]) / 3);
          assert.ok(dot(normal, axisRadial(mid)) > 0,
            `${label}/${j}: transition faces outward`);
          for (const weights of [[1 / 3, 1 / 3, 1 / 3], [0.5, 0.5, 0],
            [0.5, 0, 0.5], [0, 0.5, 0.5], [0.6, 0.2, 0.2]]) {
            const sample = tri[0].map((_, i) => tri.reduce((v, point, k) =>
              v + point[i] * weights[k], 0));
            assert.ok(comp.collisionPieces.some((p) =>
              distanceToCapsule(sample, p) <= p.radius + 1e-5),
            `${label}/${j}: entire transition is represented by collision`);
          }
        }
        for (const t of [0.25, 0.5, 0.75]) {
          const edge = a.map((v, i) => v * (1 - t) + b[i] * t);
          const wall = queryNearestSurface(game.cave, edge).wall;
          const frame = pathFrameAt(seed, edge[2]);
          const delta = sub(edge, [frame.center.x, frame.center.y, frame.center.z]);
          const rx = dot(delta, [frame.right.x, frame.right.y, frame.right.z]);
          const ry = dot(delta, [frame.up.x, frame.up.y, frame.up.z]);
          const norm = Math.hypot(rx, ry);
          const radial = [
            (frame.right.x * rx + frame.up.x * ry) / norm,
            (frame.right.y * rx + frame.up.y * ry) / norm,
            (frame.right.z * rx + frame.up.z * ry) / norm,
          ];
          assert.ok(dot(sub(edge, [wall.qx, wall.qy, wall.qz]), radial) >= -0.001,
            `${label}/${j}: contact seam stays embedded between vertices`);
        }
      }
    }
  }
});
