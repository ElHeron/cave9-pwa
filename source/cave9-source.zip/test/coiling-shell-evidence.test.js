import { readFile } from 'node:fs/promises';
import { test } from 'node:test';
import assert from 'node:assert/strict';

import {
  COILING_SHELL_APPROACHES,
  coilingHeroDifferenceCheck, coilingHeroOffControlScenario, coilingHeroScenario,
  coilingShellFramingCheck, coilingShellInspectionDepth,
  coilingShellSuiteDefinition,
} from '../scripts/visual/coiling-shell-config.mjs';
import {
  COILING_VISIBLE_RELIEF_STRENGTH, coilingAxialStrengthAtDepth, coilingVisibleFrontDepth,
} from '../src/core/CoilingShell.js';
import { styleAt } from '../src/core/Difficulty.js';
import { buildCoilingShellReport, coilingShellReportHtml } from '../scripts/visual/coiling-shell-report.mjs';
import {
  coilingShellAuthorityChecks, exactCoilingShellMatrix,
} from '../scripts/visual/coiling-shell-verification.mjs';

const contract = {
  version: 'coiling-shell-v2', seed: 2024, roomIndex: 9,
  start: 9045, end: 9225, span: 180, turns: 1.3, ridgeStrength: 8.4,
  channelCount: 2, secondaryScale: 0.45, handedness: 1, phase: 0.4,
  shoulderWidth: 1.6, halfWidth: 0.72,
};

const authority = {
  contract,
  identity: {
    requestedFamily: 'coiling', gameFamilyOverride: 'coiling', caveFamilyOverride: 'coiling',
    compositionType: 'coiling', surfaceResident: true,
  },
  rings: {
    sectorCount: 32, count: 90, firstDepth: 9045.4, lastDepth: 9224.9,
    monotonic: true, uniqueDepths: true, minimumDepthStep: 2, maximumDepthStep: 2,
    minimumShipClearReserve: 0.53, minimumBooleanReserve: 1.53,
    fingerprint: '12abcdef', sha256: 'a'.repeat(64),
    fullCaveFingerprint: '34abcdef', fullCaveSha256: 'b'.repeat(64),
    bounds: { minX: -20, minY: -20, minZ: 9045, maxX: 20, maxY: 20,
      maxZ: 9225, vertexCount: 90 * 32 },
  },
  geometryCounts: { pieces: 0, collisionPieces: 0, landmarkMeshes: 0,
    landmarkTriangles: 0, collisionCapsuleObjects: 0 },
  atlas: { version: 1, ringCount: 90, sectorCount: 32, landmarkCount: 0,
    sourceRingFingerprint: '12abcdef' },
  runtime: { appState: 'capture', gamePhase: 'running', glErrors: [] },
  runtimeErrors: [],
};

test('Coiling shell evidence exposes an exact hard matrix and truthfully blocks fake 3D shell cameras', () => {
  const suite = coilingShellSuiteDefinition();
  assert.equal(suite.name, 'coiling-shell-evidence');
  assert.equal(suite.room, 9);
  assert.deepEqual(suite.approaches, [100, 70, 45, 25]);
  assert.equal(suite.templates.length, 8);
  assert.deepEqual(suite.templates.filter((entry) => entry.kind === 'hero')
    .map((entry) => entry.approachMeters), COILING_SHELL_APPROACHES);
  assert.equal(suite.capabilities.shellOrbit.supported, false);
  assert.match(suite.capabilities.shellOrbit.reason, /LandmarkLayer/);
  assert.equal(suite.capabilities.shellOrthographic3d.supported, false);
  assert.equal(suite.templates.filter((entry) => entry.kind.startsWith('atlas-')).length, 3);
  assert.equal(suite.templates.filter((entry) => entry.kind === 'boolean-reserve').length, 1);
});

test('Hero scenarios resolve from the first visible shell relief and force Coiling before prime', () => {
  const template = coilingShellSuiteDefinition().templates.find((entry) => entry.approachMeters === 70);
  const scenario = coilingHeroScenario(template, contract);
  const visibleFront = coilingVisibleFrontDepth(contract);
  assert.equal(scenario.distance, +(visibleFront - 70).toFixed(3));
  assert.ok(visibleFront > contract.start);
  assert.ok(coilingAxialStrengthAtDepth(visibleFront, contract) >= COILING_VISIBLE_RELIEF_STRENGTH - 1e-8);
  assert.ok(coilingAxialStrengthAtDepth(visibleFront - 0.001, contract) < COILING_VISIBLE_RELIEF_STRENGTH);
  assert.equal(scenario.captureOptions.family, 'coiling');
  assert.equal(scenario.captureOptions.placement, 'place');
  assert.equal(scenario.captureOptions.camera, 'hero');
  assert.equal(scenario.captureOptions.viewport.width, 1280);
  assert.ok(styleAt(scenario.distance) > 0.99,
    'reference-form evidence must use the mature visual progression, not the black first-room look');
  assert.throws(() => coilingHeroScenario({ kind: 'atlas-unwrapped' }, contract), /Hero template/);
  assert.throws(() => coilingHeroScenario(template, {}), /contract bounds/);
  const control = coilingHeroOffControlScenario(scenario);
  assert.equal(control.captureOptions.family, 'off');
  assert.equal(control.captureOptions.settings.landmarks, false);
  assert.equal(control.captureOptions.distance, scenario.captureOptions.distance);
  assert.throws(() => coilingHeroOffControlScenario({ kind: 'atlas-unwrapped' }), /Hero scenario/);
});

test('Coiling Hero difference requires broad circumferential wall deformation', () => {
  const useful = { pass: true, fraction: 0.08, meanChangedDelta: 0.12,
    bbox: { widthFraction: 0.9, heightFraction: 0.8, touchesEdge: true },
    angularBinCount: 12, quadrantCount: 4, radialBinCount: 4 };
  assert.equal(coilingHeroDifferenceCheck(45, useful).pass, true);
  assert.equal(coilingHeroDifferenceCheck(45, { ...useful, fraction: 0.001 }).pass, false);
  assert.equal(coilingHeroDifferenceCheck(45, { ...useful, angularBinCount: 4 }).pass, false);
  assert.equal(coilingHeroDifferenceCheck(25, { ...useful,
    bbox: { ...useful.bbox, widthFraction: 0.5 } }).pass, false);
  const onset = coilingHeroDifferenceCheck(100, {});
  assert.equal(onset.pass, true);
  assert.equal(onset.required, false);
  assert.equal(onset.diagnosticPass, false);
});

test('inspection starts before C3 and a 144-ring two metre live window covers the full contract', () => {
  const inspectionDepth = coilingShellInspectionDepth(contract);
  assert.equal(inspectionDepth, 9043);
  assert.ok(inspectionDepth <= contract.start);
  const firstLiveRing = Math.ceil(inspectionDepth / 2) * 2;
  const lastLiveRing = firstLiveRing + (144 - 1) * 2;
  assert.ok(firstLiveRing <= contract.start,
    `first live ring ${firstLiveRing} must not lose contract start ${contract.start}`);
  assert.ok(lastLiveRing >= contract.end,
    `last live ring ${lastLiveRing} must cover contract end ${contract.end}`);
  assert.throws(() => coilingShellInspectionDepth({}), /contract bounds/);
});

test('framing gates reject blank, tiny and clipped atlas evidence', () => {
  const good = { blank: { pass: true }, luma: { stddev: 0.12 }, foreground: {
    fraction: 0.18, bbox: { widthFraction: 0.8, heightFraction: 0.5, touchesEdge: false },
  } };
  assert.equal(coilingShellFramingCheck('atlas-unwrapped', good).pass, true);
  assert.equal(coilingShellFramingCheck('boolean-reserve', good).pass, true);
  assert.equal(coilingShellFramingCheck('hero', good).pass, true);
  assert.equal(coilingShellFramingCheck('atlas-unwrapped', { ...good,
    foreground: { fraction: 0.001, bbox: good.foreground.bbox } }).pass, false);
  assert.equal(coilingShellFramingCheck('atlas-unwrapped', { ...good,
    foreground: { fraction: 0.18, bbox: { ...good.foreground.bbox, touchesEdge: true } } }).pass, false);
  assert.equal(coilingShellFramingCheck('hero', { ...good, blank: { pass: false } }).pass, false);
});

test('authority checks bind the real ring span, reserve, atlas and zero secondary geometry', () => {
  const checks = coilingShellAuthorityChecks(authority);
  assert.equal(Object.values(checks).every((check) => check.pass), true);
  assert.equal(coilingShellAuthorityChecks({ ...authority,
    geometryCounts: { ...authority.geometryCounts, landmarkMeshes: 1 } }).zeroSecondaryGeometry.pass, false);
  assert.equal(coilingShellAuthorityChecks({ ...authority,
    rings: { ...authority.rings, minimumShipClearReserve: 0.48 } }).booleanReserve.pass, false);
  assert.equal(coilingShellAuthorityChecks({ ...authority,
    identity: { ...authority.identity, caveFamilyOverride: null } }).forcedBeforePrime.pass, false);
  assert.equal(coilingShellAuthorityChecks({ ...authority,
    atlas: { ...authority.atlas, sourceRingFingerprint: 'wrong' } }).atlasAuthority.pass, false);
  assert.equal(coilingShellAuthorityChecks({ ...authority,
    runtimeErrors: ['webglcontextlost'] }).authorityRuntime.pass, false);
});

test('hard matrix rejects missing, duplicate, unexpected and legacy-authority frames', () => {
  const suite = coilingShellSuiteDefinition();
  const frames = suite.templates.map((template) => ({
    id: template.id, kind: template.kind, captureApi: template.captureApi,
    snapshot: template.kind === 'hero' ? { version: 'VisualSnapshotV1' } : undefined,
    ...(template.kind === 'hero' ? {
      control: { file: `frames/${template.id}-control-off.png`, snapshot: {
        version: 'VisualSnapshotV1', family: { requested: 'off', active: [] },
      } },
      difference: { file: `frames/${template.id}-family-diff.png` },
    } : {}),
  }));
  assert.equal(exactCoilingShellMatrix({ suite, frames }).pass, true);
  assert.equal(exactCoilingShellMatrix({ suite, frames: frames.slice(1) }).pass, false);
  assert.equal(exactCoilingShellMatrix({ suite, frames: [...frames, frames[0]] }).pass, false);
  assert.equal(exactCoilingShellMatrix({ suite, frames: frames.map((frame, index) => index
    ? frame : { ...frame, captureApi: 'window.__cave9.captureScenario' }) }).pass, false);
});

test('report preserves capability-blocked truth and links original evidence', () => {
  const suite = coilingShellSuiteDefinition();
  const manifest = {
    runId: 'coiling-test', source: { git: {}, runtime: {} }, suite, authority,
    blockedPasses: [{ pass: 'shellOrbit', status: 'capability-blocked',
      reason: suite.capabilities.shellOrbit.reason }],
    frames: [{ id: 'coiling-atlas-unwrapped', kind: 'atlas-unwrapped',
      file: 'frames/coiling-atlas-unwrapped.png', sourceFile: 'sources/coiling-atlas-unwrapped.svg',
      status: 'pass' }],
  };
  const report = buildCoilingShellReport(manifest);
  const html = coilingShellReportHtml(report);
  assert.equal(report.manualStatus, 'pending');
  assert.match(html, /capability-blocked/);
  assert.match(html, /0 pieces, 0 colliders/);
  assert.match(html, /frames\/coiling-atlas-unwrapped\.png/);
  assert.match(html, /sources\/coiling-atlas-unwrapped\.svg/);
});

test('capture implementation never resolves Coiling through LandmarkLayer geometry or a legacy API', async () => {
  const source = await readFile(new URL('../scripts/visual/coiling-shell-capture.mjs', import.meta.url), 'utf8');
  assert.match(source, /live CaveStream does not contain the Coiling contract span/);
  assert.match(source, /buildCaveAtlas/);
  assert.match(source, /compositionAt/);
  assert.doesNotMatch(source, /__cave9\.captureScenario\s*\(/);
  assert.doesNotMatch(source, /renderOrbitPose\s*\(/);
  assert.doesNotMatch(source, /visibleGeometryBounds/);
});
