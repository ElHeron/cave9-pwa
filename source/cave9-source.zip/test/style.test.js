// styleAt — the original → reference look morph.
//
// The whole point of expressing the morph as ONE scalar derived from depth is
// that it becomes assertable the way sightMul already is. These are the
// properties the rest of the render layer is allowed to rely on.
//
// Run with: npm test

import { test } from 'node:test';
import assert from 'node:assert/strict';

import { styleAt, difficultyAt, STYLE_START, STYLE_FULL } from '../src/core/Difficulty.js';
import { ROOM_START } from '../src/core/constants.js';

test('the original look is untouched for the whole early game', () => {
  // A player must meet cave9 as cave9 first. Nothing about the look may have
  // moved before STYLE_START.
  for (const d of [0, 100, 500, 1500, ROOM_START, STYLE_START]) {
    assert.equal(styleAt(d), 0, `style already moved at ${d} m`);
  }
});

test('the first rooms are still the original look', () => {
  // Rooms exist from ROOM_START (2000 m). The morph deliberately starts later,
  // so the first chambers a player sees are not the moment the look switches.
  assert.ok(STYLE_START > ROOM_START,
    'the morph must not begin before the player has seen a plain room');
  assert.equal(styleAt(ROOM_START), 0);
});

test('it reaches the reference and holds there', () => {
  assert.equal(styleAt(STYLE_FULL), 1);
  for (const d of [STYLE_FULL, STYLE_FULL + 5000, 1e6]) assert.equal(styleAt(d), 1);
});

test('it is monotonically non-decreasing', () => {
  let prev = -1;
  for (let d = 0; d <= STYLE_FULL + 2000; d += 100) {
    const v = styleAt(d);
    assert.ok(v >= prev, `style went backwards at ${d} m (${v} < ${prev})`);
    prev = v;
  }
});

test('it stays in 0..1 for any input, including nonsense', () => {
  for (const d of [-1e6, -1, 0, 1234, 1e9]) {
    const v = styleAt(d);
    assert.ok(v >= 0 && v <= 1, `style ${v} out of range at ${d}`);
  }
});

test('the ramp eases at both ends (no visible seam)', () => {
  // smoothstep: the derivative vanishes at both ends, so the look does not
  // lurch into motion at STYLE_START or stop dead at STYLE_FULL.
  const eps = 60;
  const dStart = styleAt(STYLE_START + eps) - styleAt(STYLE_START);
  const dMid = styleAt((STYLE_START + STYLE_FULL) / 2 + eps)
             - styleAt((STYLE_START + STYLE_FULL) / 2);
  const dEnd = styleAt(STYLE_FULL) - styleAt(STYLE_FULL - eps);
  assert.ok(dStart < dMid, 'ramp should start gently');
  assert.ok(dEnd < dMid, 'ramp should finish gently');
});

test('it crosses the middle inside the ramp, not at an edge', () => {
  const mid = styleAt((STYLE_START + STYLE_FULL) / 2);
  assert.ok(mid > 0.35 && mid < 0.65, `midpoint style ${mid} is lopsided`);
});

test('difficultyAt reports style alongside the other curves', () => {
  const d = difficultyAt(6000);
  assert.equal(d.style, styleAt(6000));
  assert.ok(d.style > 0 && d.style < 1, '6000 m should be mid-morph');
  // and it must not have disturbed its neighbours
  assert.ok(d.speedMul >= 1 && d.sightMul >= 1 && d.scoreMul >= 1);
});

test('style is independent of the difficulty curves it sits beside', () => {
  // They ramp over different depths on purpose: difficulty is a fairness curve,
  // style is an art curve, and tying them would make one hostage to the other.
  assert.notEqual(STYLE_FULL, 8000, 'style should not share the speed ramp depth');
  assert.equal(styleAt(2000), 0);
  assert.ok(difficultyAt(2000).speedMul > 1, 'difficulty is already ramping by then');
});
