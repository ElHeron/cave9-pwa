import { test } from 'node:test';
import assert from 'node:assert/strict';

import { CaveStream } from '../src/core/CaveStream.js';
import {
  COILING_SHELL_VERSION, COILING_TUBE_RESERVE,
  coilingAxialStrengthAtDepth, coilingChannelWeightAt,
  coilingContractForRoom, coilingGridAngleOffsetAtDepth, deformCoilingRadius,
} from '../src/core/CoilingShell.js';
import { Game } from '../src/core/Game.js';
import { compositionAt } from '../src/core/Landmarks.js';
import { pathFrameAt, tubeRadiusAt } from '../src/core/FlightPath.js';
import { queryNearestSurface } from '../src/core/SurfaceQuery.js';
import { ROOM_LEN, ROOM_SPACING, SECTOR_COUNT, SHIP_RADIUS } from '../src/core/constants.js';
import { buildCaveAtlas } from '../src/dev/atlas/model.js';

const ROOM = 2;
const ROOM_CENTRE = ROOM * ROOM_SPACING + ROOM_LEN / 2;

function carve(seed, family) {
  const cave = new CaveStream();
  cave.reset(seed, family);
  cave.prime();
  cave.generateThrough(ROOM_CENTRE + ROOM_LEN / 2 + 40);
  return cave;
}

function orderedRings(cave) {
  return cave.centers.map((center, index) => ({ center, index }))
    .filter(({ center }) => Number.isFinite(center[2]))
    .sort((a, b) => a.center[2] - b.center[2]);
}

function radialInFrame(frame, point) {
  const x = point[0] - frame.center.x;
  const y = point[1] - frame.center.y;
  const z = point[2] - frame.center.z;
  return Math.hypot(
    x * frame.right.x + y * frame.right.y + z * frame.right.z,
    x * frame.up.x + y * frame.up.y + z * frame.up.z,
  );
}

function ringFingerprint(rings) {
  const f32 = new Float32Array(1);
  const u32 = new Uint32Array(f32.buffer);
  let hash = 2166136261 >>> 0;
  for (const ring of rings) for (const point of ring) for (const value of point) {
    f32[0] = value;
    hash = Math.imul(hash ^ u32[0], 16777619) >>> 0;
  }
  return hash;
}

test('C3 v2 ridge parameters are deterministic, seed-varying and bounded', () => {
  const fingerprints = new Set();
  for (let seed = 1; seed <= 100; seed++) {
    const a = coilingContractForRoom(seed, ROOM, 'coiling');
    const b = coilingContractForRoom(seed, ROOM, 'coiling');
    assert.deepEqual(a, b);
    assert.equal(a.version, COILING_SHELL_VERSION);
    assert.ok(a.channelCount === 1 || a.channelCount === 2);
    assert.ok(a.span >= 160 && a.span <= 200);
    assert.ok(a.turns >= 1.1 && a.turns <= 1.5);
    assert.ok(a.ridgeStrength >= 7.6 && a.ridgeStrength <= 9.2);
    assert.ok(a.shoulderWidth >= 1.50 && a.shoulderWidth <= 1.70);
    assert.ok(a.shoulderWidth > a.halfWidth);
    assert.equal(a.secondaryScale, a.channelCount === 2 ? 0.45 : 0);
    assert.ok(a.handedness === -1 || a.handedness === 1);
    assert.equal(a.end - a.start, a.span);
    fingerprints.add(JSON.stringify(a));
  }
  assert.equal(fingerprints.size, 100);
});

test('C3 deforms only its selected span and preserves the existing ring topology exactly', () => {
  for (const seed of [1, 42, 256, 2024, 4096, 424242]) {
    const baseline = carve(seed, 'branching');
    const coiling = carve(seed, 'coiling');
    const contract = coilingContractForRoom(seed, ROOM, 'coiling');
    const baseRings = orderedRings(baseline), coilRings = orderedRings(coiling);
    assert.equal(coiling.count, baseline.count);
    assert.equal(coiling.i, baseline.i);
    assert.equal(coilRings.length, baseRings.length);
    assert.equal(coiling.rng.randval, baseline.rng.randval,
      'C3 must consume the same wall RNG draws as the control');
    assert.equal(coiling.rng.randseed, baseline.rng.randseed);

    let changedVertices = 0;
    for (let i = 0; i < coilRings.length; i++) {
      const a = baseRings[i], b = coilRings[i];
      assert.deepEqual(b.center, a.center);
      assert.equal(coiling.innerRadii[b.index], baseline.innerRadii[a.index]);
      assert.equal(coiling.segs[b.index].length, SECTOR_COUNT);
      if (b.center[2] < contract.start || b.center[2] > contract.end) {
        assert.equal(coiling.ringAngleOffsets[b.index], 0);
        assert.deepEqual(coiling.segs[b.index], baseline.segs[a.index],
          'corridor and non-C3 shoulders remain byte-for-byte unchanged');
      } else {
        assert.equal(coiling.ringAngleOffsets[b.index],
          coilingGridAngleOffsetAtDepth(b.center[2], contract));
        for (let sector = 0; sector < SECTOR_COUNT; sector++) {
          if (!Object.is(coiling.segs[b.index][sector][0], baseline.segs[a.index][sector][0]) ||
              !Object.is(coiling.segs[b.index][sector][1], baseline.segs[a.index][sector][1]) ||
              !Object.is(coiling.segs[b.index][sector][2], baseline.segs[a.index][sector][2])) {
            changedVertices++;
          }
        }
      }
    }
    assert.ok(changedVertices > 100, `seed ${seed}: C3 changes a broad wall region`);
  }
});

test('one or two broad channels carry continuous relief and leave an open wall sector', () => {
  for (const seed of [1, 42, 256, 2024, 4096, 424242]) {
    const c = coilingContractForRoom(seed, ROOM, 'coiling');
    const startAngle = c.phase;
    const endAngle = c.phase + c.handedness * Math.PI * 2 * c.turns;
    assert.equal(Math.sign(endAngle - startAngle), c.handedness);
    if (c.channelCount === 2) {
      const companionStart = startAngle + Math.PI * 0.72;
      const companionEnd = endAngle + Math.PI * 0.72;
      assert.equal(Math.sign(companionEnd - companionStart), c.handedness);
      assert.equal(companionEnd - companionStart, endAngle - startAngle);
      const middleDepth = c.centre;
      const mainAngle = c.phase + c.handedness * Math.PI * 2 * c.turns * 0.5;
      assert.equal(coilingChannelWeightAt(mainAngle + Math.PI * 0.72, middleDepth, c),
        c.secondaryScale, 'the companion remains subordinate to the main crest');
    }

    // A moving ridge has a stable profile through the middle of the chamber.
    // The largest gap between channels remains entirely unpinched, unlike the
    // former ring-wide floor that turned every axial pulse into a narrow bore.
    for (let i = 1; i <= 9; i++) {
      const t = i / 10;
      const depth = c.start + c.span * t;
      const angle = c.phase + c.handedness * Math.PI * 2 * c.turns * t;
      const gapAngle = angle + (c.channelCount === 2
        ? (Math.PI * 2 + Math.PI * 0.72) / 2 : Math.PI);
      assert.ok(Math.abs(coilingAxialStrengthAtDepth(depth, c) - c.ridgeStrength) < 1e-9);
      assert.equal(coilingChannelWeightAt(angle, depth, c), 1);
      assert.equal(coilingChannelWeightAt(gapAngle, depth, c), 0);
      const crestRadii = [12, 16, 20]
        .map((base) => deformCoilingRadius(base, 2, angle, depth, c));
      const protectedRadius = (2 + SHIP_RADIUS + COILING_TUBE_RESERVE)
        / Math.cos(Math.PI / SECTOR_COUNT) + 0.08;
      assert.ok(crestRadii.every((radius) => radius >= protectedRadius + 2.2 - 1e-9),
        'the ridge centre retains real rock above the protected tube');
      assert.ok(Math.max(...crestRadii) - Math.min(...crestRadii) < 1,
        'the full ridge compensates for different chamber-wall radii');
      assert.equal(deformCoilingRadius(16, 2, gapAngle, depth, c), 16);
      assert.ok(coilingChannelWeightAt(angle + c.halfWidth * 0.85, depth, c) > 0,
        'a wide shoulder attaches the inner ridge to the wall');
    }
    assert.equal(deformCoilingRadius(3, 2, c.phase, c.centre, c), 3,
      'a too-thin pre-existing wall is never pushed outward to fake a ridge');
    assert.equal(coilingAxialStrengthAtDepth(c.start, c), 0);
    assert.equal(coilingAxialStrengthAtDepth(c.end, c), 0);
  }
});

test('the first 45 m carries a broad, reference-readable wall arch', () => {
  const seed = 2024;
  const coiling = carve(seed, 'coiling');
  const contract = coilingContractForRoom(seed, ROOM, 'coiling');
  const early = orderedRings(coiling).filter(({ center }) =>
    center[2] >= contract.start + 6 && center[2] <= contract.start + 45);
  let strongRings = 0;
  let broadRings = 0;
  let strongestInset = 0;
  for (const { center, index } of early) {
    const insets = [...coiling.coilingInsets[index]];
    const maximum = Math.max(...insets);
    strongestInset = Math.max(strongestInset, maximum);
    if (maximum >= 6) strongRings++;
    if (insets.filter((value) => value >= 1).length >= 8) broadRings++;
  }
  assert.ok(early.length >= 18, 'two metre cadence supplies enough close-view axial layers');
  assert.ok(strongestInset >= 6, `close-view arch is only ${strongestInset.toFixed(2)}m deep`);
  assert.ok(strongRings >= 7, `only ${strongRings} early rings carry a strong ridge`);
  assert.ok(broadRings >= 7, `only ${broadRings} early rings carry a broad shoulder`);
});

test('submitted local inset follows a travelling ridge through consecutive rings', () => {
  for (const seed of [256, 2024, 4096]) {
    const cave = carve(seed, 'coiling');
    const contract = coilingContractForRoom(seed, ROOM, 'coiling');
    const rings = orderedRings(cave);
    let continuous = 0, open = 0, sampled = 0;
    for (const { center, index } of rings) {
      const depth = center[2];
      const insets = cave.coilingInsets[index];
      if (depth < contract.start || depth > contract.end) {
        assert.ok(insets.every((value) => value === 0),
          'outside C3 the normal corridor carries no ridge inset');
        continue;
      }
      if (depth < contract.start + contract.span * 0.1
        || depth > contract.end - contract.span * 0.1) continue;
      sampled++;
      const protectedRadius = (cave.innerRadii[index] + SHIP_RADIUS + COILING_TUBE_RESERVE)
        / Math.cos(Math.PI / SECTOR_COUNT) + 0.08;
      for (let sector = 0; sector < SECTOR_COUNT; sector++) {
        const radius = radialInFrame(cave.frames[index], cave.segs[index][sector]);
        const free = radius + insets[sector] - protectedRadius;
        assert.ok(insets[sector] <= Math.max(0, free - 2.2) + 2e-6,
          `seed ${seed} depth ${depth} sector ${sector}: ridge consumed its rock reserve`);
      }
      const phase = contract.phase + contract.handedness * Math.PI * 2 * contract.turns
        * ((depth - contract.start) / contract.span);
      const nearMain = insets.filter((_, sector) => {
        const angle = Math.PI / 2 + (sector - 1) * Math.PI * 2 / SECTOR_COUNT
          + cave.ringAngleOffsets[index];
        return Math.abs(Math.atan2(Math.sin(angle - phase), Math.cos(angle - phase))) < 0.36;
      });
      if (Math.max(...nearMain) >= 3) continuous++;
      if (insets.filter((value) => value === 0).length >= 3) open++;
    }
    assert.ok(sampled >= 60);
    assert.ok(continuous >= sampled * 0.8,
      `seed ${seed}: the main ridge breaks across too many depth layers`);
    assert.ok(open >= sampled * 0.8,
      `seed ${seed}: the chamber still pinches almost every ring`);
  }
});

test('the actual 32-sector triangle lattice keeps a connected helical crest', () => {
  for (const seed of [256, 2024, 4096]) {
    const cave = carve(seed, 'coiling');
    const contract = coilingContractForRoom(seed, ROOM, 'coiling');
    const rings = orderedRings(cave).filter(({ center }) =>
      center[2] >= contract.start + contract.span * 0.1
      && center[2] <= contract.end - contract.span * 0.1);
    let connected = 0;
    for (let i = 0; i < rings.length - 1; i++) {
      const a = rings[i], b = rings[i + 1];
      assert.equal(b.center[2] - a.center[2], 2);
      const middle = (a.center[2] + b.center[2]) / 2;
      const phase = contract.phase + contract.handedness * Math.PI * 2 * contract.turns
        * ((middle - contract.start) / contract.span);
      for (let sector = 0; sector < SECTOR_COUNT; sector++) {
        const next = (sector + 1) % SECTOR_COUNT;
        const angle = Math.PI / 2 + (sector - 0.5) * Math.PI * 2 / SECTOR_COUNT
          + (cave.ringAngleOffsets[a.index] + cave.ringAngleOffsets[b.index]) / 2;
        const gap = Math.abs(Math.atan2(Math.sin(angle - phase), Math.cos(angle - phase)));
        if (gap > 0.4) continue;
        // A wall quad becomes the two submitted triangles. Four positive
        // endpoint insets prove that the ridge crosses both triangles, not
        // merely a sequence of isolated inward vertices.
        if ([cave.coilingInsets[a.index][sector], cave.coilingInsets[a.index][next],
          cave.coilingInsets[b.index][sector], cave.coilingInsets[b.index][next]]
          .every((inset) => inset >= 1)) {
          connected++;
          break;
        }
      }
    }
    assert.ok(rings.length >= 60);
    assert.ok(connected >= (rings.length - 1) * 0.95,
      `seed ${seed}: the submitted triangles interrupt the travelling crest`);
  }
});

test('C3 vertex columns follow the main ridge and return smoothly to the corridor grid', () => {
  for (const seed of [256, 2024, 4096]) {
    const room = 9;
    const cave = new CaveStream();
    cave.reset(seed, 'coiling');
    cave.prime();
    cave.generateThrough(room * ROOM_SPACING + ROOM_LEN + 40);
    const control = new CaveStream();
    control.reset(seed, 'branching');
    control.prime();
    control.generateThrough(room * ROOM_SPACING + ROOM_LEN + 40);
    const controlAtDepth = new Map(orderedRings(control).map(({ center, index }) =>
      [center[2], index]));
    assert.equal(cave.rng.randval, control.rng.randval);
    assert.equal(cave.rng.randseed, control.rng.randseed);
    const contract = coilingContractForRoom(seed, room, 'coiling');
    let previous = null, aligned = 0, active = 0, unchanged = 0;
    for (const { center, index } of orderedRings(cave)) {
      const depth = center[2];
      const offset = cave.ringAngleOffsets[index];
      assert.equal(offset, coilingGridAngleOffsetAtDepth(depth, contract));
      if (depth <= contract.start || depth >= contract.end) {
        assert.equal(offset, 0, 'the ordinary corridor keeps its exact original grid');
        assert.deepEqual(cave.segs[index], control.segs[controlAtDepth.get(depth)],
          'the corridor wall outside this C3 span remains byte-for-byte unchanged');
        unchanged++;
      } else {
        active++;
        const t = (depth - contract.start) / contract.span;
        const phase = contract.phase + contract.handedness * Math.PI * 2 * contract.turns * t;
        if (t <= 0.73) {
          assert.ok(Math.abs(phase - offset - contract.phase) < 1e-10,
            'the same moving vertex columns sample the primary crest');
          aligned++;
        }
        for (const sector of [0, 9, 21]) {
          const point = cave.segs[index][sector];
          const frame = cave.frames[index];
          const delta = [point[0] - frame.center.x, point[1] - frame.center.y,
            point[2] - frame.center.z];
          const x = delta[0] * frame.right.x + delta[1] * frame.right.y
            + delta[2] * frame.right.z;
          const y = delta[0] * frame.up.x + delta[1] * frame.up.y
            + delta[2] * frame.up.z;
          const physical = Math.atan2(y, x);
          const expected = Math.PI / 2 + (sector - 1) * Math.PI * 2 / SECTOR_COUNT + offset;
          assert.ok(Math.abs(Math.atan2(Math.sin(physical - expected),
            Math.cos(physical - expected))) < 1e-9,
          'published angle offset matches the real submitted vertex');
        }
      }
      if (previous !== null) {
        const change = Math.abs(Math.atan2(Math.sin(offset - previous),
          Math.cos(offset - previous)));
        assert.ok(change < 0.25, `seed ${seed} depth ${depth}: grid twisted ${change} rad in 2m`);
      }
      previous = offset;
    }
    assert.ok(active >= 80 && aligned >= 55 && unchanged >= 15);
  }
});

test('hero chamber rotating strips keep outward winding and exact triangle clearance', () => {
  for (const seed of [256, 2024, 4096]) {
    const room = 9;
    const cave = new CaveStream();
    cave.reset(seed, 'coiling');
    cave.prime();
    cave.generateThrough(room * ROOM_SPACING + ROOM_LEN + 40);
    const contract = coilingContractForRoom(seed, room, 'coiling');
    const rings = orderedRings(cave).filter(({ center }) =>
      center[2] >= contract.start - 4 && center[2] <= contract.end + 4);
    let winding = null, triangleCount = 0;
    for (let ring = 0; ring < rings.length - 1; ring++) {
      const a = rings[ring], b = rings[ring + 1];
      const depth = (a.center[2] + b.center[2]) / 2;
      const frame = pathFrameAt(seed, depth);
      const centre = [frame.center.x, frame.center.y, frame.center.z];
      const query = queryNearestSurface(cave, centre);
      assert.ok(query.wall.surfaceDistance >=
        tubeRadiusAt(depth, seed) + SHIP_RADIUS + COILING_TUBE_RESERVE + 2.1,
      `seed ${seed}: twisting a strip consumed the full rock/tube reserve at ${depth}m`);
      for (let sector = 0; sector < SECTOR_COUNT; sector++) {
        const next = (sector + 1) % SECTOR_COUNT;
        for (const [p, q, r] of [
          [cave.segs[a.index][sector], cave.segs[b.index][sector], cave.segs[a.index][next]],
          [cave.segs[a.index][next], cave.segs[b.index][sector], cave.segs[b.index][next]],
        ]) {
          const ab = [0, 1, 2].map((axis) => q[axis] - p[axis]);
          const ac = [0, 1, 2].map((axis) => r[axis] - p[axis]);
          const normal = [ab[1] * ac[2] - ab[2] * ac[1],
            ab[2] * ac[0] - ab[0] * ac[2], ab[0] * ac[1] - ab[1] * ac[0]];
          const twiceArea = Math.hypot(...normal);
          const radial = [0, 1, 2].map((axis) =>
            (p[axis] + q[axis] + r[axis]) / 3 - centre[axis]);
          const facing = Math.sign(normal.reduce((sum, value, axis) =>
            sum + value * radial[axis], 0));
          assert.ok(twiceArea > 1, 'each rotating wall triangle retains finite area');
          if (winding === null) winding = facing;
          assert.equal(facing, winding, 'a rotating strip cannot invert its visible face');
          triangleCount++;
        }
      }
    }
    assert.ok(triangleCount >= 5000);
  }
});

test('the main ridge flank changes smoothly along the actual 32-sector triangle strips', () => {
  for (const seed of [256, 2024, 4096]) {
    const room = 9; // fixed visual acceptance chamber, including the A45 view
    const cave = new CaveStream();
    cave.reset(seed, 'coiling');
    cave.prime();
    cave.generateThrough(room * ROOM_SPACING + ROOM_LEN + 40);
    const contract = coilingContractForRoom(seed, room, 'coiling');
    const ringStep = Math.PI * 2 / SECTOR_COUNT;
    const flankSteps = [[], []];
    const previousRadii = [null, null];
    for (const { center, index } of orderedRings(cave)) {
      const depth = center[2];
      if (depth < contract.start + contract.span * 0.1
        || depth > contract.end - contract.span * 0.1) continue;
      const phase = contract.phase + contract.handedness * Math.PI * 2 * contract.turns
        * ((depth - contract.start) / contract.span);
      const radiusAt = (sector) => radialInFrame(cave.frames[index],
        cave.segs[index][((sector % SECTOR_COUNT) + SECTOR_COUNT) % SECTOR_COUNT]);
      for (const [flank, flankOffset] of [0.35, 0.55].entries()) {
        const sectorPosition = (phase + flankOffset - Math.PI / 2
          - cave.ringAngleOffsets[index]) / ringStep + 1;
        const radius = radiusAt(Math.round(sectorPosition));
        if (previousRadii[flank] !== null) {
          flankSteps[flank].push(Math.abs(radius - previousRadii[flank]));
        }
        previousRadii[flank] = radius;
      }
    }
    for (const [flank, steps] of flankSteps.entries()) {
      steps.sort((a, b) => a - b);
      assert.ok(steps.length >= 60);
      const p95 = steps[Math.floor(steps.length * 0.95)];
      assert.ok(p95 <= 1.1,
        `seed ${seed} flank ${flank}: adjacent 2m strips jump ${p95.toFixed(2)}m`);
    }
  }
});

test('the first visible shoulder has no repeated metre-scale triangle tongues', () => {
  for (const seed of [256, 2024, 4096]) {
    const room = 9;
    const cave = new CaveStream();
    cave.reset(seed, 'coiling');
    cave.prime();
    cave.generateThrough(room * ROOM_SPACING + ROOM_LEN + 40);
    const contract = coilingContractForRoom(seed, room, 'coiling');
    const ringStep = Math.PI * 2 / SECTOR_COUNT;
    const rows = orderedRings(cave).filter(({ center }) =>
      center[2] >= contract.start + 10 && center[2] <= contract.start + 55);
    assert.ok(rows.length >= 21, 'the A45 view covers adjacent two-metre wall strips');
    for (const side of [-1.35, 1.35]) {
      const steps = [];
      let previous = null;
      for (const { center, index } of rows) {
        const depth = center[2];
        const phase = contract.phase + contract.handedness * Math.PI * 2 * contract.turns
          * ((depth - contract.start) / contract.span);
        const sectorPosition = (phase + side - Math.PI / 2
          - cave.ringAngleOffsets[index]) / ringStep + 1;
        const sector = ((Math.round(sectorPosition) % SECTOR_COUNT) + SECTOR_COUNT) % SECTOR_COUNT;
        const radius = radialInFrame(cave.frames[index], cave.segs[index][sector]);
        if (previous !== null) steps.push(Math.abs(radius - previous));
        previous = radius;
      }
      steps.sort((a, b) => a - b);
      const p75 = steps[Math.floor(steps.length * 0.75)];
      const p95 = steps[Math.floor(steps.length * 0.95)];
      assert.ok(p75 <= 0.75 && p95 <= 1.15,
        `seed ${seed} shoulder ${side}: successive strips jump ${p75.toFixed(2)}/${p95.toFixed(2)}m`);
    }
  }
});

test('local ridge inset survives ring-buffer growth and clears on family reset', () => {
  const seed = 2024;
  const cave = carve(seed, 'coiling');
  const contract = coilingContractForRoom(seed, ROOM, 'coiling');
  const depth = Math.round(contract.centre / 2) * 2;
  const beforeIndex = cave.centers.findIndex((center) => center[2] === depth);
  assert.ok(beforeIndex >= 0);
  const before = [...cave.coilingInsets[beforeIndex]];
  const beforeAngleOffset = cave.ringAngleOffsets[beforeIndex];
  assert.ok(before.some((value) => value > 0));
  assert.notEqual(beforeAngleOffset, 0);
  cave.ensureCapacityForDistance(1000);
  const afterIndex = cave.centers.findIndex((center) => center[2] === depth);
  assert.ok(afterIndex >= 0);
  assert.deepEqual([...cave.coilingInsets[afterIndex]], before);
  assert.equal(cave.ringAngleOffsets[afterIndex], beforeAngleOffset);
  cave.reset(seed, 'off');
  assert.ok(cave.ringAngleOffsets.every((value) => value === 0));
  cave.prime();
  cave.generateThrough(ROOM_CENTRE + ROOM_LEN / 2 + 40);
  assert.ok(cave.coilingInsets.every((ring) => ring.every((value) => value === 0)),
    'the family-off restart cannot retain an old local ridge');
  assert.ok(cave.ringAngleOffsets.every((value) => value === 0));
});

test('C3 close-view relief fuzz retains complete protected reserve', () => {
  for (let seed = 1; seed <= 32; seed++) {
    const cave = carve(seed, 'coiling');
    const contract = coilingContractForRoom(seed, ROOM, 'coiling');
    const rings = orderedRings(cave).filter(({ center }) =>
      center[2] >= contract.start && center[2] <= contract.end);
    for (const { center, index } of rings) {
      const frame = cave.frames[index];
      const minimum = cave.innerRadii[index] + SHIP_RADIUS + COILING_TUBE_RESERVE;
      for (const point of cave.segs[index]) {
        assert.ok(radialInFrame(frame, point) >= minimum,
          `seed ${seed} depth ${center[2]} lost vertex reserve`);
      }
    }
    for (let i = 0; i < rings.length - 1; i += 7) {
      const depth = (rings[i].center[2] + rings[i + 1].center[2]) / 2;
      const frame = pathFrameAt(seed, depth);
      const query = queryNearestSurface(cave, [frame.center.x, frame.center.y, frame.center.z]);
      assert.ok(query.wall.surfaceDistance >=
        tubeRadiusAt(depth, seed) + SHIP_RADIUS + COILING_TUBE_RESERVE - 0.03,
      `seed ${seed}: exact triangle reserve lost at ${depth.toFixed(1)}m`);
    }
  }
});

test('the exact C3 ring triangles retain tube + ship + reserve clearance', () => {
  for (const seed of [1, 42, 256, 2024, 4096, 424242]) {
    const cave = carve(seed, 'coiling');
    const contract = coilingContractForRoom(seed, ROOM, 'coiling');
    const rings = orderedRings(cave).filter(({ center }) =>
      center[2] >= contract.start && center[2] <= contract.end);
    for (const { center, index } of rings) {
      const frame = cave.frames[index];
      const minimum = cave.innerRadii[index] + SHIP_RADIUS + COILING_TUBE_RESERVE;
      for (const point of cave.segs[index]) {
        assert.ok(radialInFrame(frame, point) >= minimum,
          `seed ${seed}: ring vertex lost the complete protected reserve`);
      }
    }
    for (let i = 0; i < rings.length - 1; i++) {
      const depth = (rings[i].center[2] + rings[i + 1].center[2]) / 2;
      const frame = pathFrameAt(seed, depth);
      const centre = [frame.center.x, frame.center.y, frame.center.z];
      const query = queryNearestSurface(cave, centre);
      assert.ok(query.wall.surfaceDistance >=
        tubeRadiusAt(depth, seed) + SHIP_RADIUS + COILING_TUBE_RESERVE - 0.03,
      `seed ${seed}: exact ring triangle lost the protected reserve at ${depth.toFixed(1)}m`);
    }
  }
});

test('SurfaceQuery, atlas and renderer-order fingerprints agree on the same C3 rings', () => {
  const cave = carve(2024, 'coiling');
  const atlas = buildCaveAtlas({ cave });
  const rendererOrder = Array.from({ length: cave.segs.length }, (_, spatial) =>
    cave.segs[(cave.i + spatial) % cave.segs.length]);
  const atlasOrder = atlas.rings.map((ring) => ring.sectors.map((sector) => sector.world));
  assert.equal(ringFingerprint(rendererOrder), ringFingerprint(atlasOrder));
  for (const ring of atlas.rings.filter((_, i) => i % 17 === 0)) {
    assert.deepEqual(ring.sectors.map((sector) => sector.world), cave.segs[ring.bufferIndex]);
  }
  for (let i = 0; i < atlas.rings.length - 1; i += 17) {
    const lo = atlas.rings[i], hi = atlas.rings[i + 1];
    // SurfaceQuery brackets by world z. On a curved route, choose a submitted
    // triangle whose interior z remains between its two ring-centre depths.
    let world = null;
    for (let sector = 0; sector < SECTOR_COUNT && !world; sector++) {
      const next = (sector + 1) % SECTOR_COUNT;
      const candidate = [0, 1, 2].map((axis) =>
        (lo.sectors[sector].world[axis] + hi.sectors[sector].world[axis]
          + lo.sectors[next].world[axis]) / 3);
      if (candidate[2] >= lo.depth && candidate[2] <= hi.depth) world = candidate;
    }
    assert.ok(world, 'a route-facing triangle remains in the ring depth bracket');
    assert.ok(queryNearestSurface(cave, world).wall.surfaceDistance < 1e-8,
      'SurfaceQuery resolves a point on the exact submitted ring triangle');
  }
});

test('forced C3 is selected before prime and retains identity with zero landmark geometry', () => {
  const seed = 2024; // room 2 is naturally crystal, making the override observable
  const forced = new Game().start({ mode: 2, seed, family: 'coiling' });
  const late = new Game().start({ mode: 2, seed });
  late.landmarkFamilyOverride = 'coiling';
  forced.cave.generateThrough(ROOM_CENTRE + ROOM_LEN / 2 + 40);
  late.cave.generateThrough(ROOM_CENTRE + ROOM_LEN / 2 + 40);

  const forcedHash = ringFingerprint(orderedRings(forced.cave).map(({ index }) => forced.cave.segs[index]));
  const lateHash = ringFingerprint(orderedRings(late.cave).map(({ index }) => late.cave.segs[index]));
  assert.notEqual(forcedHash, lateHash, 'setting an override after prime cannot rewrite old rings');
  assert.equal(forced.cave.landmarkFamilyOverride, 'coiling');

  const comp = compositionAt(seed, forced.cave, ROOM, 'coiling');
  assert.equal(comp.typeName, 'coiling');
  assert.equal(comp.surfaceResident, true);
  assert.equal(comp.coilingContract.version, COILING_SHELL_VERSION);
  assert.deepEqual(comp.pieces, []);
  assert.deepEqual(comp.collisionPieces, []);
});

test('a reused Game clears a forced family on plain start and explicit family:auto', () => {
  const seed = 2024; // naturally crystal in room 2
  const target = ROOM_CENTRE + ROOM_LEN / 2 + 40;
  const fresh = new Game().start({ mode: 2, seed });
  fresh.cave.generateThrough(target);
  const expected = ringFingerprint(orderedRings(fresh.cave).map(({ index }) => fresh.cave.segs[index]));

  const reused = new Game().start({ mode: 2, seed, family: 'coiling' });
  reused.cave.generateThrough(target);
  reused.start({ mode: 2, seed });
  reused.cave.generateThrough(target);
  assert.equal(reused.landmarkFamilyOverride, null);
  assert.equal(reused.cave.landmarkFamilyOverride, null);
  assert.equal(ringFingerprint(orderedRings(reused.cave).map(({ index }) => reused.cave.segs[index])), expected);
  assert.equal(compositionAt(seed, reused.cave, ROOM).typeName, 'crystal');

  reused.start({ mode: 2, seed, family: 'coiling' });
  reused.start({ mode: 2, seed, family: 'auto' });
  reused.cave.generateThrough(target);
  assert.equal(reused.landmarkFamilyOverride, null);
  assert.equal(reused.cave.landmarkFamilyOverride, null);
  assert.equal(ringFingerprint(orderedRings(reused.cave).map(({ index }) => reused.cave.segs[index])), expected);
});

test('family off suppresses a seed-selected Coiling shell before prime', () => {
  const seed = 1; // naturally Coiling in room 2
  const target = ROOM_CENTRE + ROOM_LEN / 2 + 40;
  const automatic = new Game().start({ mode: 2, seed });
  const controlled = new Game().start({ mode: 2, seed, family: 'off' });
  automatic.cave.generateThrough(target);
  controlled.cave.generateThrough(target);

  assert.ok(coilingContractForRoom(seed, ROOM), 'fixture must auto-select Coiling');
  assert.equal(coilingContractForRoom(seed, ROOM, 'off'), null);
  assert.equal(controlled.landmarkFamilyOverride, 'off');
  assert.equal(controlled.cave.landmarkFamilyOverride, 'off');
  assert.equal(compositionAt(seed, controlled.cave, ROOM), null);
  assert.notEqual(
    ringFingerprint(orderedRings(automatic.cave).map(({ index }) => automatic.cave.segs[index])),
    ringFingerprint(orderedRings(controlled.cave).map(({ index }) => controlled.cave.segs[index])),
    'the family-off control must remove surface-resident Coiling geometry',
  );
});
