import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { prototypes, runPrototype } from '../scripts/prototypes/landmark-family-core.mjs';
import { crossSectionSvg, longitudinalSvg, silhouettesSvg } from '../scripts/prototypes/landmark-family-svg.mjs';

test('family prototypes are deterministic and keep browser/render dependencies out', async () => {
  const source = await readFile(new URL('../scripts/prototypes/landmark-family-core.mjs', import.meta.url), 'utf8');
  assert.doesNotMatch(source, /from\s+['"](?:three|canvas|playwright|puppeteer)/i);
  for (const spec of prototypes) {
    assert.equal(runPrototype(spec).document.fingerprint, runPrototype(spec).document.fingerprint, spec.variant);
  }
});

test('recommended R2, B1, and C3 expose honest S1-S8 evidence', () => {
  for (const variant of ['R2', 'B1', 'C3']) {
    const run = runPrototype(prototypes.find((spec) => spec.variant === variant));
    assert.deepEqual(Object.keys(run.metrics).slice(0, 8), ['S1', 'S2', 'S3', 'S4', 'S5', 'S6', 'S7', 'S8']);
    assert.equal(run.metrics.S6.status, 'notEvaluated');
    assert.equal(run.metrics.S7.pass, true);
    assert.equal(run.metrics.S8.pass, true);
    assert.equal(run.metrics.summary.coreGatePass, true, `${variant}: ${JSON.stringify(run.metrics)}`);
  }
});

test('prototype diagrams are structured SVG rather than raster images', () => {
  const run = runPrototype(prototypes[0]);
  for (const svg of [crossSectionSvg(run.result, run.context), longitudinalSvg(run.result, run.context), silhouettesSvg(run.result)]) {
    assert.match(svg, /^<svg /);
    assert.match(svg, /data-family="roots"/);
    assert.doesNotMatch(svg, /<image\b|data:image|\.png|\.jpe?g/i);
  }
});
