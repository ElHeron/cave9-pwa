// Graze / combo scoring — risk/reward invariants (Phase 3B).
// Asserts that the graze bonus and combo are real, bounded, not farmable by
// stalling/pausing, never fire on a crash, and that distance stays raw metres
// independent of score. See SCORING_REPORT.md for the model.
import { test } from 'node:test';
import assert from 'node:assert/strict';

import {
  ScoreSystem, GRAZE_BAND, GRAZE_MAX_RATE,
  COMBO_MAX, COMBO_MULT_MAX, COMBO_GRACE,
} from '../src/core/ScoreSystem.js';
import { TWO_BUTTONS, VELOCITY } from '../src/core/constants.js';

const DT = 1 / 60;
const STEP_M = VELOCITY * DT; // metres advanced per step at base speed

// A minimal ship stand-in for ScoreSystem.update(ship, dt, mode).
function ship(dist, { z = 0, start = 0, speed = VELOCITY } = {}) {
  return { pos: [0, 0, z], start, dist, forwardSpeed: () => speed };
}

// Advance the score `steps` times with a constant wall clearance, moving the
// ship forward each step (so delta > 0). Returns the ScoreSystem.
function fly(score, dist, steps, opts = {}) {
  const advance = opts.advance ?? STEP_M;
  let z = opts.z0 ?? 0;
  for (let i = 0; i < steps; i++) {
    z += advance;
    score.update(ship(dist, { z, speed: opts.speed ?? VELOCITY }), DT, TWO_BUTTONS);
  }
  return score;
}

test('graze accrues only with positive clearance inside the band', () => {
  const near = fly(new ScoreSystem(), 0.4, 60);   // inside GRAZE_BAND (1.5)
  const safe = fly(new ScoreSystem(), 5.0, 60);    // well clear
  assert.ok(near.grazeBonus > 0, 'grazing near the wall should reward');
  assert.equal(safe.grazeBonus, 0, 'a safe-distance run earns no graze');
  assert.ok(near.grazeTime > 0 && safe.grazeTime === 0);
});

test('no graze on a crash frame (clearance == 0)', () => {
  const s = fly(new ScoreSystem(), 0, 60); // dist 0 == wall hit every frame
  assert.equal(s.grazeBonus, 0, 'a hit is never a graze');
  assert.equal(s.grazeActive, false);
});

test('graze is not farmable by stalling (no forward progress)', () => {
  const s = new ScoreSystem();
  // inside the band but the ship never advances (delta == 0)
  for (let i = 0; i < 120; i++) s.update(ship(0.4, { z: 0 }), DT, TWO_BUTTONS);
  assert.equal(s.grazeBonus, 0, 'standing still earns nothing');
  assert.equal(s.grazeActive, false);
});

test('closer to the wall grazes harder', () => {
  const close = fly(new ScoreSystem(), 0.2, 60).grazeBonus;
  const edge = fly(new ScoreSystem(), 1.3, 60).grazeBonus;
  assert.ok(close > edge, `close ${close} should beat near-band ${edge}`);
});

test('combo builds with sustained grazing and is hard-capped', () => {
  const s = fly(new ScoreSystem(), 0.3, 600); // 10 s of continuous grazing
  assert.equal(s.combo, COMBO_MAX, 'combo saturates at COMBO_MAX');
  assert.ok(s.comboMultiplier <= COMBO_MULT_MAX + 1e-9, 'multiplier capped');
  assert.equal(s.comboMultiplier, COMBO_MULT_MAX);
  assert.equal(s.bestCombo, COMBO_MAX);
});

test('combo resets after sustained safe distance', () => {
  const s = fly(new ScoreSystem(), 0.3, 300);    // build a combo
  assert.ok(s.combo > 0);
  // now fly safe for longer than the grace window
  fly(s, 5.0, Math.ceil((COMBO_GRACE / DT)) + 5);
  assert.equal(s.combo, 0, 'safe distance drops the combo');
  assert.equal(s.comboMultiplier, 1);
});

test('breakCombo() resets immediately (pause/interruption)', () => {
  const s = fly(new ScoreSystem(), 0.3, 300);
  assert.ok(s.combo > 0);
  s.breakCombo();
  assert.equal(s.combo, 0);
  assert.equal(s.comboMultiplier, 1);
});

test('no score explosion: graze rate is bounded by cap × combo cap', () => {
  const seconds = 5;
  const s = fly(new ScoreSystem(), 0.05, seconds * 60, { speed: VELOCITY * 1.35 });
  const maxPerSecond = GRAZE_MAX_RATE * COMBO_MULT_MAX;
  assert.ok(s.grazeBonus <= maxPerSecond * seconds + 1,
    `graze ${s.grazeBonus.toFixed(1)} exceeded bound ${maxPerSecond * seconds}`);
});

test('distance stays raw metres, independent of graze score', () => {
  const s = fly(new ScoreSystem(), 0.3, 120);
  const expectedDepth = STEP_M * 120;
  assert.ok(Math.abs(s.distance - expectedDepth) < 1e-6,
    `distance ${s.distance} should equal raw depth ${expectedDepth}`);
  // score (value) includes graze on top of distance points, so it is larger
  assert.ok(s.value() >= Math.floor(s.scored));
  assert.ok(s.grazeBonus > 0);
});

test('telemetry: maxSpeed, closest clearance and maxDanger are tracked', () => {
  const s = new ScoreSystem();
  fly(s, 0.5, 30, { speed: 30 });
  fly(s, 0.2, 30, { speed: 42, z0: 100 }); // closer + faster later
  assert.equal(s.maxSpeed, 42);
  assert.ok(Math.abs(s.closest - 0.2) < 1e-9, 'closest positive clearance');
  assert.ok(s.maxDanger > 0 && s.maxDanger <= 1);
});

test('one-button mode halves only distance points, never the raw distance', () => {
  const two = fly(new ScoreSystem(), 5.0, 120);
  const one = new ScoreSystem();
  let z = 0;
  for (let i = 0; i < 120; i++) { z += STEP_M; one.update(ship(5.0, { z }), DT, 1 /* ONE_BUTTON */); }
  assert.ok(Math.abs(one.distance - two.distance) < 1e-6, 'distance identical');
  assert.ok(one.scored < two.scored, 'one-button scores fewer points');
});
