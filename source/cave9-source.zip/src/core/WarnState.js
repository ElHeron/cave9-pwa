// WarnState — the whole wall-proximity warning model for one frame, in one
// place: how loud the warning is, and which side it comes from.
//
// Three consumers need the same numbers every frame — the HUD vignette and edge
// render tint, the stereo proximity tone, and the forward-light tint — plus the
// debug overlay and the capture harness when they are active. They used to reach
// for it separately: the app computed reactive/predictive/final and stashed the
// result in private fields on the core Game object, while the debug overlay ran a
// second full predictive probe of its own and the capture harness read the stash
// back out. Three views of "how close am I" that had to be kept in agreement by
// hand.
//
// computeWarn() is a PURE read of the cave + ship. It never touches ship.dist,
// the collision probes, the hit decision, the score/graze/combo or the generator.
// The kill model in CollisionSystem.js remains the sole authority on death: the
// warning may light up EARLIER than the danger, never change when the player
// actually dies.

import { predictiveWarn, finalWarn } from './Predictive.js';

// Pure directional-pan mapping (Phase 4E / L3). Given the nearest wall distance
// on the ship's left and right, return a stereo pan in [-1, 1] for the proximity
// tone: −1 = hard left, +1 = hard right, 0 = centred. The nearer side dominates,
// so a close left wall pans the warning left and a close right wall pans it
// right; symmetric clearance (or both far/unknown) stays centred. This only
// affects WHERE the existing warning is heard, never whether/when it plays.
export function directionalPan(leftClear, rightClear) {
  const lF = Number.isFinite(leftClear);
  const rF = Number.isFinite(rightClear);
  if (!lF && !rF) return 0;     // no info → centred
  if (!rF) return -1;           // only a left wall in range → full left
  if (!lF) return 1;            // only a right wall in range → full right
  const sum = leftClear + rightClear;
  if (sum <= 0) return 0;
  // left nearer (leftClear < rightClear) → negative (left); right nearer → positive
  const pan = (leftClear - rightClear) / sum;
  return Math.max(-1, Math.min(1, pan));
}

// The frame's warning state:
//   reactive    ScoreSystem.warnLevel — "how close am I now"
//   predictive  the look-ahead probe — "how close does my heading take me"
//   final       max(reactive, predictive); what every consumer displays. It can
//               only raise the warning earlier, never lower it.
//   leadDist    how far ahead the predictive probe looked (metres)
//   pan         −1..1 stereo direction of the nearest wall
//
// The pan deliberately follows the REACTIVE nearest wall (the true current
// danger side); the predictive probe leads the warning LEVEL, not its direction.
export function computeWarn(game) {
  const reactive = game.score.warnLevel || 0;
  const pred = predictiveWarn(game.cave, game.player, undefined, game.landmarkCompositions);
  return Object.freeze({
    reactive,
    predictive: pred.warn,
    final: finalWarn(reactive, pred.warn),
    leadDist: pred.leadDist,
    pan: directionalPan(game.player.leftClear, game.player.rightClear),
  });
}
