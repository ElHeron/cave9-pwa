// Deterministic pseudo-random generator.
//
// Ported from the original cave9 `src/detrand.c`, which uses the integer hash
// from Hugo Elias' Perlin-noise notes. Using the same generator means a given
// seed reproduces the same cave, exactly like the original `--level` option.
//
// JavaScript numbers are doubles, so we force 32-bit integer math with `| 0`
// and Math.imul to match the C `int` overflow behaviour.

export class RNG {
  constructor(seed = 1) {
    this.seed(seed);
  }

  seed(seed) {
    // detsrand(): randseed = seed; randval = 0;
    this.randseed = seed | 0;
    this.randval = 0;
    return this;
  }

  // detrand(): returns a float in (-1, 1).
  next() {
    let v = (this.randval + 1) | 0;
    v = (v ^ (v << 13)) | 0;
    this.randval = v;

    // randval * (randval * randval * randseed * 15731 + 789221) + 1376312589
    let inner = Math.imul(Math.imul(Math.imul(v, v), this.randseed), 15731);
    inner = (inner + 789221) | 0;
    let hash = (Math.imul(v, inner) + 1376312589) | 0;
    hash = hash & 0x7fffffff;
    return 1.0 - hash / 1073741824.0;
  }

  // DRAND in the original: a value in [0, 1).
  drand() {
    return (this.next() + 1) * 0.5;
  }

  // DRAND_BIG: a large non-negative integer (used for coin-flips).
  drandBig() {
    return (this.randval >>> 0);
  }
}

// Build a stable 31-bit integer seed from an arbitrary string (e.g. a daily
// challenge key like "2026-06-20"). djb2-style hash.
export function seedFromString(str) {
  let h = 5381;
  for (let i = 0; i < str.length; i++) {
    h = (Math.imul(h, 33) + str.charCodeAt(i)) | 0;
  }
  h = h & 0x7fffffff;
  return h === 0 ? 1 : h;
}

// A fresh random seed for normal runs.
export function randomSeed() {
  return (Math.floor(Math.random() * 0x7ffffffe) + 1) | 0;
}

// ---- daily challenge ------------------------------------------------------
// The daily challenge is a backend-free, reproducible run: the day's date string
// (UTC, YYYY-MM-DD) hashes to a stable seed, so everyone on the same calendar
// day plays the same cave, and a new day yields a different one.

// dailyKey(date): the canonical YYYY-MM-DD key for a given Date (defaults now).
export function dailyKey(date = new Date()) {
  return date.toISOString().slice(0, 10);
}

// dailySeed(date): the reproducible seed for that day's challenge.
export function dailySeed(date = new Date()) {
  return seedFromString(dailyKey(date));
}
