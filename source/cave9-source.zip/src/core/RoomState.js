// RoomState — where the player is relative to the streamed rooms.
//
// CaveStream emits a periodic bulge: every ROOM_SPACING metres
// from ROOM_START on, the cave radius swells over a ROOM_LEN window. That bulge
// is the only thing that makes a "room" exist, but nothing in the game ever said
// so — landmarks re-derived the room plane from the same constants, and the
// renderer had no idea rooms existed at all.
//
// This is the single pure derivation of "am I near a room, and how near": one
// place that encodes the room geometry, computed once per frame and
// read by whoever needs it (the atmosphere, the landmark layer, the overlay).
//
// PURE: reads a z position and nothing else. No cave, no RNG, no mutation.

import { ROOM_START, ROOM_SPACING, ROOM_LEN, ROOM_FADE_LEN } from './constants.js';

// First room index — rooms only exist from ROOM_START on.
export const FIRST_ROOM = Math.round(ROOM_START / ROOM_SPACING);

// How far ahead a room starts making itself felt, and how far behind it lingers.
// The approach is long because the atmosphere has to arrive before the formation
// does: the player should see the depth brighten and the silhouettes resolve out
// of it, not have the light snap on once they are inside.
export const ROOM_APPROACH = 260;
export const ROOM_TRAIL = 120;

// The z-span the stream bulges over for room index k, and its centre —
// which is the plane landmark formations are built on.
export function roomSpan(k) {
  const from = k * ROOM_SPACING;
  return { from, to: from + ROOM_LEN, centre: from + ROOM_LEN / 2 };
}

// Smoothstep, so the atmosphere eases rather than ramps linearly.
function smooth(t) {
  const x = Math.min(1, Math.max(0, t));
  return x * x * (3 - 2 * x);
}

// The exact spatial envelope used by CaveStream to widen the wall.  Keep this
// separate from roomAt(): roomAt deliberately has a long atmospheric approach
// and trail, while a material attached to the physical shell must only become
// active where the shell itself is widening.
//
// `weight` is the 0..1 multiplier behind ROOM_MUL.  It is intentionally pure
// and query-order independent so geometry, render state and capture tooling
// can all ask for the same answer without touching a gameplay RNG stream.
export function roomShellAt(depth) {
  if (!Number.isFinite(depth) || depth < ROOM_START) {
    return { index: -1, localDepth: 0, inside: false, weight: 0 };
  }

  const index = Math.floor(depth / ROOM_SPACING);
  const localDepth = depth - index * ROOM_SPACING;
  if (localDepth < 0 || localDepth > ROOM_LEN) {
    return { index: -1, localDepth, inside: false, weight: 0 };
  }

  const edge = Math.min(localDepth, ROOM_LEN - localDepth);
  return {
    index,
    localDepth,
    inside: true,
    weight: smooth(edge / ROOM_FADE_LEN),
  };
}

// The player's relationship to the nearest room.
//   index     room index, or -1 when none is near
//   centre    that room's z-plane
//   distance  signed metres to it (positive = ahead)
//   inside    is the player within the bulge itself
//   t         0..1 "roominess" — how fully the room's atmosphere applies
export function roomAt(playerZ) {
  if (!Number.isFinite(playerZ)) return { index: -1, centre: 0, distance: Infinity, inside: false, t: 0 };

  // The room whose centre is nearest, clamped to rooms that actually exist.
  const k = Math.max(FIRST_ROOM, Math.round((playerZ - ROOM_LEN / 2) / ROOM_SPACING));
  const { from, to, centre } = roomSpan(k);
  const distance = centre - playerZ;

  let t;
  if (playerZ < from) t = smooth(1 - (from - playerZ) / ROOM_APPROACH);
  else if (playerZ > to) t = smooth(1 - (playerZ - to) / ROOM_TRAIL);
  else t = 1;

  return { index: k, centre, distance, inside: playerZ >= from && playerZ <= to, t };
}
