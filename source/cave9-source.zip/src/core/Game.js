// Game / RunState — the platform-independent heart of a single run:
//   stream cave ahead → move player → query collision → update score.
//
// The simulation is advanced with a FIXED timestep (see DT) so that a given
// seed always produces the same cave: forward speed and force escalation are
// pure functions of depth (thrusters only affect x/y), so carving is fully
// deterministic without depending on frame timing.

import { randomSeed } from './RNG.js';
import { CaveStream } from './CaveStream.js';
import { Ship } from './Ship.js';
import { ScoreSystem } from './ScoreSystem.js';
import { sweptCollision } from './CollisionSystem.js';
import { TWO_BUTTONS, SHIP_RADIUS, FOG_END } from './constants.js';
import { difficultyAt, forwardSpeedAt, sightMul, speedMul } from './Difficulty.js';
import { pathAt, pathDerivativesAt } from './FlightPath.js';
import { GRAVITY, THRUST } from './constants.js';
import { LandmarkCache } from './LandmarkCache.js';
import { nearestRingIndex } from './SurfaceQuery.js';

export const DT = 1 / 60; // fixed simulation timestep

export const RunPhase = {
  IDLE: 'idle',
  RUNNING: 'running',
  DEAD: 'dead',
};

export class Game {
  constructor() {
    this.cave = new CaveStream();
    this.player = new Ship(SHIP_RADIUS);
    this.score = new ScoreSystem();
    this.mode = TWO_BUTTONS;
    this.seed = 1;
    this.phase = RunPhase.IDLE;
    this.time = 0;
    this.landmarkCache = new LandmarkCache();
    this.landmarkCompositions = [];
    this.landmarksEnabled = true;
    this.landmarkFamilyOverride = null;
  }

  // Begin a fresh run. opts: { mode, seed, family/landmarkFamilyOverride }
  start(opts = {}) {
    this.mode = opts.mode ?? TWO_BUTTONS;
    this.seed = (opts.seed ?? randomSeed()) | 0;
    if (this.seed === 0) this.seed = 1;

    if (Object.prototype.hasOwnProperty.call(opts, 'landmarkFamilyOverride')) {
      this.landmarkFamilyOverride = opts.landmarkFamilyOverride;
    } else if (Object.prototype.hasOwnProperty.call(opts, 'family')) {
      this.landmarkFamilyOverride = opts.family === 'auto' ? null : opts.family;
    } else {
      // Overrides belong to one run. Reusing a Game after a visual/capture run
      // must return to the seed-selected production family by default.
      this.landmarkFamilyOverride = null;
    }

    this.player.reset(SHIP_RADIUS);
    // Family selection is frozen before prime(): C3 is part of the generated
    // wall surface, so a development override applied afterwards would be too
    // late to affect the already-emitted ring buffer.
    this.cave.reset(this.seed, this.landmarkFamilyOverride);
    this.score.reset();
    this.landmarkCache.clear();
    this.landmarkCompositions = [];

    // pre-fill the ring buffer ahead of the player
    this.cave.prime();

    const startPath = pathAt(this.seed, 0);
    const startDerivative = pathDerivativesAt(this.seed, 0);
    this.player.pos[0] = startPath.x;
    this.player.pos[1] = startPath.y;
    // Enter the generated route tangent instead of spending the opening seconds
    // cancelling a velocity discontinuity that the player did not create.
    this.player.vel[0] = startDerivative.dx * this.player.vel[2];
    this.player.vel[1] = startDerivative.dy * this.player.vel[2];

    this.phase = RunPhase.RUNNING;
    this.time = 0;
    return this;
  }

  // Keep the deterministic world stream ahead of the player.
  _carve() {
    const depth = this.player.pos[2] - this.player.start;
    const sightDistance = FOG_END * sightMul(depth);
    if (this.cave.ensureCapacityForDistance(sightDistance)) this.cave.fill();
    // Preserve the full circular-buffer contract for collision, rendering and
    // landmarks while keeping its front beyond the current visible distance.
    this.cave.ensureAhead(this.player.pos[2] + this.cave.len(), 4096);
  }

  // Current difficulty parameters at the player's depth (pure; see Difficulty).
  difficulty() {
    return difficultyAt(this.player.pos[2] - this.player.start);
  }

  // Advance one fixed step. Returns true on the frame the player crashes.
  step() {
    if (this.phase !== RunPhase.RUNNING) return false;

    // Forward speed advances through depth-stable plateaus (sight steps with it for fairness;
    // see Difficulty.js / BALANCE.md). Thrusters/gravity still only touch x/y,
    // and the cave is keyed to z position, so determinism is preserved.
    const depth = this.player.pos[2] - this.player.start;
    const escalation = speedMul(depth);
    this.player.vel[2] = forwardSpeedAt(depth);
    this.player.forceScale = escalation;

    this._carve();
    const previousPos = [this.player.pos[0], this.player.pos[1], this.player.pos[2]];
    this.player.move(DT);

    const sweepDepth = Math.max(0, this.player.pos[2] - previousPos[2]);
    this.landmarkCompositions = this.landmarksEnabled
      ? this.landmarkCache.landmarksInView(this.cave, this.player.pos[2], 110, this.seed, 110 + sweepDepth,
        this.landmarkFamilyOverride)
      : [];
    const hit = sweptCollision(this.cave, this.player, previousPos, this.landmarkCompositions) <= 0;
    this.score.update(this.player, DT, this.mode);
    this.time += DT;

    if (hit) {
      this.player.lefton = this.player.righton = false;
      this.phase = RunPhase.DEAD;
      return true;
    }
    return false;
  }

  // Find the cave center roughly `lookAhead` units in front of the player.
  // Live centers always have increasing z, so we pick the one closest to the
  // player's z plus the look-ahead distance.
  _aimCenter(lookAhead) {
    const centers = this.cave.centers;
    const z = this.player.pos[2];
    const targetZ = z + lookAhead;
    const index = nearestRingIndex(this.cave, targetZ);
    const best = index >= 0 && centers[index][2] > z ? centers[index] : null;
    return best || centers[(this.cave.i + 2) % centers.length];
  }

  // autopilot(): robust demo flight controller. Aims for the cave center a few
  // rings ahead with a PD bang-bang law mapped onto the two thrusters. Because
  // a single thruster's lift cancels gravity and two thrusters climb, vertical
  // is the priority axis. Used for the menu background and the DEMO mode.
  autopilot() {
    const p = this.player;
    const depth = p.pos[2] - p.start;
    const ref = pathAt(this.seed, depth);
    const d = pathDerivativesAt(this.seed, depth);
    const vz = p.vel[2];
    const forceScale = speedMul(depth);
    const ex = ref.x - p.pos[0], ey = ref.y - p.pos[1];
    const evx = d.dx * vz - p.vel[0], evy = d.dy * vz - p.vel[1];
    const desiredX = d.ddx * vz * vz + ex * 9.0 + evx * 5.4;
    const desiredY = d.ddy * vz * vz + ey * 9.0 + evy * 5.4;

    const actions = [
      { left: false, right: false, ax: 0, ay: -GRAVITY * forceScale },
      { left: true, right: false, ax: -THRUST * forceScale, ay: 0 },
      { left: false, right: true, ax: THRUST * forceScale, ay: 0 },
      { left: true, right: true, ax: 0, ay: (THRUST - GRAVITY) * forceScale },
    ];
    let best = actions[0], bestCost = Infinity;
    for (const a of actions) {
      const dx = (a.ax - desiredX) / (THRUST * forceScale);
      const dy = (a.ay - desiredY) / (GRAVITY * forceScale);
      const cost = dx * dx + 1.35 * dy * dy;
      if (cost < bestCost) { best = a; bestCost = cost; }
    }
    p.lefton = best.left;
    p.righton = best.right;
  }

  scoreValue() {
    return this.score.value();
  }
}
