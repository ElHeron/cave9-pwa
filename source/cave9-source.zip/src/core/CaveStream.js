// Deterministic route-first cave stream.
//
// This object owns the wall cursor, wall RNG and circular ring buffer. There is
// no generator-facing Ship and no thruster/control protocol: callers state how
// far the world must exist, and the stream emits route-orthogonal rings through
// that depth while preserving the deterministic wall sequence.

import {
  SECTOR_COUNT, SEGMENT_COUNT, SEGMENT_LEN, VELOCITY,
  ROOM_MUL,
  WALL_MULT_MIN, WALL_MULT_MAX,
} from './constants.js';
import { roomShellAt } from './RoomState.js';
import { RNG } from './RNG.js';
import { v3, copy } from './vec.js';
import { pathFrameAt, tubeRadiusAt } from './FlightPath.js';
import { RoomSurfaceStore } from './landmarks/RoomSurfaceStore.js';
import {
  COILING_SHELL_VERSION, coilingAxialStrengthAtDepth, coilingContractForRoom,
  coilingGridAngleOffsetAtDepth,
  deformCoilingRadius, roomIndexAtDepth,
} from './CoilingShell.js';

export class CaveStream {
  constructor() {
    this.rng = new RNG(1);
    this._allocate(SEGMENT_COUNT);
    this.reset(1);
  }

  _allocate(capacity) {
    this.segs = Array.from({ length: capacity },
      () => Array.from({ length: SECTOR_COUNT }, () => v3()));
    this.centers = Array.from({ length: capacity }, () => v3());
    this.frames = Array.from({ length: capacity }, () => null);
    this.innerRadii = new Float64Array(capacity);
    // Axial contract strength is retained for diagnostics and active-span
    // checks. The per-sector inset is the actual applied wall displacement,
    // including the protected-radius clamp; renderers can light only the local
    // ridge rather than treating the entire ring as a crest.
    this.coilingStrengths = new Float64Array(capacity);
    this.coilingInsets = Array.from({ length: capacity }, () => new Float32Array(SECTOR_COUNT));
    // The physical angle of column j is its corridor angle plus this offset.
    // Keep it ring-aligned with segs and coilingInsets for material sampling.
    this.ringAngleOffsets = new Float64Array(capacity);
  }

  reset(seed = 1, landmarkFamilyOverride = null) {
    if (this.segs.length !== SEGMENT_COUNT) this._allocate(SEGMENT_COUNT);
    this.ringAngleOffsets.fill(0);
    // Renderer caches must distinguish two generations of the same CaveStream
    // object. A visual scenario reset can recreate the same write head/front-z
    // with a different seed or family override, so object identity alone is
    // insufficient and would leave the previous vertex buffer on screen.
    this.generation = (this.generation ?? 0) + 1;
    this.roomSurfaceStore = new RoomSurfaceStore(this.generation);
    this.seed = seed | 0 || 1;
    this.landmarkFamilyOverride = landmarkFamilyOverride;
    this.coilingShellVersion = COILING_SHELL_VERSION;
    this._coilingContracts = new Map();
    this.rng.seed(this.seed);
    this.i = 0;
    this.count = 0;
    this.cursorDepth = 0;
    // Ring positions are a geometry contract, not an artefact of the simulation
    // tick. Prime advances by 0.6 m and runtime carving by 1.5 m, neither of
    // which divides the frozen 2 m SEGMENT_LEN. Keep a separate exact lattice
    // so both phases submit the same 0, 2, 4, ... metre wall surface.
    this._nextRingDepth = 0;
    this._lastRingDepth = null;
    this.roomMul = 1;
    this.xLeftRadius = 0;
    this.xRightRadius = 0;
    this.yTopRadius = 0;
    this.yBottomRadius = 0;
  }

  len() {
    if (this.count < 2) return 0;
    const capacity = this.segs.length;
    const head = this.count < capacity ? 0 : this.i;
    const tail = (this.i - 1 + capacity) % capacity;
    return this.centers[tail][2] - this.centers[head][2];
  }

  landmarkRoomSurface(k) { return this.roomSurfaceStore.surfaceFor(k); }

  roomSurfaceMetrics() { return this.roomSurfaceStore.resourceMetrics(); }

  // Grow in coarse chunks so the unbounded speed staircase never outruns the
  // generated wall or reallocates every frame. Existing rings retain their
  // spatial order and exact values; only empty future slots are added.
  ensureCapacityForDistance(distance, chunk = 32) {
    const needed = Math.max(SEGMENT_COUNT, Math.ceil(Math.max(0, distance) / SEGMENT_LEN) + 4);
    if (needed <= this.segs.length) return false;
    const capacity = Math.ceil(needed / chunk) * chunk;
    const oldCapacity = this.segs.length;
    const oldCount = this.count;
    const oldHead = oldCount < oldCapacity ? 0 : this.i;
    const oldSegs = this.segs, oldCenters = this.centers;
    const oldFrames = this.frames, oldRadii = this.innerRadii;
    const oldCoilingStrengths = this.coilingStrengths;
    const oldCoilingInsets = this.coilingInsets;
    const oldRingAngleOffsets = this.ringAngleOffsets;
    this._allocate(capacity);
    for (let s = 0; s < oldCount; s++) {
      const from = (oldHead + s) % oldCapacity;
      this.segs[s] = oldSegs[from];
      this.centers[s] = oldCenters[from];
      this.frames[s] = oldFrames[from];
      this.innerRadii[s] = oldRadii[from];
      this.coilingStrengths[s] = oldCoilingStrengths[from];
      this.coilingInsets[s] = oldCoilingInsets[from];
      this.ringAngleOffsets[s] = oldRingAngleOffsets[from];
    }
    this.count = oldCount;
    this.i = oldCount;
    return true;
  }

  _advance(dt) { this.cursorDepth += VELOCITY * dt; }

  _updateWallState(depth) {
    this.roomMul = 1;
    const roomShell = roomShellAt(depth);
    this.roomMul = 1 + (ROOM_MUL - 1) * roomShell.weight;
    this.xRightRadius += this.rng.drand() - 0.5;
    this.yTopRadius += this.rng.drand() - 0.5;
    this.xLeftRadius += this.rng.drand() - 0.5;
    this.yBottomRadius += this.rng.drand() - 0.5;
  }

  _coilingContractAtDepth(depth) {
    const roomIndex = roomIndexAtDepth(depth);
    if (roomIndex === null) return null;
    if (!this._coilingContracts.has(roomIndex)) {
      this._coilingContracts.set(roomIndex,
        coilingContractForRoom(this.seed, roomIndex, this.landmarkFamilyOverride));
    }
    const contract = this._coilingContracts.get(roomIndex);
    return contract && depth >= contract.start && depth <= contract.end ? contract : null;
  }

  _emitRing(depth) {
    const capacity = this.segs.length;
    this._updateWallState(depth);

    const B = 2 / (WALL_MULT_MAX - WALL_MULT_MIN);
    const A = B * WALL_MULT_MAX - 1;
    const frame = pathFrameAt(this.seed, depth);
    const inner = tubeRadiusAt(depth, this.seed);
    const surfaceMargin = 0.12;
    const coiling = this._coilingContractAtDepth(depth);
    const coilingStrength = coilingAxialStrengthAtDepth(depth, coiling);
    const coilingEnvelope = coiling ? coilingStrength / coiling.ridgeStrength : 0;
    const ringAngleOffset = coilingGridAngleOffsetAtDepth(depth, coiling);

    for (let sector = 0; sector < SECTOR_COUNT; sector++) {
      const angle = Math.PI / 2 + (sector - 1) * Math.PI * 2 / SECTOR_COUNT + ringAngleOffset;
      const cos = Math.cos(angle), sin = Math.sin(angle);
      let xMultiplier = cos > 0 ? this.yTopRadius : this.yBottomRadius;
      let yMultiplier = sin > 0 ? this.xLeftRadius : this.xRightRadius;
      xMultiplier = (A + Math.sin(xMultiplier)) / B;
      yMultiplier = (A + Math.sin(yMultiplier)) / B;
      // Consume the identical two wall RNG draws per sector. Inside C3, fade
      // their independent deviations fully to the unchanged mean. Even 35%
      // residual sector jitter made the outer ridge shoulder sprout repeated
      // metre-scale triangle tongues. The four slowly evolving ring-state
      // draws still shape the chamber. At the contract ends and everywhere
      // outside it, the original values and arithmetic are used exactly.
      const randomX = this.rng.drand(), randomY = this.rng.drand();
      const noiseScale = 1 - coilingEnvelope;
      const wallRandomX = coilingEnvelope > 0 ? 0.5 + (randomX - 0.5) * noiseScale : randomX;
      const wallRandomY = coilingEnvelope > 0 ? 0.5 + (randomY - 0.5) * noiseScale : randomY;
      const sx = (inner * (xMultiplier - 1) + 0.35 + 1.65 * wallRandomX) * this.roomMul;
      const sy = (inner * (yMultiplier - 1) + 0.35 + 1.65 * wallRandomY) * this.roomMul;
      const roomShell = Math.max(0, this.roomMul - 1) * inner * 1.5;
      const shell = Math.hypot(sx * cos, sy * sin) + roomShell;
      // Three wall-embedded threads. The same phase is used by the renderer's
      // mineral colour field, so relief, texture and collision describe one
      // surface rather than a decorative spiral floating in front of the wall.
      const coilPhase = 3 * angle - depth * 0.065 + (this.seed & 255) * 0.017;
      const coilThread = 0.5 + 0.5 * Math.cos(coilPhase);
      const corridorCoil = 0.62 + 0.38 * coilThread * coilThread;
      // E[coilThread²] = 3/8 over the three complete sector cycles. Fade most
      // of their contrast toward that same mean only while C3 is active; the
      // corridor's ordinary three-thread profile stays byte-identical.
      const coil = coilingEnvelope > 0
        ? corridorCoil + (0.7625 - corridorCoil) * 0.75 * coilingEnvelope
        : corridorCoil;
      const baseRadius = inner + surfaceMargin + shell * coil;
      const radius = deformCoilingRadius(baseRadius, inner, angle, depth, coiling);
      this.coilingInsets[this.i][sector] = coiling ? Math.max(0, baseRadius - radius) : 0;
      const lx = radius * cos, ly = radius * sin;
      const vertex = this.segs[this.i][sector];
      vertex[0] = frame.center.x + frame.right.x * lx + frame.up.x * ly;
      vertex[1] = frame.center.y + frame.right.y * lx + frame.up.y * ly;
      vertex[2] = frame.center.z + frame.right.z * lx + frame.up.z * ly;
    }
    copy(this.centers[this.i], [frame.center.x, frame.center.y, frame.center.z]);
    this.frames[this.i] = frame;
    this.innerRadii[this.i] = inner;
    this.coilingStrengths[this.i] = coilingStrength;
    this.ringAngleOffsets[this.i] = ringAngleOffset;
    const emittedSlot = this.i;
    this.i = (this.i + 1) % capacity;
    this.count = Math.min(capacity, this.count + 1);
    const oldestSlot = this.count < capacity ? 0 : this.i;
    this.roomSurfaceStore.observe(this, emittedSlot, this.centers[oldestSlot][2]);
    this._lastRingDepth = depth;
    return true;
  }

  _emitDueRings(limit = this.cursorDepth) {
    let emitted = 0;
    while (this._nextRingDepth <= limit + 1e-9) {
      this._emitRing(this._nextRingDepth);
      this._nextRingDepth += SEGMENT_LEN;
      emitted++;
      if (emitted > 1_000_000) throw new Error('CaveStream ring lattice emission overflow');
    }
    return emitted;
  }

  _tick(dt, emitBeforeAdvance) {
    if (emitBeforeAdvance) this._emitDueRings();
    this._advance(dt);
    if (!emitBeforeAdvance) this._emitDueRings();
  }

  // Prime and runtime keep their existing simulation progress, but both emit
  // only on the exact SEGMENT_LEN lattice owned by _nextRingDepth.
  prime() {
    this.i = 0;
    this.count = 0;
    do this._tick(1 / 50, false); while (this.count < this.segs.length);
  }

  fill(maxTicks = this.segs.length * 4) {
    let ticks = 0;
    while (this.count < this.segs.length && ticks++ < maxTicks) this._tick(0.05, true);
    if (this.count < this.segs.length) throw new Error('CaveStream could not fill its ring buffer');
    return ticks;
  }

  ensureAhead(targetDepth, maxTicks = 64) {
    let ticks = 0;
    while ((this._lastRingDepth ?? -Infinity) < targetDepth && ticks++ < maxTicks) {
      this._tick(0.05, true);
    }
    return ticks;
  }

  generateThrough(targetDepth, maxTicks = 5_000_000) {
    let ticks = 0;
    while ((this._lastRingDepth ?? -Infinity) < targetDepth && ticks++ < maxTicks) {
      this._tick(0.05, true);
    }
    if ((this._lastRingDepth ?? -Infinity) < targetDepth) {
      throw new Error(`CaveStream could not generate a ring through ${targetDepth}m`);
    }
    return ticks;
  }
}
