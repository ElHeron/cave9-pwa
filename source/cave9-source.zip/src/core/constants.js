// Core gameplay constants, ported from the original cave9 `src/game.h`.
// Keeping the same numbers preserves the original game feel (gravity vs thrust
// ratio, forward speed, cave radius curve, room spacing, …).

export const SECTOR_COUNT = 32;   // points around each cave ring
// 144 × 2 m = 288 m of live cave at the start. CaveStream grows this circular
// buffer in chunks as the unbounded speed staircase requires more sight.
export const SEGMENT_COUNT = 144; // rings kept alive (circular buffer)
export const SEGMENT_LEN = 2.0;   // z-distance between rings

export const ROOM_SPACING = 1000;
export const ROOM_START = 2 * ROOM_SPACING;
// Reference-led axial formations occupy up to 210 m.  A 220 m wide core keeps
// them in the visible cave shell; 30 m shoulders blend the chamber into the
// corridor without a radius discontinuity.
export const ROOM_CORE_LEN = 220.0;
export const ROOM_FADE_LEN = 30.0;
export const ROOM_LEN = ROOM_CORE_LEN + ROOM_FADE_LEN * 2;
export const ROOM_MUL = 4.0;

export const SHIP_RADIUS = 1.0;

export const GRAVITY = 9.8;
export const THRUST = GRAVITY * 2;
export const VELOCITY = 30.0;     // base forward speed before Difficulty scaling

export const WALL_MULT_MIN = 1.0;
export const WALL_MULT_MAX = 2.0;

export const MAX_VEL_X = GRAVITY;
export const MAX_VEL_Y = GRAVITY * 4;
export const MAX_VEL_Z = VELOCITY;

// Game modes (control schemes)
export const ONE_BUTTON = 1;   // both thrusters fire together (easier)
export const TWO_BUTTONS = 2;  // independent left / right thrusters

// Visuals (from display.c): linear black fog, 45° FOV.
// (The original's FAR_PLANE lived here too; this remake drives its draw distance
// from the difficulty-scaled fog instead — see Renderer.setSight / Difficulty.js.)
export const FOG_END = 128;
export const FOV = 45;
