// FlightPath — the physically flyable route the cave is built around.
//
// This inverts how the cave came to exist. The original digger random-walked and
// the tunnel followed, so whether a seed was survivable was discovered by flying
// it (the 50-seed audit) rather than known. Difficulty was therefore a measured
// hope. Here the ROUTE comes first, is flyable by construction, and the cave is
// generated around it — so "this run can be completed" is a property of the
// generator, not a result.
//
// ---- why a sum of sinusoids ------------------------------------------------
//
// The ship's control envelope is unusually clean (see Ship.move):
//
//   one thruster    ax = ±THRUST (19.6),  ay = THRUST/2 − GRAVITY = 0   (hover)
//   both thrusters  ax = 0,               ay = THRUST − GRAVITY = +9.8  (climb)
//   neither         ax = 0,               ay = −GRAVITY = −9.8          (fall)
//
// So vertical is the WEAKER axis and therefore the binding one. A path x(z), y(z)
// flown at forward speed V needs lateral acceleration V²·y″, which gives the
// flyability condition |y″| ≤ a_max / V².
//
// For a sum of sinusoids y(z) = Σ Aᵢ·sin(2π z/λᵢ + φᵢ) the second derivative is
// bounded in closed form by Σ Aᵢ(2π/λᵢ)². That bound is checkable at build time,
// so a path can be PROVEN flyable rather than tested and hoped for — and the
// proof holds for every seed, not just the ones anyone sampled.
//
// The margin matters: a controller also has to correct its own tracking error,
// so the path is only allowed a fraction of the envelope (PATH_ACC_BUDGET) and
// the rest is left for the pilot.

import { GRAVITY, THRUST, VELOCITY, SHIP_RADIUS } from './constants.js';

// ---- the ship's acceleration envelope, derived from Ship.move --------------
// Vertical: both thrusters climb, neither falls — symmetric at THRUST − GRAVITY.
export const MAX_ACC_Y = THRUST - GRAVITY;
// Horizontal: a single thruster, which happens to hold altitude exactly.
export const MAX_ACC_X = THRUST;

// How much of the envelope the PATH may consume. The remainder is the pilot's
// authority to correct error, recover from a bad line, and handle the fact that
// control is four discrete states rather than a continuous force.
export const PATH_ACC_BUDGET = 0.45;

// The organic section is still proven at the old 2.2× reference speed. The
// actual runtime staircase has no ceiling; the route therefore approaches a
// straight line asymptotically as speeds grow without bound.
export const PATH_REFERENCE_SPEED_MUL = 2.2;

// ---- tube ------------------------------------------------------------------
// The swept volume kept clear around the path. Nothing — wall, landmark or
// corridor coil — may intrude it, which is what makes a run completable.
//
// Minimum radius: 2 × SHIP_RADIUS, leaving one ship radius of free space
// outside a centred hull at the tightest point.
export const TUBE_MIN_RADIUS = 2 * SHIP_RADIUS;
export const TUBE_MAX_RADIUS = 9 * SHIP_RADIUS;

// The tube narrows in WAVES rather than smoothly: open stretch, squeeze, open
// stretch, squeeze — so tension has a rhythm instead of a slope. The envelope of
// those waves closes with depth until it sits at the minimum and stays there;
// past that point difficulty comes from speed alone.
export const TUBE_WAVE_LEN = 900;
export const TUBE_FLOOR_DEPTH = 9000;

const TAU = Math.PI * 2;
export const ROUTE_STRAIGHTEN_START = TUBE_FLOOR_DEPTH;
export const ROUTE_STRAIGHTEN_SCALE = 1200;

// ---- deterministic per-seed phases ----------------------------------------
function hash2(a, b) {
  let h = (a | 0) ^ Math.imul(((b | 0) + 0x9e3779b9) | 0, 0x85ebca6b);
  h = Math.imul(h ^ (h >>> 13), 0xc2b2ae35);
  return (h ^ (h >>> 16)) >>> 0;
}
const unit = (a, b) => hash2(a, b) / 4294967296;

// The octaves the route is built from. Long wavelengths carry the big sweeping
// line, short ones the detail; amplitudes fall fast enough that the curvature
// sum stays inside the budget (asserted in test/flightpath.test.js).
// Amplitudes are not free: an octave costs A·(2π/λ)² of curvature, so short
// wavelengths are quadratically expensive. The first attempt here (26 m at
// 1400 m down to 0.7 m at 130 m) demanded 19.4 m/s² of a ship that has 9.8, and
// the analytic bound caught it before a single frame was rendered. These four
// spend ~9.8e-4, which is 4.26 m/s² at the 2.2× reference speed — inside the
// 4.41 the budget allows, with the rest left to the pilot.
const OCTAVES = [
  { len: 1800, amp: 22 },   // the big sweeping line
  { len: 900, amp: 5 },
  { len: 420, amp: 1.2 },
  { len: 200, amp: 0.2 },   // detail; anything larger here breaks flyability
];

// Worst-case |y″| of the sum: every octave peaking at once. Deliberately the
// pessimistic bound rather than a sampled maximum — a sampled one would pass
// while a rare seed failed.
export function curvatureBound(octaves = OCTAVES) {
  let sum = 0;
  for (const o of octaves) sum += o.amp * (TAU / o.len) ** 2;
  return sum;
}

// The fastest speed at which this path is still flyable with the given budget.
export function maxFlyableSpeed(octaves = OCTAVES, budget = PATH_ACC_BUDGET) {
  return Math.sqrt((MAX_ACC_Y * budget) / curvatureBound(octaves));
}

// Is the route flyable at the speed we plan for, with margin to spare?
export function isFlyable(octaves = OCTAVES) {
  return maxFlyableSpeed(octaves) >= VELOCITY * PATH_REFERENCE_SPEED_MUL;
}

function asymptoticFade(z) {
  const u = Math.max(0, z - ROUTE_STRAIGHTEN_START) / ROUTE_STRAIGHTEN_SCALE;
  const den = 1 + u ** 3;
  return {
    value: 1 / den,
    d1: (-3 * u * u / (den * den)) / ROUTE_STRAIGHTEN_SCALE,
    d2: (-6 * u / (den * den) + 18 * u ** 4 / (den ** 3)) /
      (ROUTE_STRAIGHTEN_SCALE * ROUTE_STRAIGHTEN_SCALE),
  };
}

// Closed conservative bound for the damped organic route. The fade is always
// positive (the line is never perfectly straight) and decays as z^-3, so the
// acceleration demand still tends to zero while speed grows roughly as z.
export function asymptoticCurvatureBoundAt(z, octaves = OCTAVES) {
  if (z <= ROUTE_STRAIGHTEN_START) return curvatureBound(octaves);
  const span = octaves.reduce((sum, o) => sum + o.amp, 0);
  const slope = octaves.reduce((sum, o) => sum + o.amp * TAU / o.len, 0);
  const fade = asymptoticFade(z);
  return fade.value * curvatureBound(octaves)
    + 2 * Math.abs(fade.d1) * slope
    + Math.abs(fade.d2) * 2 * span;
}

export function routeCurvatureBoundAt(z) {
  return asymptoticCurvatureBoundAt(z);
}

// ---- the route -------------------------------------------------------------
// Centre of the tube at depth z. Pure: same seed and z, same point, forever, and
// no dependence on how the player got there.
function organicState(seed, z) {
  let x = 0, y = 0, dx = 0, dy = 0, ddx = 0, ddy = 0;
  for (let i = 0; i < OCTAVES.length; i++) {
    const o = OCTAVES[i];
    const k = TAU / o.len;
    const px = unit(seed, i * 2 + 1) * TAU;
    const py = unit(seed, i * 2 + 2) * TAU;
    // x and y ride the same octaves with independent phases, so the route
    // corkscrews instead of swinging in one plane
    const ax = z * k + px, ay = z * k + py;
    x += o.amp * Math.sin(ax);
    y += o.amp * Math.sin(ay);
    dx += o.amp * k * Math.cos(ax);
    dy += o.amp * k * Math.cos(ay);
    ddx -= o.amp * k * k * Math.sin(ax);
    ddy -= o.amp * k * k * Math.sin(ay);
  }
  return { x, y, dx, dy, ddx, ddy };
}

function routeState(seed, z) {
  if (z <= ROUTE_STRAIGHTEN_START) return organicState(seed, z);
  const anchor = organicState(seed, ROUTE_STRAIGHTEN_START);
  const live = organicState(seed, z);
  const fade = asymptoticFade(z);
  const qx = live.x - anchor.x, qy = live.y - anchor.y;
  return {
    x: anchor.x + fade.value * qx,
    y: anchor.y + fade.value * qy,
    dx: fade.d1 * qx + fade.value * live.dx,
    dy: fade.d1 * qy + fade.value * live.dy,
    ddx: fade.d2 * qx + 2 * fade.d1 * live.dx + fade.value * live.ddx,
    ddy: fade.d2 * qy + 2 * fade.d1 * live.dy + fade.value * live.ddy,
  };
}

export function pathAt(seed, z) {
  const { x, y } = routeState(seed, z);
  return { x, y };
}

// Exact first/second lateral derivatives with z as the independent variable.
// The autopilot uses these for desired velocity and curvature feed-forward;
// keeping them analytic avoids finite-difference noise in the fixed-step loop.
export function pathDerivativesAt(seed, z) {
  const { dx, dy, ddx, ddy } = routeState(seed, z);
  return { dx, dy, ddx, ddy };
}

// Analytic tangent, so the cave can be built square to the route rather than
// square to the z axis (which is what makes a tunnel look extruded).
export function pathTangent(seed, z) {
  const { dx, dy } = pathDerivativesAt(seed, z);
  const l = Math.hypot(dx, dy, 1) || 1;
  return { x: dx / l, y: dy / l, z: 1 / l };
}

// Stable route-local frame.  `right` is chosen from world-up × tangent; because
// the route always points strongly along +z this cannot approach degeneracy.
// Rings, collision projection and room-local landmark coordinates all share it.
export function pathFrameAt(seed, z) {
  // Position and tangent share the same analytic route evaluation. Calling
  // pathAt and pathTangent separately repeated every octave (and the deep
  // route anchor) for each wall vertex projection and landmark contact.
  const { x, y, dx, dy } = routeState(seed, z);
  const length = Math.hypot(dx, dy, 1) || 1;
  const tangent = { x: dx / length, y: dy / length, z: 1 / length };
  const rl = Math.hypot(tangent.z, tangent.x) || 1;
  const right = { x: tangent.z / rl, y: 0, z: -tangent.x / rl };
  const up = {
    x: tangent.y * right.z - tangent.z * right.y,
    y: tangent.z * right.x - tangent.x * right.z,
    z: tangent.x * right.y - tangent.y * right.x,
  };
  return { center: { x, y, z }, tangent, right, up };
}

// ---- tube radius -----------------------------------------------------------
// Waves that close with depth. `wave` runs 0..1 across a squeeze cycle; the
// envelope it swings inside shrinks until TUBE_FLOOR_DEPTH, after which the tube
// is constant at its minimum and the game escalates by speed instead.
export function tubeRadiusAt(depth, seed = 0) {
  const d = Math.max(0, depth);
  const close = Math.min(1, d / TUBE_FLOOR_DEPTH);
  // widest the tube may be here: TUBE_MAX at the surface, TUBE_MIN at the floor
  const ceiling = TUBE_MAX_RADIUS + (TUBE_MIN_RADIUS - TUBE_MAX_RADIUS) * close;
  // the wave: 1 on the open stretches, 0 at the pinch
  const phase = (d / TUBE_WAVE_LEN + unit(seed, 99) ) * TAU;
  const wave = (Math.cos(phase) + 1) / 2;
  // a pinch never goes below the minimum, and the open stretch never above the
  // ceiling — so the tube is monotone-ish in envelope but rhythmic in feel
  return TUBE_MIN_RADIUS + (ceiling - TUBE_MIN_RADIUS) * wave;
}

// Has the tube reached its floor, i.e. is difficulty now speed alone? This is
// the point the visual morph completes and the speed steps take over.
export function atTubeFloor(depth) {
  return depth >= TUBE_FLOOR_DEPTH;
}
