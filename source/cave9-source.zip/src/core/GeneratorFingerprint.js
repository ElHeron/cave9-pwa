// Canonical generator fingerprints shared by Node tests, CLI gates, and real
// browser engines. Keeping the oracle in a browser-safe core module lets CI ask
// V8, SpiderMonkey, and JavaScriptCore the exact same question.

import { Game } from './Game.js';
import { ROOM_LEN, ROOM_START } from './constants.js';

const f32 = new Float32Array(1);
const u32 = new Uint32Array(f32.buffer);

function foldFloat32(state, value) {
  f32[0] = value;
  state.hash = Math.imul(state.hash ^ u32[0], 16777619) >>> 0;
}

export function generatorFingerprint(seed, steps = 3000) {
  const game = new Game();
  game.start({ mode: 2, seed });
  for (let step = 0; step < steps; step++) {
    game.autopilot();
    if (game.step()) break;
  }
  const state = { hash: 2166136261 >>> 0 };
  for (const ring of game.cave.segs) {
    for (const vertex of ring) for (const coordinate of vertex) foldFloat32(state, coordinate);
  }
  for (const coordinate of game.player.pos) foldFloat32(state, coordinate);
  return { hash: state.hash, writeHead: game.cave.i, score: game.scoreValue() };
}

export function firstRoomFingerprint(seed) {
  const game = new Game();
  game.start({ mode: 2, seed });
  game.cave.generateThrough(ROOM_START + ROOM_LEN);
  const state = { hash: 2166136261 >>> 0 };
  const rings = game.cave.centers
    .map((center, index) => ({ center, index }))
    .filter(({ center }) => center[2] >= ROOM_START && center[2] <= ROOM_START + ROOM_LEN)
    .sort((a, b) => a.center[2] - b.center[2]);
  for (const { center, index } of rings) {
    for (const coordinate of center) foldFloat32(state, coordinate);
    foldFloat32(state, game.cave.innerRadii[index]);
    for (const vertex of game.cave.segs[index]) {
      for (const coordinate of vertex) foldFloat32(state, coordinate);
    }
  }
  return {
    hash: state.hash,
    ringCount: rings.length,
    firstZ: rings[0]?.center[2] ?? null,
    lastZ: rings.at(-1)?.center[2] ?? null,
  };
}

export const GENERATOR_BASELINE = Object.freeze({
  corridor: Object.freeze([
    [1, 1000550680, 43, 1699],
    [42, 4129849094, 43, 1699],
    [4096, 901656642, 43, 1699],
    [424242, 1312335657, 43, 1699],
    [555, 4222977386, 43, 1699],
  ]),
  firstRoom: Object.freeze([
    // V04 visually accepted C3-v2: continuous wall crest, co-moving sector
    // grid and quiet shoulder. Other family and corridor pins are unchanged.
    [1, 3607373194],
    [42, 3134901291],
    [4096, 2409672045],
    [424242, 726037667],
    [555, 2543800698],
  ]),
});

export function generatorFingerprintReport() {
  return {
    corridor: GENERATOR_BASELINE.corridor.map(([seed]) => ({ seed, ...generatorFingerprint(seed) })),
    firstRoom: GENERATOR_BASELINE.firstRoom.map(([seed]) => ({ seed, ...firstRoomFingerprint(seed) })),
  };
}

export function expectedGeneratorFingerprintReport() {
  return {
    corridor: GENERATOR_BASELINE.corridor.map(([seed, hash, writeHead, score]) => (
      { seed, hash, writeHead, score }
    )),
    firstRoom: GENERATOR_BASELINE.firstRoom.map(([seed, hash]) => (
      { seed, hash, ringCount: ROOM_LEN / 2 + 1, firstZ: ROOM_START, lastZ: ROOM_START + ROOM_LEN }
    )),
  };
}
