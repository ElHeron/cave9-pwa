// The piece grammar and its safety guarantees.
//
// THIS IS THE INVARIANT LAYER. The families in ./families.js are art direction
// and change often; everything here is the contract they build against and must
// not change casually:
//
//   * a piece never intrudes the central NO-ENTRY tube, so a formation can never
//     occlude the flight path or the dark vanishing point;
//   * a piece's centre stays inside the rock wall (a thick base may embed into
//     the rock — occluded, harmless — but nothing pokes through);
//   * an unsafe proposed piece is not emitted. Every visible form therefore has
//     an explicit authoritative capsule rather than renderer-only fallback art.
//
// test/landmarks.test.js asserts these on real compositions, and
// test/landmark-mesh.test.js asserts the grown geometry respects them too.

// Pieces must stay inside this fraction of the room clearance (never through rock).
export const LANDMARK_WALL_MARGIN_FRAC = 0.92;
// Hard cap on pieces per composition (pool sizing + overload guard).
export const LANDMARK_MAX_PIECES = 120;

// A piece is an elongated form along a unit direction (its local +Y axis):
//   { shape, cx,cy,cz (centre), dx,dy,dz (unit dir), length, radius }
// shape ∈ 'limb' (tapered root), 'blade' (obsidian slab), 'rib' (stony bar).
// The renderer maps shape → geometry and orients local +Y onto (dx,dy,dz).
export function makePiece(shape, base, dir, length, radius) {
  const hl = length / 2;
  return {
    shape,
    cx: base.x + dir.x * hl, cy: base.y + dir.y * hl, cz: base.z + dir.z * hl,
    dx: dir.x, dy: dir.y, dz: dir.z,
    length, radius,
  };
}

export function norm3(x, y, z) {
  const l = Math.hypot(x, y, z) || 1;
  return { x: x / l, y: y / l, z: z / l };
}

// Radial distance of an (x,y) point from the room axis (cx0,cy0). z is the tunnel
// axis, so "radial" is the in-plane distance — what the safety tube is about.
export function radialOf(px, py, cx0, cy0) {
  return Math.hypot(px - cx0, py - cy0);
}

// A piece is SAFE iff, at every sampled point (base / mid / tip):
//   - its thickness clears the central no-entry tube: `r − radius ≥ inner`
//     (STRICT — this is the flight-path / vanishing-point guarantee), and
//   - its centre stays within the rock wall: `r ≤ wall` (= clearance).
// Forms GROW FROM the wall, so a thick base may embed into the rock (occluded,
// harmless); only the inner reach is safety-critical. Sampling base/mid/tip
// catches the reach + the bulge.
export function pieceSafe(p, cx0, cy0, inner, wall) {
  const hl = p.length / 2;
  const pts = [
    [p.cx - p.dx * hl, p.cy - p.dy * hl],
    [p.cx, p.cy],
    [p.cx + p.dx * hl, p.cy + p.dy * hl],
  ];
  for (const [sx, sy] of pts) {
    const r = radialOf(sx, sy, cx0, cy0);
    if (r - p.radius < inner) return false;   // never intrude the central tube
    if (r > wall) return false;               // centre stays inside the wall
  }
  return true;
}
