// Reference-driven landmark-family router.
//
// The old single-file generators were short, room-plane decorations.  The
// release families are axial structures derived from the manifest references:
// R2 wall-crawling root braids, B1 three-bank blade irises and a capsule-backed
// C3 is no longer a landmark mesh: CaveStream deforms its authoritative wall
// rings directly.  This router therefore only builds the two piece families.

import { BRANCHING, CRYSTAL, COILING } from './rng.js';
import { buildReferenceRoots } from './families/roots.js';
import { buildReferenceBlades } from './families/blades.js';

export { buildReferenceRoots } from './families/roots.js';
export { buildReferenceBlades } from './families/blades.js';

export function buildFamily(type, rng, cx, cy, z, inner, outer, wall) {
  if (type === BRANCHING) return buildReferenceRoots(rng, cx, cy, z, inner, outer, wall);
  if (type === CRYSTAL) return buildReferenceBlades(rng, cx, cy, z, inner, outer, wall);
  if (type === COILING) return [];
  throw new RangeError(`Unknown landmark family index ${type}`);
}
