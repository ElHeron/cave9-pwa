// Bounded immutable copies of actually emitted wall rings. They remain Core
// geometry authority after the circular rendering buffer recycles its slots.
import { SEGMENT_LEN, ROOM_LEN, ROOM_SPACING } from '../constants.js';
import { FIRST_ROOM_K, LANDMARK_SURFACE_HALF_SPAN, roomZ } from './rooms.js';

export const MAX_ROOM_SURFACE_STORES = 2;

function frozenVector(vector) { return Object.freeze({ ...vector }); }

export class RoomSurfaceStore {
  constructor(generation) {
    this.generation = generation;
    this.rooms = new Map();
  }

  observe(cave, slot, oldestDepth) {
    // Once even the live rear plane has passed the complete supported form
    // span, this room cannot contribute forward geometry or ship collision.
    for (const [k] of this.rooms) {
      if (oldestDepth > roomZ(k) + LANDMARK_SURFACE_HALF_SPAN) this.rooms.delete(k);
    }
    const depth = cave.centers[slot][2];
    const k = Math.round((depth - ROOM_LEN / 2) / ROOM_SPACING);
    if (k < FIRST_ROOM_K || Math.abs(depth - roomZ(k)) > LANDMARK_SURFACE_HALF_SPAN) return;
    let room = this.rooms.get(k);
    if (!room) {
      room = { records: [], view: null };
      this.rooms.set(k, room);
      while (this.rooms.size > MAX_ROOM_SURFACE_STORES) this.rooms.delete(this.rooms.keys().next().value);
    }
    if (room.records.at(-1)?.center[2] === depth) return;
    const original = cave.frames[slot];
    const record = Object.freeze({
      center: Object.freeze([...cave.centers[slot]]),
      ring: Object.freeze(cave.segs[slot].map((vertex) => Object.freeze([...vertex]))),
      frame: Object.freeze({ center: frozenVector(original.center),
        tangent: frozenVector(original.tangent), right: frozenVector(original.right), up: frozenVector(original.up) }),
    });
    room.records.push(record);
    // Each view is a regular, chronological ring lattice, allowing the exact
    // same constant-time radius/ray selectors as the live CaveStream.
    room.view = Object.freeze({ roomSurfaceK: k, generation: this.generation,
      count: room.records.length, i: 0,
      centers: Object.freeze(room.records.map((item) => item.center)),
      segs: Object.freeze(room.records.map((item) => item.ring)),
      frames: Object.freeze(room.records.map((item) => item.frame)),
    });
  }

  surfaceFor(k) { return this.rooms.get(k)?.view ?? null; }

  resourceMetrics() {
    let rings = 0, numericBytes = 0;
    for (const room of this.rooms.values()) for (const record of room.records) {
      rings++;
      // Logical Float64 coordinate payload, excluding JS object overhead;
      // overall heap is independently measured by the existing perf harness.
      numericBytes += (record.ring.length * 3 + 3 + 4 * 3) * 8;
    }
    return Object.freeze({ rooms: this.rooms.size, maxRooms: MAX_ROOM_SURFACE_STORES,
      rings, numericBytes, maxRingsPerRoom: Math.floor(2 * LANDMARK_SURFACE_HALF_SPAN / SEGMENT_LEN) + 1 });
  }
}
