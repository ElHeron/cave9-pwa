// Exact, pure-Core distance to an indexed landmark surface. The visible mesh
// and the collision query consume the same world vertices and triangles.
// Query-only closure triangles make an open wall root a signed solid but never
// contribute to nearest distance or repulsion.

const RAY_DIRECTIONS = [
  [1, 0.347291, 0.521731],
  [0.427193, 1, 0.309107],
  [0.277459, 0.619031, 1],
];
const RAY_EPSILON = 1e-10;
const SURFACE_EPSILON = 1e-8;

export function pointAabbDistanceSquared(point, bounds) {
  let squared = 0;
  for (let axis = 0; axis < 3; axis++) {
    const delta = point[axis] < bounds.min[axis]
      ? bounds.min[axis] - point[axis]
      : point[axis] > bounds.max[axis] ? point[axis] - bounds.max[axis] : 0;
    squared += delta * delta;
  }
  return squared;
}

function pointInsideBounds(point, bounds) {
  for (let axis = 0; axis < 3; axis++) {
    if (point[axis] < bounds.min[axis] - SURFACE_EPSILON
        || point[axis] > bounds.max[axis] + SURFACE_EPSILON) return false;
  }
  return true;
}

// Ericson's seven triangle regions, with a caller-owned result. Every branch
// writes qx/qy/qz; there are no temporary arrays or objects per triangle.
export function closestTrianglePointInto(px, py, pz, vertices, ai, bi, ci, out) {
  const ax = vertices[ai], ay = vertices[ai + 1], az = vertices[ai + 2];
  const bx = vertices[bi], by = vertices[bi + 1], bz = vertices[bi + 2];
  const cx = vertices[ci], cy = vertices[ci + 1], cz = vertices[ci + 2];
  const abx = bx - ax, aby = by - ay, abz = bz - az;
  const acx = cx - ax, acy = cy - ay, acz = cz - az;
  const apx = px - ax, apy = py - ay, apz = pz - az;
  const d1 = abx * apx + aby * apy + abz * apz;
  const d2 = acx * apx + acy * apy + acz * apz;
  if (d1 <= 0 && d2 <= 0) { out.qx = ax; out.qy = ay; out.qz = az; return out; }
  const bpx = px - bx, bpy = py - by, bpz = pz - bz;
  const d3 = abx * bpx + aby * bpy + abz * bpz;
  const d4 = acx * bpx + acy * bpy + acz * bpz;
  if (d3 >= 0 && d4 <= d3) { out.qx = bx; out.qy = by; out.qz = bz; return out; }
  const vc = d1 * d4 - d3 * d2;
  if (vc <= 0 && d1 >= 0 && d3 <= 0) {
    const t = d1 / (d1 - d3);
    out.qx = ax + t * abx; out.qy = ay + t * aby; out.qz = az + t * abz; return out;
  }
  const cpx = px - cx, cpy = py - cy, cpz = pz - cz;
  const d5 = abx * cpx + aby * cpy + abz * cpz;
  const d6 = acx * cpx + acy * cpy + acz * cpz;
  if (d6 >= 0 && d5 <= d6) { out.qx = cx; out.qy = cy; out.qz = cz; return out; }
  const vb = d5 * d2 - d1 * d6;
  if (vb <= 0 && d2 >= 0 && d6 <= 0) {
    const t = d2 / (d2 - d6);
    out.qx = ax + t * acx; out.qy = ay + t * acy; out.qz = az + t * acz; return out;
  }
  const va = d3 * d6 - d5 * d4;
  if (va <= 0 && d4 - d3 >= 0 && d5 - d6 >= 0) {
    const t = (d4 - d3) / ((d4 - d3) + (d5 - d6));
    out.qx = bx + t * (cx - bx); out.qy = by + t * (cy - by); out.qz = bz + t * (cz - bz); return out;
  }
  const scale = 1 / (va + vb + vc);
  out.qx = ax + abx * (vb * scale) + acx * (vc * scale);
  out.qy = ay + aby * (vb * scale) + acy * (vc * scale);
  out.qz = az + abz * (vb * scale) + acz * (vc * scale);
  return out;
}

function rayHitsBounds(point, direction, bounds) {
  let near = 0, far = Infinity;
  for (let axis = 0; axis < 3; axis++) {
    const delta = direction[axis];
    const low = bounds.min[axis] - RAY_EPSILON;
    const high = bounds.max[axis] + RAY_EPSILON;
    if (Math.abs(delta) < 1e-15) {
      if (point[axis] < low || point[axis] > high) return false;
      continue;
    }
    let a = (low - point[axis]) / delta;
    let b = (high - point[axis]) / delta;
    if (a > b) { const swap = a; a = b; b = swap; }
    near = Math.max(near, a);
    far = Math.min(far, b);
    if (far < near) return false;
  }
  return far >= 0;
}

// Möller–Trumbore with strict interior barycentrics. A hit on a shared edge or
// vertex marks the ray ambiguous; another fixed direction is then tried. This
// prevents a seam from being counted twice or not at all.
function rayTriangle(point, direction, vertices, triangles, index, state) {
  const ai = triangles[index] * 3, bi = triangles[index + 1] * 3, ci = triangles[index + 2] * 3;
  const ax = vertices[ai], ay = vertices[ai + 1], az = vertices[ai + 2];
  const e1x = vertices[bi] - ax, e1y = vertices[bi + 1] - ay, e1z = vertices[bi + 2] - az;
  const e2x = vertices[ci] - ax, e2y = vertices[ci + 1] - ay, e2z = vertices[ci + 2] - az;
  const hx = direction[1] * e2z - direction[2] * e2y;
  const hy = direction[2] * e2x - direction[0] * e2z;
  const hz = direction[0] * e2y - direction[1] * e2x;
  const det = e1x * hx + e1y * hy + e1z * hz;
  if (Math.abs(det) < 1e-13) return;
  const inv = 1 / det;
  const sx = point[0] - ax, sy = point[1] - ay, sz = point[2] - az;
  const u = (sx * hx + sy * hy + sz * hz) * inv;
  if (u < -RAY_EPSILON || u > 1 + RAY_EPSILON) return;
  const qx = sy * e1z - sz * e1y;
  const qy = sz * e1x - sx * e1z;
  const qz = sx * e1y - sy * e1x;
  const v = (direction[0] * qx + direction[1] * qy + direction[2] * qz) * inv;
  if (v < -RAY_EPSILON || u + v > 1 + RAY_EPSILON) return;
  const t = (e2x * qx + e2y * qy + e2z * qz) * inv;
  if (t < -RAY_EPSILON) return;
  if (t <= RAY_EPSILON || u <= RAY_EPSILON || v <= RAY_EPSILON
      || 1 - u - v <= RAY_EPSILON) {
    state.ambiguous = true;
  } else {
    state.hits++;
  }
}

function rayParity(point, surface, direction, state) {
  state.hits = 0; state.ambiguous = false;
  const { vertices, visibleTriangles, queryClosureTriangles, strips } = surface;
  if (strips?.length) {
    for (const strip of strips) {
      if (!rayHitsBounds(point, direction, strip.bounds)) continue;
      for (let at = strip.start; at < strip.start + strip.count; at += 3) {
        rayTriangle(point, direction, vertices, visibleTriangles, at, state);
      }
    }
  } else {
    for (let at = 0; at < visibleTriangles.length; at += 3) {
      rayTriangle(point, direction, vertices, visibleTriangles, at, state);
    }
  }
  for (let at = 0; at < queryClosureTriangles.length; at += 3) {
    rayTriangle(point, direction, vertices, queryClosureTriangles, at, state);
  }
  return !state.ambiguous;
}

// Rare fallback if each fixed ray meets a mesh edge. The signed solid angle of
// a watertight oriented triangle shell is ±4π inside and zero outside.
function windingInside(point, surface) {
  const { vertices, visibleTriangles, queryClosureTriangles } = surface;
  let angle = 0;
  const accumulate = (triangles) => {
    for (let at = 0; at < triangles.length; at += 3) {
      const ai = triangles[at] * 3, bi = triangles[at + 1] * 3, ci = triangles[at + 2] * 3;
      const ax = vertices[ai] - point[0], ay = vertices[ai + 1] - point[1], az = vertices[ai + 2] - point[2];
      const bx = vertices[bi] - point[0], by = vertices[bi + 1] - point[1], bz = vertices[bi + 2] - point[2];
      const cx = vertices[ci] - point[0], cy = vertices[ci + 1] - point[1], cz = vertices[ci + 2] - point[2];
      const la = Math.hypot(ax, ay, az), lb = Math.hypot(bx, by, bz), lc = Math.hypot(cx, cy, cz);
      const triple = ax * (by * cz - bz * cy) + ay * (bz * cx - bx * cz) + az * (bx * cy - by * cx);
      const denominator = la * lb * lc
        + (ax * bx + ay * by + az * bz) * lc
        + (bx * cx + by * cy + bz * cz) * la
        + (cx * ax + cy * ay + cz * az) * lb;
      angle += 2 * Math.atan2(triple, denominator);
    }
  };
  accumulate(visibleTriangles);
  accumulate(queryClosureTriangles);
  return Math.abs(angle) > Math.PI * 2;
}

function surfaceInside(point, surface, out) {
  if (!pointInsideBounds(point, surface.bounds)) return false;
  const state = { hits: 0, ambiguous: false };
  for (const direction of RAY_DIRECTIONS) {
    out.parityRaysTried++;
    if (rayParity(point, surface, direction, state)) return (state.hits & 1) === 1;
  }
  out.windingFallback = true;
  return windingInside(point, surface);
}

function triangleNormal(vertices, triangles, at, out) {
  const ai = triangles[at] * 3, bi = triangles[at + 1] * 3, ci = triangles[at + 2] * 3;
  const abx = vertices[bi] - vertices[ai], aby = vertices[bi + 1] - vertices[ai + 1];
  const abz = vertices[bi + 2] - vertices[ai + 2];
  const acx = vertices[ci] - vertices[ai], acy = vertices[ci + 1] - vertices[ai + 1];
  const acz = vertices[ci + 2] - vertices[ai + 2];
  const nx = aby * acz - abz * acy, ny = abz * acx - abx * acz, nz = abx * acy - aby * acx;
  const length = Math.hypot(nx, ny, nz) || 1;
  out.nx = nx / length; out.ny = ny / length; out.nz = nz / length;
}

/**
 * Exact signed nearest distance to visible indexed triangles. `surface.strips`
 * use index-entry start/count and cover visibleTriangles once each. The nearest
 * AABB strip is visited first, then farther strips are pruned against the
 * current exact best; this still returns the full-surface nearest point needed
 * for left/right clearance. The optional `out` object is reusable. Build and
 * cache surface vertices, indices and bounds before the game-step query.
 */
export function queryTriangleSurface(point, surface, out = {}) {
  const { vertices, visibleTriangles, strips } = surface;
  if (!(visibleTriangles?.length > 0) || visibleTriangles.length % 3 !== 0) {
    throw new RangeError('triangle surface requires visible triangles');
  }
  const px = point[0], py = point[1], pz = point[2];
  let best2 = Infinity, bestAt = -1, qx = 0, qy = 0, qz = 0;
  let trianglesTested = 0, stripsTested = 0;
  const scan = (start, count) => {
    stripsTested++;
    for (let at = start; at < start + count; at += 3) {
      closestTrianglePointInto(px, py, pz, vertices,
        visibleTriangles[at] * 3, visibleTriangles[at + 1] * 3, visibleTriangles[at + 2] * 3, out);
      trianglesTested++;
      const dx = px - out.qx, dy = py - out.qy, dz = pz - out.qz;
      const d2 = dx * dx + dy * dy + dz * dz;
      if (d2 < best2) { best2 = d2; bestAt = at; qx = out.qx; qy = out.qy; qz = out.qz; }
    }
  };
  if (strips?.length) {
    let nearest = 0, nearestBound2 = Infinity;
    for (let i = 0; i < strips.length; i++) {
      const lower = pointAabbDistanceSquared(point, strips[i].bounds);
      if (lower < nearestBound2) { nearest = i; nearestBound2 = lower; }
    }
    scan(strips[nearest].start, strips[nearest].count);
    for (let i = 0; i < strips.length; i++) {
      if (i !== nearest && pointAabbDistanceSquared(point, strips[i].bounds) < best2) {
        scan(strips[i].start, strips[i].count);
      }
    }
  } else {
    scan(0, visibleTriangles.length);
  }
  if (bestAt < 0) throw new RangeError('triangle surface strips do not cover visible triangles');
  const magnitude = Math.sqrt(best2);
  out.parityRaysTried = 0; out.windingFallback = false;
  const inside = magnitude > SURFACE_EPSILON && surfaceInside(point, surface, out);
  const distance = magnitude <= SURFACE_EPSILON ? 0 : inside ? -magnitude : magnitude;
  out.qx = qx; out.qy = qy; out.qz = qz;
  out.distance = distance; out.surfaceDistance = distance; out.inside = inside;
  out.trianglesTested = trianglesTested; out.stripsTested = stripsTested;
  if (magnitude > SURFACE_EPSILON) {
    const sign = inside ? -1 : 1;
    out.nx = sign * (px - qx) / magnitude;
    out.ny = sign * (py - qy) / magnitude;
    out.nz = sign * (pz - qz) / magnitude;
  } else {
    triangleNormal(vertices, visibleTriangles, bestAt, out);
  }
  return out;
}
