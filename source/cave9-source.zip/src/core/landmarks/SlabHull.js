// A crystal plate's shared geometric authority. No renderer or browser imports.
//
// One convex eight-corner fracture outline has two shallow, offset face ridges.
// Its eighteen world vertices are the shared positions consumed by both the
// renderer and the exact surface query. A piece capsule still bounds this hull
// and remains the cheap broad-phase and no-entry-tube safety contract.

const CORNERS = 8;
const TRIANGLES = 32;
const FACES = 24;

const DEFAULT_SLAB = Object.freeze({
  baseLeft: 0.77,
  baseRight: 0.89,
  lowerBreakAt: 0.28,
  lowerBreak2At: 0.68,
  upperBreakAt: 0.30,
  upperBreak2At: 0.66,
  lowerBulge: 0.42,
  upperBulge: 0.34,
  tipWidth: 0.09,
  tipShift: 0.04,
  tipLowerAt: 1,
  tipUpperAt: 1,
  baseThickness: 0.46,
  tipThickness: 0.18,
  ridgeAt: 0.55,
  ridgeShift: 0.04,
  ridgeHeight: 0.04,
  rootOverhang: 0,
});

function unit(x, y, z) {
  const length = Math.hypot(x, y, z);
  if (!(length > 0) || !Number.isFinite(length)) throw new RangeError('slab direction must be finite and nonzero');
  return { x: x / length, y: y / length, z: z / length };
}

function cross(a, b) {
  return {
    x: a.y * b.z - a.z * b.y,
    y: a.z * b.x - a.x * b.z,
    z: a.x * b.y - a.y * b.x,
  };
}

function profileFor(piece) {
  const profile = { ...DEFAULT_SLAB, ...piece.slab };
  for (const [key, value] of Object.entries(profile)) {
    if (!Number.isFinite(value)) throw new RangeError(`slab ${key} must be finite`);
  }
  if (profile.baseLeft <= 0 || profile.baseRight <= 0
      || profile.tipWidth <= 0 || profile.baseThickness <= 0 || profile.tipThickness <= 0
      || profile.rootOverhang < 0
      || profile.lowerBulge <= 0 || profile.upperBulge <= 0
      || profile.ridgeHeight <= 0 || profile.ridgeAt <= 0 || profile.ridgeAt >= 1
      || profile.lowerBreakAt <= 0 || profile.lowerBreak2At >= 1
      || profile.lowerBreakAt >= profile.lowerBreak2At
      || profile.upperBreakAt <= 0 || profile.upperBreak2At >= 1
      || profile.upperBreakAt >= profile.upperBreak2At
      || profile.tipLowerAt <= 0 || profile.tipLowerAt > 1
      || profile.tipUpperAt <= 0 || profile.tipUpperAt > 1) {
    throw new RangeError('slab profile has a degenerate width, thickness or fracture');
  }
  return profile;
}

function outlineFor(length, radius, profile) {
  const p = profile;
  const root = -p.rootOverhang * radius;
  const lowerTip = [(p.tipLowerAt * length), (p.tipShift - p.tipWidth) * radius];
  const upperTip = [(p.tipUpperAt * length), (p.tipShift + p.tipWidth) * radius];
  const lower = (t) => [root + (lowerTip[0] - root) * t,
    -p.baseLeft * radius + (lowerTip[1] + p.baseLeft * radius) * t
      - p.lowerBulge * radius * t * (1 - t)];
  const upper = (t) => [root + (upperTip[0] - root) * t,
    p.baseRight * radius + (upperTip[1] - p.baseRight * radius) * t
      + p.upperBulge * radius * t * (1 - t)];
  const outline = [
    [root, -p.baseLeft * radius],
    lower(p.lowerBreakAt),
    lower(p.lowerBreak2At),
    lowerTip,
    upperTip,
    upper(p.upperBreak2At),
    upper(p.upperBreakAt),
    [root, p.baseRight * radius],
  ];
  for (let i = 0; i < CORNERS; i++) {
    const a = outline[i], b = outline[(i + 1) % CORNERS];
    const c = outline[(i + 2) % CORNERS];
    const turn = (b[0] - a[0]) * (c[1] - b[1]) - (b[1] - a[1]) * (c[0] - b[0]);
    if (!(turn > length * radius * 1e-6)) {
      throw new RangeError(`slab outline is not strictly convex at corner ${i + 1}`);
    }
  }
  return outline;
}

function triangleIndices() {
  const triangles = new Uint8Array(TRIANGLES * 3);
  let cursor = 0;
  const tri = (a, b, c) => {
    triangles[cursor++] = a; triangles[cursor++] = b; triangles[cursor++] = c;
  };
  // +B face, -B face, then eight outward side quads. Each face has stable
  // topology, even when the authored widths, shoulders and roll vary.
  for (let i = 0; i < CORNERS; i++) tri(CORNERS * 2, CORNERS + i, CORNERS + (i + 1) % CORNERS);
  for (let i = 0; i < CORNERS; i++) tri(CORNERS * 2 + 1, (i + 1) % CORNERS, i);
  for (let i = 0; i < CORNERS; i++) {
    const j = (i + 1) % CORNERS;
    tri(i, j, j + CORNERS);
    tri(i, j + CORNERS, i + CORNERS);
  }
  return triangles;
}

// Face planes are built only once with the hull. The query reuses them for a
// signed inside test without recomputing triangle normals on every game step.
function facePlanes(vertices, triangles) {
  const planes = new Float64Array(FACES * 4);
  for (let face = 0; face < FACES; face++) {
    const representative = face < 16 ? face : 16 + (face - 16) * 2;
    const offset = representative * 3;
    const ia = triangles[offset] * 3, ib = triangles[offset + 1] * 3, ic = triangles[offset + 2] * 3;
    const abx = vertices[ib] - vertices[ia], aby = vertices[ib + 1] - vertices[ia + 1];
    const abz = vertices[ib + 2] - vertices[ia + 2];
    const acx = vertices[ic] - vertices[ia], acy = vertices[ic + 1] - vertices[ia + 1];
    const acz = vertices[ic + 2] - vertices[ia + 2];
    const normal = unit(aby * acz - abz * acy, abz * acx - abx * acz, abx * acy - aby * acx);
    const at = face * 4;
    planes[at] = normal.x; planes[at + 1] = normal.y; planes[at + 2] = normal.z;
    planes[at + 3] = normal.x * vertices[ia] + normal.y * vertices[ia + 1] + normal.z * vertices[ia + 2];
  }
  // A convex hull needs every vertex behind every outward plane. This catches
  // invalid artist profiles and inconsistent winding before either consumer
  // receives a body that cannot be queried faithfully.
  for (let face = 0; face < FACES; face++) {
    const at = face * 4;
    for (let vertex = 0; vertex < CORNERS * 2 + 2; vertex++) {
      const vi = vertex * 3;
      const side = planes[at] * vertices[vi] + planes[at + 1] * vertices[vi + 1]
        + planes[at + 2] * vertices[vi + 2] - planes[at + 3];
      if (side > 1e-7) throw new RangeError(`slab is nonconvex or inward-wound at face ${face}: ${side}`);
    }
  }
  return planes;
}

/**
 * Build one final world-space plate from a Core blade piece. `piece.slab` may
 * override any normalized DEFAULT_SLAB field; widths, shifts and thicknesses
 * are fractions of piece.radius, while shoulder positions are fractions of
 * piece.length. `rootOverhang` extends the broad base behind the endpoint into
 * the wall, inside the endpoint sphere. Invalid profiles fail instead of
 * silently escaping the capsule.
 *
 * Returned `triangles` index the shared 18 world vertices. Triangle ranges are
 * front [0,8), back [8,16), eight side pairs [16,32). The `planes` array stores
 * 24 outward (nx,ny,nz,d) face equations. Cache the object per composition;
 * do not call this from a frame query.
 */
export function slabHullForPiece(piece) {
  if (piece?.shape !== 'blade' || !(piece.length > 0) || !(piece.radius > 0)
      || !Number.isFinite(piece.length) || !Number.isFinite(piece.radius)) {
    throw new RangeError('a slab requires a finite blade piece with positive length and radius');
  }
  const T = unit(piece.dx, piece.dy, piece.dz);
  let N0;
  if (piece.slabAcross) {
    const desired = unit(piece.slabAcross.x, piece.slabAcross.y, piece.slabAcross.z);
    const along = T.x * desired.x + T.y * desired.y + T.z * desired.z;
    // The live cave supplies its local circumferential tangent. Project it
    // onto the final world piece plane so path curvature cannot turn a broad
    // face edge-on or subtly shear the capsule-covered wedge.
    N0 = unit(desired.x - T.x * along, desired.y - T.y * along,
      desired.z - T.z * along);
  } else {
    const reference = Math.abs(T.x) < 0.9 ? { x: 1, y: 0, z: 0 } : { x: 0, y: 1, z: 0 };
    const perpendicular = cross(T, reference);
    N0 = unit(perpendicular.x, perpendicular.y, perpendicular.z);
  }
  const B0 = cross(T, N0);
  const roll = piece.slabAcross ? (piece.orbitTwist ?? 0) : (piece.roll ?? 0);
  if (!Number.isFinite(roll)) throw new RangeError('slab roll must be finite');
  const cr = Math.cos(roll), sr = Math.sin(roll);
  const N = { x: N0.x * cr + B0.x * sr, y: N0.y * cr + B0.y * sr, z: N0.z * cr + B0.z * sr };
  const B = cross(T, N);
  const base = {
    x: piece.cx - T.x * piece.length / 2,
    y: piece.cy - T.y * piece.length / 2,
    z: piece.cz - T.z * piece.length / 2,
  };
  if (![base.x, base.y, base.z].every(Number.isFinite)) throw new RangeError('slab position must be finite');
  const profile = profileFor(piece);
  const outline = outlineFor(piece.length, piece.radius, profile);
  const vertices = new Float64Array((CORNERS * 2 + 2) * 3);
  const bounds = new Float64Array([Infinity, Infinity, Infinity, -Infinity, -Infinity, -Infinity]);
  for (let side = 0; side < 2; side++) for (let i = 0; i < CORNERS; i++) {
    const [along, across] = outline[i];
    const rootDistance = profile.rootOverhang * piece.radius;
    const axialFraction = (along + rootDistance) / (piece.length + rootDistance);
    const thickness = piece.radius * (profile.baseThickness
      + (profile.tipThickness - profile.baseThickness) * axialFraction) / 2;
    const capExtension = Math.max(0, -along, along - piece.length);
    if (Math.hypot(capExtension, across, thickness) > piece.radius - 1e-5) {
      throw new RangeError(`slab corner ${i} escapes its authoritative capsule`);
    }
    const out = side === 0 ? -thickness : thickness;
    const vi = (side * CORNERS + i) * 3;
    vertices[vi] = base.x + T.x * along + N.x * across + B.x * out;
    vertices[vi + 1] = base.y + T.y * along + N.y * across + B.y * out;
    vertices[vi + 2] = base.z + T.z * along + N.z * across + B.z * out;
    for (let axis = 0; axis < 3; axis++) {
      bounds[axis] = Math.min(bounds[axis], vertices[vi + axis]);
      bounds[axis + 3] = Math.max(bounds[axis + 3], vertices[vi + axis]);
    }
  }
  const ridgeAlong = profile.ridgeAt * piece.length;
  const ridgeAcross = profile.ridgeShift * piece.radius;
  for (let side = 0; side < 2; side++) {
    const axialFraction = (ridgeAlong + profile.rootOverhang * piece.radius)
      / (piece.length + profile.rootOverhang * piece.radius);
    const tapered = piece.radius * (profile.baseThickness
      + (profile.tipThickness - profile.baseThickness) * axialFraction) / 2;
    const thickness = tapered + profile.ridgeHeight * piece.radius;
    if (Math.hypot(ridgeAcross, thickness) > piece.radius - 1e-5) {
      throw new RangeError('slab ridge escapes its authoritative capsule');
    }
    const out = side === 0 ? thickness : -thickness;
    const vi = (CORNERS * 2 + side) * 3;
    vertices[vi] = base.x + T.x * ridgeAlong + N.x * ridgeAcross + B.x * out;
    vertices[vi + 1] = base.y + T.y * ridgeAlong + N.y * ridgeAcross + B.y * out;
    vertices[vi + 2] = base.z + T.z * ridgeAlong + N.z * ridgeAcross + B.z * out;
    for (let axis = 0; axis < 3; axis++) {
      bounds[axis] = Math.min(bounds[axis], vertices[vi + axis]);
      bounds[axis + 3] = Math.max(bounds[axis + 3], vertices[vi + axis]);
    }
  }
  const triangles = triangleIndices();
  const planes = facePlanes(vertices, triangles);
  return { vertices, triangles, planes, bounds, profile, outline,
    ridgeLocal: [ridgeAlong, ridgeAcross] };
}

// Ericson's seven-region point/triangle test, with a caller-owned result. No
// arrays, normals or temporary objects are created inside the triangle loop.
function closestTriangleInto(px, py, pz, v, ai, bi, ci, out) {
  const ax = v[ai], ay = v[ai + 1], az = v[ai + 2];
  const bx = v[bi], by = v[bi + 1], bz = v[bi + 2];
  const cx = v[ci], cy = v[ci + 1], cz = v[ci + 2];
  const abx = bx - ax, aby = by - ay, abz = bz - az;
  const acx = cx - ax, acy = cy - ay, acz = cz - az;
  const apx = px - ax, apy = py - ay, apz = pz - az;
  const d1 = abx * apx + aby * apy + abz * apz;
  const d2 = acx * apx + acy * apy + acz * apz;
  if (d1 <= 0 && d2 <= 0) { out.qx = ax; out.qy = ay; out.qz = az; return; }
  const bpx = px - bx, bpy = py - by, bpz = pz - bz;
  const d3 = abx * bpx + aby * bpy + abz * bpz;
  const d4 = acx * bpx + acy * bpy + acz * bpz;
  if (d3 >= 0 && d4 <= d3) { out.qx = bx; out.qy = by; out.qz = bz; return; }
  const vc = d1 * d4 - d3 * d2;
  if (vc <= 0 && d1 >= 0 && d3 <= 0) {
    const t = d1 / (d1 - d3);
    out.qx = ax + t * abx; out.qy = ay + t * aby; out.qz = az + t * abz; return;
  }
  const cpx = px - cx, cpy = py - cy, cpz = pz - cz;
  const d5 = abx * cpx + aby * cpy + abz * cpz;
  const d6 = acx * cpx + acy * cpy + acz * cpz;
  if (d6 >= 0 && d5 <= d6) { out.qx = cx; out.qy = cy; out.qz = cz; return; }
  const vb = d5 * d2 - d1 * d6;
  if (vb <= 0 && d2 >= 0 && d6 <= 0) {
    const t = d2 / (d2 - d6);
    out.qx = ax + t * acx; out.qy = ay + t * acy; out.qz = az + t * acz; return;
  }
  const va = d3 * d6 - d5 * d4;
  if (va <= 0 && d4 - d3 >= 0 && d5 - d6 >= 0) {
    const t = (d4 - d3) / ((d4 - d3) + (d5 - d6));
    out.qx = bx + t * (cx - bx); out.qy = by + t * (cy - by); out.qz = bz + t * (cz - bz); return;
  }
  const scale = 1 / (va + vb + vc);
  out.qx = ax + abx * (vb * scale) + acx * (vc * scale);
  out.qy = ay + aby * (vb * scale) + acy * (vc * scale);
  out.qz = az + abz * (vb * scale) + acz * (vc * scale);
}

/** Exact signed distance to a cached plate hull. `out` may be reused by caller. */
export function querySlabHull(point, hull, out = {}) {
  const px = point[0], py = point[1], pz = point[2];
  const { vertices, triangles, planes } = hull;
  let inside = true;
  for (let face = 0; face < FACES; face++) {
    const at = face * 4;
    if (planes[at] * px + planes[at + 1] * py + planes[at + 2] * pz - planes[at + 3] > 1e-7) {
      inside = false; break;
    }
  }
  let best2 = Infinity, bestFace = -1, qx = 0, qy = 0, qz = 0;
  for (let triangle = 0; triangle < TRIANGLES; triangle++) {
    const at = triangle * 3;
    closestTriangleInto(px, py, pz, vertices, triangles[at] * 3,
      triangles[at + 1] * 3, triangles[at + 2] * 3, out);
    const dx = px - out.qx, dy = py - out.qy, dz = pz - out.qz;
    const d2 = dx * dx + dy * dy + dz * dz;
    if (d2 < best2) {
      best2 = d2; bestFace = triangle < 16 ? triangle : 16 + Math.floor((triangle - 16) / 2);
      qx = out.qx; qy = out.qy; qz = out.qz;
    }
  }
  const distance = Math.sqrt(best2);
  const sign = inside ? -1 : 1;
  const plane = bestFace * 4;
  out.qx = qx; out.qy = qy; out.qz = qz;
  out.distance = distance;
  out.surfaceDistance = distance < 1e-6 ? 0 : sign * distance;
  out.inside = inside;
  out.nx = distance > 1e-6 ? sign * (px - qx) / distance : planes[plane];
  out.ny = distance > 1e-6 ? sign * (py - qy) / distance : planes[plane + 1];
  out.nz = distance > 1e-6 ? sign * (pz - qz) / distance : planes[plane + 2];
  return out;
}
