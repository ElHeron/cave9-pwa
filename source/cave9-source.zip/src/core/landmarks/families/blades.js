// V03 — three depth-staggered clusters of heavy fractured crystal plates.
//
// Each visible plate is one safety-checked Core blade piece. Its eight-corner
// broken wedge profile is authored here and later turned into one shared world hull
// for rendering and exact collision. Uneven paired wall sectors and varied
// depth/roll keep the room from becoming a regular 36-spoke iris.

import {
  LANDMARK_MAX_PIECES, makePiece, norm3, pieceSafe,
} from '../safety.js';

const DEG = Math.PI / 180;
const BANK_OFFSETS = [-55, -17, 23];

// Five dominant masses, eight middle plates and five companion fractures form
// three physical clusters. Each cluster shares a broad wall sector and its
// plates cross at mid-body before their differently directed ends separate.
// Bank order keeps honest, contiguous development-orbit ranges.
const BANK_PLATES = [
  [
    { angle: 15, major: true, depth: -2, lean: 1, twist: -0.22, sweep: -9, mass: 1.08 },
    { angle: 21, major: true, dominant: true, depth: -1, lean: 0, twist: 0.18, sweep: -16, mass: 1.17 },
    { angle: 29, major: true, depth: 1, lean: -1, twist: 0.25, sweep: 14, mass: 0.96 },
    { angle: 27, major: true, dominant: true, depth: 2, lean: 0, twist: -0.18, sweep: 13, mass: 1.04 },
    { angle: 34, major: true, depth: 0, lean: 1, twist: 0.31, sweep: -4, mass: 0.92 },
    { angle: 18, major: false, depth: -1, lean: -1, twist: -0.10, sweep: 5, mass: 0.95 },
    { angle: 32, major: false, depth: 2, lean: 1, twist: 0.35, sweep: -12, mass: 0.88 },
  ],
  [
    { angle: 199, major: true, dominant: true, depth: -1, lean: 0, twist: -0.20, sweep: -14, mass: 1.07 },
    { angle: 194, major: true, depth: -2, lean: 1, twist: 0.25, sweep: 9, mass: 0.94 },
    { angle: 207, major: true, dominant: true, depth: 2, lean: 0, twist: 0.18, sweep: 16, mass: 1.19 },
    { angle: 213, major: true, depth: 1, lean: -1, twist: -0.25, sweep: -9, mass: 1.00 },
    { angle: 203, major: false, depth: 0, lean: -1, twist: 0.27, sweep: 6, mass: 0.93 },
    { angle: 210, major: false, depth: 1, lean: 1, twist: -0.10, sweep: -5, mass: 0.89 },
  ],
  [
    { angle: 299, major: true, depth: -1, lean: 1, twist: 0.25, sweep: 8, mass: 1.06 },
    { angle: 315, major: true, depth: 1, lean: -1, twist: -0.30, sweep: -12, mass: 0.97 },
    { angle: 307, major: true, dominant: true, depth: 0, lean: 0, twist: 0.16, sweep: -4, mass: 1.15 },
    { angle: 312, major: true, depth: 2, lean: 1, twist: -0.20, sweep: 8, mass: 0.99 },
    { angle: 302, major: false, depth: -2, lean: -1, twist: 0.30, sweep: -6, mass: 0.91 },
  ],
];

function endpoint(piece, sign) {
  const half = piece.length / 2;
  return {
    x: piece.cx + sign * piece.dx * half,
    y: piece.cy + sign * piece.dy * half,
    z: piece.cz + sign * piece.dz * half,
  };
}

function slabProfile(rng, tier) {
  const major = tier > 1;
  const baseLeft = major ? 0.70 + rng() * 0.09 : 0.64 + rng() * 0.10;
  const baseRight = tier === 3 ? 0.83 + rng() * 0.07
    : tier === 2 ? 0.79 + rng() * 0.07 : 0.76 + rng() * 0.08;
  return {
    baseLeft, baseRight,
    lowerBreakAt: 0.20 + rng() * 0.10,
    lowerBreak2At: 0.62 + rng() * 0.10,
    upperBreakAt: 0.24 + rng() * 0.10,
    upperBreak2At: 0.61 + rng() * 0.11,
    lowerBulge: (major ? 0.38 : 0.32) + rng() * 0.18,
    upperBulge: (major ? 0.28 : 0.24) + rng() * 0.19,
    tipWidth: (tier === 3 ? 0.24 : tier === 2 ? 0.17 : 0.10)
      + rng() * (tier === 3 ? 0.10 : 0.07),
    tipShift: (rng() - 0.5) * (tier === 3 ? 0.28 : 0.19),
    tipLowerAt: 0.94 + rng() * 0.04,
    tipUpperAt: 0.94 + rng() * 0.04,
    baseThickness: (major ? 0.42 : 0.33) + rng() * 0.06,
    tipThickness: (major ? 0.16 : 0.13) + rng() * 0.06,
    ridgeAt: 0.44 + rng() * 0.20,
    ridgeShift: (rng() - 0.5) * 0.22,
    ridgeHeight: (major ? 0.09 : 0.07) + rng() * 0.06,
    rootOverhang: (tier === 3 ? 0.29 : tier === 2 ? 0.37 : 0.45) + rng() * 0.02,
  };
}

/** Build the pure Core piece grammar in route-local room coordinates. */
export function buildReferenceBlades(rng, cx, cy, z, inner, outer, wall) {
  const pieces = [];
  const annulus = outer - inner;
  const bankZs = BANK_OFFSETS.map((offset) => z + offset + (rng() - 0.5) * 5);
  const phase = (rng() - 0.5) * 0.22;
  for (let bank = 0; bank < BANK_PLATES.length; bank++) {
    const bankTurn = (rng() - 0.5) * 0.08;
    const layout = BANK_PLATES[bank];
    for (let slot = 0; slot < layout.length && pieces.length < LANDMARK_MAX_PIECES; slot++) {
      const design = layout[slot];
      const az = phase + bankTurn + design.angle * DEG + (rng() - 0.5) * 0.08;
      const baseR = outer - rng() * Math.min(0.24, annulus * 0.018);
      const desiredClearance = (design.major ? 1.05 : 1.40) + rng() * 0.35;
      const nominalRadius = design.dominant
        ? annulus * 0.28 * design.mass + rng() * 0.34
        : design.major
          ? annulus * 0.185 * design.mass + rng() * 0.27
          : annulus * 0.125 * design.mass + rng() * 0.24;
      const contactRadius = wall - baseR + 0.16;
      const availableRadius = baseR - inner - desiredClearance - 0.45;
      const radius = Math.min(Math.max(nominalRadius, contactRadius), availableRadius);
      if (!(radius > 0.35)) continue;
      const maxClearance = Math.max(0.12, baseR - inner - radius - 0.4);
      const surfaceClearance = Math.min(desiredClearance, maxClearance);
      const tipR = Math.min(baseR - 0.35, inner + radius + surfaceClearance);
      const baseZ = bankZs[bank] + design.depth + (rng() - 0.5) * 1.5;
      const tipZ = baseZ + design.lean + (rng() - 0.5) * (design.dominant ? 2 : 5);
      const base = { x: cx + baseR * Math.cos(az),
        y: cy + baseR * Math.sin(az), z: baseZ };
      const tipAz = az + (design.sweep + (rng() - 0.5) * 3) * DEG;
      const tip = { x: cx + tipR * Math.cos(tipAz),
        y: cy + tipR * Math.sin(tipAz), z: tipZ };
      const dir = norm3(tip.x - base.x, tip.y - base.y, tip.z - base.z);
      const length = Math.hypot(tip.x - base.x, tip.y - base.y, tip.z - base.z);
      const piece = makePiece('blade', base, dir, length, radius);
      if (!pieceSafe(piece, cx, cy, inner, wall)) continue;
      piece.gid = pieces.length;
      piece.node = 0;
      piece.bank = bank;
      piece.bankZ = bankZs[bank];
      piece.slot = slot;
      piece.major = !!design.dominant;
      piece.tier = design.dominant ? 3 : design.major ? 2 : 1;
      piece.role = design.dominant ? 'fracture-anchor'
        : design.major ? 'fracture-mass' : 'fracture-companion';
      piece.profile = design.dominant ? 'anchor' : design.major ? 'mass' : 'companion';
      // The broad axis is near the Hero image plane, but several substantial
      // opposing rolls reveal actual thickness from an oblique orbit.
      const orbitTwist = design.twist + (rng() - 0.5) * 0.09;
      piece.roll = Math.PI / 2 + orbitTwist;
      piece.orbitTwist = orbitTwist;
      piece.slab = slabProfile(rng, piece.tier);
      piece.surfaceClearance = surfaceClearance;
      piece.wallRooted = true;
      pieces.push(piece);
    }
  }
  Object.defineProperty(pieces, 'bounds', {
    enumerable: false,
    value: pieces.reduce((bounds, piece) => {
      const a = endpoint(piece, -1), b = endpoint(piece, 1);
      bounds.zMin = Math.min(bounds.zMin, a.z, b.z);
      bounds.zMax = Math.max(bounds.zMax, a.z, b.z);
      return bounds;
    }, { zMin: Infinity, zMax: -Infinity }),
  });
  return pieces;
}
