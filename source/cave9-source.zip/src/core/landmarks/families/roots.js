// Three wall-grown trunks with substantial, parent-attached side branches.
import { makePiece, norm3, pieceSafe, LANDMARK_MAX_PIECES } from '../safety.js';

const mix = (a, b, t) => a + (b - a) * t;
const polar = (cx, cy, radius, angle, z) => ({
  x: cx + radius * Math.cos(angle), y: cy + radius * Math.sin(angle), z,
});

// Accept a whole chain; rejecting individual segments would detach its fork.
function append(out, nodes, radii, metadata, cx, cy, inner, wall) {
  const pending = [];
  for (let i = 1; i < nodes.length; i++) {
    const a = nodes[i - 1], b = nodes[i];
    const length = Math.hypot(b.x - a.x, b.y - a.y, b.z - a.z);
    const piece = Object.assign(makePiece('limb', a,
      norm3(b.x - a.x, b.y - a.y, b.z - a.z), length, radii[i - 1]),
    metadata, { node: i - 1, wallContact: !!metadata.wallRooted && i <= 2 });
    if (!pieceSafe(piece, cx, cy, inner, wall)) return false;
    pending.push(piece);
  }
  if (out.length + pending.length > LANDMARK_MAX_PIECES) return false;
  out.push(...pending);
  return true;
}

export function buildReferenceRoots(rng, cx, cy, z, inner, outer, wall) {
  const out = [], phase = rng() * Math.PI * 2, annulus = wall - inner;
  for (let tree = 0; tree < 3; tree++) {
    const azimuth = phase + tree * Math.PI * 2 / 3 + (rng() - .5) * .20;
    const rootZ = z + [-25, 8, 29][tree] + (rng() - .5) * 5;
    const base = Math.min(2.75, annulus * .25) * [1.15, .91, 1.03][tree];
    const tip = Math.max(.18, base * .09), pull = 17 + tree * 2 + rng() * 3;
    const radii = Array.from({ length: 8 }, (_, i) => mix(base, tip, (i / 7) ** 1.05));
    const endRadius = inner + radii[6] + 1.8;
    const nodes = Array.from({ length: 9 }, (_, i) => {
      const t = i / 8;
      return polar(cx, cy, mix(wall - 1e-4, endRadius, t * (1.6 - .6 * t)),
        azimuth + (tree % 2 ? 1 : -1) * .22 * t,
        rootZ - pull * (.65 * t + .35 * t * t));
    });
    const gid = `root-tree-${tree}`;
    if (!append(out, nodes, radii, {
      gid, componentGid: gid, tier: 2, role: 'hero-claw', wallRooted: true,
      wallContactSegments: 2, treeIndex: tree,
    }, cx, cy, inner, wall)) continue;

    // Different forks: five children use 25 segments, three trunks use 24.
    for (let child = 0; child < (tree === 1 ? 1 : 2); child++) {
      const station = child === 0 ? 2 : 4, parent = nodes[station];
      const radius = radii[station] * [.68, .58][child];
      const childTip = Math.max(.10, radius * .18);
      const parentRadius = Math.hypot(parent.x - cx, parent.y - cy);
      const direction = (tree + child) % 2 ? 1 : -1;
      const arc = direction * (.25 + rng() * .12);
      const axial = (child === 0 ? -1 : 1) * (7 + tree * 1.3 + rng() * 2);
      const parentDirection = norm3(nodes[station + 1].x - nodes[station - 1].x,
        nodes[station + 1].y - nodes[station - 1].y,
        nodes[station + 1].z - nodes[station - 1].z);
      const lead = Math.min(2.1, Math.max(.12, (parentRadius - inner - radius - .35) * .55));
      const childNodes = Array.from({ length: 6 }, (_, i) => {
        const t = i / 5, stem = lead * (1 - Math.exp(-5 * t)) / (1 - Math.exp(-5));
        const spread = Math.max(0, (t - .2) / .8);
        // Preserve a parent-aligned first segment, then reveal the thick fork.
        const fork = t <= .2 ? t * t * t : .008 + .992 * spread * spread * (3 - 2 * spread);
        const x = parent.x + parentDirection.x * stem - cx;
        const y = parent.y + parentDirection.y * stem - cy;
        const angle = arc * fork;
        return {
          x: cx + x * Math.cos(angle) - y * Math.sin(angle),
          y: cy + x * Math.sin(angle) + y * Math.cos(angle),
          z: parent.z + parentDirection.z * stem + axial * fork,
        };
      });
      const childRadii = [1, .95, .80, .52, .18]
        .map((scale) => Math.max(childTip, radius * scale));
      append(out, childNodes, childRadii, {
        gid: `${gid}-branch-${child}`, componentGid: gid, parentGid: gid,
        parentNode: station, parentT: 0, treeIndex: tree, tier: 1,
        role: 'root-branch', wallRooted: false, branchIndex: child,
        startInsideParent: true, parentRadius: radii[station],
      }, cx, cy, inner, wall);
    }
  }
  return out;
}
