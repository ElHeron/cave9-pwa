// LEGACY C3 comparison fixture — deliberately NOT routed by families.js.
//
// Production coiling is `coiling-shell-v1` in core/CoilingShell.js and emits
// zero landmark pieces/colliders/draws. Keep this former capsule approximation
// only until the browser/performance G0↔G2 comparison has been accepted; tests
// and diagnostic scripts may import it directly, but runtime code must not.

import {
  LANDMARK_MAX_PIECES, makePiece, norm3, pieceSafe,
} from '../safety.js';

const TAU = Math.PI * 2;
const SEGMENTS_PER_HELIX = 48;
const HELIX_COUNT = 2;

function clamp(value, lo, hi) {
  return Math.max(lo, Math.min(hi, value));
}

function polar(cx, cy, radial, azimuth, z) {
  return {
    x: cx + radial * Math.cos(azimuth),
    y: cy + radial * Math.sin(azimuth),
    z,
  };
}

function radialFrom(cx, cy, point) {
  return Math.hypot(point.x - cx, point.y - cy);
}

function segmentRadiusLimit(cx, cy, inner, a, b) {
  const middle = {
    x: (a.x + b.x) * 0.5,
    y: (a.y + b.y) * 0.5,
  };
  return Math.min(
    radialFrom(cx, cy, a),
    radialFrom(cx, cy, b),
    radialFrom(cx, cy, middle),
  ) - inner - 0.06;
}

function makeRibSegment(a, b, radius) {
  const length = Math.hypot(b.x - a.x, b.y - a.y, b.z - a.z);
  return makePiece('rib', a, norm3(b.x - a.x, b.y - a.y, b.z - a.z), length, radius);
}

export function buildLegacyReferenceRibs(rng, cx, cy, z, inner, outer, wall) {
  if (!(wall > inner + 0.5) || LANDMARK_MAX_PIECES < HELIX_COUNT * SEGMENTS_PER_HELIX) return [];

  const pieces = [];
  const handedness = rng() < 0.5 ? -1 : 1;
  const baseAzimuth = rng() * TAU;
  const span = 160 + rng() * 50;
  const turns = 1.2 + rng() * 0.42;
  const hubMaxima = 5 + Math.floor(rng() * 4);
  const phaseDrift = (rng() - 0.5) * 0.16;

  const annulus = wall - inner;
  const embedDepth = clamp(annulus * 0.025, 0.10, 0.24);
  const centreRadius = Math.min(wall - embedDepth, Math.max(outer, wall - embedDepth));
  const primaryMax = Math.min(4.8, annulus * 0.50);
  const primaryMin = Math.max(embedDepth * 1.45, primaryMax * 0.42);
  const zStart = z - span * 0.5;

  for (let helix = 0; helix < HELIX_COUNT; helix++) {
    const gid = `rib-shell-${helix}`;
    const phaseOffset = helix * Math.PI + helix * phaseDrift;
    const axialOffset = helix === 0 ? 0 : 0.18;
    const strength = helix === 0 ? 1 : 0.76;
    const points = [];

    for (let node = 0; node <= SEGMENTS_PER_HELIX; node++) {
      const t = node / SEGMENTS_PER_HELIX;
      const azimuth = baseAzimuth + phaseOffset + handedness * turns * TAU * t;
      points.push(polar(cx, cy, centreRadius, azimuth, zStart + span * t));
    }

    for (let node = 0; node < SEGMENTS_PER_HELIX && pieces.length < LANDMARK_MAX_PIECES; node++) {
      const t = (node + 0.5) / SEGMENTS_PER_HELIX;
      const bandPosition = t * hubMaxima - 0.5 - axialOffset;
      const vertebra = 0.5 + 0.5 * Math.cos(TAU * bandPosition);
      const requestedRadius = (primaryMin + (primaryMax - primaryMin) * vertebra * vertebra) * strength;
      const safeLimit = segmentRadiusLimit(cx, cy, inner, points[node], points[node + 1]);
      const radius = Math.min(requestedRadius, safeLimit);
      if (!(radius > embedDepth + 0.02)) continue;

      const piece = makeRibSegment(points[node], points[node + 1], radius);
      if (!pieceSafe(piece, cx, cy, inner, wall)) continue;

      const axialLayer = clamp(Math.floor(t * hubMaxima), 0, hubMaxima - 1);
      const peakT = (axialLayer + 0.5 + axialOffset) / hubMaxima;
      const peakNode = clamp(Math.round(peakT * SEGMENTS_PER_HELIX - 0.5), 0, SEGMENTS_PER_HELIX - 1);
      piece.gid = gid;
      piece.node = node;
      piece.tier = helix === 0 ? 2 : 1;
      piece.role = 'shell-channel';
      piece.referenceVariant = 'C3-legacy-comparison';
      piece.helix = helix;
      piece.axialLayer = axialLayer;
      piece.hubMaxima = hubMaxima;
      piece.hubWeight = vertebra * vertebra;
      piece.hubPeak = node === peakNode;
      piece.wallContact = true;
      piece.wallEmbedded = true;
      piece.wallRadius = wall;
      pieces.push(piece);
    }
  }

  return pieces;
}

// Compatibility alias for old A/B tooling. It is intentionally absent from
// the production family router.
export const buildReferenceRibs = buildLegacyReferenceRibs;
