// The landmark family selector and its deterministic PRNG.
//
// Landmarks must never touch the game's RNG stream (that would change every
// generated cave), so they carry their own: a hash of (seed, roomIndex) seeding
// a mulberry32. Same seed + room → same formation, forever, with no ordering
// dependency on anything the simulation does.

// The three landmark families. One is chosen per room.
export const LANDMARK_TYPES = ['branching', 'crystal', 'coiling'];
export const BRANCHING = 0, CRYSTAL = 1, COILING = 2;

export function hash2(a, b) {
  let h = (a | 0) ^ Math.imul(((b | 0) + 0x9e3779b9) | 0, 0x85ebca6b);
  h = Math.imul(h ^ (h >>> 13), 0xc2b2ae35);
  return (h ^ (h >>> 16)) >>> 0;
}
export function mulberry32(seed) {
  let t = seed >>> 0;
  return function () {
    t = (t + 0x6d2b79f5) | 0;
    let x = t;
    x = Math.imul(x ^ (x >>> 15), x | 1);
    x ^= x + Math.imul(x ^ (x >>> 7), x | 61);
    return ((x ^ (x >>> 14)) >>> 0) / 4294967296;
  };
}

// Which family a given room shows — deterministic from (seed, roomIndex).
export function landmarkType(seed, k) {
  return hash2(seed | 0, k | 0) % LANDMARK_TYPES.length;
}

