// Shared, deterministic surface for a wall-rooted claw. Core owns the exact
// triangles; rendering and collision consume the same immutable geometry.
// This module has no Three.js, DOM, cave, or renderer dependency.

const add = (a, b) => ({ x: a.x + b.x, y: a.y + b.y, z: a.z + b.z });
const sub = (a, b) => ({ x: a.x - b.x, y: a.y - b.y, z: a.z - b.z });
const scale = (a, s) => ({ x: a.x * s, y: a.y * s, z: a.z * s });
const dot = (a, b) => a.x * b.x + a.y * b.y + a.z * b.z;
const cross = (a, b) => ({ x: a.y * b.z - a.z * b.y,
  y: a.z * b.x - a.x * b.z, z: a.x * b.y - a.y * b.x });
const length = (a) => Math.hypot(a.x, a.y, a.z);
const norm = (a) => scale(a, 1 / (length(a) || 1));
const smoothstep = (t) => t * t * (3 - 2 * t);
const contourSampleCache = new Map();

function contourSamplesFor(radial, phase) {
  const key = `${radial}:${phase}`;
  let samples = contourSampleCache.get(key);
  if (samples) return samples;
  samples = Array.from({ length: radial + 1 }, (_, j) => {
    const a = (j / radial) * Math.PI * 2;
    const cs = Math.cos(a), sn = Math.sin(a);
    const crestGap = Math.abs(Math.atan2(Math.sin(a - phase), Math.cos(a - phase)));
    return { cs, sn, contour: 0.72 + 0.28 * Math.max(0, 1 - crestGap / 0.60) };
  });
  contourSampleCache.set(key, samples);
  return samples;
}

function rotateAround(v, axis, angle) {
  // Equivalent to Vector3.applyAxisAngle, kept here so Core never imports THREE.
  const s = Math.sin(angle / 2), w = Math.cos(angle / 2);
  const qx = axis.x * s, qy = axis.y * s, qz = axis.z * s;
  const ix = w * v.x + qy * v.z - qz * v.y;
  const iy = w * v.y + qz * v.x - qx * v.z;
  const iz = w * v.z + qx * v.y - qy * v.x;
  const iw = -qx * v.x - qy * v.y - qz * v.z;
  return { x: ix * w + iw * -qx + iy * -qz - iz * -qy,
    y: iy * w + iw * -qy + iz * -qx - ix * -qz,
    z: iz * w + iw * -qz + ix * -qy - iy * -qx };
}

// Every sweep strip references every vertex of its two adjacent rings (and
// the tip/closure reference their final apex). Scan that contiguous vertex
// span once instead of revisiting each endpoint for every triangle index.
function boundsForVertexRange(vertices, start, count) {
  const min = [Infinity, Infinity, Infinity], max = [-Infinity, -Infinity, -Infinity];
  for (let vertex = start; vertex < start + count; vertex++) {
    const index = vertex * 3;
    for (let axis = 0; axis < 3; axis++) {
      min[axis] = Math.min(min[axis], vertices[index + axis]);
      max[axis] = Math.max(max[axis], vertices[index + axis]);
    }
  }
  return { min, max };
}

function orientFootprint(vertices, ringStart, footprint, radial, axisA, axisB) {
  const next = Array.from({ length: radial }, (_, j) => {
    const i = (ringStart[1] + j) * 3;
    return { x: vertices[i], y: vertices[i + 1], z: vertices[i + 2] };
  });
  const ab = sub(axisB, axisA), ab2 = dot(ab, ab) || 1;
  let best = null;
  for (const direction of [1, -1]) for (let shift = 0; shift < radial; shift++) {
    let reversed = 0, folded = 0, minAgreement = 1;
    for (let j = 0; j < radial; j++) {
      const j1 = (j + 1) % radial;
      const a = footprint[(shift + direction * j + radial) % radial];
      const b = footprint[(shift + direction * j1 + radial) % radial];
      const c = next[j1], d = next[j];
      // This is the same cross/sub/dot arithmetic as the original fold test,
      // in scalars. Avoiding thousands of temporary vectors on every genuine
      // wall revision keeps the exact chosen phase and visible buffer intact.
      const bax = b.x - a.x, bay = b.y - a.y, baz = b.z - a.z;
      const cax = c.x - a.x, cay = c.y - a.y, caz = c.z - a.z;
      const dax = d.x - a.x, day = d.y - a.y, daz = d.z - a.z;
      const n0x = bay * caz - baz * cay;
      const n0y = baz * cax - bax * caz;
      const n0z = bax * cay - bay * cax;
      const n1x = cay * daz - caz * day;
      const n1y = caz * dax - cax * daz;
      const n1z = cax * day - cay * dax;
      const centre0x = (a.x + b.x + c.x) / 3;
      const centre0y = (a.y + b.y + c.y) / 3;
      const centre0z = (a.z + b.z + c.z) / 3;
      const centre1x = (a.x + c.x + d.x) / 3;
      const centre1y = (a.y + c.y + d.y) / 3;
      const centre1z = (a.z + c.z + d.z) / 3;
      const t0 = Math.max(0, Math.min(1, ((centre0x - axisA.x) * ab.x
        + (centre0y - axisA.y) * ab.y + (centre0z - axisA.z) * ab.z) / ab2));
      const t1 = Math.max(0, Math.min(1, ((centre1x - axisA.x) * ab.x
        + (centre1y - axisA.y) * ab.y + (centre1z - axisA.z) * ab.z) / ab2));
      const r0x = centre0x - (axisA.x + ab.x * t0);
      const r0y = centre0y - (axisA.y + ab.y * t0);
      const r0z = centre0z - (axisA.z + ab.z * t0);
      const r1x = centre1x - (axisA.x + ab.x * t1);
      const r1y = centre1y - (axisA.y + ab.y * t1);
      const r1z = centre1z - (axisA.z + ab.z * t1);
      if (n0x * r0x + n0y * r0y + n0z * r0z <= 0) reversed++;
      if (n1x * r1x + n1y * r1y + n1z * r1z <= 0) reversed++;
      const agreement = (n0x * n1x + n0y * n1y + n0z * n1z)
        / (Math.hypot(n0x, n0y, n0z) * Math.hypot(n1x, n1y, n1z) || 1);
      if (agreement <= 0) folded++;
      minAgreement = Math.min(minAgreement, agreement);
      // The score is lexicographic and each partial count can only worsen.
      // Once this phase can no longer beat the current best, the remaining
      // triangles cannot affect which footprint orientation is selected.
      if (best && (folded > best.folded
        || folded === best.folded && reversed > best.reversed
        || folded === best.folded && reversed === best.reversed
          && minAgreement <= best.minAgreement)) break;
    }
    const candidate = { shift, direction, reversed, folded, minAgreement };
    if (!best || candidate.folded < best.folded
      || candidate.folded === best.folded && candidate.reversed < best.reversed
      || candidate.folded === best.folded && candidate.reversed === best.reversed
        && candidate.minAgreement > best.minAgreement) best = candidate;
  }
  for (let j = 0; j <= radial; j++) {
    const point = footprint[(best.shift + best.direction * j + radial) % radial];
    const i = (ringStart[0] + j) * 3;
    vertices[i] = point.x; vertices[i + 1] = point.y; vertices[i + 2] = point.z;
  }
  return best;
}

export function buildRootSurface(comp, pieces) {
  if (!pieces?.length) return null;
  const p0 = pieces[0], h0 = p0.length / 2;
  const pts = [{ pos: { x: p0.cx - p0.dx * h0,
    y: p0.cy - p0.dy * h0, z: p0.cz - p0.dz * h0 },
  r: p0.branchStartRadius ?? p0.radius }];
  for (const p of pieces) {
    const h = p.length / 2;
    pts.push({ pos: { x: p.cx + p.dx * h, y: p.cy + p.dy * h, z: p.cz + p.dz * h },
      r: p === p0 && p.wallBodyRadius != null ? p.wallBodyRadius : p.radius });
  }
  pts.at(-1).r *= 0.10;
  const radial = 16, n = pts.length;
  const first = pts[0].pos, origin = comp.frame?.center;
  const right = comp.frame?.right, up = comp.frame?.up;
  let rootWallAxis = null;
  if (origin && right && up) {
    const delta = sub(first, origin);
    rootWallAxis = norm(add(scale(right, dot(delta, right)), scale(up, dot(delta, up))));
  }

  const tangents = [];
  for (let i = 0; i < n; i++) {
    const a = pts[Math.max(0, i - 1)].pos, b = pts[Math.min(n - 1, i + 1)].pos;
    const d = sub(b, a);
    tangents.push(length(d) ** 2 < 1e-9 ? { x: 0, y: 0, z: 1 } : norm(d));
  }
  const axis = Math.abs(tangents[0].x) < 0.9
    ? { x: 1, y: 0, z: 0 } : { x: 0, y: 1, z: 0 };
  let firstNormal = norm(cross(tangents[0], axis));
  if (rootWallAxis) {
    const tangent = cross(rootWallAxis, tangents[0]);
    if (length(tangent) ** 2 > 1e-8) firstNormal = norm(tangent);
  }
  const normals = [firstNormal];
  for (let i = 1; i < n; i++) {
    let nrm = normals[i - 1];
    let rot = cross(tangents[i - 1], tangents[i]);
    const s = length(rot);
    if (s > 1e-6) {
      rot = scale(rot, 1 / s);
      nrm = rotateAround(nrm, rot, Math.atan2(s, dot(tangents[i - 1], tangents[i])));
    }
    nrm = norm(sub(nrm, scale(tangents[i], dot(nrm, tangents[i]))));
    normals.push(nrm);
  }

  const vertices = [], uvs = [], along = [], visibleTriangles = [], ringStart = [];
  const contourPhase = Math.PI * (1.5 + ((p0.clawIndex || 0) % 3 - 1) / 4);
  // The angular contour depends only on the claw phase. Reusing the same
  // values across genuine wall revisions keeps every emitted vertex identical.
  const contourSamples = contourSamplesFor(radial, contourPhase);
  const pushVertex = (point, u, v, progress) => {
    const index = vertices.length / 3;
    vertices.push(point.x, point.y, point.z);
    uvs.push(u, v); along.push(progress);
    return index;
  };
  for (let i = 0; i < n; i++) {
    const B = norm(cross(tangents[i], normals[i]));
    const tf = i / (n - 1);
    const rootFlat = p0.parentGid ? 0.76 : 0.36 + (0.76 - 0.36)
      * smoothstep(Math.max(0, Math.min(1, (tf - 0.10) / 0.40)));
    ringStart.push(vertices.length / 3);
    for (let j = 0; j <= radial; j++) {
      const { cs, sn, contour } = contourSamples[j];
      const ox = (normals[i].x * cs + B.x * sn * rootFlat) * pts[i].r * contour;
      const oy = (normals[i].y * cs + B.y * sn * rootFlat) * pts[i].r * contour;
      const oz = (normals[i].z * cs + B.z * sn * rootFlat) * pts[i].r * contour;
      pushVertex({ x: pts[i].pos.x + ox, y: pts[i].pos.y + oy,
        z: pts[i].pos.z + oz }, j / radial, tf * 4, tf);
    }
  }
  let contactPhase = null;
  if (p0.wallFootprint?.length === radial) {
    contactPhase = orientFootprint(vertices, ringStart, p0.wallFootprint,
      radial, pts[0].pos, pts[1].pos);
  }
  const strips = [];
  const outwardQuad = (triangles) => {
    const axis = sub(pts[1].pos, pts[0].pos), axis2 = dot(axis, axis) || 1;
    const normals = [];
    for (const indices of triangles) {
      const points = indices.map(index => ({ x: vertices[index * 3],
        y: vertices[index * 3 + 1], z: vertices[index * 3 + 2] }));
      const normal = cross(sub(points[1], points[0]), sub(points[2], points[0]));
      const centre = scale(add(add(points[0], points[1]), points[2]), 1 / 3);
      const t = Math.max(0, Math.min(1, dot(sub(centre, pts[0].pos), axis) / axis2));
      if (dot(normal, sub(centre, add(pts[0].pos, scale(axis, t)))) <= 0) return false;
      normals.push(normal);
    }
    return dot(normals[0], normals[1]) > 0;
  };
  for (let i = 0; i < n - 1; i++) {
    const start = visibleTriangles.length;
    const a = ringStart[i], b = ringStart[i + 1];
    for (let j = 0; j < radial; j++) {
      const usual = [[a + j, a + j + 1, b + j + 1], [a + j, b + j + 1, b + j]];
      let triangles = usual;
      if (i === 0 && contactPhase && !outwardQuad(usual)) {
        // A nonplanar measured wall mouth can require the other diagonal.
        // Keep every vertex and the two-triangle budget exactly unchanged.
        const alternate = [[a + j, a + j + 1, b + j], [a + j + 1, b + j + 1, b + j]];
        if (outwardQuad(alternate)) triangles = alternate;
      }
      visibleTriangles.push(...triangles[0], ...triangles[1]);
    }
    strips.push({ start, count: visibleTriangles.length - start });
  }
  const last = pts[n - 1], tr = last.r;
  const apex = pushVertex({ x: last.pos.x + tangents[n - 1].x * tr * 0.35,
    y: last.pos.y + tangents[n - 1].y * tr * 0.35,
    z: last.pos.z + tangents[n - 1].z * tr * 0.35 }, 0.5, 1, 1);
  const tipStart = visibleTriangles.length;
  for (let j = 0; j < radial; j++) visibleTriangles.push(
    ringStart[n - 1] + j, ringStart[n - 1] + j + 1, apex);
  strips.push({ start: tipStart, count: visibleTriangles.length - tipStart });
  for (let i = 0; i < n - 1; i++) {
    strips[i].bounds = boundsForVertexRange(vertices, ringStart[i],
      2 * (radial + 1));
  }
  strips[n - 1].bounds = boundsForVertexRange(vertices, ringStart[n - 1],
    apex - ringStart[n - 1] + 1);

  const visibleVertexCount = vertices.length / 3;
  // Close the open wall mouth behind the live contact. This fan is query-only:
  // its triangles never contribute to rendering or nearest-surface distance.
  // A mapped production footprint uses a cap deeper in rock along measured
  // wall rays. A synthetic/no-footprint tube instead closes in its first ring
  // plane; it must never invent a long hidden cone beyond an unauthored wall.
  const queryClosureTriangles = [];
  let closureKind;
  if (p0.wallFootprintSurface?.length === radial && contactPhase) {
    closureKind = 'wall-buried-fan';
    const ordered = Array.from({ length: radial }, (_, j) => {
      const index = (contactPhase.shift + contactPhase.direction * j + radial) % radial;
      return { surface: p0.wallFootprintSurface[index],
        inset: p0.wallFootprint[index] };
    });
    const average = { x: 0, y: 0, z: 0 }, averageDirection = { x: 0, y: 0, z: 0 };
    for (const pair of ordered) {
      average.x += pair.surface.x / radial;
      average.y += pair.surface.y / radial;
      average.z += pair.surface.z / radial;
      const direction = norm(sub(pair.inset, pair.surface));
      averageDirection.x += direction.x / radial;
      averageDirection.y += direction.y / radial;
      averageDirection.z += direction.z / radial;
    }
    const cap = add(average, scale(norm(averageDirection), Math.max(3, p0.radius * 1.5)));
    const back = pushVertex(cap, 0.5, 0, 0);
    for (let j = 0; j < radial; j++) queryClosureTriangles.push(
      ringStart[0] + j + 1, ringStart[0] + j, back);
  } else {
    closureKind = 'base-plane-fan';
    const back = pushVertex(pts[0].pos, 0.5, 0, 0);
    for (let j = 0; j < radial; j++) queryClosureTriangles.push(
      ringStart[0] + j + 1, ringStart[0] + j, back);
  }
  return { vertices: Float64Array.from(vertices), visibleVertexCount,
    visibleTriangles: Uint32Array.from(visibleTriangles),
    queryClosureTriangles: Uint32Array.from(queryClosureTriangles),
    strips, bounds: boundsForVertexRange(vertices, 0, vertices.length / 3),
    gid: p0.gid, piece: p0, uvs: Float64Array.from(uvs),
    along: Float64Array.from(along), contactPhase, closureKind };
}
