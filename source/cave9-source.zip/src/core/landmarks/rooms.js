// Rooms are CaveStream's periodic 4x-wide chambers. Root and Crystal use the
// emitter's bounded, immutable room surface after live render slots recycle;
// other families and synthetic callers retain their live-buffer behavior.

import { SECTOR_COUNT, SEGMENT_LEN, ROOM_START, ROOM_SPACING, ROOM_LEN } from '../constants.js';

// First room index: rooms exist only at depth >= ROOM_START (= 2 * ROOM_SPACING).
export const FIRST_ROOM_K = Math.round(ROOM_START / ROOM_SPACING); // 2
export const LANDMARK_FORM_HALF_SPAN = 110;
export const LANDMARK_SURFACE_HALF_SPAN = LANDMARK_FORM_HALF_SPAN + SEGMENT_LEN * 1.5;

// The emitter owns this bounded history independently of composition callers.
// Synthetic caves retain their existing live-surface behavior.
export function roomSurfaceFor(cave, k) {
  return cave.landmarkRoomSurface?.(k) ?? cave;
}

// z-plane of room index k.
export function roomZ(k) {
  return ROOM_LEN / 2 + ROOM_SPACING * k;
}

export function ringCentroidClearance(cave, idx) {
  const ring = cave.segs[idx];
  const frame = cave.frames?.[idx];
  if (!frame) return { cx: 0, cy: 0, clearance: -Infinity, frame: null };
  let min = Infinity;
  for (let j = 0; j < SECTOR_COUNT; j++) {
    const dx = ring[j][0] - frame.center.x;
    const dy = ring[j][1] - frame.center.y;
    const dz = ring[j][2] - frame.center.z;
    const x = dx * frame.right.x + dy * frame.right.y + dz * frame.right.z;
    const y = dx * frame.up.x + dy * frame.up.y + dz * frame.up.z;
    const d = Math.hypot(x, y);
    if (d < min) min = d;
  }
  return { cx: frame.center.x, cy: frame.center.y, clearance: min, frame };
}

function nearestRingIndex(cave, zTarget) {
  let best = -1, bestD = SEGMENT_LEN;
  for (let k = 0; k < cave.centers.length; k++) {
    const cz = cave.centers[k][2];
    if (!Number.isFinite(cz)) continue;
    const d = Math.abs(cz - zTarget);
    if (d <= bestD) { bestD = d; best = k; }
  }
  return best;
}

// Buffer index of the live ring that room k's composition is built from, or −1
// if that room's z-plane is not currently carved. Exported so a memo can tell
// whether a cached composition is still current (see core/LandmarkCache.js)
// without rebuilding it.
export function roomRingIndex(cave, k) {
  if (cave.roomSurfaceK === k) {
    return cave.centers.findIndex((center) => center[2] === roomZ(k));
  }
  return nearestRingIndex(cave, roomZ(k));
}


// The room indices whose z-planes fall in the visible span [playerZ - behind,
// playerZ + range]. Rooms are ROOM_SPACING apart and the view is about one room,
// so this is normally 0 or 1 rooms. An empty range comes back as kFrom > kTo.
export function visibleRoomRange(playerZ, range, behind = SEGMENT_LEN * 2) {
  if (!Number.isFinite(playerZ) || !(range > 0)) return { kFrom: 1, kTo: 0 };
  // Intersect the complete room interval [k*spacing, k*spacing+ROOM_LEN] with
  // the visible span. Long axial families must not disappear merely because
  // their room centre has passed behind the camera.
  return {
    kFrom: Math.max(FIRST_ROOM_K, Math.ceil((playerZ - behind - ROOM_LEN) / ROOM_SPACING)),
    kTo: Math.floor((playerZ + range) / ROOM_SPACING),
  };
}
