// CaveMetrics — headless, deterministic analysis of a generated cave. Turns the
// otherwise-opaque generator into measurable fairness / readability numbers:
//   - radius (tunnel size), clearance (tightest off-centre room),
//   - curvature (how hard the centreline bends), narrowing (how fast walls
//     close in — the unfair-peak detector),
//   - reaction window (seconds of warning at the current speed/sight).
// plus a flight pass (autopilot) for near-wall density and false-death checks.
//
// Everything is a pure function of the seed (owned CaveStream RNG), so the
// same seed always yields the same metrics — used by test/seeds.test.js and the
// GENERATOR_REPORT.md generator.

import { Game } from './Game.js';
import { difficultyAt, reactionWindow } from './Difficulty.js';
import { pathFrameAt, tubeRadiusAt } from './FlightPath.js';
import {
  SECTOR_COUNT, SEGMENT_COUNT, SEGMENT_LEN, SHIP_RADIUS, TWO_BUTTONS,
} from './constants.js';

// 2D centroid + radius stats of one cave ring (array of [x,y,z]).
function ringStats(ring, frame) {
  let cx = 0, cy = 0, cz = 0;
  for (let j = 0; j < SECTOR_COUNT; j++) {
    cx += ring[j][0]; cy += ring[j][1]; cz += ring[j][2];
  }
  cx /= SECTOR_COUNT; cy /= SECTOR_COUNT; cz /= SECTOR_COUNT;
  let min = Infinity, max = 0, sum = 0;
  let finite = Number.isFinite(cx) && Number.isFinite(cy);
  for (let j = 0; j < SECTOR_COUNT; j++) {
    const dx = ring[j][0] - frame.center.x;
    const dy = ring[j][1] - frame.center.y;
    const dz = ring[j][2] - frame.center.z;
    const lx = dx * frame.right.x + dy * frame.right.y + dz * frame.right.z;
    const ly = dx * frame.up.x + dy * frame.up.y + dz * frame.up.z;
    const d = Math.hypot(lx, ly);
    if (!Number.isFinite(d)) finite = false;
    if (d < min) min = d;
    if (d > max) max = d;
    sum += d;
  }
  return { cx, cy, cz, clearance: min, radius: sum / SECTOR_COUNT, maxRadius: max, finite };
}

// Walk a seed's cave to `maxDepth` metres in "ghost" mode (advance z, let the
// generator carve; the ghost's x/y never affect carving) and sample every ring.
// Returns the generator-intrinsic geometry metrics.
export function caveGeometryMetrics(seed, opts = {}) {
  const mode = opts.mode ?? TWO_BUTTONS;
  const maxDepth = opts.maxDepth ?? 6000;

  const g = new Game();
  g.start({ mode, seed });

  const rings = [];
  let guard = 0;
  const maxGuard = Math.ceil(maxDepth / SEGMENT_LEN) + SEGMENT_COUNT + 100;
  let lastZ = -Infinity;
  while (g.player.pos[2] - g.player.start < maxDepth && guard++ < maxGuard) {
    g.player.pos[2] += SEGMENT_LEN; // ghost forward one ring spacing
    g._carve();
    const capacity = g.cave.segs.length;
    const idx = (g.cave.i - 1 + capacity) % capacity;
    const s = ringStats(g.cave.segs[idx], g.cave.frames[idx]);
    if (s.cz > lastZ + SEGMENT_LEN * 0.5) { // de-dupe rings at the same z
      rings.push(s);
      lastZ = s.cz;
    }
  }

  // aggregate
  let minRadius = Infinity, maxRadius = 0, sumRadius = 0;
  let minClearance = Infinity, sumClearance = 0;
  let maxCurvature = 0, sumCurvature = 0, curvCount = 0;
  let maxNarrowing = 0;       // largest clearance drop per metre
  let minReaction = Infinity, sumReaction = 0;
  let allFinite = true;
  let narrowRings = 0;        // clearance < 2*shipRadius (tight)

  for (let k = 0; k < rings.length; k++) {
    const r = rings[k];
    if (!r.finite) allFinite = false;
    minRadius = Math.min(minRadius, r.radius);
    maxRadius = Math.max(maxRadius, r.radius);
    sumRadius += r.radius;
    minClearance = Math.min(minClearance, r.clearance);
    sumClearance += r.clearance;
    if (r.clearance < 2 * SHIP_RADIUS) narrowRings++;

    const depth = r.cz - g.player.start;
    const rw = reactionWindow(depth);
    minReaction = Math.min(minReaction, rw);
    sumReaction += rw;

    if (k > 0) {
      const p = rings[k - 1];
      const dz = Math.max(1e-6, r.cz - p.cz);
      // curvature: lateral drift of the centreline per metre travelled
      const turn = Math.hypot(r.cx - p.cx, r.cy - p.cy) / dz;
      maxCurvature = Math.max(maxCurvature, turn);
      sumCurvature += turn; curvCount++;
      // narrowing: how fast the tunnel closes (clearance loss per metre)
      const drop = Math.max(0, p.clearance - r.clearance) / dz;
      maxNarrowing = Math.max(maxNarrowing, drop);
    }
  }

  return {
    seed, mode, samples: rings.length, depthReached: lastZ - g.player.start,
    minRadius, avgRadius: sumRadius / rings.length, maxRadius,
    minClearance, avgClearance: sumClearance / rings.length,
    narrowRings, narrowDensity: narrowRings / rings.length,
    avgCurvature: curvCount ? sumCurvature / curvCount : 0, maxCurvature,
    maxNarrowing,
    minReactionWindow: minReaction, avgReactionWindow: sumReaction / rings.length,
    allFinite,
  };
}

// Fly a seed with the built-in autopilot and measure the pilot-dependent
// fairness signals: how deep a competent pilot gets, near-wall density, the
// closest the pilot came to the wall, and a false-death sentinel (a crash while
// the 4 collision probes were all comfortably inside the cave).
export function flightMetrics(seed, opts = {}) {
  const mode = opts.mode ?? TWO_BUTTONS;
  const maxSteps = opts.maxSteps ?? 25000;

  const g = new Game();
  g.start({ mode, seed });

  let steps = 0, crashed = false, nearWall = 0, minDist = Infinity;
  let falseDeaths = 0, graceFrames = 0;
  let maxTrackingError = 0, minTrackingReserve = Infinity;
  const nearThresh = SHIP_RADIUS; // "near" = within one ship-radius of the wall

  for (; steps < maxSteps; steps++) {
    g.autopilot();
    const died = g.step();
    const p = g.player;
    const depth = p.pos[2] - p.start;
    const frame = pathFrameAt(seed, depth);
    const dx = p.pos[0] - frame.center.x;
    const dy = p.pos[1] - frame.center.y;
    const dz = p.pos[2] - frame.center.z;
    const tracking = Math.hypot(
      dx * frame.right.x + dy * frame.right.y + dz * frame.right.z,
      dx * frame.up.x + dy * frame.up.y + dz * frame.up.z,
    );
    const trackingReserve = tubeRadiusAt(depth, seed) - p.radius - tracking;
    maxTrackingError = Math.max(maxTrackingError, tracking);
    minTrackingReserve = Math.min(minTrackingReserve, trackingReserve);
    if (p.graced) graceFrames++;
    if (p.dist > 0 && p.dist < minDist) minDist = p.dist;
    if (p.dist >= 0 && p.dist < nearThresh) nearWall++;
    if (died) {
      crashed = true;
      // Independent sentinel: core guarantees every visible surface stays
      // outside the analytic tube. A death while the complete ship hull still
      // has positive tube reserve therefore cannot be a legitimate contact.
      if (trackingReserve > 0.05) falseDeaths++;
      break;
    }
  }

  return {
    seed, mode, steps, crashed,
    depthReached: g.player.pos[2] - g.player.start,
    score: g.scoreValue(),
    nearWallFrames: nearWall, nearWallDensity: nearWall / Math.max(1, steps),
    minDist: minDist === Infinity ? null : minDist,
    maxTrackingError, minTrackingReserve,
    graceFrames, falseDeaths,
    difficulty: difficultyAt(g.player.pos[2] - g.player.start),
  };
}
