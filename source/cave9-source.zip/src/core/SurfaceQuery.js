// One read-only description of the nearest visible cave surface.
//
// Collision, predictive warning, directional audio, graze distance and crash
// repulsion all use this module. The wall query includes the exact submitted
// triangles of every potentially touching tilted ring strip. Roots and crystal
// plates use their shared visible surfaces; legacy pieces retain the capsule
// query until they provide an authoritative surface of their own.

import { SECTOR_COUNT, SEGMENT_LEN } from './constants.js';
import { queryTriangleSurface } from './landmarks/TriangleSurfaceQuery.js';
import { querySlabHull } from './landmarks/SlabHull.js';

// CaveStream rings live on an exact SEGMENT_LEN lattice and the circular
// buffer preserves their spatial order. That makes ring lookup arithmetic,
// rather than a scan whose cost grows with the sight-distance buffer.
function ringLayout(cave) {
  const capacity = cave.centers?.length || 0;
  const count = Math.max(0, Math.min(capacity, cave.count ?? capacity));
  if (!count) return null;
  const head = count < capacity ? 0 : ((cave.i ?? 0) % capacity + capacity) % capacity;
  const firstZ = cave.centers[head]?.[2];
  if (!Number.isFinite(firstZ)) return null;
  if (count > 1) {
    const secondZ = cave.centers[(head + 1) % capacity]?.[2];
    const tailZ = cave.centers[(head + count - 1) % capacity]?.[2];
    const expectedTail = firstZ + (count - 1) * SEGMENT_LEN;
    if (Math.abs(secondZ - firstZ - SEGMENT_LEN) > 1e-9
        || Math.abs(tailZ - expectedTail) > 1e-9) return null;
  }
  return { capacity, count, head, firstZ };
}

function spatialIndex(layout, offset) {
  return (layout.head + Math.max(0, Math.min(layout.count - 1, offset))) % layout.capacity;
}

function linearNearestRingIndex(cave, z) {
  let best = -1, gap = Infinity;
  for (let i = 0; i < (cave.centers?.length || 0); i++) {
    const cz = cave.centers[i]?.[2];
    const distance = Math.abs(cz - z);
    if (Number.isFinite(cz) && distance < gap) { gap = distance; best = i; }
  }
  return best;
}

function linearBracketingRingIndices(cave, z) {
  let before = -1, after = -1, beforeZ = -Infinity, afterZ = Infinity;
  for (let i = 0; i < (cave.centers?.length || 0); i++) {
    const cz = cave.centers[i]?.[2];
    if (!Number.isFinite(cz)) continue;
    if (cz <= z && cz > beforeZ) { beforeZ = cz; before = i; }
    if (cz >= z && cz < afterZ) { afterZ = cz; after = i; }
  }
  const nearest = linearNearestRingIndex(cave, z);
  return [before < 0 ? nearest : before, after < 0 ? nearest : after];
}

export function nearestRingIndex(cave, z) {
  const layout = ringLayout(cave);
  if (!Number.isFinite(z)) return -1;
  // Synthetic/debug surfaces are allowed to use arbitrary ring spacing. The
  // production CaveStream takes the constant-time branch above; only a
  // non-lattice external cave falls back to the compatibility scan.
  if (!layout) return linearNearestRingIndex(cave, z);
  const position = (z - layout.firstZ) / SEGMENT_LEN;
  const lowerOffset = Math.max(0, Math.min(layout.count - 1, Math.floor(position)));
  const upperOffset = Math.max(0, Math.min(layout.count - 1, Math.ceil(position)));
  const lower = spatialIndex(layout, lowerOffset);
  const upper = spatialIndex(layout, upperOffset);
  const lowerGap = Math.abs(cave.centers[lower][2] - z);
  const upperGap = Math.abs(cave.centers[upper][2] - z);
  if (lowerGap < upperGap) return lower;
  if (upperGap < lowerGap) return upper;
  // Preserve the old linear scan's midpoint tie-break, even across wraparound.
  return Math.min(lower, upper);
}

export function bracketingRingIndices(cave, z) {
  const layout = ringLayout(cave);
  if (!Number.isFinite(z)) return [-1, -1];
  if (!layout) return linearBracketingRingIndices(cave, z);
  const position = (z - layout.firstZ) / SEGMENT_LEN;
  const last = layout.count - 1;
  if (position <= 0) {
    const first = spatialIndex(layout, 0);
    return [first, first];
  }
  if (position >= last) {
    const tail = spatialIndex(layout, last);
    return [tail, tail];
  }
  return [
    spatialIndex(layout, Math.floor(position)),
    spatialIndex(layout, Math.ceil(position)),
  ];
}

// Ericson closest-point region tests. The returned point lies on the exact
// visible triangle, so its distance and normal source are shared truth.
export function closestTrianglePoint(p, a, b, c, out = {}) {
  // Collision samples many neighbouring wall triangles. Scalar temporaries
  // and a caller-owned result avoid five short arrays and one object per
  // triangle while retaining the same region tests and arithmetic order.
  const abx = b[0] - a[0], aby = b[1] - a[1], abz = b[2] - a[2];
  const acx = c[0] - a[0], acy = c[1] - a[1], acz = c[2] - a[2];
  const apx = p[0] - a[0], apy = p[1] - a[1], apz = p[2] - a[2];
  const d1 = abx * apx + aby * apy + abz * apz;
  const d2 = acx * apx + acy * apy + acz * apz;
  if (d1 <= 0 && d2 <= 0) return pointResult(p, a[0], a[1], a[2], out);
  const bpx = p[0] - b[0], bpy = p[1] - b[1], bpz = p[2] - b[2];
  const d3 = abx * bpx + aby * bpy + abz * bpz;
  const d4 = acx * bpx + acy * bpy + acz * bpz;
  if (d3 >= 0 && d4 <= d3) return pointResult(p, b[0], b[1], b[2], out);
  const vc = d1 * d4 - d3 * d2;
  if (vc <= 0 && d1 >= 0 && d3 <= 0) {
    const v = d1 / (d1 - d3);
    return pointResult(p, a[0] + v * abx, a[1] + v * aby, a[2] + v * abz, out);
  }
  const cpx = p[0] - c[0], cpy = p[1] - c[1], cpz = p[2] - c[2];
  const d5 = abx * cpx + aby * cpy + abz * cpz;
  const d6 = acx * cpx + acy * cpy + acz * cpz;
  if (d6 >= 0 && d5 <= d6) return pointResult(p, c[0], c[1], c[2], out);
  const vb = d5 * d2 - d1 * d6;
  if (vb <= 0 && d2 >= 0 && d6 <= 0) {
    const w = d2 / (d2 - d6);
    return pointResult(p, a[0] + w * acx, a[1] + w * acy, a[2] + w * acz, out);
  }
  const va = d3 * d6 - d5 * d4;
  if (va <= 0 && d4 - d3 >= 0 && d5 - d6 >= 0) {
    const w = (d4 - d3) / ((d4 - d3) + (d5 - d6));
    return pointResult(p,
      b[0] + w * (c[0] - b[0]), b[1] + w * (c[1] - b[1]), b[2] + w * (c[2] - b[2]), out);
  }
  const denom = 1 / (va + vb + vc);
  const v = vb * denom, w = vc * denom;
  return pointResult(p,
    a[0] + abx * v + acx * w,
    a[1] + aby * v + acy * w,
    a[2] + abz * v + acz * w, out);
}

function pointResult(p, qx, qy, qz, out = {}) {
  out.qx = qx; out.qy = qy; out.qz = qz;
  out.distance = Math.hypot(p[0] - qx, p[1] - qy, p[2] - qz);
  return out;
}

export function pointCapsuleAxis(point, piece) {
  const half = piece.length / 2;
  const ax = piece.cx - piece.dx * half, ay = piece.cy - piece.dy * half, az = piece.cz - piece.dz * half;
  const bx = piece.cx + piece.dx * half, by = piece.cy + piece.dy * half, bz = piece.cz + piece.dz * half;
  const dx = bx - ax, dy = by - ay, dz = bz - az;
  const px = point[0] - ax, py = point[1] - ay, pz = point[2] - az;
  const den = dx * dx + dy * dy + dz * dz || 1;
  const t = Math.max(0, Math.min(1, (px * dx + py * dy + pz * dz) / den));
  return pointResult(point, ax + dx * t, ay + dy * t, az + dz * t);
}

export function projectToFrame(frame, point) {
  const x = point[0] - frame.center.x;
  const y = point[1] - frame.center.y;
  const z = point[2] - frame.center.z;
  return [
    x * frame.right.x + y * frame.right.y + z * frame.right.z,
    x * frame.up.x + y * frame.up.y + z * frame.up.z,
  ];
}

export function pointInsideRing(ring, frame, point) {
  const [px, py] = projectToFrame(frame, point);
  let inside = false;
  for (let i = 0, j = SECTOR_COUNT - 1; i < SECTOR_COUNT; j = i++) {
    const [xi, yi] = projectToFrame(frame, ring[i]);
    const [xj, yj] = projectToFrame(frame, ring[j]);
    if (((yi > py) !== (yj > py)) &&
        px < (xj - xi) * (py - yi) / ((yj - yi) || Number.EPSILON) + xi) inside = !inside;
  }
  return inside;
}

function sideOf(point, q, right) {
  return (q.qx - point[0]) * right.x + (q.qy - point[1]) * right.y + (q.qz - point[2]) * right.z;
}

// A route-orthogonal ring can extend several metres to either side of its
// centre's world-z. Choosing triangles from centre-z alone misses visible wall
// contacts on a tilted strip. Include every strip whose actual vertex extent
// intersects the probe sphere, while retaining the original bracketing strip.
// Production rings are immutable until re-emitted at a new lattice depth;
// cache only their z bounds, not the query or its nearest point. Synthetic
// surfaces may be edited directly and deliberately take the uncached path.
const wallBoundsCaches = new WeakMap();
const rootSurfaceGroups = new WeakMap();

function exactRootGroups(surfaces) {
  let groups = rootSurfaceGroups.get(surfaces);
  if (!groups) {
    groups = new Set(surfaces.map(surface => surface.gid));
    rootSurfaceGroups.set(surfaces, groups);
  }
  return groups;
}

function wallBoundsCache(cave, layout) {
  if (!layout || !Number.isInteger(cave.generation)
      || !Number.isFinite(cave._lastRingDepth)) return null;
  let cache = wallBoundsCaches.get(cave);
  if (!cache || cache.segs !== cave.segs || cache.generation !== cave.generation) {
    cache = { segs: cave.segs, generation: cave.generation,
      depths: new Float64Array(layout.capacity).fill(NaN),
      min: new Float64Array(layout.capacity), max: new Float64Array(layout.capacity) };
    wallBoundsCaches.set(cave, cache);
  }
  return cache;
}

function ringZBounds(cave, index, cache, out) {
  const depth = cave.centers[index][2];
  if (cache && cache.depths[index] === depth) {
    out[0] = cache.min[index]; out[1] = cache.max[index]; return;
  }
  let min = Infinity, max = -Infinity;
  for (const vertex of cave.segs[index]) {
    min = Math.min(min, vertex[2]); max = Math.max(max, vertex[2]);
  }
  if (cache) {
    cache.depths[index] = depth; cache.min[index] = min; cache.max[index] = max;
  }
  out[0] = min; out[1] = max;
}

export function queryNearestSurface(cave, point, hullRadius = 0, compositions = []) {
  // Collision's existing numeric-grace path must also work when exact root
  // surfaces are present; their triangle query requires finite coordinates.
  if (!point.every(Number.isFinite)) return {
    ringIndex: -1, frame: null, wall: null, landmark: null, nearest: null,
    leftClear: Number.MAX_VALUE, rightClear: Number.MAX_VALUE,
  };
  const ringIndex = nearestRingIndex(cave, point[2]);
  const frame = ringIndex >= 0 ? cave.frames?.[ringIndex] : null;
  const right = frame?.right || { x: 1, y: 0, z: 0 };
  let wall = null;
  const [lo, hi] = bracketingRingIndices(cave, point[2]);
  const layout = ringLayout(cave);
  const order = layout ? null : (cave.centers || []).map((center, index) => ({ z: center?.[2], index }))
    .filter(({ z, index }) => Number.isFinite(z) && cave.segs?.[index])
    .sort((a, b) => a.z - b.z).map(({ index }) => index);
  const count = layout?.count ?? order.length;
  const boundsCache = wallBoundsCache(cave, layout);
  const previousBounds = [0, 0], nextBounds = [0, 0];
  const padding = Math.max(0, hullRadius) + 1e-8;
  const wallScratch = {};
  for (let offset = 0; offset + 1 < count; offset++) {
    const a = layout ? spatialIndex(layout, offset) : order[offset];
    const b = layout ? spatialIndex(layout, offset + 1) : order[offset + 1];
    ringZBounds(cave, a, boundsCache, previousBounds);
    ringZBounds(cave, b, boundsCache, nextBounds);
    if (!(a === lo && b === hi)
        && (point[2] + padding < Math.min(previousBounds[0], nextBounds[0])
          || point[2] - padding > Math.max(previousBounds[1], nextBounds[1]))) continue;
    for (let j = 0; j < SECTOR_COUNT; j++) {
      const j1 = (j + 1) % SECTOR_COUNT;
      closestTrianglePoint(point, cave.segs[a][j], cave.segs[b][j], cave.segs[a][j1], wallScratch);
      if (!wall || wallScratch.distance < wall.surfaceDistance) {
        wall = { ...wallScratch, surfaceDistance: wallScratch.distance };
      }
      closestTrianglePoint(point, cave.segs[a][j1], cave.segs[b][j], cave.segs[b][j1], wallScratch);
      if (wallScratch.distance < wall.surfaceDistance) {
        wall = { ...wallScratch, surfaceDistance: wallScratch.distance };
      }
    }
  }
  if (!wall && ringIndex >= 0) {
    for (const vertex of cave.segs[ringIndex]) {
      const q = pointResult(point, vertex[0], vertex[1], vertex[2]);
      if (!wall || q.distance < wall.surfaceDistance) wall = { ...q, surfaceDistance: q.distance };
    }
  }
  if (wall) {
    wall.kind = 'wall';
    wall.hullClearance = wall.surfaceDistance - hullRadius;
  }

  let landmark = null;
  let leftClear = Number.MAX_VALUE, rightClear = Number.MAX_VALUE;
  if (wall) {
    if (sideOf(point, wall, right) < 0) leftClear = wall.surfaceDistance;
    else rightClear = wall.surfaceDistance;
  }
  const rootScratch = {};
  const slabScratch = {};
  for (const comp of compositions || []) {
    const roots = comp.rootSurfaces;
    const exactGroups = roots?.length ? exactRootGroups(roots) : null;
    for (const surface of roots || []) {
      // The same axial horizon as the capsule path, applied to the complete
      // curved surface rather than only its first straight piece.
      const padding = hullRadius + 8;
      if (point[2] < surface.bounds.min[2] - padding
          || point[2] > surface.bounds.max[2] + padding) continue;
      const q = queryTriangleSurface(point, surface, rootScratch);
      const surfaceDistance = q.distance;
      const candidate = { ...q, kind: 'landmark', piece: surface.piece, surfaceDistance,
        hullClearance: surfaceDistance - hullRadius };
      if (!landmark || candidate.hullClearance < landmark.hullClearance) landmark = candidate;
      const directional = Math.max(0, surfaceDistance);
      if (sideOf(point, q, right) < 0) leftClear = Math.min(leftClear, directional);
      else rightClear = Math.min(rightClear, directional);
    }
    for (const piece of comp.collisionPieces || comp.pieces) {
      // Root pieces and their bridge capsules are conservative bounds. Once
      // an exact surface exists, querying either again would restore the
      // invisible shoulder hit zones that the narrow phase removed.
      if (exactGroups?.has(piece.gid)) continue;
      if (Math.abs(piece.cz - point[2]) > piece.length / 2 + piece.radius + hullRadius + 8) continue;
      const slab = piece.shape === 'blade' ? piece.slabHull : null;
      const q = slab ? querySlabHull(point, slab, slabScratch) : pointCapsuleAxis(point, piece);
      const surfaceDistance = slab ? q.surfaceDistance : q.distance - piece.radius;
      const candidate = { ...q, kind: 'landmark', piece, surfaceDistance,
        hullClearance: surfaceDistance - hullRadius };
      if (!landmark || candidate.hullClearance < landmark.hullClearance) landmark = candidate;
      const directional = Math.max(0, surfaceDistance);
      if (sideOf(point, q, right) < 0) leftClear = Math.min(leftClear, directional);
      else rightClear = Math.min(rightClear, directional);
    }
  }

  let nearest = wall;
  if (landmark && (!nearest || landmark.hullClearance < nearest.hullClearance)) nearest = landmark;
  return { ringIndex, frame, wall, landmark, nearest, leftClear, rightClear };
}
