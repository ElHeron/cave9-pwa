// The rules that affect a scored run. Keep this pure so the app, storage and
// future shared-link validation use one canonical profile identity.
export const RULE_PROFILE_VERSION = 1;

export function normalizeRunRules(source = {}) {
  const values = source && typeof source === 'object' ? source : {};
  const controlMode = values.controlMode === 1 ? 1 : 2;
  const rawThrust = values.thrustScale ?? values.sensitivity;
  const thrustScale = Number.isFinite(rawThrust)
    ? Math.min(1.6, Math.max(0.6, rawThrust))
    : 1;
  const landmarks = values.landmarks !== false;
  const key = `r${RULE_PROFILE_VERSION}-m${controlMode}-t${thrustScale.toString()}-l${landmarks ? 1 : 0}`;
  return Object.freeze({ controlMode, thrustScale, landmarks, key });
}

export const DAILY_RULES = normalizeRunRules({ controlMode: 2, thrustScale: 1, landmarks: true });

// Reject a stored/received profile that claims a key inconsistent with its
// values. Valid keys are generated from the exact applied JavaScript Number.
export function isNormalizedRunRules(rules) {
  if (!rules || typeof rules !== 'object') return false;
  if (rules.controlMode !== 1 && rules.controlMode !== 2) return false;
  if (!Number.isFinite(rules.thrustScale) || rules.thrustScale < 0.6 || rules.thrustScale > 1.6) return false;
  if (typeof rules.landmarks !== 'boolean') return false;
  return rules.key === normalizeRunRules(rules).key;
}
