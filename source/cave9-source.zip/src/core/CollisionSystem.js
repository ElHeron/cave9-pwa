// Collision is the mutating adapter over the shared, read-only SurfaceQuery.
// It records probes/clearances on Ship and turns hull clearance <= 0 into death.

import { SHIP_RADIUS } from './constants.js';
import { v3, set, sub2, norm, clamp } from './vec.js';
import { pointInsideRing, queryNearestSurface } from './SurfaceQuery.js';

const _surfacePoint = v3();

export function collision(cave, ship, compositions = []) {
  const query = queryNearestSurface(cave, ship.pos, ship.radius, compositions);
  const frame = query.frame;
  const right = frame?.right || { x: 1, y: 0, z: 0 };
  const up = frame?.up || { x: 0, y: 1, z: 0 };
  const probes = [
    [ship.pos[0] - right.x * ship.radius, ship.pos[1] - right.y * ship.radius, ship.pos[2] - right.z * ship.radius],
    [ship.pos[0] + up.x * ship.radius, ship.pos[1] + up.y * ship.radius, ship.pos[2] + up.z * ship.radius],
    [ship.pos[0] + right.x * ship.radius, ship.pos[1] + right.y * ship.radius, ship.pos[2] + right.z * ship.radius],
    [ship.pos[0] - up.x * ship.radius, ship.pos[1] - up.y * ship.radius, ship.pos[2] - up.z * ship.radius],
  ];
  const ring = query.ringIndex >= 0 ? cave.segs[query.ringIndex] : null;
  const probeInside = frame && ring ? probes.map((p) => pointInsideRing(ring, frame, p))
    : [true, true, true, true];
  for (let i = 0; i < probes.length; i++) {
    ship.probePos[i][0] = probes[i][0];
    ship.probePos[i][1] = probes[i][1];
    ship.probeInside[i] = probeInside[i];
  }
  ship.leftClear = query.leftClear;
  ship.rightClear = query.rightClear;

  const normalSource = query.nearest;
  if (normalSource) set(_surfacePoint, normalSource.qx, normalSource.qy, normalSource.qz);
  else if (frame) set(_surfacePoint, frame.center.x, frame.center.y, frame.center.z);
  else set(_surfacePoint, 0, 0, 0);
  sub2(ship.repulsion, _surfacePoint, ship.pos);
  norm(ship.repulsion);

  const clearance = query.nearest?.hullClearance ?? Number.MAX_VALUE;
  const finite = ship.pos.every(Number.isFinite) && Number.isFinite(clearance) &&
    Number.isFinite(_surfacePoint[0]) && Number.isFinite(_surfacePoint[1]) && Number.isFinite(_surfacePoint[2]);
  if (!finite) {
    ship.graced = true;
    ship.dist = 2 * ship.radius;
    return ship.dist;
  }
  ship.graced = false;
  if (probeInside.some((inside) => !inside) || clearance <= 0) {
    ship.dist = 0;
    return 0;
  }
  ship.dist = clearance;
  return clearance;
}

// Continuous hull check for an otherwise fixed simulation step. At deep speed
// stairs a ship may travel farther than a thin landmark in one frame; sampling
// the segment at no more than one hull radius makes consecutive swept spheres
// overlap, so no visible surface can fall between two collision queries.
export function sweptCollision(cave, ship, from, compositions = [], maxStep = ship.radius) {
  const end = [ship.pos[0], ship.pos[1], ship.pos[2]];
  const dx = end[0] - from[0], dy = end[1] - from[1], dz = end[2] - from[2];
  const steps = Math.max(1, Math.ceil(Math.hypot(dx, dy, dz) / Math.max(1e-6, maxStep)));
  let clearance = Number.MAX_VALUE;
  for (let step = 1; step <= steps; step++) {
    const t = step / steps;
    ship.pos[0] = from[0] + dx * t;
    ship.pos[1] = from[1] + dy * t;
    ship.pos[2] = from[2] + dz * t;
    clearance = collision(cave, ship, compositions);
    if (clearance <= 0) return 0;
  }
  return clearance;
}

export function shipHit(ship) {
  return 1 - clamp(ship.dist / (2 * SHIP_RADIUS), 0, 1);
}
