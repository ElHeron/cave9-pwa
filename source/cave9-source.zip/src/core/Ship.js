// Ship physics — ported from `ship_move`/`ship_init` in the original game.c.
//
// The ship always moves forward at a constant speed (vel.z ≈ VELOCITY) and is
// pulled down by gravity. The player can only fire two diagonal thrusters
// (left/right), each adding up+sideways acceleration. This is the core
// "fight against gravity + inertia" feel of SF-Cave.

import { GRAVITY, THRUST, VELOCITY, SHIP_RADIUS } from './constants.js';
import { v3, set, add, addScale, sub2, len } from './vec.js';

export class Ship {
  constructor(radius = SHIP_RADIUS) {
    this.radius = radius;
    this.pos = v3();
    this.vel = v3();
    this.lookAt = v3();
    this.roll = 0;
    this.lefton = false;
    this.righton = false;
    this.dist = Number.MAX_VALUE;   // distance to nearest cave wall
    // Additive directional clearance (Phase 4E / L3): nearest wall distance on
    // the ship's left (x<pos.x) vs right (x>pos.x) side of the head ring. Read
    // by the directional proximity audio ONLY — never affects the crash test.
    this.leftClear = Number.MAX_VALUE;
    this.rightClear = Number.MAX_VALUE;
    this.repulsion = v3(0, 1, 0);   // surface normal at collision (for FX)
    this.start = 0;                 // starting depth
    this.thrustScale = 1;           // player "sensitivity" (only the player ship)
    this.forceScale = 1;            // shared gravity/thrust difficulty staircase
    // collision debug probes: the 4 diamond points tested each frame and whether
    // each is inside the cave polygon. Filled by CollisionSystem; read by the
    // debug overlay. Persistent arrays so the hot path never allocates.
    this.probePos = [[0, 0], [0, 0], [0, 0], [0, 0]];
    this.probeInside = [true, true, true, true];
    this.graced = false;            // last collision skipped a degenerate frame
    this.reset(radius);
  }

  reset(radius = this.radius) {
    set(this.pos, 0, 0, this.start);
    set(this.vel, 0, 0, VELOCITY);
    set(this.lookAt, 0, 0, VELOCITY);
    this.roll = 0;
    this.radius = radius;
    this.dist = Number.MAX_VALUE;
    this.leftClear = Number.MAX_VALUE;
    this.rightClear = Number.MAX_VALUE;
    set(this.repulsion, 0, 1, 0);
    this.lefton = this.righton = false;
    this.forceScale = 1;
  }

  // ship_move(): integrate one physics step of length dt.
  move(dt) {
    const forceScale = Number.isFinite(this.forceScale) ? Math.max(0, this.forceScale) : 1;
    const acc = THRUST * this.thrustScale * forceScale * dt;
    let roll = 0;

    if (this.lefton) {
      add(this.vel, [-acc, acc / 2, 0]);
      roll--;
    }
    if (this.righton) {
      add(this.vel, [+acc, acc / 2, 0]);
      roll++;
    }

    this.vel[1] -= GRAVITY * forceScale * dt;

    addScale(this.pos, this.vel, dt);

    // smooth lookAt toward velocity
    const d = v3();
    sub2(d, this.vel, this.lookAt);
    addScale(this.lookAt, d, 0.2);

    // smooth roll toward the input direction
    this.roll += (roll ? 0.015 : 0.06) * (roll - this.roll);
  }

  speed() {
    return len(this.vel);
  }

  // Forward progression is intentionally separate from total 3D velocity.
  // Steering/gravity change x/y and must never make the displayed flight speed
  // appear to pulse while the depth-based z plateau is constant.
  forwardSpeed() {
    return Math.abs(this.vel[2]);
  }
}
