// Visible landmarks — WHERE cave architecture may exist (Phase 4G / M2 + 4G.2).
//
// PURE, ADDITIVE, READ-ONLY. Landmarks are sparse, deterministic
// rock formations placed in the generator's **rooms** (the periodic 4×-wide
// chambers emitted by CaveStream). They give orientation, depth and a
// sense of progress. Their pieces and bridge capsules are the shared authority
// for rendering, collision, warning and capture; touching any family is lethal.
// They remain independent of scoring and the generator's RNG stream.
//
// This module is the subsystem's public face and the composition assembler. The
// parts live in ./landmarks/:
//
//   rng.js       the family selector + its own PRNG (never the game's stream)
//   rooms.js     where rooms are, and reading the live cave ring at one
//   safety.js    the piece grammar and its guarantees — the INVARIANT layer
//   families.js  the three families' skeletons — ART DIRECTION, changes often
//
// The safety/art split is the important one: families.js may be rewritten freely
// as the look is re-directed, but every piece it emits still goes through
// safety.js, so a formation can never occlude the flight path or the dark
// vanishing point no matter how the art evolves. What the pieces LOOK like is a
// third thing again, and lives in render/landmarks/.
//
// Same seed + roomIndex → identical composition (proven in test/landmarks.test.js).
// See LANDMARK_ART_DIRECTION_REPORT.md for the families, rules and rejects.

import { BRANCHING, COILING, CRYSTAL, hash2, mulberry32, landmarkType, LANDMARK_TYPES } from './landmarks/rng.js';
import { roomZ, roomRingIndex, ringCentroidClearance, visibleRoomRange,
  roomSurfaceFor, LANDMARK_FORM_HALF_SPAN } from './landmarks/rooms.js';
import {
  LANDMARK_WALL_MARGIN_FRAC, LANDMARK_MAX_PIECES, norm3,
} from './landmarks/safety.js';
import { buildFamily } from './landmarks/families.js';
import { buildRootSurface } from './landmarks/RootSurface.js';
import { slabHullForPiece } from './landmarks/SlabHull.js';
import { CaveStream } from './CaveStream.js';
import { pathFrameAt, tubeRadiusAt } from './FlightPath.js';
import { SEGMENT_LEN } from './constants.js';
import { coilingContractForRoom } from './CoilingShell.js';
import { nearestRingIndex, bracketingRingIndices } from './SurfaceQuery.js';

// Re-exported so callers (and tests) keep one import for the whole subsystem.
export { LANDMARK_TYPES, BRANCHING, CRYSTAL, COILING, landmarkType } from './landmarks/rng.js';
export { FIRST_ROOM_K, roomZ, roomRingIndex, visibleRoomRange } from './landmarks/rooms.js';
export {
  LANDMARK_WALL_MARGIN_FRAC, LANDMARK_MAX_PIECES,
} from './landmarks/safety.js';

// A chamber needs at least this much annulus between the no-entry tube and the
// wall before any formation is worth attempting.
const MIN_ANNULUS = 2.5;
export { LANDMARK_FORM_HALF_SPAN };

// Only an explicitly supplied preceding composition may reuse authoring work.
// Weak keys follow the existing bounded composition cache; the four-argument
// builder always regenerates its own radius and family as the fresh oracle.
const compositionAuthoring = new WeakMap();

function copyAuthoredPieces(template) {
  const pieces = template.map((piece) => ({
    ...piece,
    ...(piece.slab ? { slab: { ...piece.slab } } : {}),
  }));
  const bounds = Object.getOwnPropertyDescriptor(template, 'bounds');
  if (bounds) Object.defineProperty(pieces, 'bounds', {
    ...bounds, value: { ...bounds.value },
  });
  return pieces;
}

function freezeAuthoredPieces(pieces) {
  for (const piece of pieces) {
    if (piece.slab) Object.freeze(piece.slab);
    Object.freeze(piece);
  }
  if (pieces.bounds) Object.freeze(pieces.bounds);
  return Object.freeze(pieces);
}

function previousAuthoring(composition, seed, cave, k, zT, frame, type, outer, clearance) {
  if (!(cave instanceof CaveStream) || !Number.isInteger(cave.generation)
      || (type !== CRYSTAL && type !== BRANCHING)) return null;
  const prior = composition && compositionAuthoring.get(composition);
  return prior && prior.cave === cave && prior.generation === cave.generation
    && Object.is(prior.seed, seed) && Object.is(prior.k, k)
    && Object.is(prior.zT, zT) && prior.frame === frame && prior.type === type
    && Object.is(prior.outer, outer) && Object.is(prior.clearance, clearance)
    ? prior : null;
}

// Exact live-cave dependency of compositionAt().  Long reference-led forms
// sample the wall over the whole axial span, so the centre ring alone is not a
// sufficient cache revision.  Ring contents are immutable while their centre
// z remains in a circular-buffer slot; recording every relevant slot+z pair is
// therefore a compact, collision-free revision for this cave instance.
//
// null has the same meaning as compositionAt(): the room centre is not carved.
export function compositionSurfaceRevision(cave, k, centreRing = roomRingIndex(cave, k)) {
  if (centreRing < 0) return null;
  const zT = roomZ(k);
  const reach = LANDMARK_FORM_HALF_SPAN + SEGMENT_LEN * 1.5;
  const parts = [`g:${cave.generation ?? 'external'}`];
  for (let i = 0; i < cave.centers.length; i++) {
    const z = cave.centers[i][2];
    if (Number.isFinite(z) && Math.abs(z - zT) <= reach) parts.push(`${i}:${z}`);
  }
  return parts.join('|');
}

// The broad revision above remains the conservative contract for all families
// and external/synthetic caves. A production root, however, only reads a
// discrete set of live wall samples. Record *every attempted* sample, including
// failed footprint rays: a newly emitted ring can turn a fallback into a real
// contact. CaveStream ring vertices/frames are immutable within a generation,
// so the selected ring depths are an exact geometry identity across circular
// recycling and index-only resize. A generation change invalidates even if the
// same depth lattice is emitted again after reset.
function selectedRingDepth(cave, index) {
  const depth = cave.centers?.[index]?.[2];
  return index >= 0 && Number.isFinite(depth) ? depth : 'none';
}

function rootQuerySelection(cave, query) {
  if (query.kind === 'radius') {
    const nearest = nearestRingIndex(cave, query.depth);
    const [before, after] = query.axial
      ? bracketingRingIndices(cave, query.depth) : [-1, -1];
    return `${selectedRingDepth(cave, nearest)},${selectedRingDepth(cave, before)},${selectedRingDepth(cave, after)}`;
  }
  // wallPointOnLiveTriangles probes both sides of an exact ring plane. Keep
  // both even when a ray currently fails; a future bracket may make it valid.
  const minus = bracketingRingIndices(cave, query.depth - 1e-5);
  const plus = bracketingRingIndices(cave, query.depth + 1e-5);
  return `${selectedRingDepth(cave, minus[0])},${selectedRingDepth(cave, minus[1])},`
    + `${selectedRingDepth(cave, plus[0])},${selectedRingDepth(cave, plus[1])}`;
}

function rootQueryRevision(cave, queries) {
  return queries.map((query) => rootQuerySelection(cave, query)).join('|');
}

function rootCompositionRevision(cave, k, dependencies, reevaluate = false) {
  const centreRing = roomRingIndex(cave, k);
  if (centreRing < 0) return null;
  const parts = [`root:g${cave.generation}:c${selectedRingDepth(cave, centreRing)}`];
  for (const [gid, dependency] of dependencies) {
    parts.push(`${gid}:${reevaluate
      ? rootQueryRevision(cave, dependency.queries) : dependency.selection}`);
  }
  return parts.join('|');
}

function sameBladeQueryValue(a, b) {
  if (Object.is(a, b)) return true;
  if (!a || !b || typeof a !== 'object' || typeof b !== 'object') return false;
  return Object.is(a.x, b.x) && Object.is(a.y, b.y)
    && Object.is(a.z, b.z);
}

function bladeQueryValue(cave, query) {
  return query.kind === 'radius'
    ? caveWallRadiusAt(cave, query.depth, query.azimuth, query.fallback,
      query.axial)
    : wallPointOnLiveTriangles(cave, query.seed, query.routeDepth,
      query.azimuth, null, query.frame);
}

function bladeNumberToken(value) {
  return Object.is(value, -0) ? '-0' : String(value);
}

function bladeValueToken(value) {
  return value === null ? 'n' : typeof value === 'number'
    ? `r${bladeNumberToken(value)}`
    : `p${bladeNumberToken(value.x)},${bladeNumberToken(value.y)},${bladeNumberToken(value.z)}`;
}

function bladeCompositionRevision(cave, k, queries, reevaluate = false) {
  const centreRing = roomRingIndex(cave, k);
  if (centreRing < 0) return null;
  // A newly selected ring pair can still yield precisely the same contact
  // point/radius (notably while a failed front ray keeps using its fallback).
  // Only the actual values consumed by mapping may change the composition.
  const values = queries.map((query) => {
    if (!reevaluate || query.selection === rootQuerySelection(cave, query)) {
      return query.value;
    }
    const value = bladeQueryValue(cave, query);
    return sameBladeQueryValue(value, query.value) ? query.value : value;
  });
  return `blade:g${cave.generation}:c${selectedRingDepth(cave, centreRing)}`
    + `:v${values.map(bladeValueToken).join('|')}`;
}

export function compositionDependencyRevision(cave, k, composition) {
  const wallSurface = composition?.type === BRANCHING || composition?.type === CRYSTAL
    ? roomSurfaceFor(cave, k) : cave;
  const dependencies = composition?.rootFormDependencies;
  if (dependencies && Number.isInteger(cave.generation)) {
    return rootCompositionRevision(wallSurface, k, dependencies, true);
  }
  const bladeQueries = composition?.bladeWallQueries;
  if (bladeQueries && cave instanceof CaveStream && Number.isInteger(cave.generation)) {
    return bladeCompositionRevision(wallSurface, k, bladeQueries, true);
  }
  return compositionSurfaceRevision(cave, k);
}

function uniqueRootQueries(queries) {
  const unique = new Map();
  for (const query of queries) {
    const key = `${query.kind}:${query.depth}:${query.axial ? 1 : 0}`;
    if (!unique.has(key)) unique.set(key, Object.freeze(query));
  }
  return Object.freeze([...unique.values()]);
}

function sameRootValue(a, b) {
  if (Object.is(a, b)) return true;
  if (!a || !b || typeof a !== 'object' || typeof b !== 'object') return false;
  const ak = Object.keys(a), bk = Object.keys(b);
  if (ak.length !== bk.length) return false;
  for (let i = 0; i < ak.length; i++) {
    if (ak[i] !== bk[i] || !sameRootValue(a[ak[i]], b[bk[i]])) return false;
  }
  return true;
}

function rootQuerySink(map, gid) {
  let queries = map.get(gid);
  if (!queries) { queries = []; map.set(gid, queries); }
  return queries;
}

// Child displacement is authored in its parent's tangent frame. Reconstruct
// that frame after live-wall mapping instead of independently snapping a fork.
function rootTangentFrame(a, b) {
  const tangent = norm3(b.x - a.x, b.y - a.y, b.z - a.z);
  const reference = Math.abs(tangent.z) < 0.9
    ? { x: 0, y: 0, z: 1 } : { x: 1, y: 0, z: 0 };
  const normal = norm3(tangent.y * reference.z - tangent.z * reference.y,
    tangent.z * reference.x - tangent.x * reference.z,
    tangent.x * reference.y - tangent.y * reference.x);
  const binormal = norm3(tangent.y * normal.z - tangent.z * normal.y,
    tangent.z * normal.x - tangent.x * normal.z,
    tangent.x * normal.y - tangent.y * normal.x);
  return [tangent, normal, binormal];
}

export function compositionSurfaceComplete(cave, k) {
  const zT = roomZ(k);
  const reach = LANDMARK_FORM_HALF_SPAN + SEGMENT_LEN * 1.5;
  let first = Infinity, last = -Infinity;
  for (const center of cave.centers || []) {
    const z = center?.[2];
    if (!Number.isFinite(z)) continue;
    first = Math.min(first, z);
    last = Math.max(last, z);
  }
  // Ring centres live on the exact SEGMENT_LEN lattice. One segment of
  // tolerance admits the nearest bracketing planes without accepting a missing
  // axial region that would still change live-wall remapping.
  return first <= zT - reach + SEGMENT_LEN
    && last >= zT + reach - SEGMENT_LEN;
}

function protectedRadiusAcross(seed, centreZ) {
  let radius = 0;
  for (let dz = -LANDMARK_FORM_HALF_SPAN; dz <= LANDMARK_FORM_HALF_SPAN; dz += SEGMENT_LEN) {
    radius = Math.max(radius, tubeRadiusAt(centreZ + dz, seed) + 0.35);
  }
  return radius;
}

function angularGap(a, b) {
  return Math.abs(Math.atan2(Math.sin(a - b), Math.cos(a - b)));
}

function ringWallRadiusAt(cave, ringIndex, azimuth, fallback) {
  if (ringIndex < 0 || !cave.frames[ringIndex]) return fallback;
  const ring = cave.segs[ringIndex], localFrame = cave.frames[ringIndex];
  let first = null, second = null;
  for (const vertex of ring) {
    const dx = vertex[0] - localFrame.center.x;
    const dy = vertex[1] - localFrame.center.y;
    const dz = vertex[2] - localFrame.center.z;
    const x = dx * localFrame.right.x + dy * localFrame.right.y + dz * localFrame.right.z;
    const y = dx * localFrame.up.x + dy * localFrame.up.y + dz * localFrame.up.z;
    const candidate = { gap: angularGap(Math.atan2(y, x), azimuth), radius: Math.hypot(x, y) };
    if (!first || candidate.gap < first.gap) { second = first; first = candidate; }
    else if (!second || candidate.gap < second.gap) second = candidate;
  }
  if (!first) return fallback;
  if (!second) return first.radius;
  const total = first.gap + second.gap || 1;
  return first.radius * (second.gap / total) + second.radius * (first.gap / total);
}

function caveWallRadiusAt(cave, worldZ, azimuth, fallback, axialInterpolation = false,
  rootQueries = null) {
  if (rootQueries) rootQueries.push({ kind: 'radius', depth: worldZ, axial: axialInterpolation });
  const bestRing = nearestRingIndex(cave, worldZ);
  const bestDepth = bestRing < 0 ? Infinity : Math.abs(cave.centers[bestRing][2] - worldZ);
  if (bestRing < 0 || bestDepth > SEGMENT_LEN * 1.5) return fallback;
  if (!axialInterpolation) return ringWallRadiusAt(cave, bestRing, azimuth, fallback);

  // Long wall-rooted chains can place successive nodes on opposite sides of a
  // 2 m ring boundary. Sampling only the nearest ring makes an otherwise smooth
  // authored shoulder jump radially. Interpolate the bracketing live rings at
  // the same route-local azimuth before mapping the chain to world space.
  const [before, after] = bracketingRingIndices(cave, worldZ);
  const beforeZ = cave.centers[before]?.[2], afterZ = cave.centers[after]?.[2];
  if (before < 0 || after < 0 || !cave.frames[before] || !cave.frames[after]
      || !Number.isFinite(beforeZ) || !Number.isFinite(afterZ)
      || afterZ - beforeZ > SEGMENT_LEN * 1.5) {
    return ringWallRadiusAt(cave, bestRing, azimuth, fallback);
  }
  const a = ringWallRadiusAt(cave, before, azimuth, fallback);
  if (before === after) return a;
  const b = ringWallRadiusAt(cave, after, azimuth, fallback);
  return a + (b - a) * ((worldZ - beforeZ) / (afterZ - beforeZ));
}

function rayTriangleDistance(origin, direction, a, b, c) {
  const e1x = b[0] - a[0], e1y = b[1] - a[1], e1z = b[2] - a[2];
  const e2x = c[0] - a[0], e2y = c[1] - a[1], e2z = c[2] - a[2];
  const px = direction.y * e2z - direction.z * e2y;
  const py = direction.z * e2x - direction.x * e2z;
  const pz = direction.x * e2y - direction.y * e2x;
  const det = e1x * px + e1y * py + e1z * pz;
  if (Math.abs(det) < 1e-10) return Infinity;
  const tx = origin.x - a[0], ty = origin.y - a[1], tz = origin.z - a[2];
  const u = (tx * px + ty * py + tz * pz) / det;
  if (u < -1e-8 || u > 1 + 1e-8) return Infinity;
  const qx = ty * e1z - tz * e1y;
  const qy = tz * e1x - tx * e1z;
  const qz = tx * e1y - ty * e1x;
  const v = (direction.x * qx + direction.y * qy + direction.z * qz) / det;
  if (v < -1e-8 || u + v > 1 + 1e-8) return Infinity;
  const distance = (e2x * qx + e2y * qy + e2z * qz) / det;
  return distance > 0 ? distance : Infinity;
}

function wallPointOnLiveTriangles(cave, seed, depth, azimuth, rootQueries = null,
  sampledFrame = null) {
  const frame = sampledFrame || pathFrameAt(seed, depth);
  const origin = frame.center;
  if (rootQueries) rootQueries.push({ kind: 'footprint', depth: origin.z });
  const radial = {
    x: frame.right.x * Math.cos(azimuth) + frame.up.x * Math.sin(azimuth),
    y: frame.right.y * Math.cos(azimuth) + frame.up.y * Math.sin(azimuth),
    z: frame.right.z * Math.cos(azimuth) + frame.up.z * Math.sin(azimuth),
  };
  // Intersect the outward route-radial ray, including its axial component, so
  // the footprint follows the bent room wall without a horizontal shear.
  const length = Math.hypot(radial.x, radial.y, radial.z) || 1;
  const direction = { x: radial.x / length, y: radial.y / length, z: radial.z / length };
  let nearest = Infinity;
  const seen = new Set();
  // At an exact ring plane, either adjacent strip may own the contact. Probe
  // both sides without ever snapping to a distant fold or unrelated sector.
  for (const queryDepth of [origin.z - 1e-5, origin.z + 1e-5]) {
    const [lo, hi] = bracketingRingIndices(cave, queryDepth);
    if (lo < 0 || hi < 0 || lo === hi || !cave.segs[lo] || !cave.segs[hi]) continue;
    const key = `${lo}:${hi}`;
    if (seen.has(key)) continue;
    seen.add(key);
    for (let j = 0; j < cave.segs[lo].length; j++) {
      const j1 = (j + 1) % cave.segs[lo].length;
      const a = cave.segs[lo][j], b = cave.segs[hi][j];
      const c = cave.segs[lo][j1], d = cave.segs[hi][j1];
      nearest = Math.min(nearest,
        rayTriangleDistance(origin, direction, a, b, c),
        rayTriangleDistance(origin, direction, c, b, d));
    }
  }
  if (!Number.isFinite(nearest)) return null;
  return { x: origin.x + direction.x * nearest,
    y: origin.y + direction.y * nearest, z: origin.z + direction.z * nearest };
}

// Continuous root/rib forms are rendered as one smooth tube through the tip of
// every grouped piece.  At a turn, the surface triangles bridge from one ring
// orientation to the next; although every ring vertex is inside an endpoint
// capsule, the bridge interior is not necessarily inside either original
// segment capsule.  These extra capsules follow the exact rendered centreline
// spans and use the larger endpoint radius.  A capsule is convex, so it contains
// both endpoint rings and every triangle between them.
//
// They live beside (rather than inside) `pieces`: pieces remain the visible
// family grammar and pool count, while every collision consumer reads this
// authoritative superset from the same cached composition.
function collisionCapsulesFor(pieces) {
  const capsules = pieces.slice();
  const forms = new Map();
  for (const p of pieces) {
    if (p.shape === 'blade' || p.gid == null) continue;
    let form = forms.get(p.gid);
    if (!form) { form = []; forms.set(p.gid, form); }
    form.push(p);
  }
  for (const form of forms.values()) {
    form.sort((a, b) => (a.node || 0) - (b.node || 0));
    for (let i = 1; i < form.length; i++) {
      const prev = form[i - 1], next = form[i];
      const ph = prev.length / 2, nh = next.length / 2;
      const a = {
        x: prev.cx + prev.dx * ph,
        y: prev.cy + prev.dy * ph,
        z: prev.cz + prev.dz * ph,
      };
      const b = {
        x: next.cx + next.dx * nh,
        y: next.cy + next.dy * nh,
        z: next.cz + next.dz * nh,
      };
      const length = Math.hypot(b.x - a.x, b.y - a.y, b.z - a.z);
      if (!(length > 1e-9)) continue;
      const dir = norm3(b.x - a.x, b.y - a.y, b.z - a.z);
      capsules.push({
        shape: 'bridge', collisionOnly: true,
        cx: (a.x + b.x) / 2, cy: (a.y + b.y) / 2, cz: (a.z + b.z) / 2,
        dx: dir.x, dy: dir.y, dz: dir.z,
        length, radius: Math.max(prev.radius, next.radius),
        gid: next.gid, node: next.node,
      });
    }
  }
  return capsules;
}

// Build the full deterministic composition for room k from the live cave, or
// null if the room plane is not carved / the chamber is too tight for any piece.
export function compositionAt(seed, cave, k, forcedType = null, reuseComposition = null) {
  const zT = roomZ(k);
  const requestedType = forcedType == null ? cave.landmarkFamilyOverride : forcedType;
  // A family-off run is the paired geometric control used by visual evidence.
  // It suppresses both secondary meshes and surface-resident C3 rather than
  // treating an unknown string as the seed-selected production family.
  if (requestedType === 'off') return null;
  const forcedIndex = typeof requestedType === 'string'
    ? LANDMARK_TYPES.indexOf(requestedType) : requestedType;
  const type = Number.isInteger(forcedIndex) && forcedIndex >= 0 && forcedIndex < LANDMARK_TYPES.length
    ? forcedIndex : landmarkType(seed, k);
  const wallSurface = cave instanceof CaveStream && (type === BRANCHING || type === CRYSTAL)
    ? roomSurfaceFor(cave, k) : cave;
  const idx = roomRingIndex(wallSurface, k);
  if (idx < 0) return null;
  let surfaceRevision = null;
  const { cx, cy, clearance, frame } = ringCentroidClearance(wallSurface, idx);
  if (!Number.isFinite(clearance) || clearance <= 0) return null;

  // The route's live boolean tube is authoritative.  A small extra reserve
  // covers tube-radius variation across an axial landmark form.
  const outer = LANDMARK_WALL_MARGIN_FRAC * clearance;
  const authoring = previousAuthoring(reuseComposition, seed, cave, k, zT,
    frame, type, outer, clearance);
  const inner = authoring ? authoring.inner : protectedRadiusAcross(seed, zT);
  if (type === COILING) {
    // C3 has no secondary landmark skeleton. Its identity remains discoverable
    // for snapshots/reports, while all physical and visible authority lives in
    // CaveStream's ring triangles.
    const coilingContract = coilingContractForRoom(seed, k, cave.landmarkFamilyOverride);
    if (!coilingContract) return null;
    surfaceRevision = compositionSurfaceRevision(cave, k, idx);
    return {
      k, type, typeName: LANDMARK_TYPES[type], z: zT,
      cx, cy, clearance, inner, outer, wall: clearance, frame, surfaceRevision,
      surfaceResident: true,
      coilingContract,
      pieces: [],
      collisionPieces: [],
    };
  }
  if (outer - inner < MIN_ANNULUS) return null; // no room for a safe formation
  const rng = mulberry32(hash2(seed | 0, k | 0));
  // (re)draw the type selector off the same stream start so pieces vary per seed
  rng();

  // `outer` bounds piece PLACEMENT; `clearance` is the real wall the safety pass
  // allows a thick base to embed into (see safety.js / pieceSafe).
  // Families are authored in route-local coordinates (x/y radial, z axial),
  // then rigidly transformed into the room frame.  Safety is therefore checked
  // in the same cross-section the boolean tube uses.
  // The private template is pristine local grammar, never a mapped world piece.
  // Both families mutate their working pieces below (including crystal radius
  // and nested slab metadata), so every rebuild receives an independent copy.
  const retainAuthoring = cave instanceof CaveStream && Number.isInteger(cave.generation)
    && (type === CRYSTAL || type === BRANCHING);
  const template = authoring && Object.is(authoring.inner, inner)
    ? authoring.template
    : retainAuthoring
      ? freezeAuthoredPieces(buildFamily(type, rng, 0, 0, 0, inner, outer, clearance))
      : null;
  const pieces = template ? copyAuthoredPieces(template)
    : buildFamily(type, rng, 0, 0, 0, inner, outer, clearance);
  // Capture every live-wall selector that a blade actually attempts. A missing
  // front strip is still a dependency: when it arrives, fallback contact must
  // be replaced by the newly emitted triangles.
  const bladeWallQueries = type === CRYSTAL && cave instanceof CaveStream
    && Number.isInteger(cave.generation) ? [] : null;
  const hasRoots = pieces.some((piece) => piece.wallRooted);
  const rootNodeQueries = hasRoots ? new Map() : null;
  const rootFootprintQueries = hasRoots ? new Map() : null;
  // This optional cache hint is never needed by the pure four-argument API.
  // An unchanged CaveStream ring generation, room frame and authored annulus
  // make a prior root form reusable if every ring selector it actually read
  // still resolves to the same immutable wall rings.
  const oldRootForms = hasRoots && cave instanceof CaveStream
    && reuseComposition?.rootCave === cave
    && reuseComposition.rootGeneration === cave.generation
    && reuseComposition.rootSeed === (seed | 0)
    && reuseComposition.k === k && reuseComposition.type === type
    && reuseComposition.frame === frame
    && reuseComposition.inner === inner && reuseComposition.outer === outer
    && reuseComposition.clearance === clearance
    ? reuseComposition.rootFormDependencies : null;
  // The authored route depends only on seed and exact depth, while a live wall
  // revision changes ring geometry. Retain the expensive analytic frames at
  // precisely sampled depths across revisions; copy the map so a prior
  // composition remains immutable as a cache result.
  const rootRouteFrames = oldRootForms && reuseComposition.rootRouteFrames instanceof Map
    ? new Map(reuseComposition.rootRouteFrames) : new Map();
  const routeFrameAt = (depth) => {
    let sampled = rootRouteFrames.get(depth);
    if (!sampled) {
      sampled = pathFrameAt(seed, depth);
      rootRouteFrames.set(depth, sampled);
    }
    return sampled;
  };

  // Fit authoring coordinates to the irregular live wall. A rooted chain
  // follows the wall closely at its base and preserves its authored inward
  // reach near the tip. The node-radius clamp protects the flight tube.
  const mapToLiveWall = (point, piece, endpoint, nodeRadius = piece.radius,
    axialInterpolation = false, querySink = null) => {
    const r = Math.hypot(point.x, point.y);
    const azimuth = Math.atan2(point.y, point.x);
    const bladeQueries = piece.shape === 'blade' ? querySink : null;
    let bladeContact = null;
    let wallRadius = caveWallRadiusAt(wallSurface, zT + point.z, azimuth, clearance,
      axialInterpolation, bladeQueries ? null : querySink);
    const fraction = Math.max(0, Math.min(1, (r - inner) / Math.max(1e-6, clearance - inner)));
    let mappedRadius = axialInterpolation
      ? r + (wallRadius - clearance) * fraction ** 3
      : inner + (wallRadius - inner) * fraction;
    if (piece.role === 'hero-crawler' || piece.role === 'shell-channel') {
      mappedRadius = wallRadius - (piece.role === 'shell-channel' ? 0.18 : 0.45);
    } else if (piece.role === 'claw-stem' && piece.node === 0 && endpoint === 'base') {
      mappedRadius = wallRadius - 0.45;
    } else if (piece.shape === 'blade' && endpoint === 'base') {
      // Blade bases use the real wall triangles. The nearest-ring radius can
      // sit 40 cm inward at a folded facet, detaching a narrow visible plate
      // even though its larger safety capsule touches rock.
      const contactFrame = routeFrameAt(zT + point.z);
      const contact = wallPointOnLiveTriangles(wallSurface, seed, zT + point.z,
        azimuth, bladeQueries ? null : querySink, contactFrame);
      if (bladeQueries) {
        bladeContact = contact;
        bladeQueries.push({ kind: 'footprint', depth: contactFrame.center.z,
          routeDepth: zT + point.z, azimuth, seed, frame: contactFrame,
          value: contact });
      }
      if (contact) {
        wallRadius = Math.hypot(contact.x - contactFrame.center.x,
          contact.y - contactFrame.center.y, contact.z - contactFrame.center.z);
      }
      mappedRadius = wallRadius - 0.08;
    }
    if (bladeQueries && (endpoint !== 'base' || !bladeContact)) {
      // The nearest-ring radius only affects a blade base when the exact wall
      // ray failed. A successful triangle contact supersedes it completely.
      bladeQueries.push({ kind: 'radius', depth: zT + point.z,
        azimuth, fallback: clearance, axial: axialInterpolation,
        value: wallRadius });
    }
    mappedRadius = Math.max(inner + nodeRadius + 0.05, Math.min(wallRadius, mappedRadius));
    return {
      x: mappedRadius * Math.cos(azimuth),
      y: mappedRadius * Math.sin(azimuth),
      z: point.z,
      wallRadius,
    };
  };

  const toWorldPoint = (x, y, localZ) => {
    const localFrame = routeFrameAt(zT + localZ);
    return {
      x: localFrame.center.x + localFrame.right.x * x + localFrame.up.x * y,
      y: localFrame.center.y + localFrame.right.y * x + localFrame.up.y * y,
      z: localFrame.center.z + localFrame.right.z * x + localFrame.up.z * y,
    };
  };

  // A root sweep is one continuous chain even though Core stores its segments
  // separately. Map each shared node only once. Its larger adjacent capsule
  // radius governs the inner clamp, avoiding tiny seams where radii taper.
  const rootForms = new Map();
  const pieceSlots = new Map();
  for (let slot = 0; slot < pieces.length; slot++) {
    const p = pieces[slot];
    pieceSlots.set(p, slot);
    if ((!p.wallRooted && !p.parentGid) || p.shape !== 'limb' || p.gid == null) continue;
    let form = rootForms.get(p.gid);
    if (!form) { form = []; rootForms.set(p.gid, form); }
    form.push(p);
  }
  const endpointAt = (p, sign, local = false) => {
    const source = local ? p.local : p;
    const h = (local ? p.localLength : p.length) / 2 * sign;
    return { x: source.cx + source.dx * h, y: source.cy + source.dy * h,
      z: source.cz + source.dz * h };
  };
  const authoredNodes = new Map();
  for (const [gid, form] of rootForms) {
    form.sort((a, b) => a.node - b.node);
    authoredNodes.set(gid, [endpointAt(form[0], -1), ...form.map((p) => endpointAt(p, 1))]);
  }
  const reusedRootGids = new Set();
  for (const [gid, form] of rootForms) {
    form.sort((a, b) => (a.node || 0) - (b.node || 0));
    const old = oldRootForms instanceof Map ? oldRootForms.get(gid) : null;
    if (form[0].parentGid && !reusedRootGids.has(form[0].parentGid)) continue;
    if (!old || old.pieces.length !== form.length
        || old.selection !== rootQueryRevision(wallSurface, old.queries)) continue;
    for (let i = 0; i < form.length; i++) {
      pieces[pieceSlots.get(form[i])] = old.pieces[i];
      form[i] = old.pieces[i];
    }
    rootNodeQueries.set(gid, old.nodeQueries);
    rootFootprintQueries.set(gid, old.footprintQueries);
    reusedRootGids.add(gid);
  }
  const rootEndpoints = new Map();
  const mappedRootNodes = new Map();
  const pieceEndpoint = (p, sign) => {
    const h = p.length / 2 * sign;
    return { x: p.cx + p.dx * h, y: p.cy + p.dy * h, z: p.cz + p.dz * h };
  };
  for (const [gid, form] of rootForms) {
    if (reusedRootGids.has(gid)) {
      mappedRootNodes.set(gid, [endpointAt(form[0], -1, true),
        ...form.map((p) => endpointAt(p, 1, true))]);
      continue;
    }
    const sourceNodes = [pieceEndpoint(form[0], -1), ...form.map((p) => pieceEndpoint(p, 1))];
    const querySink = rootQuerySink(rootNodeQueries, gid);
    let mappedNodes;
    if (form[0].parentGid) {
      const child = form[0], parent = rootForms.get(child.parentGid);
      const sourceParent = authoredNodes.get(child.parentGid);
      const mappedParent = mappedRootNodes.get(child.parentGid);
      if (!parent || !mappedParent) throw new Error('Root child requires its mapped parent');
      const station = child.parentNode;
      const sourceOrigin = sourceParent[station], mappedOrigin = mappedParent[station];
      const sourceFrame = rootTangentFrame(sourceParent[station - 1], sourceParent[station + 1]);
      const mappedFrame = rootTangentFrame(mappedParent[station - 1], mappedParent[station + 1]);
      const reconstruct = (scale) => sourceNodes.map((point) => {
        const delta = { x: point.x - sourceOrigin.x, y: point.y - sourceOrigin.y,
          z: point.z - sourceOrigin.z };
        const result = { ...mappedOrigin };
        for (let axis = 0; axis < 3; axis++) {
          const metres = (delta.x * sourceFrame[axis].x + delta.y * sourceFrame[axis].y
            + delta.z * sourceFrame[axis].z) * scale;
          for (const key of ['x', 'y', 'z']) result[key] += metres * mappedFrame[axis][key];
        }
        return result;
      });
      // Whole-child scale only. The attachment is never clamped or detached.
      for (const scale of [1, 0.85, 0.70]) {
        const candidate = reconstruct(scale);
        const safe = form.every((p, i) => {
          const a = candidate[i], b = candidate[i + 1], radius = p.radius * scale;
          return [a, { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2, z: (a.z + b.z) / 2 }, b]
            .every((point) => {
              const r = Math.hypot(point.x, point.y);
              const wall = caveWallRadiusAt(wallSurface, zT + point.z,
                Math.atan2(point.y, point.x), clearance, true, querySink);
              return r - radius >= inner + 0.05 && r <= wall;
            });
        });
        if (!safe) continue;
        mappedNodes = candidate.map((point) => ({ ...point,
          wallRadius: caveWallRadiusAt(wallSurface, zT + point.z,
            Math.atan2(point.y, point.x), clearance, true, querySink) }));
        for (const p of form) p.radius *= scale;
        child.parentContact = Math.min(1, station / parent.length * 4);
        child.parentAlong = station / parent.length;
        child.branchStartRadius = parent[station - 1].radius * 0.18;
        child.parentMappedTangent = mappedFrame[0];
        child.branchMappingScale = scale;
        break;
      }
      if (!mappedNodes) {
        rootQuerySink(rootNodeQueries, child.parentGid).push(...querySink);
        for (const p of form) p.rejectedBranch = true;
        rootForms.delete(gid);
        continue;
      }
      // A parent wall revision invalidates its children's mapping as well.
      querySink.push(...(rootNodeQueries.get(child.parentGid) || []));
    } else mappedNodes = sourceNodes.map((point, node) => {
      const prev = form[node - 1], next = form[node];
      const p = next || prev;
      const nodeRadius = Math.max(prev?.radius || 0, next?.radius || 0);
      return mapToLiveWall(point, p, node === 0 ? 'base' : 'tip',
        nodeRadius, true, querySink);
    });
    mappedRootNodes.set(gid, mappedNodes);
    // Adjacent segments share these nodes exactly. Reuse the same world point
    // instead of running FlightPath twice for every interior joint.
    const worldNodes = mappedNodes.map((point) => toWorldPoint(point.x, point.y, point.z));
    for (let i = 0; i < form.length; i++) {
      rootEndpoints.set(form[i], { a: mappedNodes[i], b: mappedNodes[i + 1],
        wa: worldNodes[i], wb: worldNodes[i + 1] });
    }
  }
  for (const p of pieces) {
    if (p.rejectedBranch) continue;
    if (reusedRootGids.has(p.gid)) continue;
    const mappedRoot = rootEndpoints.get(p);
    const sourceBase = pieceEndpoint(p, -1);
    const sourceTip = pieceEndpoint(p, 1);
    const bladeQueries = p.shape === 'blade' ? bladeWallQueries : null;
    const a = mappedRoot?.a || mapToLiveWall(sourceBase, p, 'base',
      p.radius, false, bladeQueries);
    let b;
    if (p.shape === 'blade') {
      // A blade must keep the proportions of its authored body after its base
      // reaches the live wall. Independently remapping the tip stretched the
      // axis by up to 3.8x while leaving its width and thickness unchanged.
      // Scale the whole route-local body about the protected inner-circle
      // point behind its base; the exact wall contact remains `a`.
      const baseRadius = Math.hypot(sourceBase.x, sourceBase.y);
      const liveBaseRadius = Math.hypot(a.x, a.y);
      const scale = (liveBaseRadius - inner) / (baseRadius - inner);
      if (!(scale > 0) || !Number.isFinite(scale)) {
        throw new RangeError('blade live-wall scale must be finite and positive');
      }
      const pivotX = inner * sourceBase.x / baseRadius;
      const pivotY = inner * sourceBase.y / baseRadius;
      const tip = {
        x: pivotX + scale * (sourceTip.x - pivotX),
        y: pivotY + scale * (sourceTip.y - pivotY),
        z: sourceBase.z + scale * (sourceTip.z - sourceBase.z),
      };
      b = { ...tip, wallRadius: mapToLiveWall(tip, p, 'tip',
        p.radius, false, bladeQueries).wallRadius };
      p.radius *= scale;
      p.liveWallScale = scale;
    } else b = mappedRoot?.b || mapToLiveWall(sourceTip, p, 'tip');
    const wa = mappedRoot?.wa || toWorldPoint(a.x, a.y, a.z);
    const wb = mappedRoot?.wb || toWorldPoint(b.x, b.y, b.z);
    const wd = norm3(wb.x - wa.x, wb.y - wa.y, wb.z - wa.z);
    const worldLength = Math.hypot(wb.x - wa.x, wb.y - wa.y, wb.z - wa.z);
    const localLength = Math.hypot(b.x - a.x, b.y - a.y, b.z - a.z);
    const localDir = norm3(b.x - a.x, b.y - a.y, b.z - a.z);
    p.local = {
      cx: (a.x + b.x) / 2, cy: (a.y + b.y) / 2, cz: (a.z + b.z) / 2,
      dx: localDir.x, dy: localDir.y, dz: localDir.z,
    };
    p.wallRadiusBase = a.wallRadius;
    p.wallRadiusTip = b.wallRadius;
    p.localLength = localLength;
    p.cx = (wa.x + wb.x) / 2; p.cy = (wa.y + wb.y) / 2; p.cz = (wa.z + wb.z) / 2;
    p.dx = wd.x; p.dy = wd.y; p.dz = wd.z;
    p.length = worldLength;
  }
  for (let i = pieces.length - 1; i >= 0; i--) {
    if (pieces[i].rejectedBranch) pieces.splice(i, 1);
  }
  pieceSlots.clear();
  for (let i = 0; i < pieces.length; i++) pieceSlots.set(pieces[i], i);

  // The root's first cross-section is an actual contact curve on the submitted
  // cave triangles, rather than a circular ring centred approximately at the
  // wall. Each route-local (depth, azimuth) sample intersects its outward ray
  // with the exact ring triangles; no nearest-point snap can jump across a fold.
  // The contact edge is embedded 40 cm along the same outward ray. This closes
  // chord gaps over the triangulated wall's inward facet valleys (the raw 16
  // point edge leaves up to 17 cm exposed on the three review seeds).
  // Every final point fits inside the first Core capsule's endpoint sphere.
  // If the real wall's facets need more depth than the authored nominal radius,
  // grow that authoritative capsule rather than shrinking the visible contact
  // to a peg. The room-wide protected annulus caps that growth.
  for (const p of pieces) {
    if (p.role !== 'hero-claw' || p.node !== 0) continue;
    if (reusedRootGids.has(p.gid)) continue;
    const querySink = rootQuerySink(rootFootprintQueries, p.gid);
    const h = p.length / 2, lh = p.localLength / 2;
    const base = { x: p.cx - p.dx * h, y: p.cy - p.dy * h, z: p.cz - p.dz * h };
    const localBase = { x: p.local.cx - p.local.dx * lh,
      y: p.local.cy - p.local.dy * lh, z: p.local.cz - p.local.dz * lh };
    const azimuth = Math.atan2(localBase.y, localBase.x);
    const wallRadius = p.wallRadiusBase;
    const wallInset = 0.40;
    const routeRadiusRoom = (point) => {
      const frame = routeFrameAt(point.z);
      const dx = point.x - frame.center.x, dy = point.y - frame.center.y,
        dz = point.z - frame.center.z;
      const x = dx * frame.right.x + dy * frame.right.y + dz * frame.right.z;
      const y = dx * frame.up.x + dy * frame.up.y + dz * frame.up.z;
      return Math.hypot(x, y) - inner - 0.05;
    };
    const tip = { x: p.cx + p.dx * h, y: p.cy + p.dy * h, z: p.cz + p.dz * h };
    const maxSafeRadius = Math.min(routeRadiusRoom(base),
      routeRadiusRoom({ x: p.cx, y: p.cy, z: p.cz }), routeRadiusRoom(tip));
    for (const footprintScale of [0.70, 0.62, 0.54, 0.46, 0.38]) {
      const reach = p.radius * footprintScale;
      const points = [];
      const surfacePoints = [];
      let valid = true;
      for (let j = 0; j < 16; j++) {
        const a = j * Math.PI / 8;
        const sampleAzimuth = azimuth + reach * Math.cos(a) / wallRadius;
        const sampleDepth = zT + localBase.z - reach * Math.sin(a);
        const frame = routeFrameAt(sampleDepth);
        const surfacePoint = wallPointOnLiveTriangles(wallSurface, seed, sampleDepth, sampleAzimuth,
          querySink, frame);
        if (!surfacePoint) { valid = false; break; }
        const point = {
          x: surfacePoint.x + wallInset * (frame.right.x * Math.cos(sampleAzimuth)
            + frame.up.x * Math.sin(sampleAzimuth)),
          y: surfacePoint.y + wallInset * (frame.right.y * Math.cos(sampleAzimuth)
            + frame.up.y * Math.sin(sampleAzimuth)),
          z: surfacePoint.z + wallInset * (frame.right.z * Math.cos(sampleAzimuth)
            + frame.up.z * Math.sin(sampleAzimuth)),
        };
        surfacePoints.push(surfacePoint);
        points.push(point);
      }
      if (!valid) continue;
      const requiredRadius = Math.max(p.radius,
        ...points.map((point) => Math.hypot(point.x - base.x,
          point.y - base.y, point.z - base.z) / 0.985));
      if (requiredRadius > maxSafeRadius) continue;
      p.wallBodyRadius = p.radius;
      p.radius = requiredRadius;
      p.wallFootprint = points;
      p.wallFootprintSurface = surfacePoints;
      p.wallFootprintInset = wallInset;
      p.wallFootprintScale = footprintScale;
      break;
    }
  }

  if (pieces.length > LANDMARK_MAX_PIECES) pieces.length = LANDMARK_MAX_PIECES;
  if (pieces.length === 0) return null;

  // Deterministic per-piece shade in [0,1) — the renderer maps it to a small set
  // of mineral material variants so the formation isn't one uniform tone. Derived
  // from (seed, k, index) so it is stable and independent of build order.
  for (let i = 0; i < pieces.length; i++) {
    if (!reusedRootGids.has(pieces[i].gid)) {
      const shadeKey = type === BRANCHING ? pieces[i].treeIndex : i;
      pieces[i].shade = (hash2(seed | 0, (k | 0) * 101 + shadeKey) % 1024) / 1024;
    }
    if (pieces[i].shape === 'blade') {
      const piece = pieces[i], half = piece.localLength / 2;
      const azimuth = Math.atan2(piece.local.cy - piece.local.dy * half,
        piece.local.cx - piece.local.dx * half);
      const localFrame = routeFrameAt(zT + piece.local.cz);
      // A plate's width follows the wall circumference. A fixed world-axis
      // helper made identical authored rolls edge-on at different azimuths.
      Object.defineProperty(piece, 'slabAcross', { enumerable: false, value: {
        x: -Math.sin(azimuth) * localFrame.right.x + Math.cos(azimuth) * localFrame.up.x,
        y: -Math.sin(azimuth) * localFrame.right.y + Math.cos(azimuth) * localFrame.up.y,
        z: -Math.sin(azimuth) * localFrame.right.z + Math.cos(azimuth) * localFrame.up.z,
      } });
      Object.defineProperty(piece, 'slabHull', {
        value: slabHullForPiece(piece), enumerable: false,
      });
    }
  }

  // A selector change can still evaluate to identical geometry (for example
  // a footprint attempt which remains outside every new ring pair). Preserve
  // the identity of those pieces/surfaces too, so the renderer can skip their
  // fixed mesh ranges without weakening the fresh-composition contract.
  for (const [gid, form] of rootForms) {
    if (reusedRootGids.has(gid)) continue;
    if (form[0].parentGid && !reusedRootGids.has(form[0].parentGid)) continue;
    const old = oldRootForms instanceof Map ? oldRootForms.get(gid) : null;
    if (!old || !sameRootValue(form, old.pieces)) continue;
    for (let i = 0; i < form.length; i++) {
      pieces[pieceSlots.get(form[i])] = old.pieces[i];
      form[i] = old.pieces[i];
    }
    reusedRootGids.add(gid);
  }

  for (const [gid, form] of rootForms) {
    if (!form[0].parentGid || reusedRootGids.has(gid)) continue;
    rootFootprintQueries.set(gid, rootFootprintQueries.get(form[0].parentGid) || []);
  }
  const collisionPieces = collisionCapsulesFor(pieces);

  const allRootQueries = [];
  for (const gid of rootForms.keys()) allRootQueries.push(...(rootNodeQueries.get(gid) || []));
  for (const p of pieces) if (p.role === 'hero-claw' && p.node === 0) {
    allRootQueries.push(...(rootFootprintQueries.get(p.gid) || []));
  }
  const rootWallQueries = rootForms.size > 0 && Number.isInteger(cave.generation)
    ? Object.freeze(allRootQueries) : null;
  const uniqueBladeQueries = bladeWallQueries
    ? Object.freeze(bladeWallQueries.map((query) => Object.freeze({
      ...query, selection: rootQuerySelection(wallSurface, query),
    }))) : null;
  if (!rootWallQueries) surfaceRevision = uniqueBladeQueries
    ? bladeCompositionRevision(wallSurface, k, uniqueBladeQueries)
    : compositionSurfaceRevision(wallSurface, k, idx);

  const composition = {
    k, type, typeName: LANDMARK_TYPES[type], z: zT,
    cx, cy, clearance, inner, outer, wall: clearance, frame, surfaceRevision,
    pieces, collisionPieces,
  };
  if (rootWallQueries) Object.defineProperty(composition, 'rootWallQueries', {
    value: rootWallQueries, enumerable: false,
  });
  if (uniqueBladeQueries) Object.defineProperty(composition, 'bladeWallQueries', {
    value: uniqueBladeQueries, enumerable: false,
  });
  if (rootForms.size > 0) {
    const surfaces = [...rootForms].map(([gid, form]) =>
      reusedRootGids.has(gid) && oldRootForms?.get(gid)?.surface
        ? oldRootForms.get(gid).surface : buildRootSurface(composition, form));
    Object.defineProperty(composition, 'rootSurfaces', {
      value: surfaces, enumerable: false,
    });
    if (rootWallQueries) {
      const dependencies = new Map();
      let index = 0;
      for (const [gid, form] of rootForms) {
        const old = oldRootForms?.get(gid);
        const surface = surfaces[index++];
        const nodeQueries = rootNodeQueries.get(gid) || [];
        const footprintQueries = rootFootprintQueries.get(gid) || [];
        if (old && old.surface === surface && old.nodeQueries === nodeQueries
            && old.footprintQueries === footprintQueries) {
          dependencies.set(gid, old);
          continue;
        }
        const queries = uniqueRootQueries([...nodeQueries, ...footprintQueries]);
        dependencies.set(gid, Object.freeze({
          pieces: Object.freeze([...form]), surface,
          nodeQueries: Object.freeze([...nodeQueries]),
          footprintQueries: Object.freeze([...footprintQueries]), queries,
          selection: rootQueryRevision(wallSurface, queries),
        }));
      }
      composition.surfaceRevision = rootCompositionRevision(wallSurface, k, dependencies);
      for (const [name, value] of [
        ['rootFormDependencies', dependencies], ['rootCave', cave],
        ['rootGeneration', cave.generation], ['rootSeed', seed | 0],
        ['rootRouteFrames', rootRouteFrames],
      ]) Object.defineProperty(composition, name, { value, enumerable: false });
    }
  }
  if (retainAuthoring) compositionAuthoring.set(composition, Object.freeze({
    cave, generation: cave.generation, seed, k, zT, frame, type,
    inner, outer, clearance, template,
  }));
  return composition;
}

// All landmark compositions currently in view. PURE: reads the cave + the seed
// only, and rebuilds every composition from scratch. Hot callers should go
// through core/LandmarkCache.js instead, which memoizes this per room.
export function landmarksInView(cave, playerZ, range, seed, behind, forcedType = null) {
  const out = [];
  const { kFrom, kTo } = visibleRoomRange(playerZ, range, behind);
  for (let k = kFrom; k <= kTo; k++) {
    const c = compositionAt(seed | 0, cave, k, forcedType);
    if (c) out.push(c);
  }
  return out;
}

// ---- reductions over an already-gathered composition list -------------------
// Split out from the whole-cave helpers below so a caller (the cached path, the
// debug overlay, the capture harness) can gather the list ONCE and then ask it
// several questions, instead of re-scanning the cave per question.

// Forward distance (z − playerZ) of the nearest composition in the list, or null.
export function nearestCompositionDistance(comps, playerZ) {
  let best = null;
  for (const c of comps) {
    const d = c.z - playerZ;
    if (best === null || Math.abs(d) < Math.abs(best)) best = d;
  }
  return best;
}

// Total piece count across a composition list (debug / pool sizing).
export function totalPieceCount(comps) {
  let n = 0;
  for (const c of comps) n += c.pieces.length;
  return n;
}

// The nearest in-view landmark's forward distance (z − playerZ), or null.
export function nearestLandmarkDistance(cave, playerZ, range, seed) {
  return nearestCompositionDistance(landmarksInView(cave, playerZ, range, seed), playerZ);
}

// Total piece count across all in-view compositions (debug / pool sizing).
export function landmarkPieceCount(cave, playerZ, range, seed) {
  return totalPieceCount(landmarksInView(cave, playerZ, range, seed));
}
