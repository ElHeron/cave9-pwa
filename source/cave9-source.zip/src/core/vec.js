// Minimal 3D vector helpers on plain `[x, y, z]` arrays.
// Mirrors the macros in the original `src/vec.h`.

export const v3 = (x = 0, y = 0, z = 0) => [x, y, z];
export const set = (o, x, y, z) => { o[0] = x; o[1] = y; o[2] = z; return o; };
export const copy = (o, a) => { o[0] = a[0]; o[1] = a[1]; o[2] = a[2]; return o; };
export const add = (o, a) => { o[0] += a[0]; o[1] += a[1]; o[2] += a[2]; return o; };
export const sub2 = (o, a, b) => { o[0] = a[0] - b[0]; o[1] = a[1] - b[1]; o[2] = a[2] - b[2]; return o; };
export const addScale = (o, a, s) => { o[0] += a[0] * s; o[1] += a[1] * s; o[2] += a[2] * s; return o; };
export const len = (a) => Math.hypot(a[0], a[1], a[2]);
export const norm = (a) => { const l = len(a) || 1; a[0] /= l; a[1] /= l; a[2] /= l; return a; };
export const scaleDiv = (o, s) => { o[0] /= s; o[1] /= s; o[2] /= s; return o; };

export const clamp = (x, lo, hi) => Math.max(lo, Math.min(hi, x));
