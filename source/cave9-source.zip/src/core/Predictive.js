// Read-only look-ahead warning over the exact same SurfaceQuery as collision.

import { SHIP_RADIUS } from './constants.js';
import { queryNearestSurface } from './SurfaceQuery.js';

export const T_LEAD = 0.20;

export function warnFromMin(min, radius) {
  if (!(min < Number.MAX_VALUE)) return 0;
  const clearance = min - radius;
  if (clearance <= 0) return 1;
  return 1 - Math.min(1, clearance / (2 * SHIP_RADIUS));
}

export function predictiveWarn(cave, ship, tLead = T_LEAD, compositions = []) {
  const none = { warn: 0, leadDist: 0, leftClear: Number.MAX_VALUE, rightClear: Number.MAX_VALUE };
  const point = [
    ship.pos[0] + ship.vel[0] * tLead,
    ship.pos[1] + ship.vel[1] * tLead,
    ship.pos[2] + ship.vel[2] * tLead,
  ];
  if (!point.every(Number.isFinite)) return none;
  const query = queryNearestSurface(cave, point, ship.radius, compositions);
  return {
    warn: warnFromMin(query.nearest?.surfaceDistance ?? Number.MAX_VALUE, ship.radius),
    leadDist: point[2] - ship.pos[2],
    leftClear: query.leftClear,
    rightClear: query.rightClear,
  };
}

export function finalWarn(reactive, predictive) {
  return Math.max(reactive || 0, predictive || 0);
}
