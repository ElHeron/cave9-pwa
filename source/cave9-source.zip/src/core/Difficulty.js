// Difficulty — the single source of truth for live speed, sight, score and
// visual morphing. Boolean-tube radius belongs to FlightPath, not this profile.
// The live dimensions are:
//   - speed:   the player flies a little faster the deeper they get,
//   - sight:   fog/draw distance grows WITH speed so the time-to-react
//              (reaction window) never collapses — this is the fairness lever,
//   - score:   points-per-metre ramp up with depth to reward going deep.
//
// All functions here are PURE functions of `depth` (metres travelled,
// pos.z - start). They are unit-tested for monotonicity / bounds in
// test/difficulty.test.js and documented with concrete numbers in BALANCE.md.

import { VELOCITY, FOG_END } from './constants.js';
import { clamp } from './vec.js';

// ---- tuning constants (see BALANCE.md for the rationale) -------------------

// Forward-speed staircase: eight 1 km stages carry the run from 1.0× to
// SPEED_FLOOR_MUL. Each stage is an exact 850 m plateau followed by one 150 m
// LINEAR ramp into the next plateau. Linear is intentional: no sine/smoothstep
// easing means no hidden acceleration/deceleration wave inside the ramp.
export const SPEED_FLOOR_MUL = 1.35;
export const SPEED_RAMP_DEPTH = 8000;
export const SPEED_RAMP_STEPS = 8;
export const SPEED_RAMP_STEP_LEN = SPEED_RAMP_DEPTH / SPEED_RAMP_STEPS;
export const SPEED_PLATEAU_FRAC = 0.85;

// Sight (fog far-plane) ramp: grows from 1.0× toward SIGHT_FLOOR_MUL across the
// same depth so that, as speed rises, the player still sees far enough ahead.
// This is what guarantees a non-shrinking reaction window (fairness).
export const SIGHT_FLOOR_MUL = 1.30;

// Once the tube reaches its minimum at 9 km, difficulty climbs forever in
// 1.2 km stages: 1,020 m plateau, then one 180 m linear ramp. There is no cap.
export const SPEED_STEP_START = 9000;
export const SPEED_STEP_LEN = 1200;
export const SPEED_STEP_GAIN = 0.17;
// Reference point, not a ceiling: the fifth completed step reaches 2.2× at
// 15 km. Later steps continue with the same gain.
export const SPEED_REFERENCE_DEPTH = 15000;
export const SPEED_REFERENCE_MUL = 2.2;

// Score ramp: points-per-metre grow from 1.0× to SCORE_MAX_MUL with depth, so
// the deep, tight cave is worth chasing. Distance remains raw metres; only the
// score is multiplied.
export const SCORE_MAX_MUL = 2.5;
export const SCORE_RAMP_DEPTH = 10000;

// Look morph (see styleAt). Starts past the first rooms so a player meets the
// original look first, and completes well inside a good run's reach.
export const STYLE_START = 2500;
export const STYLE_FULL = 9000;

// Named difficulty tiers, purely for diagnostics/reporting. Boundaries in
// metres. The simulation itself reads the continuous curves, not the tier.
export const TIERS = [
  { name: 'CRUISE', from: 0 },
  { name: 'DESCENT', from: 1500 },
  { name: 'TIGHT', from: 4000 },
  { name: 'DEEP', from: 8000 },
  { name: 'ABYSS', from: 14000 },
];

// ---- curve primitives -----------------------------------------------------

// speedMul: the sole authoritative forward-speed profile. It alternates flat
// plateaus and monotone linear ramps; it never eases, falls, or oscillates.
function plateauRamp(distance, stageLength, base, gain) {
  const progress = distance / stageLength;
  const completed = Math.floor(progress);
  const local = progress - completed;
  const ramp = clamp((local - SPEED_PLATEAU_FRAC) / (1 - SPEED_PLATEAU_FRAC), 0, 1);
  return base + gain * (completed + ramp);
}

export function speedMul(depth) {
  const d = Math.max(0, Number.isFinite(depth) ? depth : 0);
  if (d < SPEED_RAMP_DEPTH) {
    return plateauRamp(d, SPEED_RAMP_STEP_LEN, 1,
      (SPEED_FLOOR_MUL - 1) / SPEED_RAMP_STEPS);
  }
  if (d < SPEED_STEP_START) return SPEED_FLOOR_MUL;
  return plateauRamp(d - SPEED_STEP_START, SPEED_STEP_LEN,
    SPEED_FLOOR_MUL, SPEED_STEP_GAIN);
}

// Absolute forward speed shared by simulation, tooling and diagnostics. Keeping
// the base-velocity multiplication here prevents secondary implementations of
// the live speed contract from drifting away from speedMul().
export function forwardSpeedAt(depth) {
  return VELOCITY * speedMul(depth);
}

// sightMul follows speed in lock-step after the floor, preserving reaction
// time while both values continue upward without a ceiling.
export function sightMul(depth) {
  const d = Math.max(0, Number.isFinite(depth) ? depth : 0);
  if (d <= SPEED_STEP_START) {
    const t = (speedMul(d) - 1) / (SPEED_FLOOR_MUL - 1);
    return 1 + (SIGHT_FLOOR_MUL - 1) * t;
  }
  return SIGHT_FLOOR_MUL * speedMul(d) / SPEED_FLOOR_MUL;
}

// styleAt: how far the LOOK has travelled from the original cave9 toward the
// reference art direction (0 → 1). See LANDMARK_STRATEGY.md.
//
// The reference frames are not meant to replace cave9's look — the original is
// crude, fast and minimal, and that austerity is the game's identity in the first
// minutes. Instead the distance between the two is a function of depth: the
// player flies out of the original game and into the reference world, and the
// transformation is itself the progression.
//
// One scalar, deliberately, because everything downstream derives from it — room
// haze, formation density and scale, crag, embers. That is what makes the whole
// morph assertable: capture a depth ladder and check the descriptors move
// monotonically, exactly as sightMul is checked today.
//
// STYLE_START is past the first rooms on purpose. Rooms exist from 2000 m, so
// the first ones a player meets are still nearly the original look and the
// change is something they fly into rather than something switched on.
export function styleAt(depth) {
  const t = clamp((depth - STYLE_START) / (STYLE_FULL - STYLE_START), 0, 1);
  // smoothstep: no visible seam where the ramp begins or ends
  return t * t * (3 - 2 * t);
}

// scoreMul: points-per-metre multiplier, 1.0 → SCORE_MAX_MUL.
export function scoreMul(depth) {
  const t = clamp(depth / SCORE_RAMP_DEPTH, 0, 1);
  return 1 + (SCORE_MAX_MUL - 1) * t;
}

// reactionWindow: the headline FAIRNESS metric — roughly how many seconds of
// tunnel the player can see ahead at the current speed. = sightDistance/speed.
// Because sight and speed ramp together, this stays within a tight band; the
// seed regression tests assert it never drops below a floor.
export function reactionWindow(depth) {
  const sight = FOG_END * sightMul(depth);
  const speed = forwardSpeedAt(depth);
  return sight / speed;
}

export function tierAt(depth) {
  let t = TIERS[0];
  for (const tier of TIERS) if (depth >= tier.from) t = tier;
  return t.name;
}

// difficultyAt: bundle every live parameter for a given depth. Used by the
// game loop, the debug overlay and the reports so they all agree.
export function difficultyAt(depth) {
  const d = Math.max(0, depth);
  return {
    depth: d,
    tier: tierAt(d),
    speedMul: speedMul(d),
    sightMul: sightMul(d),
    scoreMul: scoreMul(d),
    style: styleAt(d),
    speed: forwardSpeedAt(d),
    reactionWindow: reactionWindow(d),
  };
}
