// LandmarkCache — a memo over compositionAt().
//
// Building a composition is not cheap: 50–120 safety-checked pieces grown from a
// mulberry32 stream (~0.09 ms). It is also a PURE function of (seed, room index,
// the live cave rings across the formation's complete axial span), and each ring
// sits unchanged until its circular-buffer slot is recycled.
// So the uncached API rebuilds the identical formation on every call — and there
// are several callers per frame (the renderer, the debug overlay, the capture
// harness), each independently rebuilding what the others just built.
//
// The cache keys on (seed, room) and validates against a surface revision made
// from every relevant live ring. This matters while the far half of a long room
// is still being generated: a centre-only key would preserve fallback wall
// radii and make render/collision disagree with a pure rebuild. The cave object
// itself is part of the check too, because the app runs two games at once (the
// player's run and the menu demo) and they must never share an entry.
//
// This is a pure performance layer: `compositionAt` here returns exactly what
// core/Landmarks.js returns, which is asserted in test/landmark-cache.test.js.

import {
  compositionAt as computeComposition,
  compositionSurfaceRevision,
  compositionDependencyRevision,
  visibleRoomRange,
  nearestCompositionDistance,
  totalPieceCount,
} from './Landmarks.js';
import { CaveStream } from './CaveStream.js';

// Rooms in view at once is 0–1, so this only has to absorb a little churn:
// crossing a room boundary, the two live games, and the capture harness jumping
// between seeds. Small enough that eviction never costs anything real.
export const DEFAULT_MAX_ROOMS = 6;

// CaveStream only changes a live ring when it emits one; resize only reorders
// slots, and reset advances generation. Within this exact emission state, even
// the dependency selector check can be reused by the several callers in one
// frame. External/synthetic caves keep the normal revision path.
function ringEmissionState(cave) {
  if (!(cave instanceof CaveStream) || !Number.isInteger(cave.generation)
      || !Number.isInteger(cave.count)
      || !Number.isInteger(cave.i) || !Number.isFinite(cave._lastRingDepth)) return null;
  return [cave.generation, cave.count, cave.i, cave.centers.length, cave._lastRingDepth];
}

function sameRingEmissionState(a, b) {
  return a && b && a.length === b.length && a.every((value, index) => value === b[index]);
}

export class LandmarkCache {
  constructor(maxRooms = DEFAULT_MAX_ROOMS) {
    this.maxRooms = maxRooms;
    this._entries = new Map(); // `${seed}:${k}:${variant}` → { cave, surfaceRevision, comp, seen }
    this._clock = 0;
    this.hits = 0;
    this.misses = 0;
    this.evictions = 0;
  }

  get size() { return this._entries.size; }

  resourceMetrics() {
    return Object.freeze({
      rooms: this.size,
      maxRooms: this.maxRooms,
      hits: this.hits,
      misses: this.misses,
      evictions: this.evictions,
    });
  }

  clear() {
    this._entries.clear();
    this.hits = this.misses = this.evictions = 0;
  }

  // Memoized compositionAt. Identical result to the pure function.
  compositionAt(seed, cave, k, forcedType = null) {
    // The live cave override participates in the pure function when no
    // explicit type is supplied. A reused cave may change this on reset.
    const variant = forcedType == null
      ? `cave:${String(cave.landmarkFamilyOverride ?? 'auto')}`
      : `forced:${String(forcedType)}`;
    const key = `${seed | 0}:${k | 0}:${variant}`;
    const hit = this._entries.get(key);
    const ringState = ringEmissionState(cave);
    const sameEmission = hit && hit.cave === cave
      && sameRingEmissionState(hit.ringState, ringState);
    const hitRevision = hit && hit.cave === cave && !sameEmission
      ? compositionDependencyRevision(cave, k, hit.comp) : null;
    if (hit && hit.cave === cave
        && (sameEmission || hitRevision !== null && hit.surfaceRevision === hitRevision)) {
      this.hits++;
      hit.seen = ++this._clock;
      hit.ringState = ringState;
      return hit.comp;
    }

    // null is cached too: "this room is carved but too tight for a formation" is
    // a real answer that cost a full ring-clearance pass to reach.
    const comp = computeComposition(seed, cave, k, forcedType,
      hit?.cave === cave ? hit.comp : null);
    const surfaceRevision = comp?.surfaceRevision ?? compositionSurfaceRevision(cave, k);
    // A room without a live centre ring is not a cacheable miss.
    if (surfaceRevision === null) return null;
    this.misses++;
    this._entries.set(key, {
      cave, surfaceRevision,
      comp, seen: ++this._clock, ringState,
    });
    this._evict();
    return comp;
  }

  _evict() {
    if (this._entries.size <= this.maxRooms) return;
    let oldestKey = null, oldestSeen = Infinity;
    for (const [key, e] of this._entries) {
      if (e.seen < oldestSeen) { oldestSeen = e.seen; oldestKey = key; }
    }
    if (oldestKey !== null && this._entries.delete(oldestKey)) this.evictions++;
  }

  // ---- cached mirrors of the pure Landmarks API ---------------------------
  // Same signatures, same results — only the rebuilding is skipped.

  landmarksInView(cave, playerZ, range, seed, behind, forcedType = null) {
    const out = [];
    const { kFrom, kTo } = visibleRoomRange(playerZ, range, behind);
    for (let k = kFrom; k <= kTo; k++) {
      const c = this.compositionAt(seed | 0, cave, k, forcedType);
      if (c) out.push(c);
    }
    return out;
  }

  nearestLandmarkDistance(cave, playerZ, range, seed) {
    return nearestCompositionDistance(this.landmarksInView(cave, playerZ, range, seed), playerZ);
  }

  landmarkPieceCount(cave, playerZ, range, seed) {
    return totalPieceCount(this.landmarksInView(cave, playerZ, range, seed));
  }
}
