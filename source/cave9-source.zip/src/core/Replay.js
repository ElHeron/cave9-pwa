// Replay — deterministic input-replay harness (Phase 4B, gate P1).
//
// A replay is a seed + control mode + a frame-by-frame track of thruster inputs.
// Running it drives the REAL simulation: each frame sets `player.lefton/righton`
// and calls `Game.step()` — exactly the path `main.js._stepRun()` uses for live
// play. Nothing is injected into the score or state; the end values are whatever
// the physics/collision/scoring produce. The same seed + same track therefore
// must yield byte-identical end values, which is the determinism proof this gate
// exists to provide.
//
// This module is pure core (no DOM/THREE), so it is unit-tested headlessly and
// reused by scripts/replay-test.mjs and scripts/make-replays.mjs.

import { Game } from './Game.js';
import { TWO_BUTTONS } from './constants.js';

// Thruster state packs into a 2-bit mask so a track is compact and JSON-stable.
export const L_BIT = 1; // left thruster
export const R_BIT = 2; // right thruster

export function encodeMask(left, right) {
  return (left ? L_BIT : 0) | (right ? R_BIT : 0);
}
export function maskLeft(mask) { return (mask & L_BIT) !== 0; }
export function maskRight(mask) { return (mask & R_BIT) !== 0; }

// Run-length encode a flat array of masks into [mask, count] pairs (keeps the
// committed fixtures small and human-diffable).
export function rleEncode(masks) {
  const out = [];
  for (const m of masks) {
    const last = out[out.length - 1];
    if (last && last[0] === m) last[1]++;
    else out.push([m, 1]);
  }
  return out;
}

// Expand [mask, count] pairs back into a flat per-frame mask array.
export function rleDecode(track) {
  const out = [];
  for (const [m, n] of track) for (let i = 0; i < n; i++) out.push(m);
  return out;
}

// The canonical end-state of a run — every field the P1 gate asserts on.
// Rounding is applied so the comparison is exact and JSON-stable across
// platforms (doubles are deterministic here, but this removes any printf risk).
export function summarize(game) {
  const p = game.player;
  const s = game.score;
  const r = (x, n = 6) => Number.isFinite(x) ? +x.toFixed(n) : null;
  return {
    seed: game.seed,
    mode: game.mode,
    alive: game.phase === 'running',
    crashed: game.phase === 'dead',
    pos: [r(p.pos[0]), r(p.pos[1]), r(p.pos[2])],
    distance: r(s.distance),
    score: game.scoreValue(),          // integer
    grazeTime: r(s.grazeTime),
    bestCombo: s.bestCombo,            // integer level 0..COMBO_MAX
    closest: s.closest === Number.MAX_VALUE ? null : r(s.closest),
    maxSpeed: r(s.maxSpeed),
  };
}

export const REPLAY_CHECKPOINT_INTERVAL = 300;

// Mid-run state checksum. End-state equality alone can miss a divergence that
// later cancels out; periodic hashes localise the first drift to a short step
// interval. Values are canonicalised before the small FNV-1a fold so fixtures
// remain plain JSON and the same function runs in browsers and Node.
export function replayStateChecksum(game) {
  const finite = (value) => Number.isFinite(value) ? Number(value).toFixed(9) : String(value);
  const p = game.player, s = game.score, c = game.cave;
  const fields = [
    game.phase, finite(game.time), c.i, c.count, finite(c.cursorDepth), c.rng.randval,
    ...p.pos.map(finite), ...p.vel.map(finite), ...p.lookAt.map(finite), finite(p.roll),
    finite(p.dist), p.lefton ? 1 : 0, p.righton ? 1 : 0,
    finite(s.distance), finite(s.scored), finite(s.grazeBonus), finite(s.grazeTime),
    s.combo, s.bestCombo, finite(s.closest), finite(s.maxDanger), finite(s.maxSpeed),
  ];
  const text = fields.join('|');
  let hash = 2166136261 >>> 0;
  for (let i = 0; i < text.length; i++) hash = Math.imul(hash ^ text.charCodeAt(i), 16777619) >>> 0;
  return hash.toString(16).padStart(8, '0');
}

function appendCheckpoint(checkpoints, step, game) {
  if (checkpoints.at(-1)?.step === step) return;
  checkpoints.push({ step, checksum: replayStateChecksum(game) });
}

// Run a replay through the real Game.step path. `frames` is either a flat mask
// array or an RLE track ([mask,count] pairs) — auto-detected. Stops on the frame
// the player crashes or when the track is exhausted. Returns { result, steps }.
export function runReplay(replay) {
  const { seed, mode = TWO_BUTTONS } = replay;
  const masks = Array.isArray(replay.frames) && Array.isArray(replay.frames[0])
    ? rleDecode(replay.frames)
    : (replay.frames || []);

  const game = new Game();
  game.start({ mode, seed });

  let steps = 0;
  const checkpointInterval = replay.checkpointInterval || REPLAY_CHECKPOINT_INTERVAL;
  const checkpoints = [];
  for (let f = 0; f < masks.length; f++) {
    const m = masks[f];
    // EXACT live-play path: set thruster flags, then advance one fixed step.
    game.player.lefton = maskLeft(m);
    game.player.righton = maskRight(m);
    steps = f + 1;
    const crashed = game.step();
    if (steps % checkpointInterval === 0) appendCheckpoint(checkpoints, steps, game);
    if (crashed) break; // crashed this frame
  }
  appendCheckpoint(checkpoints, steps, game);

  return { result: summarize(game), steps, checkpoints };
}

// Record a replay by running a controller against the real sim and capturing the
// exact per-frame thruster flags it produced. The controller is a function
// (game) => void that sets player.lefton/righton (the built-in autopilot is the
// default). The recorded track, replayed through runReplay(), reproduces the
// identical end state — that round-trip is the recorder's correctness contract.
export function recordReplay({ seed, mode = TWO_BUTTONS, maxSteps = 4000, controller } = {}) {
  const drive = controller || ((g) => g.autopilot());
  const game = new Game();
  game.start({ mode, seed });

  const masks = [];
  const checkpoints = [];
  let crashed = false;
  for (let i = 0; i < maxSteps; i++) {
    drive(game);
    masks.push(encodeMask(game.player.lefton, game.player.righton));
    if (game.step()) { crashed = true; }
    if (masks.length % REPLAY_CHECKPOINT_INTERVAL === 0) {
      appendCheckpoint(checkpoints, masks.length, game);
    }
    if (crashed) break;
  }

  appendCheckpoint(checkpoints, masks.length, game);

  const replay = { seed, mode, checkpointInterval: REPLAY_CHECKPOINT_INTERVAL, frames: rleEncode(masks) };
  return { replay, masks, result: summarize(game), checkpoints, crashed, steps: masks.length };
}
