// Score system.
//
// The original cave9 scored purely on depth (`game_score` = pos.z). We keep
// distance (raw metres) as the backbone but reward the things that make a run
// risky and deep:
//   - depth, multiplied by a depth-based score curve (see Difficulty.js) so
//     the tight, dangerous deep cave is worth more per metre,
//   - GRAZE: skimming close to the walls without crashing (risk/reward),
//   - COMBO: sustained, controlled wall proximity multiplies the graze reward,
//     capped, and reset by reaching safe distance, crashing or an interruption.
//
// `distance` is always raw metres travelled (what the HUD/death screen show).
// The one-button (easier) mode and the depth multiplier only affect `scored`,
// the points contribution — never the displayed distance. Graze/combo only add
// to `grazeBonus`. See SCORING_REPORT.md for the full model + exploit analysis.

import { SHIP_RADIUS, ONE_BUTTON, VELOCITY } from './constants.js';
import { scoreMul } from './Difficulty.js';

// ---- graze / combo tuning (documented in SCORING_REPORT.md) ----------------

// A graze counts only with POSITIVE clearance inside this band (metres of
// surface clearance, i.e. ship.dist). Tighter than the proximity-warning band
// (2·SHIP_RADIUS) so a graze is genuinely risky, not just "near a wall".
export const GRAZE_BAND = 1.5 * SHIP_RADIUS;

// Base graze points per second at the wall (closeness = 1), before the combo
// multiplier and the forward-speed factor. Capped so it can never explode.
export const GRAZE_MAX_RATE = 50;

// Combo: every COMBO_STEP_TIME seconds of *cumulative* grazing raises the combo
// one level, up to COMBO_MAX. The multiplier is 1 + level·COMBO_MULT_PER, hard
// capped at COMBO_MULT_MAX. Reaching safe distance (or stalling) for longer than
// COMBO_GRACE resets the combo; a crash or interruption resets it immediately.
export const COMBO_STEP_TIME = 0.5;
export const COMBO_MAX = 4;
export const COMBO_MULT_PER = 0.5;
export const COMBO_MULT_MAX = 1 + COMBO_MAX * COMBO_MULT_PER; // 3.0×
export const COMBO_GRACE = 0.3;

export class ScoreSystem {
  constructor() {
    this.reset();
  }

  reset() {
    this.distance = 0;     // raw metres travelled (HUD DIST)
    this.scored = 0;       // depth points (distance × mode × depth-multiplier)
    this.time = 0;

    // graze / combo
    this.grazeBonus = 0;       // accumulated graze+combo points
    this.grazeActive = false;  // grazing this frame?
    this.grazeTime = 0;        // total seconds spent grazing
    this.combo = 0;            // current combo level (0..COMBO_MAX)
    this.comboMultiplier = 1;  // derived from combo (1..COMBO_MULT_MAX)
    this.bestCombo = 0;        // peak combo level this run

    // run telemetry (for the run summary + dev overlay)
    this.closest = Number.MAX_VALUE; // closest POSITIVE clearance (metres)
    this.maxDanger = 0;        // peak proximity 0..1
    this.maxSpeed = 0;         // peak speed (units/s)
    this.warnLevel = 0;        // 0..1 proximity for HUD/audio

    this._prevDepth = 0;
    this._comboGrazeTime = 0;  // cumulative graze toward the next combo level
    this._safeTime = 0;        // seconds since the last graze frame
  }

  // Called every physics step. Uses ship.dist (surface clearance; 0 == hit).
  update(ship, dt, gameMode) {
    this.time += dt;
    const depth = Math.max(0, ship.pos[2] - ship.start);

    // integrate distance score over the metres gained this step, scaled by the
    // depth multiplier (and halved in the easier one-button mode)
    const delta = Math.max(0, depth - this._prevDepth);
    const modeFactor = gameMode === ONE_BUTTON ? 0.5 : 1;
    this.scored += delta * scoreMul(depth) * modeFactor;
    this._prevDepth = depth;
    this.distance = depth;

    // Graze scaling and run telemetry mean forward flight speed. Using the full
    // vector length here made ordinary x/y steering look like speed waves.
    const sp = ship.forwardSpeed();
    if (sp > this.maxSpeed) this.maxSpeed = sp;

    const clearance = ship.dist; // surface clearance; exactly 0 means a hit
    const positive = clearance > 0 && clearance < Number.MAX_VALUE;

    // proximity warning (kept on the original 2·SHIP_RADIUS band so the HUD /
    // audio thresholds are unchanged)
    if (positive) {
      this.warnLevel = 1 - Math.min(1, clearance / (2 * SHIP_RADIUS));
      if (clearance < this.closest) this.closest = clearance;
      if (this.warnLevel > this.maxDanger) this.maxDanger = this.warnLevel;
    } else {
      this.warnLevel = 0;
    }

    // GRAZE: positive clearance, inside the graze band, and actually advancing
    // (delta > 0) so it can never be farmed by stalling / pausing.
    const grazing = positive && clearance < GRAZE_BAND && delta > 0;
    this.grazeActive = grazing;

    if (grazing) {
      this._safeTime = 0;
      this.grazeTime += dt;

      // build combo: cumulative graze time → discrete levels (capped)
      this._comboGrazeTime += dt;
      while (this._comboGrazeTime >= COMBO_STEP_TIME && this.combo < COMBO_MAX) {
        this._comboGrazeTime -= COMBO_STEP_TIME;
        this.combo++;
      }
      this.comboMultiplier = Math.min(COMBO_MULT_MAX, 1 + this.combo * COMBO_MULT_PER);
      if (this.combo > this.bestCombo) this.bestCombo = this.combo;

      // reward: closer to the wall = more, with a hard rate cap; scaled by the
      // combo multiplier and a (clamped) forward-speed factor.
      const closeness = 1 - clearance / GRAZE_BAND;        // 0..1
      const speedFactor = Math.min(1.5, sp / VELOCITY);
      const rate = Math.min(GRAZE_MAX_RATE, GRAZE_MAX_RATE * closeness * closeness * speedFactor);
      this.grazeBonus += rate * this.comboMultiplier * dt;
    } else {
      // not grazing (safe distance, hit, or stalled): drop the combo after a
      // short grace so a single safe blip doesn't punish, but sustained safe
      // distance / a crash resets it.
      this._safeTime += dt;
      if (this._safeTime >= COMBO_GRACE) this._resetCombo();
    }
  }

  // Hard-reset the combo immediately. Called on pause / menu / any interruption
  // by the app so a combo can never survive across a break in the run.
  breakCombo() {
    this._resetCombo();
  }

  _resetCombo() {
    this.combo = 0;
    this.comboMultiplier = 1;
    this._comboGrazeTime = 0;
  }

  value() {
    return Math.floor(this.scored + this.grazeBonus);
  }
}
