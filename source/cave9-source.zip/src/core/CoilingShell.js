// Authoritative C3 coiling shell deformation.
//
// This module owns no geometry buffer.  It only supplies a deterministic,
// route-local radial inset to CaveStream while a coiling room is emitted.  The
// resulting 32-sector rings therefore remain the single surface consumed by
// rendering, wall collision, SurfaceQuery and the development atlas.

import {
  ROOM_LEN, ROOM_SPACING, ROOM_START, SECTOR_COUNT, SHIP_RADIUS,
} from './constants.js';
import {
  COILING, LANDMARK_TYPES, hash2, landmarkType, mulberry32,
} from './landmarks/rng.js';

const TAU = Math.PI * 2;
const CONTRACT_SALT = 0x43c30117;
const SECONDARY_RIDGE_SCALE = 0.45;

export const COILING_SHELL_VERSION = 'coiling-shell-v2';
export const COILING_TUBE_RESERVE = 0.5;
export const COILING_VISIBLE_RELIEF_STRENGTH = 4;
const COILING_MIN_RIDGE_STRENGTH = 7.6;
// Nominal relief only. A ridge may displace more of a wide chamber's locally
// available wall mass; rendering must clamp any accent normalized by this.
export const COILING_MAX_RIDGE_STRENGTH = 9.2;

const clamp = (value, lo, hi) => Math.max(lo, Math.min(hi, value));
const smoothstep = (value) => {
  const t = clamp(value, 0, 1);
  return t * t * (3 - 2 * t);
};

export function resolvedLandmarkType(seed, roomIndex, forcedType = null) {
  // `off` is an explicit diagnostic control, not an unknown family that may
  // silently fall back to the seed-selected production family. Keeping this
  // decision in the core resolver also prevents CaveStream from authoring a C3
  // shell before the visual layer gets a chance to hide landmark meshes.
  if (forcedType === 'off') return null;
  const forcedIndex = typeof forcedType === 'string' ? LANDMARK_TYPES.indexOf(forcedType) : forcedType;
  return Number.isInteger(forcedIndex) && forcedIndex >= 0 && forcedIndex < LANDMARK_TYPES.length
    ? forcedIndex : landmarkType(seed, roomIndex);
}

export function roomIndexAtDepth(depth) {
  if (!Number.isFinite(depth) || depth < ROOM_START) return null;
  const roomIndex = Math.floor(depth / ROOM_SPACING);
  const localDepth = depth - roomIndex * ROOM_SPACING;
  return localDepth >= 0 && localDepth <= ROOM_LEN ? roomIndex : null;
}

// One immutable parameter set per (seed, room). Ranges are part of the C3 v2
// contract and intentionally independent of CaveStream's mutable wall RNG.
export function coilingContractForRoom(seed, roomIndex, forcedType = null) {
  if (resolvedLandmarkType(seed, roomIndex, forcedType) !== COILING) return null;
  const rng = mulberry32(hash2(hash2(seed | 0, roomIndex | 0), CONTRACT_SALT));
  const span = 160 + rng() * 40;
  const turns = 1.1 + rng() * 0.4;
  const ridgeStrength = COILING_MIN_RIDGE_STRENGTH
    + rng() * (COILING_MAX_RIDGE_STRENGTH - COILING_MIN_RIDGE_STRENGTH);
  const channelCount = 1 + (rng() >= 0.5 ? 1 : 0);
  const handedness = rng() < 0.5 ? -1 : 1;
  const phase = rng() * TAU;
  const halfWidth = 0.68 + rng() * 0.16;
  const shoulderWidth = 1.50 + rng() * 0.20;
  const centre = roomIndex * ROOM_SPACING + ROOM_LEN / 2;
  return Object.freeze({
    version: COILING_SHELL_VERSION,
    seed: seed | 0,
    roomIndex,
    centre,
    start: centre - span / 2,
    end: centre + span / 2,
    span,
    turns,
    ridgeStrength,
    channelCount,
    secondaryScale: channelCount === 2 ? SECONDARY_RIDGE_SCALE : 0,
    handedness,
    phase,
    halfWidth,
    shoulderWidth,
  });
}

export function coilingContractAtDepth(seed, depth, forcedType = null) {
  const roomIndex = roomIndexAtDepth(depth);
  if (roomIndex === null) return null;
  const contract = coilingContractForRoom(seed, roomIndex, forcedType);
  return contract && depth >= contract.start && depth <= contract.end ? contract : null;
}

function angularWeight(angle, centre, halfWidth) {
  const gap = Math.abs(Math.atan2(Math.sin(angle - centre), Math.cos(angle - centre)));
  if (gap >= halfWidth) return 0;
  return smoothstep(1 - gap / halfWidth);
}

export function coilingAxialStrengthAtDepth(depth, contract) {
  if (!contract || !Number.isFinite(depth) || depth < contract.start || depth > contract.end) return 0;
  const t = (depth - contract.start) / contract.span;
  const edge = smoothstep(Math.min(t, 1 - t) / 0.045);
  // One sustained mass, faded into the surrounding wall at each end. Short
  // axial oscillations turned the travelling channel into repeated pinches.
  return edge * contract.ridgeStrength;
}

// Keep the real 32-sector vertex columns travelling with the main helix. The
// final partial turn unwinds over the last 27% of C3, where the ridge fades,
// so the next ordinary corridor ring resumes its original sector positions.
// A complete turn needs no unwinding because it is the same physical lattice.
export function coilingGridAngleOffsetAtDepth(depth, contract) {
  if (!contract || !Number.isFinite(depth) || depth <= contract.start || depth >= contract.end) return 0;
  const t = (depth - contract.start) / contract.span;
  const totalTravel = contract.handedness * TAU * contract.turns;
  const remainder = totalTravel - TAU * Math.round(totalTravel / TAU);
  const unwind = smoothstep((t - 0.73) / 0.27);
  return totalTravel * t - remainder * unwind;
}

// The inner channel makes the crest readable, while a wider low shoulder
// attaches it to the wall. Neither term has a circumferential floor: the
// opposite wall stays open and the same crest can be followed through depth.
export function coilingChannelWeightAt(angle, depth, contract) {
  if (!contract || depth < contract.start || depth > contract.end) return 0;
  const t = (depth - contract.start) / contract.span;
  const travellingPhase = contract.phase + contract.handedness * TAU * contract.turns * t;
  let weight = 0;
  for (let channel = 0; channel < contract.channelCount; channel++) {
    const centre = travellingPhase + (channel === 0 ? 0 : Math.PI * 0.72);
    const core = angularWeight(angle, centre, contract.halfWidth);
    const shoulder = angularWeight(angle, centre, contract.shoulderWidth);
    // The wide shoulder carries most of the radial transition across several
    // real wall sectors. A narrow high core made each 2 m triangle step read
    // as a separate tooth when the helix moved ~half a sector per ring.
    const profile = core * 0.15 + shoulder * 0.85;
    weight = Math.max(weight, profile * (channel === 0 ? 1 : contract.secondaryScale));
  }
  return weight;
}

// The contract starts at the mathematically smooth zero-relief shoulder. Hero
// evidence must instead measure from the first genuinely visible shell arch;
// otherwise A25/A45 are distances from empty ramp space and not from the form.
export function coilingVisibleFrontDepth(contract,
  minimumStrength = COILING_VISIBLE_RELIEF_STRENGTH) {
  if (!contract || !Number.isFinite(contract.start) || !Number.isFinite(contract.end)
    || !(contract.span > 0) || !(minimumStrength > 0)) {
    throw new TypeError('coiling visible front requires a finite contract and positive strength');
  }
  const step = Math.min(0.125, contract.span / 2048);
  let previous = contract.start;
  for (let depth = contract.start + step; depth <= contract.end + 1e-9; depth += step) {
    const current = Math.min(depth, contract.end);
    if (coilingAxialStrengthAtDepth(current, contract) >= minimumStrength) {
      let lo = previous, hi = current;
      for (let i = 0; i < 32; i++) {
        const mid = (lo + hi) / 2;
        if (coilingAxialStrengthAtDepth(mid, contract) >= minimumStrength) hi = mid;
        else lo = mid;
      }
      return hi;
    }
    previous = current;
  }
  throw new RangeError('coiling contract never reaches the visible relief threshold');
}

// Apply C3 to one already-generated wall radius.  The deformation is an inward
// shell channel, but its final clamp explicitly protects the analytic Boolean
// tube, the complete ship hull and a fixed reserve.  It never changes ring
// cadence, sector count, frame, centre or topology.
export function deformCoilingRadius(baseRadius, tubeRadius, angle, depth, contract) {
  if (!contract || depth < contract.start || depth > contract.end) return baseRadius;
  const axialStrength = coilingAxialStrengthAtDepth(depth, contract);
  const channelWeight = coilingChannelWeightAt(angle, depth, contract);
  // A polygon edge lies inside its endpoint radii. Compensate for that chord so
  // the submitted 32-sector triangle surface, not merely its vertices, retains
  // the requested radial reserve.
  const protectedRadius = (tubeRadius + SHIP_RADIUS + COILING_TUBE_RESERVE)
    / Math.cos(Math.PI / SECTOR_COUNT) + 0.08;
  const free = baseRadius - protectedRadius;
  if (free <= 0) return baseRadius;
  // A fixed-metre inset inherited the wall's 8+ m local radius variation and
  // left a jagged inner crest. Use the free rock thickness instead, retaining
  // at least 2.2 m above the protected radius at a full-strength ridge centre.
  const fullInset = Math.max(0, Math.min(free - 2.2,
    Math.max(contract.ridgeStrength, 0.82 * free)));
  const envelope = axialStrength / contract.ridgeStrength;
  return Math.max(protectedRadius, baseRadius - fullInset * envelope * channelWeight);
}
