// RunTicker — the fixed-timestep accumulator.
//
// The simulation must advance in exact DT steps regardless of the display's
// refresh rate: that is what makes a seed reproducible (see Game.js). This is
// the one place that translates a variable real frame time into whole steps.
//
// Two details are load-bearing and easy to get wrong when the loop is written
// inline (it was written inline three times before this existed):
//
//   * a frame runs at most MAX_STEPS_PER_FRAME steps, so a long stall (a tab
//     coming back, a GC pause) does not spiral into a freeze trying to catch up
//     on seconds of simulation at once;
//   * when a step stops early, its time is NOT consumed — the leftover stays in
//     the accumulator and carries into the next frame, so nothing is lost.
//
// Pure: no game, no DOM, no clock of its own.

export const MAX_STEPS_PER_FRAME = 6;

export class RunTicker {
  constructor(dt, maxSteps = MAX_STEPS_PER_FRAME) {
    this.dt = dt;
    this.maxSteps = maxSteps;
    this.accumulator = 0;
  }

  reset() { this.accumulator = 0; }

  // Run whole steps for `realDt` seconds of wall clock. `step()` is called once
  // per simulated step and returns false to end the frame early (a crash, a
  // restart). Returns the number of steps actually run.
  advance(realDt, step) {
    this.accumulator += realDt;
    let steps = 0;
    while (this.accumulator >= this.dt && steps < this.maxSteps) {
      if (step() === false) break; // early stop: leave this step's time unspent
      this.accumulator -= this.dt;
      steps++;
    }
    return steps;
  }
}
