// dom — every element id the app layer reaches for, in one place.
//
// MenuSystem owns the ids for the screens and HUD it renders. These are the
// remainder: the canvas, the attract-mode overlay, the touch zones and the menu
// buttons the app wires actions onto. Collecting them here means a rename in
// index.html has one place to follow, and it makes the ids assertable from a
// test (see test/dom.test.js, which reads index.html and checks every id below
// actually exists).

export const $ = (id) => document.getElementById(id);

export const ELEMENT_IDS = {
  canvas: 'game-canvas',
  demoOverlay: 'demo-overlay',
  touchLeft: 'touch-left',
  touchRight: 'touch-right',
  seedInput: 'seed-input',
};

// Menu and end-of-run buttons the app binds click actions to.
export const BUTTON_IDS = {
  play: 'btn-play',
  demo: 'btn-demo',
  daily: 'btn-daily',
  seedPlay: 'btn-seed-play',
  sharedPlay: 'btn-shared-play',
  helpSkip: 'btn-help-skip',
  settings: 'btn-settings',
  credits: 'btn-credits',
  settingsBack: 'btn-settings-back',
  settingsReset: 'btn-settings-reset',
  creditsBack: 'btn-credits-back',
  resume: 'btn-resume',
  pauseRestart: 'btn-pause-restart',
  pauseMenu: 'btn-pause-menu',
  touchPause: 'btn-touch-pause',
  retry: 'btn-retry',
  deathMenu: 'btn-death-menu',
  share: 'btn-share',
  shareResult: 'btn-share-result',
};

export const element = (name) => $(ELEMENT_IDS[name]);

// Bind click handlers by button NAME rather than raw id, so a typo is a thrown
// error at startup instead of a button that silently does nothing.
export function bindClicks(handlers) {
  for (const [name, fn] of Object.entries(handlers)) {
    const id = BUTTON_IDS[name];
    if (!id) throw new Error(`bindClicks: unknown button "${name}"`);
    const el = $(id);
    if (!el) throw new Error(`bindClicks: no element #${id} for "${name}"`);
    el.addEventListener('click', fn);
  }
}
