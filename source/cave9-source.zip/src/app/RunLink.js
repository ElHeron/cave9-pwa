// Shareable run identity. The c9 marker prevents ordinary capture/dev query
// parameters from being interpreted as a game link.
import { seedFromString } from '../core/RNG.js';
import { DAILY_RULES, normalizeRunRules } from '../core/RunRules.js';
import { createRunContext } from './RunContext.js';

const SEED = /^-?(?:[1-9]\d*|0)$/;
const DAY = /^\d{4}-\d{2}-\d{2}$/;
const FIELDS = ['c9', 'seed', 'mode', 'thrust', 'landmarks', 'profile'];

export function parseSeed(value) {
  const raw = String(value ?? '').trim();
  if (!SEED.test(raw)) return null;
  const seed = Number(raw);
  return Number.isSafeInteger(seed) && seed >= -0x80000000 && seed <= 0x7fffffff && seed !== 0
    ? seed : null;
}

export function validDailyDay(day) {
  if (typeof day !== 'string' || !DAY.test(day)) return false;
  const date = new Date(`${day}T00:00:00Z`);
  return Number.isFinite(date.getTime()) && date.toISOString().slice(0, 10) === day;
}

export function makeRunLink(context, href) {
  const url = new URL(href);
  url.search = '';
  url.hash = '';
  const { rules } = context;
  url.searchParams.set('c9', '1');
  url.searchParams.set('seed', String(context.seed));
  url.searchParams.set('mode', String(rules.controlMode));
  url.searchParams.set('thrust', String(rules.thrustScale));
  url.searchParams.set('landmarks', rules.landmarks ? '1' : '0');
  url.searchParams.set('profile', rules.key);
  if (context.daily) url.searchParams.set('day', context.dailyKey);
  return url.href;
}

export function parseRunLink(search) {
  const params = search instanceof URLSearchParams ? search : new URLSearchParams(search);
  if (!params.has('c9')) return { status: 'none' };
  const invalid = { status: 'invalid', message: 'This run link is invalid. Check the seed and rules, then try again.' };
  if (params.get('c9') !== '1') return invalid;
  const fields = params.has('day') ? [...FIELDS, 'day'] : FIELDS;
  if (fields.some((field) => params.getAll(field).length !== 1)) return invalid;
  if ([...params.keys()].some((key) => !fields.includes(key))) return invalid;
  const seed = parseSeed(params.get('seed'));
  if (seed === null || String(seed) !== params.get('seed')) return invalid;
  const mode = params.get('mode');
  const thrust = params.get('thrust');
  const landmarks = params.get('landmarks');
  if (!['1', '2'].includes(mode) || !['0', '1'].includes(landmarks)) return invalid;
  const thrustValue = Number(thrust);
  if (!Number.isFinite(thrustValue) || thrustValue < 0.6 || thrustValue > 1.6 || String(thrustValue) !== thrust) return invalid;
  const rules = normalizeRunRules({ controlMode: Number(mode), thrustScale: thrustValue, landmarks: landmarks === '1' });
  if (rules.key !== params.get('profile')) return invalid;
  const day = params.get('day');
  if (day !== null) {
    if (!validDailyDay(day) || seedFromString(day) !== seed || rules.key !== DAILY_RULES.key) return invalid;
    return { status: 'valid', context: createRunContext({ daily: true, date: new Date(`${day}T12:00:00Z`) }) };
  }
  return { status: 'valid', context: createRunContext({ seed, rules }) };
}
