// SessionRunner — one definition of "advance a game and show the result".
//
// The app steps three different sessions: the player's run (input-driven, a
// crash ends it), the attract-mode demo (autopilot, a crash restarts it), and
// the menu background (the same autopilot game, drawn quietly with no overlay).
// Those three used to be three near-identical 30-line methods on GameApp, which
// is exactly how they drifted apart — the frame contract (compute the warning,
// then audio, then draw distance, then render, then debug) was written
// out three times, and one of them silently used a different crash policy.
//
// Now the differences are the arguments and the frame contract is written once.

import { DT } from '../core/Game.js';
import { shipHit } from '../core/CollisionSystem.js';
import { computeWarn } from '../core/WarnState.js';
import { RunTicker } from './RunTicker.js';

// What a crash means for a session, as the value its handler returns to the
// ticker: END stops the frame there, CONTINUE keeps spending the frame's
// remaining time on whatever the handler put in place (a fresh run).
export const CRASH_ENDS_FRAME = false;
export const CRASH_CONTINUES_FRAME = true;

export class SessionRunner {
  constructor({ renderer, menu, audio, debug }) {
    this.renderer = renderer;
    this.menu = menu;
    this.audio = audio;
    this.debug = debug;
    this.ticker = new RunTicker(DT);
  }

  reset() { this.ticker.reset(); }

  // Advance `game` by the whole steps owed for `realDt`.
  //   control(game)  applies this step's inputs (real input, or the autopilot)
  //   onCrash(game)  reacts to a crash and returns CRASH_ENDS_FRAME /
  //                  CRASH_CONTINUES_FRAME
  // Returns true if the game crashed during this frame.
  simulate(game, realDt, control, onCrash) {
    let crashed = false;
    this.ticker.advance(realDt, () => {
      control(game);
      if (!game.step()) return true;
      crashed = true;
      return onCrash(game);
    });
    return crashed;
  }

  // Present a simulated frame: warning state, audio, draw distance, render,
  // debug overlay — in that order. Returns the frame's warning state.
  //
  // The warning is computed ONCE here and handed to every consumer, so the
  // proximity tone, render tint and debug overlay can never
  // disagree about how close the wall is.
  //
  // `hit` is the 0..1 shake/tint factor; pass 1 on the crash frame.
  present(game, hit) {
    const p = game.player;
    const warn = this.trackWarn(game);

    this.audio.thrust(p.lefton || p.righton);
    this.audio.proximity(warn.final, warn.pan);

    this.renderer.setSight(game.difficulty().sightMul);
    this.renderer.render(game, hit, warn.final);
    this.menu.setSpeedFx?.(this.renderer.speedFx || 0);
    this.debug.update(game, warn);
    return warn;
  }

  // The menu background: simulated the same way, drawn quietly — no overlay, no
  // audio, no warning.
  presentIdle(game) {
    this.renderer.renderIdle(game);
  }

  // Hold the last simulated frame (pause / death screens): redraw only.
  presentHeld(game, hit) {
    this.renderer.render(game, hit);
  }

  // Compute this frame's warning state (see core/WarnState.js) and remember it
  // as `lastWarn`. The app owns the frame, so the frame's derived state lives
  // here — the core Game stays plain simulation data. Read back by the capture
  // harness and by anything driving the app from outside (window.__cave9).
  trackWarn(game) {
    this.lastWarn = computeWarn(game);
    return this.lastWarn;
  }

  // Convenience for callers that just need the shake factor of a normal frame.
  hitOf(game, crashed) {
    return crashed ? 1 : shipHit(game.player);
  }
}
