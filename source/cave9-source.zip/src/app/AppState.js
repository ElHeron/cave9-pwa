// The app-level state machine. Distinct from the core's RunPhase: RunPhase is
// about one simulated run (idle / running / dead), AppState is about what the
// whole application is doing (which screen, which game is being stepped).
//
//   BOOT     assets loading, nothing stepped yet
//   MENU     menu screens up; the demo game runs as a quiet background
//   RUNNING  the player's run is being stepped from real input
//   PAUSED   the player's run is frozen, last frame held
//   DEAD     run over, summary up, last frame held
//   DEMO     attract mode — the autopilot run is shown with the full HUD
//   CAPTURE  a frozen deterministic frame for the screenshot harness
export const AppState = {
  BOOT: 'boot',
  MENU: 'menu',
  RUNNING: 'running',
  PAUSED: 'paused',
  DEAD: 'dead',
  DEMO: 'demo',
  CAPTURE: 'capture',
};

// Auto-start the attract-mode demo after this long idle on the main menu.
export const IDLE_DEMO_MS = 15000;
