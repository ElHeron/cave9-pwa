// settingsBindings — the single table mapping a setting key to its effect.
//
// This used to be written twice: once as `_applyAllSettings()` (a flat list of
// calls run at boot and after a reset) and once as a `switch` in
// `onSettingChange()` (run when the player moves a control). Two lists of the
// same thing drift: adding a setting meant remembering both, and the two copies
// had previously diverged on `touchHand`.
//
// A binding is:
//   apply(value, ctx)        the effect itself — run on boot AND on change
// `ctx` is what a binding is allowed to touch: renderer, audio, input, games,
// setReducedMotion and activeRunRules. Touch listeners are stable;
// setTouchHand changes their mapping at press time, including boot and reset.

export const SETTINGS_BINDINGS = {
  controlMode: { apply: (v, ctx) => ctx.input.setMode(ctx.activeRunRules?.()?.controlMode ?? v) },

  sensitivity: {
    apply: (v, ctx) => {
      for (const g of ctx.games) g.player.thrustScale = v;
      const rules = ctx.activeRunRules?.();
      if (rules) ctx.games[0].player.thrustScale = rules.thrustScale;
    },
  },

  invertX: { apply: (v, ctx) => ctx.input.setInvertX(v) },

  brightness: { apply: (v, ctx) => ctx.renderer.setBrightness(v) },

  fov: { apply: (v, ctx) => ctx.renderer.setFov(v) },

  motion: {
    // The renderer scales shake/bob; the body class lets CSS drop HUD pulse and
    // flash animations for players who dialled motion down.
    apply: (v, ctx) => { ctx.renderer.setMotion(v); ctx.setReducedMotion(v); },
  },

  quality: { apply: (v, ctx) => ctx.renderer.setQuality(v) },

  rockDetail: { apply: (v, ctx) => ctx.renderer.setRockDetail(v) },

  landmarks: {
    apply: (v, ctx) => {
      const rules = ctx.activeRunRules?.();
      ctx.renderer.setLandmarks(rules?.landmarks ?? v);
      for (const g of ctx.games) g.landmarksEnabled = !!v;
      if (rules) ctx.games[0].landmarksEnabled = rules.landmarks;
    },
  },

  sound: { apply: (v, ctx) => ctx.audio.setEnabled(v) },

  volume: { apply: (v, ctx) => ctx.audio.setVolume(v) },

  touchHand: { apply: (v, ctx) => ctx.input.setTouchHand(v) },
};

// Keep the live argument for callers that apply one setting after a UI change.
export function applySetting(key, value, ctx, live = false) {
  const binding = SETTINGS_BINDINGS[key];
  if (!binding) return false; // a settings key with no runtime effect
  binding.apply(value, ctx);
  return true;
}

// Apply every bound setting from the given store (boot, and after a reset).
export function applyAllSettings(settings, ctx) {
  for (const key of Object.keys(SETTINGS_BINDINGS)) {
    applySetting(key, settings.get(key), ctx, false);
  }
}
