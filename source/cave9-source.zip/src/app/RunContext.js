// A run's immutable identity. Retry passes this same object back to the app;
// display/input settings outside `rules` can still change independently.
import { dailyKey, seedFromString, randomSeed } from '../core/RNG.js';
import { DAILY_RULES, normalizeRunRules } from '../core/RunRules.js';

export function createRunContext({ daily = false, seed, date = new Date(), settings, rules } = {}) {
  const day = daily ? dailyKey(date) : null;
  const rawSeed = daily ? seedFromString(day) : (seed ?? randomSeed());
  const normalizedSeed = rawSeed | 0 || 1; // matches Game.start()
  const selected = rules ?? (settings?.get
    ? {
        controlMode: settings.get('controlMode'),
        sensitivity: settings.get('sensitivity'),
        landmarks: settings.get('landmarks'),
      }
    : settings);
  const appliedRules = daily ? DAILY_RULES : normalizeRunRules(selected);
  return Object.freeze({ seed: normalizedSeed, daily: !!daily, dailyKey: day, rules: appliedRules });
}
