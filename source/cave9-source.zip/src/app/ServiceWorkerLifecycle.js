// Production-only registration. The worker stays in the browser's normal
// waiting state until every tab using the previous version is closed.

export function serviceWorkerUrls(base, pageUrl) {
  const scope = new URL(base, pageUrl);
  if (!scope.pathname.endsWith('/')) {
    throw new Error('Service worker base must be a directory URL');
  }
  return { scope: scope.href, script: new URL('sw.js', scope).href };
}

export async function registerProductionServiceWorker({
  production,
  base,
  pageUrl,
  serviceWorker = globalThis.navigator?.serviceWorker,
  onUpdate = () => {},
} = {}) {
  if (!production || !serviceWorker) return null;
  const { scope, script } = serviceWorkerUrls(base, pageUrl);
  const registration = await serviceWorker.register(script, { scope, updateViaCache: 'none' });
  const report = () => onUpdate(Boolean(registration.waiting));
  registration.addEventListener('updatefound', () => {
    registration.installing?.addEventListener('statechange', report);
  });
  serviceWorker.addEventListener('controllerchange', report);
  report();
  // A long-open tab need not wait for its next navigation to discover a build.
  // An offline update check is harmless; the installed shell remains usable.
  void registration.update().catch(() => {});
  return registration;
}
