import { AppState } from './AppState.js';
import { bindNativeListeners } from '../platform/NativeApp.js';

export async function handleAndroidBack(app, exitApp) {
  if (app.state === AppState.RUNNING) app.togglePause();
  else if (app.state === AppState.DEMO) app.demoToMenu();
  else if (app.state === AppState.PAUSED || app.state === AppState.DEAD
    || (app.state === AppState.MENU && app.menu.current !== 'menu')) app.toMenu();
  else await exitApp();
}

export function pauseNativeApp(app) {
  if (app.state === AppState.RUNNING) app.togglePause();
  app.audio.stopLoops();
  void app.audio.ctx?.suspend().catch(() => {});
}

export function bindNativeApp(app, options) {
  return bindNativeListeners({
    onPause: () => pauseNativeApp(app),
    onBack: exitApp => handleAndroidBack(app, exitApp),
  }, options);
}
