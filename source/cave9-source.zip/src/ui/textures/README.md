# Cave9 runtime UI textures

These three 256×256 PNGs are the restrained runtime subset of the UI material
direction. They were generated with OpenAI's built-in ImageGen workflow on
2026-08-09 and downscaled locally with nearest-neighbour sampling.

* `panel-strata.png` — quiet V2-style shale strata behind menu copy.
* `control-obsidian.png` — V3-style obsidian facets under buttons and controls.
* `success-growth.png` — sparse V4-style green growth for positive highlights.

The CSS supplies borders, focus rings, state colour and contrast. The bitmap
assets deliberately contain no text, icons, frames, directional lighting or
embedded control state.

Prompt summaries:

1. Seamless, low-resolution dark stratified shale panel material with a compact
   blue-gray palette, sparse dim cyan flecks and no focal point.
2. Seamless, low-resolution matte obsidian control material made from small
   irregular plates and restrained steel-blue edges, without glowing cracks.
3. Seamless, low-resolution dark cave growth with sparse moss-green lichen
   clusters and broad negative space for a success accent.

The full concept atlases and contact sheet live in `artifacts/ui-concepts/`.

## Component pack v2

The first three texture-only assets above proved too subtle in the real menu and
are retained only as historical source material. The active component pack in
`v2/` supplies the real panel shell, four button states, separate slider rail /
hinge / lever layers, settings micro-controls and red/green semantic states.
Its unmodified ImageGen sheets, mapping and complete contact sheet live in
`artifacts/ui-runtime-v2/`; rebuild it with `npm run make:ui-assets`.
