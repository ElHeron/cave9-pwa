// MenuSystem — owns all DOM/HTML UI: screen switching, the auto-built settings
// panel, credits, the minimal flight overlay and the death screen. Pure presentation; the
// game logic lives elsewhere and talks to it through small methods/callbacks.

import { SETTINGS_SCHEMA } from '../platform/SettingsSystem.js';
import { sourceDownloadUrl } from '../platform/NativeApp.js';

const $ = (id) => document.getElementById(id);

const SCREENS = ['menu', 'seed', 'settings', 'credits', 'pause', 'death'];
const SETTINGS_GROUPS = ['Gameplay', 'Display', 'Audio / Touch'];

export class MenuSystem {
  constructor() {
    this.overlay = $('overlay');
    this.touch = $('touch-controls');
    this.flightOverlay = $('flight-overlay');
    this.speedVignette = $('speed-vignette');
    this.loading = $('loading');
    this.el = {
      menuBest: $('menu-best'),
      menuDailyBest: $('menu-daily-best'), menuDailySeed: $('menu-daily-seed'),
      deathScore: $('death-score'),
      deathNewBest: $('death-newbest'),
      deathMode: $('death-mode'), deathBest: $('death-best'),
      deathDistance: $('death-distance'), deathSpeed: $('death-speed'),
      deathGraze: $('death-graze'), deathCombo: $('death-combo'), deathRules: $('death-rules'),
      copyStatus: $('copy-status'),
      firstRunHelp: $('first-run-help'), sharedRun: $('shared-run'),
      sharedRunDescription: $('shared-run-description'), menuMessage: $('menu-message'),
      seedMessage: $('seed-message'),
      menuUpdateNotice: $('menu-update-notice'), deathUpdateNotice: $('death-update-notice'),
    };
    this.current = 'menu';
    this.settingsGroup = SETTINGS_GROUPS[0];
    // Measure the actual responsive stations, so the curve meets their dots at
    // every aspect ratio rather than scaling fixed mockup coordinates.
    const route = document.querySelector('.flight-route');
    this.routeObserver = new ResizeObserver(() => this._drawRoute());
    this.routeObserver.observe(route);
    this.overlay.addEventListener('keydown', (event) => {
      const back = { seed: 'btn-seed-back', settings: 'btn-settings-back', credits: 'btn-credits-back' }[this.current];
      if (event.key === 'Escape' && back) {
        event.preventDefault();
        $(back).click();
      }
    });
  }

  _drawRoute() {
    const route = document.querySelector('.flight-route');
    const rect = route.getBoundingClientRect();
    if (!rect.width || !rect.height) return;
    const points = [...route.querySelectorAll('.route-point')].map(dot => {
      const r = dot.getBoundingClientRect();
      return [r.x + r.width / 2 - rect.x, r.y + r.height / 2 - rect.y];
    });
    const [a, b, c, d] = points;
    const ab = b[0] - a[0], bc = c[0] - b[0], cd = d[0] - c[0];
    $('menu-route-path').setAttribute('d', `M${a} C${a[0] + ab * .45},${b[1] - 12} ${b[0] - ab * .3},${b[1] - 12} ${b} C${b[0] + bc / 3},${b[1] - 12} ${c[0] - bc / 3},${c[1] - 12} ${c} C${c[0] + cd * .4},${c[1]} ${d[0] - cd * .3},${d[1] - 10} ${d}`);
  }

  hideLoading() { this.loading.classList.add('hidden'); }

  showScreen(name) {
    this.current = name;
    for (const s of SCREENS) {
      const screen = $('screen-' + s);
      screen.classList.toggle('hidden', s !== name);
      screen.setAttribute('aria-hidden', String(s !== name));
      screen.inert = s !== name;
    }
    this.overlay.classList.toggle('hidden', name == null);
    this.overlay.setAttribute('aria-hidden', String(name == null));
    this.overlay.inert = name == null;
    const target = name === 'menu' && !this.el.sharedRun.classList.contains('hidden')
      ? $('btn-shared-play')
      : ({ menu: $('btn-play'), seed: $('seed-input'), settings: $('settings-list').querySelector('[aria-selected="true"]') || $('btn-settings-back'),
          credits: $('btn-credits-back'), pause: $('btn-resume'), death: $('btn-retry') })[name];
    target?.focus();
    if (name === 'menu') this._drawRoute();
  }

  hideOverlay() {
    this.overlay.classList.add('hidden');
    this.overlay.setAttribute('aria-hidden', 'true');
    this.overlay.inert = true;
    this.current = null;
    $('game-canvas').focus();
  }

  setFlightOverlayVisible(v) {
    this.flightOverlay.classList.toggle('hidden', !v);
    this.flightOverlay.setAttribute('aria-hidden', String(!v));
  }
  setTouchVisible(v) {
    this.touch.classList.toggle('hidden', !v);
    this.touch.setAttribute('aria-hidden', String(!v));
  }

  setSpeedFx(amount) {
    if (!this.speedVignette) return;
    this.speedVignette.style.opacity = String(Math.max(0, Math.min(0.72, amount * 0.72)));
  }

  setMenuBest(n) { this.el.menuBest.textContent = n; }

  // Daily challenge info on the main menu (today's best + the day's seed).
  setDailyInfo(best, seed) {
    if (this.el.menuDailyBest) this.el.menuDailyBest.textContent = best;
    if (this.el.menuDailySeed) this.el.menuDailySeed.textContent = seed;
  }

  // ---- Death / run summary ----------------------------------------------
  showDeath({ score, newBest, context, previousBest, telemetry }) {
    this.el.deathScore.textContent = score;
    this.el.deathNewBest.classList.toggle('hidden', !newBest);
    const { rules } = context;
    const comparison = context.daily ? `Daily ${context.dailyKey}` : `Seed ${context.seed}`;
    this.el.deathMode.textContent = comparison;
    this.el.deathBest.textContent = previousBest > 0
      ? `Previous comparable best: ${previousBest} · ${score >= previousBest ? '+' : ''}${score - previousBest}`
      : 'First recorded result for these rules';
    this.el.deathDistance.textContent = `${Math.floor(telemetry.distance)} m`;
    this.el.deathSpeed.textContent = `${Math.round(telemetry.maxSpeed)}`;
    this.el.deathGraze.textContent = `${telemetry.grazeTime.toFixed(1)} s`;
    this.el.deathCombo.textContent = `×${telemetry.bestComboMultiplier.toFixed(1)}`;
    this.el.deathRules.textContent = `${rules.controlMode === 2 ? 'Two thrusters' : 'One button'} · thrust ×${rules.thrustScale} · obstacles ${rules.landmarks ? 'on' : 'off'}`;
    this.setCopyStatus('');
    this.showScreen('death');
  }

  setCopyStatus(message) { this.el.copyStatus.textContent = message; }
  setUpdateReady(ready) {
    this.el.menuUpdateNotice.classList.toggle('hidden', !ready);
    this.el.deathUpdateNotice.classList.toggle('hidden', !ready);
  }
  showFirstRunHelp(show) { this.el.firstRunHelp.classList.toggle('hidden', !show); }
  showSharedRun(context) {
    this.el.sharedRun.classList.toggle('hidden', !context);
    if (context) this.el.sharedRunDescription.textContent = context.daily
      ? `Shared Daily ${context.dailyKey} · seed ${context.seed} · two thrusters, standard thrust, obstacles on`
      : `Shared seed ${context.seed} · ${context.rules.controlMode === 2 ? 'two thrusters' : 'one button'} · thrust ×${context.rules.thrustScale} · obstacles ${context.rules.landmarks ? 'on' : 'off'}`;
  }
  setMenuMessage(message) {
    this.el.menuMessage.textContent = message;
    this.el.menuMessage.classList.toggle('hidden', !message);
    this.el.seedMessage.textContent = message;
    this.el.seedMessage.classList.toggle('hidden', !message);
    $('seed-input').setAttribute('aria-invalid', String(!!message));
  }

  // ---- Settings panel (auto-built from schema) --------------------------
  buildSettings(settings, onChange) {
    const list = $('settings-list');
    list.innerHTML = '';
    const tabs = document.createElement('div');
    tabs.className = 'settings-tabs';
    tabs.setAttribute('role', 'tablist');
    tabs.setAttribute('aria-label', 'Settings categories');
    const groups = document.createElement('div');
    groups.className = 'settings-groups';
    const panels = new Map();
    const selectGroup = (name, focus = false) => {
      this.settingsGroup = name;
      for (const [group, panel] of panels) {
        const selected = group === name;
        const tab = $(panel.getAttribute('aria-labelledby'));
        tab.setAttribute('aria-selected', String(selected));
        tab.tabIndex = selected ? 0 : -1;
        panel.classList.toggle('hidden', !selected);
        panel.inert = !selected;
        if (selected && focus) tab.focus();
      }
      groups.scrollTop = 0;
    };
    for (const [index, name] of SETTINGS_GROUPS.entries()) {
      const tab = document.createElement('button');
      tab.type = 'button';
      tab.className = 'settings-tab';
      tab.id = `settings-tab-${index}`;
      tab.textContent = name;
      tab.setAttribute('role', 'tab');
      tab.setAttribute('aria-controls', `settings-group-${index}`);
      tab.addEventListener('click', () => selectGroup(name));
      tab.addEventListener('keydown', event => {
        let next;
        if (event.key === 'ArrowRight') next = (index + 1) % SETTINGS_GROUPS.length;
        if (event.key === 'ArrowLeft') next = (index + SETTINGS_GROUPS.length - 1) % SETTINGS_GROUPS.length;
        if (event.key === 'Home') next = 0;
        if (event.key === 'End') next = SETTINGS_GROUPS.length - 1;
        if (next !== undefined) {
          event.preventDefault();
          selectGroup(SETTINGS_GROUPS[next], true);
        }
      });
      tabs.appendChild(tab);
      const panel = document.createElement('div');
      panel.className = 'settings-group';
      panel.id = `settings-group-${index}`;
      panel.setAttribute('role', 'tabpanel');
      panel.setAttribute('aria-labelledby', tab.id);
      panels.set(name, panel);
      groups.appendChild(panel);
    }
    list.append(tabs, groups);

    for (const field of SETTINGS_SCHEMA) {
      const row = document.createElement('div');
      row.className = 'settings-row';
      row.dataset.setting = field.key;
      const label = document.createElement('label');
      label.textContent = field.label;
      label.id = `setting-label-${field.key}`;
      row.appendChild(label);

      const control = document.createElement('div');
      control.className = 'settings-control';

      if (field.kind === 'range') {
        const input = document.createElement('input');
        input.type = 'range';
        input.id = `setting-${field.key}`;
        label.htmlFor = input.id;
        input.min = field.min; input.max = field.max; input.step = field.step;
        input.value = settings.get(field.key);
        const out = document.createElement('span');
        out.className = 'settings-value';
        const fmt = (v) => field.fmt === '%' ? Math.round(v * 100) + '%'
          : field.fmt === '°' ? v + '°'
          : field.fmt === 'x' ? (+v).toFixed(2) + '×'
          : v;
        out.textContent = fmt(input.value);
        input.addEventListener('input', () => {
          const v = parseFloat(input.value);
          out.textContent = fmt(v);
          onChange(field.key, v);
        });
        control.append(input, out);
      } else if (field.kind === 'toggle') {
        const btn = document.createElement('button');
        btn.id = `setting-${field.key}`;
        btn.type = 'button';
        btn.setAttribute('aria-labelledby', label.id);
        label.htmlFor = btn.id;
        btn.className = 'toggle-btn';
        const paint = (v) => {
          btn.textContent = v ? 'ON' : 'OFF';
          btn.classList.toggle('on', v);
          btn.setAttribute('aria-pressed', String(!!v));
        };
        paint(settings.get(field.key));
        btn.addEventListener('click', () => {
          const v = !settings.get(field.key);
          paint(v); onChange(field.key, v);
        });
        control.appendChild(btn);
      } else if (field.kind === 'choice') {
        const seg = document.createElement('div');
        seg.className = 'segmented';
        seg.setAttribute('role', 'group');
        seg.setAttribute('aria-labelledby', label.id);
        const paint = (val) => {
          for (const b of seg.children) {
            const selected = `${b.dataset.value}` === `${val}`;
            b.classList.toggle('on', selected);
            b.setAttribute('aria-pressed', String(selected));
          }
        };
        for (const c of field.choices) {
          const b = document.createElement('button');
          b.type = 'button';
          b.textContent = c.label;
          b.dataset.value = c.value;
          b.addEventListener('click', () => {
            const value = typeof field.choices[0].value === 'number' ? Number(c.value) : c.value;
            onChange(field.key, value);
            paint(c.value);
          });
          seg.appendChild(b);
        }
        paint(settings.get(field.key));
        control.appendChild(seg);
      }

      row.appendChild(control);
      panels.get(['Audio', 'Touch'].includes(field.section) ? 'Audio / Touch' : field.section).appendChild(row);
    }

    selectGroup(this.settingsGroup);
    this._settingsRebuild = () => this.buildSettings(settings, onChange);
  }

  refreshSettings() { if (this._settingsRebuild) this._settingsRebuild(); }

  buildCredits() {
    const body = $('credits-body');
    body.innerHTML = `
      <p><strong>Cave9</strong> is a browser cave-runner inspired by the classic
      <em>cave9</em> from <strong>9Hells</strong> (Carlo "zed9h" Caputo &amp;
      Rodolfo "bart9h" Borges).</p>
      <p>The original game explored a 3D take on SF-Cave:
      <a href="https://github.com/bart9h/cave9" target="_blank" rel="noopener">github.com/bart9h/cave9</a></p>
      <h3>Inspiration</h3>
      <ul>
        <li>Carlo Caputo (zed9h) — code</li>
        <li>Rodolfo Borges (bart9h) — code</li>
        <li>Victor Bogado — collision detection idea, cave deformation</li>
        <li>Timo Paulssen — deterministic cave generation (seeds)</li>
        <li>Daniel Beltrão Borges — 2D cave-gen prototype</li>
      </ul>
      <h3>This project</h3>
      <p>The route-first cave stream, surface collision, formations, shader
      materials and menu textures form this project's own current game and
      visual direction. Rendering uses
      <a href="https://threejs.org" target="_blank" rel="noopener">Three.js</a>.</p>
      <h3>License &amp; notices</h3>
      <p>This project is published under <strong>GPL-3.0-or-later</strong>.
      Original cave9 remains a separate, credited source of inspiration.
      Retained original audio and reference files keep their original notices;
      see <code>LICENSE_NOTES.md</code> and <code>licenses/</code>.</p>
      <p><a href="./LICENSE.txt" target="_blank" rel="noopener">License</a> ·
      <a href="./LICENSE_NOTES.txt" target="_blank" rel="noopener">Credits &amp; asset notices</a> ·
      <a href="${sourceDownloadUrl()}" download>Download source (online)</a></p>
    `;
  }
}
