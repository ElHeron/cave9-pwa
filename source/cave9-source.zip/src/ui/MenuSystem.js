// MenuSystem — owns all DOM/HTML UI: screen switching, the auto-built settings
// panel, credits, the minimal flight overlay and the death screen. Pure presentation; the
// game logic lives elsewhere and talks to it through small methods/callbacks.

import { SETTINGS_SCHEMA } from '../platform/SettingsSystem.js';

const $ = (id) => document.getElementById(id);

const SCREENS = ['menu', 'settings', 'credits', 'pause', 'death'];

export class MenuSystem {
  constructor() {
    this.overlay = $('overlay');
    this.touch = $('touch-controls');
    this.flightOverlay = $('flight-overlay');
    this.speedVignette = $('speed-vignette');
    this.loading = $('loading');
    this.el = {
      menuBest: $('menu-best'),
      menuDailyBest: $('menu-daily-best'), menuDailySeed: $('menu-daily-seed'),
      deathScore: $('death-score'),
      deathNewBest: $('death-newbest'),
      deathMode: $('death-mode'), deathBest: $('death-best'),
      deathDistance: $('death-distance'), deathSpeed: $('death-speed'),
      deathGraze: $('death-graze'), deathCombo: $('death-combo'), deathRules: $('death-rules'),
      copyStatus: $('copy-status'),
      firstRunHelp: $('first-run-help'), sharedRun: $('shared-run'),
      sharedRunDescription: $('shared-run-description'), menuMessage: $('menu-message'),
      menuUpdateNotice: $('menu-update-notice'), deathUpdateNotice: $('death-update-notice'),
    };
    this.current = 'menu';
  }

  hideLoading() { this.loading.classList.add('hidden'); }

  showScreen(name) {
    this.current = name;
    for (const s of SCREENS) {
      const screen = $('screen-' + s);
      screen.classList.toggle('hidden', s !== name);
      screen.setAttribute('aria-hidden', String(s !== name));
      screen.inert = s !== name;
    }
    this.overlay.classList.toggle('hidden', name == null);
    this.overlay.setAttribute('aria-hidden', String(name == null));
    this.overlay.inert = name == null;
    const target = name === 'menu' && !this.el.sharedRun.classList.contains('hidden')
      ? $('btn-shared-play')
      : ({ menu: $('btn-play'), settings: $('settings-list').querySelector('input, button') || $('btn-settings-back'),
          credits: $('btn-credits-back'), pause: $('btn-resume'), death: $('btn-retry') })[name];
    target?.focus();
  }

  hideOverlay() {
    this.overlay.classList.add('hidden');
    this.overlay.setAttribute('aria-hidden', 'true');
    this.overlay.inert = true;
    this.current = null;
    $('game-canvas').focus();
  }

  setFlightOverlayVisible(v) {
    this.flightOverlay.classList.toggle('hidden', !v);
    this.flightOverlay.setAttribute('aria-hidden', String(!v));
  }
  setTouchVisible(v) {
    this.touch.classList.toggle('hidden', !v);
    this.touch.setAttribute('aria-hidden', String(!v));
  }

  setSpeedFx(amount) {
    if (!this.speedVignette) return;
    this.speedVignette.style.opacity = String(Math.max(0, Math.min(0.72, amount * 0.72)));
  }

  setMenuBest(n) { this.el.menuBest.textContent = n; }

  // Daily challenge info on the main menu (today's best + the day's seed).
  setDailyInfo(best, seed) {
    if (this.el.menuDailyBest) this.el.menuDailyBest.textContent = best;
    if (this.el.menuDailySeed) this.el.menuDailySeed.textContent = seed;
  }

  // ---- Death / run summary ----------------------------------------------
  showDeath({ score, newBest, context, previousBest, telemetry }) {
    this.el.deathScore.textContent = score;
    this.el.deathNewBest.classList.toggle('hidden', !newBest);
    const { rules } = context;
    const comparison = context.daily ? `Daily ${context.dailyKey}` : `Seed ${context.seed}`;
    this.el.deathMode.textContent = comparison;
    this.el.deathBest.textContent = previousBest > 0
      ? `Previous comparable best: ${previousBest} · ${score >= previousBest ? '+' : ''}${score - previousBest}`
      : 'First recorded result for these rules';
    this.el.deathDistance.textContent = `${Math.floor(telemetry.distance)} m`;
    this.el.deathSpeed.textContent = `${Math.round(telemetry.maxSpeed)}`;
    this.el.deathGraze.textContent = `${telemetry.grazeTime.toFixed(1)} s`;
    this.el.deathCombo.textContent = `×${telemetry.bestComboMultiplier.toFixed(1)}`;
    this.el.deathRules.textContent = `${rules.controlMode === 2 ? 'Two thrusters' : 'One button'} · thrust ×${rules.thrustScale} · obstacles ${rules.landmarks ? 'on' : 'off'}`;
    this.setCopyStatus('');
    this.showScreen('death');
  }

  setCopyStatus(message) { this.el.copyStatus.textContent = message; }
  setUpdateReady(ready) {
    this.el.menuUpdateNotice.classList.toggle('hidden', !ready);
    this.el.deathUpdateNotice.classList.toggle('hidden', !ready);
  }
  showFirstRunHelp(show) { this.el.firstRunHelp.classList.toggle('hidden', !show); }
  showSharedRun(context) {
    this.el.sharedRun.classList.toggle('hidden', !context);
    if (context) this.el.sharedRunDescription.textContent = context.daily
      ? `Shared Daily ${context.dailyKey} · seed ${context.seed} · two thrusters, standard thrust, obstacles on`
      : `Shared seed ${context.seed} · ${context.rules.controlMode === 2 ? 'two thrusters' : 'one button'} · thrust ×${context.rules.thrustScale} · obstacles ${context.rules.landmarks ? 'on' : 'off'}`;
  }
  setMenuMessage(message) {
    this.el.menuMessage.textContent = message;
    this.el.menuMessage.classList.toggle('hidden', !message);
  }

  // ---- Settings panel (auto-built from schema) --------------------------
  buildSettings(settings, onChange) {
    const list = $('settings-list');
    list.innerHTML = '';
    let lastSection = null;

    for (const field of SETTINGS_SCHEMA) {
      if (field.section !== lastSection) {
        const h = document.createElement('h3');
        h.className = 'settings-section';
        h.textContent = field.section;
        list.appendChild(h);
        lastSection = field.section;
      }

      const row = document.createElement('div');
      row.className = 'settings-row';
      const label = document.createElement('label');
      label.textContent = field.label;
      label.id = `setting-label-${field.key}`;
      row.appendChild(label);

      const control = document.createElement('div');
      control.className = 'settings-control';

      if (field.kind === 'range') {
        const input = document.createElement('input');
        input.type = 'range';
        input.id = `setting-${field.key}`;
        label.htmlFor = input.id;
        input.min = field.min; input.max = field.max; input.step = field.step;
        input.value = settings.get(field.key);
        const out = document.createElement('span');
        out.className = 'settings-value';
        const fmt = (v) => field.fmt === '%' ? Math.round(v * 100) + '%'
          : field.fmt === '°' ? v + '°'
          : field.fmt === 'x' ? (+v).toFixed(2) + '×'
          : v;
        out.textContent = fmt(input.value);
        input.addEventListener('input', () => {
          const v = parseFloat(input.value);
          out.textContent = fmt(v);
          onChange(field.key, v);
        });
        control.append(input, out);
      } else if (field.kind === 'toggle') {
        const btn = document.createElement('button');
        btn.id = `setting-${field.key}`;
        label.htmlFor = btn.id;
        btn.className = 'toggle-btn';
        const paint = (v) => {
          btn.textContent = v ? 'ON' : 'OFF';
          btn.classList.toggle('on', v);
          btn.setAttribute('aria-pressed', String(!!v));
        };
        paint(settings.get(field.key));
        btn.addEventListener('click', () => {
          const v = !settings.get(field.key);
          paint(v); onChange(field.key, v);
        });
        control.appendChild(btn);
      } else if (field.kind === 'choice') {
        const seg = document.createElement('div');
        seg.className = 'segmented';
        seg.setAttribute('role', 'group');
        seg.setAttribute('aria-labelledby', label.id);
        const paint = (val) => {
          for (const b of seg.children) {
            const selected = `${b.dataset.value}` === `${val}`;
            b.classList.toggle('on', selected);
            b.setAttribute('aria-pressed', String(selected));
          }
        };
        for (const c of field.choices) {
          const b = document.createElement('button');
          b.textContent = c.label;
          b.dataset.value = c.value;
          b.addEventListener('click', () => {
            const value = typeof field.choices[0].value === 'number' ? Number(c.value) : c.value;
            onChange(field.key, value);
            paint(c.value);
          });
          seg.appendChild(b);
        }
        paint(settings.get(field.key));
        control.appendChild(seg);
      }

      row.appendChild(control);
      list.appendChild(row);
    }

    this._settingsRebuild = () => this.buildSettings(settings, onChange);
  }

  refreshSettings() { if (this._settingsRebuild) this._settingsRebuild(); }

  buildCredits() {
    const body = $('credits-body');
    body.innerHTML = `
      <p><strong>Cave9</strong> is a browser cave-runner inspired by the classic
      <em>cave9</em> from <strong>9Hells</strong> (Carlo "zed9h" Caputo &amp;
      Rodolfo "bart9h" Borges).</p>
      <p>The original game explored a 3D take on SF-Cave:
      <a href="https://github.com/bart9h/cave9" target="_blank" rel="noopener">github.com/bart9h/cave9</a></p>
      <h3>Inspiration</h3>
      <ul>
        <li>Carlo Caputo (zed9h) — code</li>
        <li>Rodolfo Borges (bart9h) — code</li>
        <li>Victor Bogado — collision detection idea, cave deformation</li>
        <li>Timo Paulssen — deterministic cave generation (seeds)</li>
        <li>Daniel Beltrão Borges — 2D cave-gen prototype</li>
      </ul>
      <h3>This project</h3>
      <p>The route-first cave stream, surface collision, formations, shader
      materials and menu textures form this project's own current game and
      visual direction. Rendering uses
      <a href="https://threejs.org" target="_blank" rel="noopener">Three.js</a>.</p>
      <h3>License &amp; notices</h3>
      <p>This project is published under <strong>GPL-3.0-or-later</strong>.
      Original cave9 remains a separate, credited source of inspiration.
      Retained original audio and reference files keep their original notices;
      see <code>LICENSE_NOTES.md</code> and <code>licenses/</code>.</p>
      <p><a href="./LICENSE.txt" target="_blank" rel="noopener">License</a> ·
      <a href="./LICENSE_NOTES.txt" target="_blank" rel="noopener">Credits &amp; asset notices</a> ·
      <a href="./source/cave9-source.zip" download>Download source (online)</a></p>
    `;
  }
}
