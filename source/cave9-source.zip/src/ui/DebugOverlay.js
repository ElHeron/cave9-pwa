// DebugOverlay — a release-hideable dev panel showing live runtime metrics:
// FPS, seed, distance, speed, cave radius / clearance, danger, the live
// difficulty parameters and the 4 collision probes (green = inside the cave,
// red = outside). Toggled with F3 or backtick; off by default so it never ships
// visible. Pure DOM + a small SVG probe diagram; reads only plain values so it
// stays decoupled from THREE.

import { dailySeed } from '../core/RNG.js';
import { computeWarn } from '../core/WarnState.js';
import { nearestCompositionDistance, totalPieceCount } from '../core/Landmarks.js';
import { tubeRadiusAt } from '../core/FlightPath.js';
import { FOG_END } from '../core/constants.js';

const TEMPLATE = `
  <div class="dbg-title">CAVE9 DEV <span class="dbg-hint">F3 / \`</span></div>
  <div class="dbg-grid">
    <span>fps</span><b data-k="fps">–</b>
    <span>run seed</span><b data-k="seed">–</b>
    <span>daily seed</span><b data-k="daily">–</b>
    <span>tier</span><b data-k="tier">–</b>
    <span>dist</span><b data-k="dist">–</b>
    <span>forward</span><b data-k="speed">–</b>
    <span>thrusters</span><b data-k="thrusters">–</b>
    <span>cave r</span><b data-k="radius">–</b>
    <span>clear</span><b data-k="clear">–</b>
    <span>closest</span><b data-k="closest">–</b>
    <span>danger</span><b data-k="danger">–</b>
    <span>maxDanger</span><b data-k="maxDanger">–</b>
    <span>react warn</span><b data-k="reactWarn">–</b>
    <span>pred warn</span><b data-k="predWarn">–</b>
    <span>final warn</span><b data-k="finalWarn">–</b>
    <span>lead</span><b data-k="lead">–</b>
    <span>landmarks</span><b data-k="lmCount">–</b>
    <span>lm type</span><b data-k="lmType">–</b>
    <span>lm pieces</span><b data-k="lmPieces">–</b>
    <span>nearest lm</span><b data-k="lmNear">–</b>
    <span>pan L/R</span><b data-k="pan">–</b>
    <span>graze</span><b data-k="graze">–</b>
    <span>grazeT</span><b data-k="grazeT">–</b>
    <span>combo</span><b data-k="combo">–</b>
    <span>combo×</span><b data-k="comboMul">–</b>
    <span>speed×</span><b data-k="speedMul">–</b>
    <span>score×</span><b data-k="scoreMul">–</b>
    <span>react</span><b data-k="react">–</b>
    <span>grace</span><b data-k="grace">–</b>
  </div>
  <div class="dbg-probes">
    <svg viewBox="-3 -3 6 6" width="84" height="84" aria-hidden="true">
      <circle cx="0" cy="0" r="2.6" class="dbg-ring"/>
      <circle data-p="0" cx="-2" cy="0"  r="0.5"/>
      <circle data-p="1" cx="0"  cy="-2" r="0.5"/>
      <circle data-p="2" cx="2"  cy="0"  r="0.5"/>
      <circle data-p="3" cx="0"  cy="2"  r="0.5"/>
      <circle cx="0" cy="0" r="0.25" class="dbg-center"/>
    </svg>
    <div class="dbg-probe-label">collision probes<br><span data-k="probetxt">L T R B</span></div>
  </div>`;

export class DebugOverlay {
  constructor() {
    this.el = document.createElement('div');
    this.el.id = 'debug-overlay';
    this.el.className = 'debug-overlay hidden';
    this.el.innerHTML = TEMPLATE;
    document.body.appendChild(this.el);

    this.k = {};
    for (const b of this.el.querySelectorAll('[data-k]')) this.k[b.dataset.k] = b;
    this.probes = [...this.el.querySelectorAll('[data-p]')];

    this.visible = false;
    this._frames = 0;
    this._fps = 0;
    this._acc = 0;

    window.addEventListener('keydown', (e) => {
      if (e.code === 'F3' || e.key === '`' || e.key === '~') {
        e.preventDefault();
        this.toggle();
      }
    });
  }

  toggle(force) {
    this.visible = force === undefined ? !this.visible : !!force;
    this.el.classList.toggle('hidden', !this.visible);
  }

  // call once per rendered frame with the real frame dt (seconds)
  tick(realDt) {
    this._frames++;
    this._acc += realDt;
    if (this._acc >= 0.5) {
      this._fps = Math.round(this._frames / this._acc);
      this._frames = 0;
      this._acc = 0;
    }
  }

  // game: a Game instance (running or demo).
  // warn: the frame's warning state from SessionRunner, so the overlay shows the
  //   exact numbers audio/renderer used rather than a second probe of its
  //   own. Defaults to computing it, for callers driving the app from outside.
  // Cheap no-op while hidden.
  update(game, warn = undefined) {
    if (!this.visible || !game) return;
    // Deliberately not a default parameter: that would run the probe before the
    // guard above, costing a frame's work even while the overlay is hidden.
    if (warn === undefined) warn = computeWarn(game);
    const p = game.player;
    const d = game.difficulty();
    const set = (key, v) => { const el = this.k[key]; if (el) el.textContent = v; };

    const s = game.score;
    set('fps', this._fps);
    set('seed', game.seed);
    set('daily', dailySeed());
    set('tier', d.tier);
    set('dist', `${Math.floor(s.distance)} m`);
    set('speed', p.forwardSpeed().toFixed(1));
    set('thrusters', p.lefton && p.righton ? 'BOTH'
      : p.lefton ? 'LEFT' : p.righton ? 'RIGHT' : 'OFF');
    set('radius', tubeRadiusAt(p.pos[2] - p.start, game.seed).toFixed(1));
    set('clear', (p.dist === Number.MAX_VALUE ? '–' : Math.max(0, p.dist).toFixed(2)));
    set('closest', (s.closest === Number.MAX_VALUE ? '–' : s.closest.toFixed(2)));
    set('danger', `${Math.round((s.warnLevel || 0) * 100)}%`);
    set('maxDanger', `${Math.round((s.maxDanger || 0) * 100)}%`);
    // Warning breakdown (Phase 4F / M1): reactive = current proximity, pred =
    // look-ahead proximity along the heading, final = max() — the exact values
    // the proximity tone, render tint and diagnostics were driven with.
    set('reactWarn', `${Math.round(warn.reactive * 100)}%`);
    set('predWarn', `${Math.round(warn.predictive * 100)}%`);
    set('finalWarn', `${Math.round(warn.final * 100)}%`);
    set('lead', `${warn.leadDist.toFixed(1)} m`);
    // Landmarks (Phase 4G / M2): count of in-view room formations + the nearest
    // one's forward distance. Range ≈ the typical rendered fog far-plane. Read
    // through this Game's cache, so opening the overlay
    // costs a map lookup rather than three extra composition rebuilds a frame.
    const lmRange = FOG_END * d.sightMul;
    const comps = game.landmarksEnabled
      ? game.landmarkCache.landmarksInView(game.cave, p.pos[2], lmRange, game.seed,
        undefined, game.landmarkFamilyOverride) : [];
    set('lmCount', `${comps.length}`);
    set('lmType', comps.length ? comps[0].typeName : '–');
    set('lmPieces', `${totalPieceCount(comps)}`);
    const lmNear = nearestCompositionDistance(comps, p.pos[2]);
    set('lmNear', lmNear === null ? '–' : `${lmNear.toFixed(0)} m`);
    // directional proximity pan (−1 left … +1 right), additive audio cue
    const side = warn.pan < -0.05 ? 'L' : warn.pan > 0.05 ? 'R' : '·';
    set('pan', `${warn.pan.toFixed(2)} ${side}`);
    set('graze', s.grazeActive ? 'YES' : 'no');
    set('grazeT', `${(s.grazeTime || 0).toFixed(1)} s`);
    set('combo', `${s.combo || 0}`);
    set('comboMul', `${(s.comboMultiplier || 1).toFixed(1)}×`);
    set('speedMul', `${d.speedMul.toFixed(2)}×`);
    set('scoreMul', `${d.scoreMul.toFixed(2)}×`);
    set('react', `${d.reactionWindow.toFixed(2)} s`);
    set('grace', p.graced ? 'YES' : 'no');

    for (let i = 0; i < 4; i++) {
      this.probes[i].classList.toggle('inside', !!p.probeInside[i]);
      this.probes[i].classList.toggle('outside', !p.probeInside[i]);
    }
    set('probetxt', p.probeInside.map((v, i) => (v ? '·' : 'X')).join(' '));
  }
}
