// Cave9 — application entry point.
//
// GameApp is the composition root and the app-level state machine: it owns the
// systems, wires the DOM to them, and decides which session the frame belongs
// to. The work each frame actually does lives in ./app/SessionRunner.js; the
// settings key→effect table lives in ./app/settingsBindings.js; the screenshot
// harness is dynamically imported from ./app/CaptureHarness.js so it stays out
// of the shipped chunk.

import { Game } from './core/Game.js';
import { randomSeed } from './core/RNG.js';
import { COMBO_MULT_PER, COMBO_MULT_MAX } from './core/ScoreSystem.js';
import { tierAt } from './core/Difficulty.js';
import { Renderer } from './render/Renderer.js';
import { InputAdapter, isTouchDevice } from './platform/InputAdapter.js';
import { AudioSystem } from './platform/AudioSystem.js';
import { SettingsSystem } from './platform/SettingsSystem.js';
import { SaveSystem } from './platform/SaveSystem.js';
import { MenuSystem } from './ui/MenuSystem.js';
import { DebugOverlay } from './ui/DebugOverlay.js';
import { AppState, IDLE_DEMO_MS } from './app/AppState.js';
import { SessionRunner, CRASH_ENDS_FRAME, CRASH_CONTINUES_FRAME } from './app/SessionRunner.js';
import { applySetting, applyAllSettings } from './app/settingsBindings.js';
import { element, bindClicks } from './app/dom.js';
import { createRunContext } from './app/RunContext.js';
import { makeRunLink, parseRunLink, parseSeed } from './app/RunLink.js';
import { registerProductionServiceWorker } from './app/ServiceWorkerLifecycle.js';

export class GameApp {
  constructor() {
    this.canvas = element('canvas');
    const query = new URLSearchParams(window.location.search);
    this.renderer = new Renderer(this.canvas, {
      preserveDrawingBuffer: query.has('capture') || query.has('visualLab') || query.has('lab'),
    });
    this.settings = new SettingsSystem();
    this.audio = new AudioSystem();
    this.menu = new MenuSystem();
    this.debug = new DebugOverlay(); // hidden until F3 / backtick

    this.game = new Game();
    this.demo = new Game(); // living background for the menu

    this.input = new InputAdapter({
      onPause: () => this.togglePause(),
      onConfirm: () => this.onConfirm(),
    });

    this.session = new SessionRunner({
      renderer: this.renderer, menu: this.menu, audio: this.audio, debug: this.debug,
    });

    this.state = AppState.BOOT;
    this.AppState = AppState;
    this.runContext = null;
    this.updateAvailable = false;
    const incomingLink = parseRunLink(query);
    this.sharedContext = incomingLink.status === 'valid' ? incomingLink.context : null;
    this.runLinkError = incomingLink.status === 'invalid' ? incomingLink.message : '';
    this._portraitQuery = window.matchMedia?.('(orientation: portrait) and (max-width: 820px)');
    this.lastTime = performance.now();
    this.touch = isTouchDevice();
    this.demoOverlay = element('demoOverlay');
    this.lastInteract = performance.now();
    this._demoKeyHandler = (e) => { if (e.code !== 'Escape') this.demoTakeOver(); };
    this._held = null; // frozen frame for the capture harness
    this.externalFrameDriver = query.has('perf') && !query.has('c9');

    applyAllSettings(this.settings, this.settingsContext());
    this._wireUI();
    this._bindWindow();
  }

  async boot() {
    this.menu.buildSettings(this.settings, (k, v) => this.onSettingChange(k, v));
    this.menu.buildCredits();

    await Promise.all([this.renderer.load(), this.audio.load()]);

    this.demo.start({ mode: this.settings.get('controlMode'), seed: randomSeed() });
    this.menu.hideLoading();
    this.toMenu();
    this._registerServiceWorker();

    const query = new URLSearchParams(window.location.search);
    if (query.has('visualLab') || query.has('lab')) {
      try {
        const { mountVisualLab } = await import('./dev/lab/index.mjs');
        this.visual = await mountVisualLab({ app: this });
      } catch (error) {
        this.visualLabError = String(error?.stack || error);
        console.error('Visual Lab failed to mount', error);
      }
    }

    if (!this.externalFrameDriver) requestAnimationFrame((t) => this.loop(t));
  }

  // ---- state transitions ------------------------------------------------
  toMenu() {
    this.state = AppState.MENU;
    // Asset loading and time spent in a run are not idle time on the menu.
    this.lastInteract = performance.now();
    this.audio.stopLoops();
    this.input.setEnabled(false);
    // A Daily run may have forced obstacles on. Restore the player's free-run
    // presentation and controls without changing their persisted settings.
    const settingsContext = this.settingsContext();
    for (const key of ['controlMode', 'sensitivity', 'landmarks']) {
      applySetting(key, this.settings.get(key), settingsContext);
    }
    this.menu.setFlightOverlayVisible(false);
    this.menu.setTouchVisible(false);
    const today = new Date();
    const freeContext = createRunContext({ seed: 1, settings: this.settings });
    const dailyContext = createRunContext({ daily: true, date: today });
    this.menu.setMenuBest(SaveSystem.getRunBest(freeContext));
    this.menu.setDailyInfo(SaveSystem.getRunDailyBest(dailyContext), dailyContext.seed);
    this.menu.showSharedRun(this.sharedContext);
    this.menu.setMenuMessage(this.runLinkError);
    this.menu.showFirstRunHelp(!this.settings.get('helpSeen'));
    this.menu.showScreen('menu');
    this._refreshUpdateNotice();
    this._checkForUpdate();
  }

  startRun(opts = {}) {
    this.dismissHelp();
    this.audio.resume();
    this.runContext = opts.context ?? createRunContext({ ...opts, settings: this.settings });
    this.dailyRun = this.runContext.daily; // kept for existing app/debug consumers
    const rules = this.runContext.rules;
    this.game.landmarksEnabled = rules.landmarks;
    this.game.start({ mode: rules.controlMode, seed: this.runContext.seed });
    this.game.player.thrustScale = rules.thrustScale;
    this.renderer.setLandmarks(rules.landmarks);
    SaveSystem.setLastSeed(this.runContext.seed);

    this.state = AppState.RUNNING;
    this._refreshUpdateNotice();
    this.session.reset();
    this.input.setMode(rules.controlMode);
    this.input.setEnabled(true);
    this.menu.hideOverlay();
    this.menu.setFlightOverlayVisible(true);
    this.menu.setTouchVisible(this.touch);
    if (this._portraitQuery?.matches) this.togglePause();
  }

  togglePause() {
    if (this.state === AppState.DEMO) { this.demoToMenu(); return; }
    if (this.state === AppState.RUNNING) {
      this.state = AppState.PAUSED;
      this._refreshUpdateNotice();
      this.game.score.breakCombo(); // a combo never survives an interruption
      this.audio.stopLoops();
      this.input.setEnabled(false);
      this.menu.setFlightOverlayVisible(false);
      this.menu.setTouchVisible(false);
      this.menu.showScreen('pause');
      this.audio.blip(440);
    } else if (this.state === AppState.PAUSED) {
      this.resume();
    }
  }

  resume() {
    if (this.state !== AppState.PAUSED || this._portraitQuery?.matches) return;
    this.state = AppState.RUNNING;
    this.input.setEnabled(true);
    this.menu.hideOverlay();
    this.menu.setFlightOverlayVisible(true);
    this.menu.setTouchVisible(this.touch);
  }

  // ---- demo / attract mode ---------------------------------------------
  startDemo() {
    this.state = AppState.DEMO;
    this._refreshUpdateNotice();
    this.audio.stopLoops();
    this.input.setEnabled(false);
    this.restartDemo();
    this.menu.hideOverlay();
    this.menu.setFlightOverlayVisible(true);
    this.menu.setTouchVisible(false);
    this.demoOverlay.classList.remove('hidden');
    this.demoOverlay.onpointerdown = () => this.demoTakeOver();
    window.addEventListener('keydown', this._demoKeyHandler);
  }

  // A fresh autopilot run on a new seed — the demo never stops, it just starts over.
  restartDemo() {
    this.demo.start({ mode: this.settings.get('controlMode'), seed: randomSeed() });
  }

  _endDemo() {
    this.demoOverlay.classList.add('hidden');
    this.demoOverlay.onpointerdown = null;
    window.removeEventListener('keydown', this._demoKeyHandler);
  }

  demoTakeOver() {
    if (this.state !== AppState.DEMO) return;
    this._endDemo();
    this.startRun(); // hand control to the player with a fresh run
  }

  demoToMenu() {
    if (this.state !== AppState.DEMO) return;
    this._endDemo();
    this.toMenu();
  }

  die() {
    this.state = AppState.DEAD;
    this.audio.crash();
    this.input.setEnabled(false);
    this.menu.setFlightOverlayVisible(false);
    this.menu.setTouchVisible(false);

    const score = this.game.scoreValue();
    const previousBest = this.runContext.daily
      ? SaveSystem.getRunDailyBest(this.runContext)
      : SaveSystem.getRunSeedBest(this.runContext);
    const result = SaveSystem.recordRun(this.runContext, score);
    const newBest = this.runContext.daily ? result.newDailyBest : result.newSeedBest;
    const s = this.game.score;

    this.menu.showDeath({
      score,
      newBest,
      context: this.runContext,
      previousBest,
      telemetry: {
        distance: s.distance,
        maxSpeed: s.maxSpeed,
        grazeTime: s.grazeTime,
        bestComboMultiplier: Math.min(COMBO_MULT_MAX, 1 + s.bestCombo * COMBO_MULT_PER),
      },
    });
    this._refreshUpdateNotice();
    this._checkForUpdate();
  }

  _refreshUpdateNotice() {
    this.menu.setUpdateReady?.(this.updateAvailable
      && (this.state === AppState.MENU || this.state === AppState.DEAD));
  }

  _checkForUpdate() {
    void this.swRegistration?.update().catch(() => {});
  }

  _registerServiceWorker() {
    void registerProductionServiceWorker({
      production: Boolean(import.meta.env?.PROD),
      base: import.meta.env?.BASE_URL || './',
      pageUrl: window.location.href,
      onUpdate: ready => {
        this.updateAvailable = ready;
        this._refreshUpdateNotice();
      },
    }).then(registration => { this.swRegistration = registration; })
      .catch(error => { this.serviceWorkerError = String(error); });
  }

  onConfirm() {
    if (this.state === AppState.MENU && this.menu.current === 'menu') this.startRun();
    else if (this.state === AppState.DEAD) this.retryRun();
    else if (this.state === AppState.PAUSED) this.resume();
    else if (this.state === AppState.DEMO) this.demoTakeOver();
  }

  retryRun() {
    if (this.runContext) this.startRun({ context: this.runContext });
  }

  // ---- settings ---------------------------------------------------------
  // What a settings binding is allowed to touch (see app/settingsBindings.js).
  settingsContext() {
    return {
      renderer: this.renderer,
      audio: this.audio,
      input: this.input,
      games: [this.game, this.demo],
      activeRunRules: () => ([AppState.RUNNING, AppState.PAUSED, AppState.DEAD].includes(this.state)
        ? this.runContext?.rules : null),
      setReducedMotion: (m) => this.setReducedMotion(m),
    };
  }

  // Toggle a body class so CSS can drop HUD pulse/flash animations when the
  // player has dialed motion down (reduced-motion accessibility).
  setReducedMotion(motion) {
    document.body.classList.toggle('reduced-motion', motion < 0.05);
  }

  onSettingChange(key, rawValue) {
    const value = this.settings.set(key, rawValue); // clamped/validated value
    applySetting(key, value, this.settingsContext(), true);
  }

  resetSettings() {
    this.settings.reset();
    applyAllSettings(this.settings, this.settingsContext());
    this.menu.refreshSettings();
  }

  dismissHelp() {
    if (!this.settings.get('helpSeen')) this.settings.set('helpSeen', true);
    this.menu.showFirstRunHelp(false);
  }

  startSeed() {
    const seed = parseSeed(element('seedInput').value);
    if (seed === null) {
      this.menu.setMenuMessage('Enter a nonzero whole seed from -2147483648 to 2147483647.');
      return;
    }
    this.runLinkError = '';
    this.menu.setMenuMessage('');
    this.startRun({ seed });
  }

  startSharedRun() {
    if (this.sharedContext) this.startRun({ context: this.sharedContext });
  }

  // ---- wiring -----------------------------------------------------------
  _wireUI() {
    bindClicks({
      play: () => { this.audio.blip(); this.startRun(); },
      demo: () => { this.audio.blip(); this.startDemo(); },
      daily: () => { this.audio.blip(); this.startRun({ daily: true }); },
      seedPlay: () => this.startSeed(),
      sharedPlay: () => this.startSharedRun(),
      helpSkip: () => this.dismissHelp(),
      settings: () => this.menu.showScreen('settings'),
      credits: () => this.menu.showScreen('credits'),
      settingsBack: () => this.toMenu(),
      settingsReset: () => this.resetSettings(),
      creditsBack: () => this.toMenu(),

      resume: () => this.resume(),
      pauseRestart: () => this.retryRun(),
      pauseMenu: () => this.toMenu(),
      touchPause: () => this.togglePause(),

      retry: () => this.retryRun(),
      deathMenu: () => this.toMenu(),
      share: () => this._copySeed(),
      shareResult: () => this._copyResult(),
    });

    this.input.bindTouch(element('touchLeft'), element('touchRight'));
    element('seedInput').addEventListener('keydown', (event) => {
      if (event.key === 'Enter') { event.preventDefault(); this.startSeed(); }
    });
  }

  async _copySeed() {
    await this._copy(makeRunLink(this.runContext, globalThis.location?.href ?? 'http://localhost/'));
  }

  // A compact, local, shareable result string (no backend). Captures the run's
  // headline facts so a player can paste their score/seed anywhere.
  _copyResult() {
    const s = this.game.score;
    const bestComboMult = Math.min(COMBO_MULT_MAX, 1 + s.bestCombo * COMBO_MULT_PER);
    const tag = this.runContext.daily ? `Daily ${this.runContext.dailyKey}` : `seed ${this.runContext.seed}`;
    const rules = this.runContext.rules;
    const text =
      `Cave9 — ${tag}\n` +
      `Rules ${rules.key}: ${rules.controlMode === 2 ? 'two thrusters' : 'one button'}, thrust ×${rules.thrustScale}, obstacles ${rules.landmarks ? 'on' : 'off'}\n` +
      `Score ${this.game.scoreValue()} · ${Math.floor(s.distance)}m · ${tierAt(s.distance)}\n` +
      `Max speed ${Math.round(s.maxSpeed)} · Graze ${s.grazeTime.toFixed(1)}s · Best combo ×${bestComboMult.toFixed(1)}\n` +
      makeRunLink(this.runContext, globalThis.location?.href ?? 'http://localhost/');
    return this._copy(text);
  }

  async _copy(text) {
    try {
      await navigator.clipboard.writeText(text);
      this.menu.setCopyStatus?.('Copied to clipboard.');
      this.audio.blip(880);
      return true;
    } catch {
      this.menu.setCopyStatus?.('Copy failed. Check clipboard permission and try again.');
      return false;
    }
  }

  _bindWindow() {
    window.addEventListener('resize', () => this.renderer.resize());
    document.addEventListener('visibilitychange', () => {
      if (document.hidden && this.state === AppState.RUNNING) this.togglePause();
    });
    this._portraitQuery?.addEventListener('change', (event) => {
      if (event.matches && this.state === AppState.RUNNING) this.togglePause();
    });
    const markInteract = () => { this.lastInteract = performance.now(); };
    window.addEventListener('pointerdown', markInteract);
    window.addEventListener('keydown', markInteract);
  }

  // ---- deterministic screenshot harness ---------------------------------
  // Test infrastructure, loaded on demand so it is code-split out of the chunk
  // players download. Driven from Playwright as window.__cave9.captureScenario;
  // page.evaluate awaits the returned promise.
  async captureScenario(opts = {}) {
    const { captureScenario } = await import('./app/CaptureHarness.js');
    return captureScenario(this, opts);
  }

  // Freeze a rendered frame so the loop keeps the WebGL canvas live for capture.
  holdCaptureFrame(game, hit, warn, orbit = null) {
    this._held = { game, hit, warn, orbit };
  }

  // Headless Chromium may throttle rAF independently of render cost. The
  // performance harness therefore stops the automatic scheduler and invokes
  // the frozen render directly with one monotonic wall clock.
  useExternalFrameDriver() { this.externalFrameDriver = true; }

  releaseExternalFrameDriver() {
    if (!this.externalFrameDriver) return;
    this.externalFrameDriver = false;
    this.lastTime = performance.now();
    requestAnimationFrame((t) => this.loop(t));
  }

  // ---- main loop --------------------------------------------------------
  loop(now) {
    const realDt = Math.min(0.1, (now - this.lastTime) / 1000);
    this.lastTime = now;
    this.input.update();
    this.debug.tick(realDt);

    switch (this.state) {
      case AppState.CAPTURE: this._holdFrame(); break;
      case AppState.RUNNING: this._stepRun(realDt); break;
      case AppState.DEMO: this._stepDemoRun(realDt); break;
      case AppState.MENU: this._stepMenu(realDt, now); break;
      default:
        // PAUSED / DEAD: hold the last frame
        this.session.presentHeld(this.game, this.state === AppState.DEAD ? 1 : 0);
    }

    if (!this.externalFrameDriver) requestAnimationFrame((t) => this.loop(t));
  }

  // The player's run: real input, and a crash ends both the frame and the run.
  _stepRun(realDt) {
    const crashed = this.session.simulate(
      this.game, realDt,
      (g) => {
        const thrust = this.input.sampleStep();
        g.player.lefton = thrust.left;
        g.player.righton = thrust.right;
      },
      () => CRASH_ENDS_FRAME,
    );
    this.session.present(this.game, this.session.hitOf(this.game, crashed));
    if (crashed) this.die();
  }

  // Attract mode: the autopilot flies, a crash starts a fresh run next frame,
  // and the HUD shows the AI's live score.
  _stepDemoRun(realDt) {
    this.session.simulate(
      this.demo, realDt,
      (g) => g.autopilot(),
      () => { this.restartDemo(); return CRASH_ENDS_FRAME; },
    );
    this.session.present(this.demo, this.session.hitOf(this.demo, false));
  }

  // Menu background: the same autopilot game drawn quietly. A crash restarts it
  // and the frame keeps spending its remaining steps on the fresh run.
  _stepMenu(realDt, now) {
    this.session.simulate(
      this.demo, realDt,
      (g) => g.autopilot(),
      () => { this.restartDemo(); return CRASH_CONTINUES_FRAME; },
    );
    this.session.presentIdle(this.demo);

    // Idle attract-mode only kicks in on the MAIN menu screen — never while
    // Settings or Credits are open (they keep state===MENU but change the
    // visible sub-screen). Fixes the demo hijacking those panels.
    if (this.menu.current === 'menu' && now - this.lastInteract > IDLE_DEMO_MS) {
      this.startDemo();
    }
  }

  // Frozen deterministic frame for the screenshot harness. We do NOT step the
  // sim, but we DO re-render every tick: with shake off and the bob phase pinned
  // to 0 every re-render is byte-identical, yet keeping the WebGL canvas live
  // means the compositor always sees the current frame rather than a stale or
  // empty buffer in headless Chromium.
  _holdFrame() {
    if (!this._held) return;
    this.renderer.cameraCtl.shakeEnabled = false;
    this.renderer.cameraCtl._t = 0;
    this.renderer.render(this._held.game, this._held.hit, this._held.warn);
    if (this._held.orbit) {
      this.renderer.renderOrbitPose(this._held.orbit.comp, this._held.orbit.angle);
    }
  }
}

if (typeof window !== 'undefined' && typeof document !== 'undefined') {
  const app = new GameApp();
  app.boot();

  // Exposed for automated runtime verification (e2e/preview checks).
  window.__cave9 = app;
  window.__cave9.AppState = AppState;
}
