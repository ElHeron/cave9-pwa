// Atmosphere — what the air does, as a property of PLACE.
//
// The corridor ends in black. That is a deliberate, tested readability invariant:
// the dark vanishing point is how a player reads depth and speed, and the landmark
// keep-out tube exists solely to never occlude it.
//
// The reference frames (docs/Inspiritation/) work the opposite way round: near-black
// mineral standing against a LIGHTER hazy depth. The formation is the silhouette and
// the cave behind it is the light. Against a black corridor that effect is
// unreachable — dark on dark is not a silhouette — which is why tuning landmark
// colours could never get there.
//
// So the haze is scoped to ROOMS. Fog colour can begin lifting gently as a
// physical chamber opens, while the fog planes keep following the established
// gameplay visibility profile. This makes early rooms legible without changing
// their draw distance or the corridor's black vanishing point.
//
// Lifting the fog colour rather than adding a glow plane matters:
//   * it is what fog is for, so it needs no blending tricks and cannot be occluded
//     wrongly or double-counted,
//   * everything already in the scene integrates automatically — walls, landmarks
//     and the far hole all resolve to the same haze,
//   * outside rooms it is exactly the old behaviour, bit for bit, so the flight
//     corridor's readability is untouched.
//
// This module is the ONLY writer of the scene's fog and background. Draw distance
// has two inputs (the difficulty sight curve and the player's brightness setting)
// and they compose here rather than fighting over `fog.far` from two places.

import * as THREE from 'three';
import { FOG_END } from '../core/constants.js';
import { VISIBILITY, visibilityAt } from './VisibilityProfile.js';

// Corridor: the original look. Black fog, black background.
export const CORRIDOR = Object.freeze({
  color: 0x000000,
  near: VISIBILITY.corridorNear,
  farScale: 1.0,
});

// Room: a cool, dim haze. Desaturated enough to read as depth behind rock,
// rather than a luminous plane.
export const ROOM = Object.freeze({
  color: 0x293444,
  near: VISIBILITY.roomNear,        // pushed out so near formations stay unfogged and dark
  farScale: VISIBILITY.roomFarScale,  // haze closes in, which is what makes the depth read as fill
});

// A physical early chamber colours the distant air before the style morph.
// The fog planes still use the styled room weight through visibilityAt().
export const EARLY_ROOM_COLOR_WEIGHT = 0.70;

const _a = new THREE.Color();
const _b = new THREE.Color();

export class Atmosphere {
  constructor(scene) {
    this.scene = scene;
    this.fog = new THREE.Fog(CORRIDOR.color, CORRIDOR.near, FOG_END);
    this.background = new THREE.Color(CORRIDOR.color);
    scene.fog = this.fog;
    scene.background = this.background;

    this.readability = true;
    this.brightness = 1.0;
    this.sight = 1.0; // difficulty-driven draw distance multiplier
    this.roomT = 0;   // visibility weight: controls fog near/far only
    this.colorT = 0;  // colour weight: may reveal a physical early room sooner

    this.apply();
  }

  setReadability(on) { this.readability = !!on; this.apply(); }
  setBrightness(b) { this.brightness = b; this.apply(); }

  // Difficulty-driven draw distance: sight grows with depth/speed so the player
  // keeps a constant reaction window (see Difficulty.js / BALANCE.md).
  setSight(mul) {
    if (Math.abs(mul - this.sight) < 1e-3) return;
    this.sight = mul;
    this.apply();
  }

  // Visibility remains tied to the styled room profile. Optional colorT lets
  // physical room presence tint the air earlier without moving either fog plane.
  setRoom(t, colorT = t) {
    const v = Math.min(1, Math.max(0, t || 0));
    const c = Math.min(1, Math.max(0, colorT || 0));
    if (Math.abs(v - this.roomT) < 1e-3 && Math.abs(c - this.colorT) < 1e-3) return;
    this.roomT = v;
    this.colorT = c;
    this.apply();
  }

  apply() {
    const t = this.roomT;
    const visibility = visibilityAt({ sight: this.sight, room: t, readability: this.readability });
    this.fog.near = visibility.near;
    this.fog.far = visibility.far;

    _a.setHex(CORRIDOR.color);
    _b.setHex(ROOM.color);
    this.fog.color.copy(_a).lerp(_b, this.colorT);
    // The background is the same haze, so the far hole and the walls resolve to
    // one value instead of the hole staying a black disc inside a grey cave.
    this.background.copy(this.fog.color);
  }
}
