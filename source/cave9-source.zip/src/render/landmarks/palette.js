// Landmark colour palettes.
//
// Landmark tone is BAKED INTO VERTEX COLOURS rather than carried by per-form
// materials, so a whole formation stays at two draw calls. Every ramp here runs
// dark wet contact → mineral body → light edge, which is what makes a form read
// by silhouette and relief instead of by glowing pale (a pale form reads as a
// Fremdkörper stuck onto the cave rather than grown out of it).

// VALUE RANGE — the thing that decides whether a formation reads as cave rock.
//
// The reference frames (docs/Inspiritation/) are near-black mineral silhouetted
// against a LIGHTER hazy vanishing point, with brightness only on thin crest
// highlights. The formation is the dark shape; the cave behind it is the light.
//
// An earlier pass had this inverted — pale bodies over a dark cave — and the
// forms read as bulbous tusks stuck onto the rock instead of grown from it. So:
// bodies stay well below the wall's own luminance, and only the edge crest is
// allowed to be bright. If a form ever looks pale again, it is these numbers.
const EDGE = [0.34, 0.39, 0.47]; // the single bright value: a lit crest, nothing else

// Deterministic per-form rock palette, nudged by the form's `shade` (0..1) so a
// composition is not one uniform tone.
export function rockColors(shade) {
  return {
    cBase: [0.030 + 0.010 * shade, 0.035 + 0.011 * shade, 0.043 + 0.013 * shade], // wet contact
    cBody: [0.070 + 0.025 * shade, 0.078 + 0.027 * shade, 0.092 + 0.030 * shade], // cave-rock body
    cTip: [0.125 + 0.040 * shade, 0.140 + 0.042 * shade, 0.165 + 0.045 * shade],  // restrained crest
  };
}

// Obsidian shard palette: a near-black contact base, two barely-separated cool
// inner planes (the fake internal colour-bleed between neighbouring facets) and
// the one lit edge crest. Shades above 0.5 lean violet, below lean blue.
export function crystalColors(shade) {
  const violet = shade > 0.5;
  return {
    cBase: [0.012, 0.015, 0.022],                                  // obsidian contact
    cInner: violet ? [0.050, 0.035, 0.072] : [0.035, 0.045, 0.070], // cool inner plane
    cInner2: violet ? [0.075, 0.055, 0.110] : [0.055, 0.070, 0.105], // 2nd inner plane
    cEdge: EDGE,                                                 // lit edge crest
  };
}
