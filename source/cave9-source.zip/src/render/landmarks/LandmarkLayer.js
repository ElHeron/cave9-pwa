// LandmarkLayer — the scene-graph side of visible landmarks (Phase 4G / M2).
//
// Owns everything THREE about landmarks: the two shared materials, the group
// they hang under, and the per-room geometry cache. It asks core/Landmarks.js
// which compositions are in view (a PURE read of the cave + seed — no sim,
// collision or RNG state is touched), grows each new one exactly once via
// LandmarkMeshBuilder, and keeps a small LRU of built rooms.
//
// Rooms are ROOM_SPACING apart and the view spans roughly one, so a build is
// rare and the result is a tiny static world-space mesh group per room.

import * as THREE from 'three';
import { compositionSurfaceComplete, visibleRoomRange } from '../../core/Landmarks.js';
import { buildCompositionAccums, groupForms } from './LandmarkMeshBuilder.js';
import { applyCaveMineral, applyCaveRim } from '../materials/caveMineral.js';
import {
  applyLandmarkSurface, setCaveSurfaceUniforms,
} from '../materials/caveSurface.js';
import { applySpeedWarp } from '../materials/speedWarp.js';
import { LandmarkSurfaceProjector } from './surfaceProjection.js';

// How many built rooms to keep around. Two or three are ever live (the one in
// view plus the one just behind); the rest is slack so turning around or a small
// z jitter does not thrash the builder.
export const MAX_CACHED_ROOMS = 4;
export const MAX_CACHED_GEOMETRY_BYTES = 1024 * 1024;
export const LANDMARK_PREWARM_AHEAD_METERS = 96;

const GRAIN_REPEAT = 2.4;

// Independent roots occupy disjoint ranges of the single rock mesh. Retaining
// these ranges lets a live-wall revision refresh only changed claws, without
// adding draw calls, a second room cache, or stale collision geometry.
function rootMeshParts(comp, geometry) {
  if (comp.typeName !== 'branching' || !comp.rootSurfaces?.length) return null;
  let vertex = 0, index = 0;
  const parts = [];
  for (const pieces of groupForms(comp)) {
    const surface = comp.rootSurfaces.find((s) => s.gid === pieces[0].gid);
    if (!surface) return null;
    parts.push({ surface, pieces, shade: pieces[0].shade || 0, vertex, index,
      vertices: surface.visibleVertexCount, indices: surface.visibleTriangles.length });
    vertex += surface.visibleVertexCount;
    index += surface.visibleTriangles.length;
  }
  return vertex === geometry.attributes.position?.count && index === geometry.index?.count
    ? parts : null;
}

function refreshRootMesh(group, comp, projector) {
  const previous = group.userData.rootParts;
  if (!previous || group.children.length !== 1) return null;
  const geometry = group.children[0].geometry;
  const next = rootMeshParts(comp, geometry);
  if (!next || next.length !== previous.length) return null;
  if (!next.every((part, i) => {
    const old = previous[i];
    return part.surface.gid === old.surface.gid && part.vertex === old.vertex
      && part.index === old.index && part.vertices === old.vertices
      && part.indices === old.indices;
  })) return null;
  const updates = [];
  // Validate every replacement before touching the retained buffers. A topology
  // or attribute-layout change falls back to the ordinary complete rebuild.
  for (let i = 0; i < next.length; i++) {
    const part = next[i], old = previous[i];
    if (part.surface === old.surface && part.shade === old.shade) continue;
    const { rock } = buildCompositionAccums({ ...comp, pieces: part.pieces,
      rootChartPieces: comp.pieces,
      rootSurfaces: [part.surface] });
    const fresh = rock.toGeometry(projector);
    const names = Object.keys(geometry.attributes);
    const compatible = fresh.index?.count === part.indices
      && names.length === Object.keys(fresh.attributes).length
      && names.every((name) => {
        const a = geometry.attributes[name], b = fresh.attributes[name];
        return b && a.itemSize === b.itemSize && a.normalized === b.normalized
          && a.array.constructor === b.array.constructor && b.count === part.vertices;
      })
      && fresh.index.array.every((value, j) =>
        geometry.index.array[part.index + j] === value + part.vertex);
    if (!compatible) {
      fresh.dispose();
      for (const update of updates) update.fresh.dispose();
      return null;
    }
    updates.push({ part, fresh });
  }
  for (const { part, fresh } of updates) {
    for (const [name, source] of Object.entries(fresh.attributes)) {
      const target = geometry.attributes[name];
      const offset = part.vertex * target.itemSize;
      target.array.set(source.array, offset);
      target.addUpdateRange(offset, source.array.length);
      target.needsUpdate = true;
    }
    fresh.dispose();
  }
  if (updates.length) {
    geometry.boundingBox = null;
    geometry.boundingSphere = null;
  }
  group.userData.rootParts = next;
  return updates.length;
}

export function geometryByteLength(geometry) {
  if (!geometry) return 0;
  let bytes = geometry.index?.array?.byteLength || 0;
  for (const attribute of Object.values(geometry.attributes || {})) {
    bytes += attribute?.array?.byteLength || 0;
  }
  return bytes;
}

export function compositionFrontDepth(comp) {
  const pieces = Array.isArray(comp?.pieces) ? comp.pieces : [];
  if (!pieces.length) return Number(comp?.z);
  let front = Infinity;
  for (const piece of pieces) {
    const axialHalfLength = Math.abs(Number(piece.dz) || 0) * (Number(piece.length) || 0) / 2;
    front = Math.min(front, Number(piece.cz) - axialHalfLength - (Number(piece.radius) || 0));
  }
  return front;
}

// One tiny deterministic mask replaces the old procedural fragment FBM. UVs
// repeat it across the generated meshes; sparse soft islands become emissive
// pockets without any per-pixel noise loop or runtime randomness.
export function makeEmberMask(size = 64, seed = 0x9e3779b9) {
  const data = new Uint8Array(size * size * 4);
  let state = seed >>> 0;
  const random = () => {
    state = (Math.imul(state, 1664525) + 1013904223) >>> 0;
    return state / 0x100000000;
  };
  const pockets = Array.from({ length: 20 }, () => ({
    x: random() * size,
    y: random() * size,
    r: size * (0.032 + random() * 0.038),
    hot: 0.55 + random() * 0.45,
  }));
  for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) {
    let value = 0;
    for (const p of pockets) {
      const dx0 = Math.abs(x - p.x), dy0 = Math.abs(y - p.y);
      const dx = Math.min(dx0, size - dx0), dy = Math.min(dy0, size - dy0);
      const d = Math.hypot(dx, dy) / p.r;
      if (d < 1) value = Math.max(value, (1 - d * d) ** 2 * p.hot);
    }
    const v = Math.round(Math.min(1, value) * 255);
    const i = (y * size + x) * 4;
    data[i] = data[i + 1] = data[i + 2] = v;
    data[i + 3] = 255;
  }
  return data;
}

function emberTexture() {
  const size = 64;
  const tex = new THREE.DataTexture(makeEmberMask(size), size, size, THREE.RGBAFormat);
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  tex.magFilter = THREE.LinearFilter;
  tex.minFilter = THREE.LinearMipmapLinearFilter;
  tex.generateMipmaps = true;
  tex.colorSpace = THREE.NoColorSpace;
  tex.needsUpdate = true;
  return tex;
}

export class LandmarkLayer {
  constructor(scene, { softwareRenderer = false } = {}) {
    this.softwareRenderer = !!softwareRenderer;
    // WET ROCK (branching limbs): vertex-coloured, textured with the
    // cave wall, smooth-shaded so the vertex crag carries micro-relief. color=white
    // so the baked vertex gradient (dark wet base → mineral body → light edge)
    // shows fully; DoubleSide keeps the closed tubes robust to winding.
    // The emissive is a floor, not a look: just enough that a silhouette does not
    // dissolve into the black far hole. It used to be strong enough to lift the
    // whole form off the rock, which is what made formations read as pale objects
    // placed in the cave rather than as part of it.
    const RockMaterial = this.softwareRenderer ? THREE.MeshLambertMaterial : THREE.MeshStandardMaterial;
    this.rockMat = new RockMaterial({
      color: 0xffffff, vertexColors: true,
      ...(!this.softwareRenderer && { roughness: 0.78, metalness: 0.0 }),
      emissive: 0x07090c, emissiveIntensity: 1.0, flatShading: false, side: THREE.FrontSide,
    });
    // FACETTED OBSIDIAN (crystal shards): flat-shaded for hard facets, no env
    // reflection, slightly glossy so the head-light catches crisp edge glints. The
    // colour-bleed (dark obsidian base → cool blue/violet inner planes → light
    // edges) is baked into vertex colours — no neon, no transparency.
    // Obsidian: low roughness so existing directional lights can distinguish
    // broad planes while a small neutral rim preserves the sharpest edges.
    const CrystalMaterial = this.softwareRenderer ? THREE.MeshLambertMaterial : THREE.MeshStandardMaterial;
    this.crystalMat = new CrystalMaterial({
      color: 0xffffff, vertexColors: true,
      ...(!this.softwareRenderer && { roughness: 0.22, metalness: 0.20 }),
      emissive: 0x07090d, emissiveIntensity: 1.0, flatShading: true, side: THREE.FrontSide,
    });
    let rockMineral = null;
    this.surfaceUniforms = { rock: null, crystal: null };
    if (this.softwareRenderer) {
      applyCaveRim(this.rockMat, { rimCurve: 'quartic', rimStrength: 0.22 });
      applyCaveRim(this.crystalMat, { rimCurve: 'linear', rimStrength: 0.25 });
    } else {
      rockMineral = applyCaveMineral(this.rockMat, {
        cragStrength: 0.75, cragScale: 0.30,
        emberThreshold: 0.50, emberStrength: 1.6,
        rimPower: 4.5, rimStrength: 0.22,
      });
      applyCaveMineral(this.crystalMat, {
        cragStrength: 0.22, cragScale: 0.55,
        emberEnabled: false,
        rimPower: 0.9, rimStrength: 0.25,
      });
      this.surfaceUniforms.rock = applyLandmarkSurface(this.rockMat, { family: 'branching' });
      this.surfaceUniforms.crystal = applyLandmarkSurface(this.crystalMat, { family: 'crystal' });
    }
    this.speedWarp = [applySpeedWarp(this.rockMat), applySpeedWarp(this.crystalMat)];
    this.emberMask = this.softwareRenderer ? null : emberTexture();
    this.grainTex = null;
    this.surfaceArrayActive = false;
    if (rockMineral) rockMineral.uEmberMask.value = this.emberMask;
    // Explicit material property so resource instrumentation can account for
    // this custom-uniform texture just like standard material maps.
    if (this.emberMask) this.rockMat.emberMask = this.emberMask;

    this.group = new THREE.Group();
    scene.add(this.group);


    this.enabled = true;
    // Compositions (WHERE a formation is) are memoized in core; this map caches
    // the grown GEOMETRY (what it looks like) so a room is meshed only once.
    this.built = new Map(); // surface-revision key → { group, key, roomKey, seen }
    this._frame = 0;
    this.geometryBytes = 0;
    this.metrics = {
      builds: 0,
      evictions: 0,
      revisionReplacements: 0,
      revisionUpdates: 0,
      updatedRootForms: 0,
      disposedGeometries: 0,
      textureApplications: 0,
      textureReuses: 0,
      textureSkips: 0,
      peakRooms: 0,
      peakGeometryBytes: 0,
      prewarmBuilds: 0,
      coldVisibleBuilds: 0,
      prewarmActivations: 0,
      programPrewarms: 0,
      programPrewarmFailures: 0,
    };
    this._disposed = false;
  }

  resourceMetrics() {
    return Object.freeze({
      rooms: this.built.size,
      maxRooms: MAX_CACHED_ROOMS,
      geometryBytes: this.geometryBytes,
      maxGeometryBytes: MAX_CACHED_GEOMETRY_BYTES,
      overBudget: this.built.size > MAX_CACHED_ROOMS
        || this.geometryBytes > MAX_CACHED_GEOMETRY_BYTES,
      ...this.metrics,
    });
  }

  setEnabled(on) {
    this.enabled = !!on;
    if (!this.enabled) {
      for (const e of this.built.values()) e.group.visible = false;
    }
  }

  setSpeedFx(amount) {
    for (const u of this.speedWarp) u.value = amount;
  }

  // The generated 256 px grain is already the exact runtime asset. Loading it
  // directly avoids decoding an old 2K source and allocating a canvas merely to
  // downscale it again. Missing texture remains a vertex-colour-only fallback.
  applyTextures({ grainTex, anisotropy = 1 } = {}) {
    const mat = this.rockMat;
    if (this.softwareRenderer) {
      mat.map = null;
      mat.normalMap = null;
      if (grainTex?.isTexture) this.metrics.textureSkips++;
      for (const material of [this.rockMat, this.crystalMat]) material.needsUpdate = true;
      return;
    }
    if (grainTex?.isTexture) {
      if (this.grainTex === grainTex
        && mat.map === (this.surfaceArrayActive ? null : grainTex)) {
        this.metrics.textureReuses++;
        return;
      }
      this.grainTex = grainTex;
      grainTex.wrapS = grainTex.wrapT = THREE.MirroredRepeatWrapping;
      grainTex.colorSpace = THREE.SRGBColorSpace;
      grainTex.anisotropy = Math.max(1, Math.min(4, anisotropy));
      grainTex.repeat.set(GRAIN_REPEAT, GRAIN_REPEAT);
      grainTex.generateMipmaps = true;
      grainTex.needsUpdate = true;
      // The array atlas already supplies the colour grain. A second 2.4x UV
      // sample would lay an unrelated pattern over the shared wall contact.
      mat.map = this.surfaceArrayActive ? null : grainTex;
      this.metrics.textureApplications++;
    }
    // Mid-frequency landmark relief is carried by the two-octave vertex crag
    // and by real silhouette geometry. The landmark path adds no normal-map
    // sampler; the hardware cave wall separately owns its generated normal /
    // height pair and the near-field colour-detail sample.
    mat.normalMap = null;
    for (const material of [this.rockMat, this.crystalMat]) material.needsUpdate = true;
  }

  // Bind the common cave-surface array to both landmark materials. The renderer
  // owns loading/capability checks; this layer only enables a pre-installed
  // shader patch once a valid WebGL2 texture and manifest have arrived.
  applySurfaceTexture({ texture = null, manifest = null, strength = 1 } = {}) {
    if (this.softwareRenderer || !texture?.isTexture) {
      this.surfaceArrayActive = false;
      if (!this.softwareRenderer && this.rockMat.map !== this.grainTex) {
        this.rockMat.map = this.grainTex;
        this.rockMat.needsUpdate = true;
      }
      for (const material of [this.rockMat, this.crystalMat]) {
        if (material.defines?.LANDMARK_SURFACE_ARRAY) {
          const { LANDMARK_SURFACE_ARRAY: _removed, ...defines } = material.defines || {};
          material.defines = defines;
          material.needsUpdate = true;
        }
      }
      setCaveSurfaceUniforms(this.surfaceUniforms.rock, { texture: null, strength: 0 });
      setCaveSurfaceUniforms(this.surfaceUniforms.crystal, { texture: null, strength: 0 });
      return false;
    }
    const means = Array.isArray(manifest?.layers)
      ? manifest.layers.map((layer) => layer.meanLinear || [0.18, 0.18, 0.18])
      : undefined;
    this.surfaceArrayActive = true;
    if (this.rockMat.map) {
      this.rockMat.map = null;
      this.rockMat.needsUpdate = true;
    }
    for (const [material, uniforms] of [
      [this.rockMat, this.surfaceUniforms.rock],
      [this.crystalMat, this.surfaceUniforms.crystal],
    ]) {
      material.defines = { ...(material.defines || {}), LANDMARK_SURFACE_ARRAY: 1 };
      material.needsUpdate = true;
      setCaveSurfaceUniforms(uniforms, { texture, means, strength });
    }
    return true;
  }

  // Ensure each in-view composition is built + visible; hide the rest and evict
  // the oldest off-screen ones so the cache stays small.
  update(cave, playerZ, range, seed, cache, forcedType = null,
    prewarmRange = range) {
    if (!this.enabled) return;
    if (!cache) throw new Error('LandmarkLayer requires the active Game landmark cache');
    for (const uniforms of Object.values(this.surfaceUniforms)) {
      if (uniforms?.uLandmarkSurfaceSeed) uniforms.uLandmarkSurfaceSeed.value = seed;
    }
    const visibleComps = cache.landmarksInView(cave, playerZ, range, seed, undefined, forcedType)
      .filter((comp) => compositionFrontDepth(comp) <= playerZ + range);
    const warmComps = [...visibleComps];
    if (prewarmRange > range) {
      const { kFrom, kTo } = visibleRoomRange(playerZ, prewarmRange);
      for (let k = kFrom; k <= kTo; k++) {
        if (!compositionSurfaceComplete(cave, k)) continue;
        const comp = cache.compositionAt(seed, cave, k, forcedType);
        if (comp && compositionFrontDepth(comp) <= playerZ + prewarmRange
          && !warmComps.includes(comp)) warmComps.push(comp);
      }
    }
    const visibleRoomKeys = new Set(visibleComps.map((comp) =>
      `${seed}:${comp.k}:${comp.typeName}:${comp.surfaceRevision}`));
    const comps = [...new Map([...visibleComps, ...warmComps].map((comp) => [
      `${seed}:${comp.k}:${comp.typeName}:${comp.surfaceRevision}`, comp,
    ])).values()];
    this._frame++;

    const live = new Set();
    for (const comp of comps) {
      const roomKey = `${seed}:${comp.k}:${comp.typeName}`;
      const key = `${roomKey}:${comp.surfaceRevision}`;
      const visible = visibleRoomKeys.has(key);
      live.add(key);
      let e = this.built.get(key);
      if (!e) {
        for (const old of this.built.values()) {
          if (old.roomKey !== roomKey) continue;
          const updated = refreshRootMesh(old.group, comp, old.projector);
          if (updated === null) break;
          this.built.delete(old.key);
          old.key = key;
          this.built.set(key, old);
          e = old;
          this.metrics.revisionUpdates++;
          this.metrics.updatedRootForms += updated;
          break;
        }
      }
      if (!e) {
        // A long formation can become visible while the last wall rings are
        // still entering the live buffer. Core then issues a new composition
        // revision. Replace the previous GPU geometry immediately so rendering,
        // collision, warning and capture keep describing the same surface.
        for (const old of [...this.built.values()]) {
          if (old.roomKey === roomKey && old.key !== key) {
            this.metrics.revisionReplacements++;
            this._evict(old);
          }
        }
        const projector = this.softwareRenderer ? null
          : new LandmarkSurfaceProjector(seed, comp.k);
        const group = this._buildGroup(comp, projector);
        const geometryBytes = group.children.reduce(
          (sum, child) => sum + geometryByteLength(child.geometry), 0);
        // Make room before publishing the new entry. Geometry has only been
        // built on the CPU at this point; it has not been attached/uploaded, so
        // the retained scene cache never transiently exceeds four rooms or the
        // byte budget merely because a fifth room entered view.
        const replaceable = [...this.built.values()]
          .filter((old) => !live.has(old.key))
          .sort((a, b) => a.seen - b.seen);
        while ((this.built.size + 1 > MAX_CACHED_ROOMS
          || this.geometryBytes + geometryBytes > MAX_CACHED_GEOMETRY_BYTES)
          && replaceable.length) {
          this._evict(replaceable.shift());
        }
        e = { group, projector, geometryBytes, key, roomKey, seen: 0, disposed: false,
          prewarmed: !visible, wasVisible: false };
        this.built.set(key, e);
        this.geometryBytes += geometryBytes;
        this.metrics.builds++;
        if (visible) this.metrics.coldVisibleBuilds++;
        else this.metrics.prewarmBuilds++;
        this.metrics.peakRooms = Math.max(this.metrics.peakRooms, this.built.size);
        this.metrics.peakGeometryBytes = Math.max(
          this.metrics.peakGeometryBytes, this.geometryBytes);
        this.group.add(e.group);
      }
      if (visible && e.prewarmed && !e.wasVisible) this.metrics.prewarmActivations++;
      e.group.visible = visible;
      e.wasVisible ||= visible;
      e.seen = this._frame;
    }
    for (const e of this.built.values()) if (!live.has(e.key)) e.group.visible = false;

    const stale = [...this.built.values()]
      .filter((e) => !live.has(e.key))
      .sort((a, b) => a.seen - b.seen);
    while ((this.built.size > MAX_CACHED_ROOMS
      || this.geometryBytes > MAX_CACHED_GEOMETRY_BYTES) && stale.length) {
      this._evict(stale.shift());
    }
  }

  _buildGroup(comp, projector = null) {
    const { rock, crystal } = buildCompositionAccums(comp);
    const group = new THREE.Group();
    for (const [acc, mat] of [[rock, this.rockMat], [crystal, this.crystalMat]]) {
      if (acc.empty()) continue;
      const m = new THREE.Mesh(acc.toGeometry(projector), mat);
      m.frustumCulled = false;
      group.add(m);
    }
    if (group.children.length === 1) {
      group.userData.rootParts = rootMeshParts(comp, group.children[0].geometry);
    }
    return group;
  }

  // Compile hidden prewarm groups before they enter the visible fog range.
  // Visibility is restored in finally so a driver/compiler exception can never
  // leak a future room into the current frame.
  prepareHiddenPrograms(compile) {
    if (typeof compile !== 'function') return;
    for (const entry of this.built.values()) {
      if (!entry.prewarmed || entry.wasVisible || entry.programPrepared) continue;
      const visible = entry.group.visible;
      try {
        entry.group.visible = true;
        compile(entry.group);
        entry.programPrepared = true;
        this.metrics.programPrewarms++;
      } catch {
        this.metrics.programPrewarmFailures++;
      } finally {
        entry.group.visible = visible;
      }
    }
  }

  _evict(entry) {
    if (!entry || entry.disposed || this.built.get(entry.key) !== entry) return false;
    entry.disposed = true;
    this.group.remove(entry.group);
    for (const m of entry.group.children) if (m.geometry) {
      m.geometry.dispose();
      this.metrics.disposedGeometries++;
    }
    this.built.delete(entry.key);
    entry.projector?.dispose();
    this.geometryBytes = Math.max(0, this.geometryBytes - entry.geometryBytes);
    this.metrics.evictions++;
    return true;
  }

  dispose() {
    if (this._disposed) return;
    this._disposed = true;
    for (const entry of [...this.built.values()]) this._evict(entry);
    this.group.removeFromParent();
    const grain = this.grainTex;
    grain?.dispose?.();
    this.emberMask?.dispose?.();
    this.rockMat.dispose();
    this.crystalMat.dispose();
  }
}
