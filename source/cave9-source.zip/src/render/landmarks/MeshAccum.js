// MeshAccum — a growable position/colour/uv/index buffer.
//
// One accumulator per MATERIAL per composition, so a whole landmark formation
// costs at most two draw calls. The geometry builders (see primitives.js and
// LandmarkMeshBuilder.js) only ever push into an accumulator; nothing in this
// file knows what a landmark is, which keeps the builders unit-testable.

import * as THREE from 'three';
import { landmarkBodyChartOffset } from './surfaceProjection.js';

export class MeshAccum {
  constructor() { this.p = []; this.c = []; this.u = []; this.i = []; this.contact = []; this.family = []; this.chart = []; }

  vcount() { return this.p.length / 3; }

  vert(x, y, z, col, u = 0, v = 0, contact = 1, family = 0, chart = null) {
    this.p.push(x, y, z); this.c.push(col[0], col[1], col[2]); this.u.push(u, v);
    this.contact.push(contact); this.family.push(family); this.chart.push(chart);
    return this.p.length / 3 - 1;
  }

  tri(a, b, c) { this.i.push(a, b, c); }

  quad(a, b, c, d) { this.i.push(a, b, c, a, c, d); }

  empty() { return this.i.length === 0; }

  toGeometry(projector = null) {
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(this.p, 3));
    g.setAttribute('color', new THREE.Float32BufferAttribute(this.c, 3));
    g.setAttribute('uv', new THREE.Float32BufferAttribute(this.u, 2));
    if (projector) {
      const local = new Float32Array(this.vcount() * 4);
      const chartOffset = new Float32Array(this.vcount());
      const chartCache = new Map();
      for (let i = 0; i < this.vcount(); i++) {
        const at = i * 3;
        const p = projector.project({ x: this.p[at], y: this.p[at + 1], z: this.p[at + 2] },
          this.contact[i]);
        local.set([p.axialDepth, p.localRight, p.localUp, p.contact], i * 4);
        chartOffset[i] = landmarkBodyChartOffset(projector, this.chart[i], chartCache);
      }
      g.setAttribute('landmarkSurfaceLocal', new THREE.BufferAttribute(local, 4));
      g.setAttribute('landmarkSurfaceFamily', new THREE.Float32BufferAttribute(this.family, 1));
      g.setAttribute('landmarkBodyChartOffset', new THREE.BufferAttribute(chartOffset, 1));
    }
    g.setIndex(this.i);
    g.computeVertexNormals();
    return g;
  }
}
