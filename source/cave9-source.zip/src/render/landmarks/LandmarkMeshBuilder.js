// LandmarkMeshBuilder — turns a deterministic landmark composition (the pure
// skeleton from core/Landmarks.js) into drawable geometry.
//
// Core decides both safe placement and the final RootSurface/SlabHull world
// positions consumed by collision. This module assigns colour, UVs and hard
// face normals to those same visible triangles (see primitives.js).
//
// The split matters because the skeleton carries the guarantees the game depends
// on — nothing intrudes the central no-entry tube, and the same (seed, room)
// always produces the same formation. Geometry may be re-art-directed freely as
// long as it stays inside the skeleton's clamps.
//
// Everything here is deterministic: no Math.random, no frame state. The same
// composition always yields byte-identical buffers.

import { MeshAccum } from './MeshAccum.js';
import { buildTube, buildSlabHull, lerp3 } from './primitives.js';
import { buildRootSurface } from '../../core/landmarks/RootSurface.js';
import { slabHullForPiece } from '../../core/landmarks/SlabHull.js';
import { rockColors, crystalColors } from './palette.js';

// Group a composition's pieces into forms (one array per `gid`), each sorted
// along the form by `node`. Pieces without a gid become their own single-piece
// form, keyed negatively so they can never collide with a real gid.
export function groupForms(comp) {
  const groups = new Map();
  for (let i = 0; i < comp.pieces.length; i++) {
    const p = comp.pieces[i];
    const id = p.gid == null ? -1 - i : p.gid;
    let g = groups.get(id);
    if (!g) { g = []; groups.set(id, g); }
    g.push(p);
  }
  const forms = [...groups.values()];
  for (const g of forms) g.sort((a, b) => (a.node || 0) - (b.node || 0));
  return forms;
}

// Grow a curved tapered TUBE through a form's segment chain. Branching limbs
// use a gently faceted, asymmetric oval that stays inside every Core capsule.
export function growTubeForm(acc, comp, pieces, kind, shade) {
  const branching = comp.typeName === 'branching' && kind === 'limb';
  if (branching) {
    // Core is the one geometric authority. Synthetic render fixtures that do
    // not pass through compositionAt use the same pure helper directly.
    const surface = comp.rootSurfaces?.find((entry) => entry.gid === pieces[0].gid)
      || buildRootSurface(comp, pieces);
    const parent = pieces[0].parentGid
      ? (comp.rootChartPieces || comp.pieces).find((p) => p.gid === pieces[0].parentGid)
      : null;
    const cols = rockColors(parent?.shade ?? shade);
    const offset = acc.vcount();
    // Core's first sweep ring is the exact wall footprint. The centreline
    // stations only supply a material chart; no visible position is changed.
    const first = pieces[0];
    const chartStations = rootChartStations(comp).get(first.gid);
    const ringWidth = (surface.visibleVertexCount - 1) / chartStations.length;
    if (!Number.isInteger(ringWidth)) throw new Error('RootSurface chart ring layout changed');
    for (let i = 0; i < surface.visibleVertexCount; i++) {
      const k = i * 3, u = i * 2, tf = surface.along[i];
      const bodyAlong = first.parentGid ? (first.parentAlong ?? 0.25)
        + (1 - (first.parentAlong ?? 0.25)) * tf : tf;
      const color = bodyAlong < 0.5 ? lerp3(cols.cBase, cols.cBody, bodyAlong * 2)
        : lerp3(cols.cBody, cols.cTip, (bodyAlong - 0.5) * 2);
      const contact = first.parentGid ? (first.parentContact ?? 1)
        + (1 - (first.parentContact ?? 1)) * tf : Math.min(1, tf * 4);
      acc.vert(surface.vertices[k], surface.vertices[k + 1], surface.vertices[k + 2],
        color, surface.uvs[u], surface.uvs[u + 1], contact, 0,
        chartStations[Math.min(chartStations.length - 1, Math.floor(i / ringWidth))]);
    }
    for (let i = 0; i < surface.visibleTriangles.length; i += 3) {
      acc.tri(offset + surface.visibleTriangles[i],
        offset + surface.visibleTriangles[i + 1],
        offset + surface.visibleTriangles[i + 2]);
    }
    return;
  }
  const pts = [];
  const p0 = pieces[0], hl0 = p0.length / 2;
  pts.push({ pos: { x: p0.cx - p0.dx * hl0, y: p0.cy - p0.dy * hl0, z: p0.cz - p0.dz * hl0 }, r: p0.radius });
  for (const p of pieces) {
    const hl = p.length / 2;
    pts.push({ pos: { x: p.cx + p.dx * hl, y: p.cy + p.dy * hl, z: p.cz + p.dz * hl },
      r: p === p0 && p.wallBodyRadius != null ? p.wallBodyRadius : p.radius });
  }
  // Buttress roots need a genuinely pointed reach: a half-radius terminal ring
  // still presents as a dark circular pipe cap in the Hero view. Ribs retain
  // the broader rounded termination used by their legacy comparison fixture.
  pts[pts.length - 1].r *= kind === 'limb' ? 0.10 : 0.55;
  const cols = rockColors(shade);
  buildTube(acc, pts, {
    radial: kind === 'rib' ? 9 : branching ? 16 : 8,
    flat: kind === 'rib' ? 0.55 : branching ? 0.76 : 1.0,
    rootContour: branching,
    contourPhase: Math.PI * (1.5 + ((pieces[0].clawIndex || 0) % 3 - 1) / 4),
    // No renderer-only flare: the first Core capsules provide the shoulder.
    baseBoost: 0,
    gnarl: 0,
    cBase: cols.cBase, cBody: cols.cBody, cTip: cols.cTip,
    surfaceFamily: comp.typeName === 'coiling' ? 2 : 0,
  });
}

// One parent station object is shared by the trunk ring and child base ring.
// Partial refresh supplies full rootChartPieces, preserving the same ancestry.
const rootChartContexts = new WeakMap();
function rootChartStations(comp) {
  let context = rootChartContexts.get(comp);
  if (context) return context;
  context = new Map();
  const forms = groupForms({ pieces: comp.rootChartPieces || comp.pieces });
  const pending = new Map(forms.map((form) => [form[0].gid, form]));
  const build = (gid) => {
    if (context.has(gid)) return context.get(gid);
    const form = pending.get(gid);
    if (!form) throw new Error('Root chart requires its parent form');
    const first = form[0], half = first.length / 2;
    const base = first.parentGid ? build(first.parentGid)[first.parentNode]
      : { point: { x: first.cx - first.dx * half, y: first.cy - first.dy * half,
        z: first.cz - first.dz * half }, previous: null };
    const stations = [base];
    for (const piece of form) {
      const h = piece.length / 2;
      stations.push({ point: { x: piece.cx + piece.dx * h,
        y: piece.cy + piece.dy * h, z: piece.cz + piece.dz * h },
      previous: stations.at(-1) });
    }
    context.set(gid, stations);
    return stations;
  };
  for (const gid of pending.keys()) build(gid);
  rootChartContexts.set(comp, context);
  return context;
}

// One Core blade piece becomes one exact shared eight-corner wedge. Each face
// duplicates its source corners for hard normals/UVs, but no new position or
// triangle is invented by the renderer.
export function growSlabForm(acc, comp, pieces, shade) {
  const piece = pieces[0];
  const hull = piece.slabHull || slabHullForPiece(piece);
  buildSlabHull(acc, hull, piece, crystalColors(shade));
}

// BRANCHING — a wall-grown root system made entirely from authoritative limb
// capsules. There are no renderer-only contact mounds or child growths.
export function growBranching(rock, comp, forms) {
  for (const g of forms) growTubeForm(rock, comp, g, 'limb', g[0].shade || 0);
}

// CRYSTAL — each authoritative blade hull becomes exactly one visible wedge.
export function growCrystal(crystal, comp, forms) {
  for (const g of forms) growSlabForm(crystal, comp, g, g[0].shade || 0);
}

// Build a composition's geometry into one accumulator per material.
// Returns { rock, crystal } — either may be empty.
export function buildCompositionAccums(comp) {
  const rock = new MeshAccum(), crystal = new MeshAccum();
  const forms = groupForms(comp);

  if (comp.typeName === 'branching') {
    growBranching(rock, comp, forms);
  } else if (comp.typeName === 'crystal') {
    growCrystal(crystal, comp, forms);
  } else {
    for (const g of forms) growTubeForm(rock, comp, g, g[0].shape, g[0].shade || 0);
  }
  return { rock, crystal };
}
