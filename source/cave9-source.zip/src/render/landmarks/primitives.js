// Landmark geometry primitives for the authoritative Core piece grammar.
//
// Every emitted vertex must remain inside its source collision capsule. The
// renderer therefore contains only exact capsule sweeps and contained slabs:
//   * curved, tapered TUBES through a segment chain (branching limbs, coiling
//     ribs — the latter with a flattened-oval cross-section), and
//   * broad, thin obsidian SLABS for blades.
//
// Everything here is a pure function of its arguments plus the accumulator it
// writes into: no scene, no material, no cave, no randomness. That is what makes
// the whole landmark look testable headlessly (test/landmark-mesh.test.js).

import * as THREE from 'three';

// A unit vector perpendicular to t.
export function perpendicular(t) {
  const a = Math.abs(t.x) < 0.9 ? new THREE.Vector3(1, 0, 0) : new THREE.Vector3(0, 1, 0);
  return new THREE.Vector3().crossVectors(t, a).normalize();
}

// Component-wise lerp of two [r,g,b] triples.
export function lerp3(a, b, t) {
  return [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t];
}

function orientedContactRing(acc, ringStart, footprint, radial, axisA, axisB) {
  const next = Array.from({ length: radial }, (_, j) => {
    const i = (ringStart[1] + j) * 3;
    return { x: acc.p[i], y: acc.p[i + 1], z: acc.p[i + 2] };
  });
  const diff = (a, b) => ({ x: a.x - b.x, y: a.y - b.y, z: a.z - b.z });
  const cross = (a, b) => ({ x: a.y * b.z - a.z * b.y,
    y: a.z * b.x - a.x * b.z, z: a.x * b.y - a.y * b.x });
  const dot = (a, b) => a.x * b.x + a.y * b.y + a.z * b.z;
  const length = (v) => Math.hypot(v.x, v.y, v.z);
  const ab = diff(axisB, axisA);
  const ab2 = dot(ab, ab) || 1;
  const axisRadial = (point) => {
    const t = Math.max(0, Math.min(1, dot(diff(point, axisA), ab) / ab2));
    return diff(point, { x: axisA.x + ab.x * t,
      y: axisA.y + ab.y * t, z: axisA.z + ab.z * t });
  };
  let best = null;
  for (const direction of [1, -1]) for (let shift = 0; shift < radial; shift++) {
    const first = Array.from({ length: radial }, (_, j) =>
      footprint[(shift + direction * j + radial) % radial]);
    let reversed = 0, folded = 0, minAgreement = 1;
    for (let j = 0; j < radial; j++) {
      const j1 = (j + 1) % radial;
      const a = first[j], b = first[j1], c = next[j1], d = next[j];
      const n0 = cross(diff(b, a), diff(c, a));
      const n1 = cross(diff(c, a), diff(d, a));
      const centre0 = { x: (a.x + b.x + c.x) / 3,
        y: (a.y + b.y + c.y) / 3, z: (a.z + b.z + c.z) / 3 };
      const centre1 = { x: (a.x + c.x + d.x) / 3,
        y: (a.y + c.y + d.y) / 3, z: (a.z + c.z + d.z) / 3 };
      if (dot(n0, axisRadial(centre0)) <= 0) reversed++;
      if (dot(n1, axisRadial(centre1)) <= 0) reversed++;
      const agreement = dot(n0, n1) / (length(n0) * length(n1) || 1);
      if (agreement <= 0) folded++;
      minAgreement = Math.min(minAgreement, agreement);
    }
    const candidate = { shift, direction, reversed, folded, minAgreement };
    if (!best || candidate.folded < best.folded
      || candidate.folded === best.folded && candidate.reversed < best.reversed
      || candidate.folded === best.folded && candidate.reversed === best.reversed
        && candidate.minAgreement > best.minAgreement) best = candidate;
  }
  // Only the starting index changes. The final positions themselves are the
  // Core-authoritative triangle contacts, never renderer-generated volume.
  for (let j = 0; j <= radial; j++) {
    const p = footprint[(best.shift + best.direction * j + radial) % radial];
    const i = (ringStart[0] + j) * 3;
    acc.p[i] = p.x; acc.p[i + 1] = p.y; acc.p[i + 2] = p.z;
  }
}

// A curved, tapered tube through `pts` ([{pos:{x,y,z}, r}]). Parallel-transport
// frames keep the cross-section from twisting; `flat` squashes one axis (oval
// ribs). Colour lerps base→body→tip along the length. A tapered tip cap closes
// it to a point so arms end as growth, not a cut rod.
//
// opts: { radial, flat, rootContour, contourPhase, rootWallAxis, wallFootprint,
//         baseBoost, gnarl,
//         cx, cy, inner, cBase, cBody, cTip }
//   baseBoost  fattens the wall end into a thick trunk
//   gnarl      knobby radius wobble (organic bark)
//   cx/cy/inner  per-point safety clamp against the central no-entry tube
export function buildTube(acc, pts, opts) {
  const n = pts.length;
  if (n < 2) return;
  const radial = opts.radial || 7;
  const flat = opts.flat == null ? 1 : opts.flat;
  const rootContour = opts.rootContour || false;
  const contourPhase = opts.contourPhase || 0;
  const smoothstep = (t) => t * t * (3 - 2 * t);
  const boost = opts.baseBoost || 0;
  const gnarl = opts.gnarl || 0;
  const cx = opts.cx, cy = opts.cy, inner = opts.inner;
  const { cBase, cBody, cTip } = opts;

  const T = [];
  for (let i = 0; i < n; i++) {
    const a = pts[Math.max(0, i - 1)].pos, b = pts[Math.min(n - 1, i + 1)].pos;
    const t = new THREE.Vector3(b.x - a.x, b.y - a.y, b.z - a.z);
    if (t.lengthSq() < 1e-9) t.set(0, 0, 1);
    T.push(t.normalize());
  }
  let firstNormal = perpendicular(T[0]);
  if (rootContour && opts.rootWallAxis) {
    // N is wall-tangential, so B = T × N points radially. Flattening B grows a
    // broad shelf along the wall without adding uncollidable mesh volume.
    const radialAxis = new THREE.Vector3(opts.rootWallAxis.x,
      opts.rootWallAxis.y, opts.rootWallAxis.z);
    const tangent = new THREE.Vector3().crossVectors(radialAxis, T[0]);
    if (tangent.lengthSq() > 1e-8) firstNormal = tangent.normalize();
  }
  const N = [firstNormal];
  for (let i = 1; i < n; i++) {
    const nrm = N[i - 1].clone();
    const axis = new THREE.Vector3().crossVectors(T[i - 1], T[i]);
    const s = axis.length();
    if (s > 1e-6) { axis.multiplyScalar(1 / s); nrm.applyAxisAngle(axis, Math.atan2(s, T[i - 1].dot(T[i]))); }
    nrm.addScaledVector(T[i], -nrm.dot(T[i])).normalize();
    N.push(nrm);
  }

  const ringStart = [];
  for (let i = 0; i < n; i++) {
    const B = new THREE.Vector3().crossVectors(T[i], N[i]).normalize();
    const tf = i / (n - 1);
    const rootFlat = rootContour ? 0.36 + (flat - 0.36)
      * smoothstep(Math.max(0, Math.min(1, (tf - 0.10) / 0.40))) : flat;
    // fatten toward the base + lumpy multi-frequency gnarl, then CLAMP to the
    // radial clearance so the (thicker) ring can never cross the central no-entry
    // tube — the wall end grows into a fat trunk (large clearance) while the
    // reaching tip stays at its safe size. The clamp lets the whole body fatten
    // up to whatever the room allows, so arms read as thick roots, not spikes.
    const lump = 1 + gnarl * (Math.sin(i * 1.9 + pts[i].pos.z * 0.35) + 0.6 * Math.sin(i * 4.3 + pts[i].pos.x * 0.5));
    let r = pts[i].r * (1 + boost * (1 - tf)) * lump;
    if (inner != null) {
      const R = Math.hypot(pts[i].pos.x - cx, pts[i].pos.y - cy);
      r = Math.min(r, Math.max(pts[i].r, R - inner - 0.15));
    }
    const col = tf < 0.5 ? lerp3(cBase, cBody, tf * 2) : lerp3(cBody, cTip, (tf - 0.5) * 2);
    ringStart.push(acc.vcount());
    for (let j = 0; j <= radial; j++) {
      const a = (j / radial) * Math.PI * 2;
      const cs = Math.cos(a), sn = Math.sin(a);
      // A single narrow longitudinal crest and broad receding facets replace
      // the circular pipe cross-section. Its maximum remains the Core radius.
      const crestGap = Math.abs(Math.atan2(Math.sin(a - contourPhase),
        Math.cos(a - contourPhase)));
      const contour = rootContour ? 0.72 + 0.28 * Math.max(0, 1 - crestGap / 0.60) : 1;
      const ox = (N[i].x * cs + B.x * sn * rootFlat) * r * contour;
      const oy = (N[i].y * cs + B.y * sn * rootFlat) * r * contour;
      const oz = (N[i].z * cs + B.z * sn * rootFlat) * r * contour;
      acc.vert(pts[i].pos.x + ox, pts[i].pos.y + oy, pts[i].pos.z + oz, col,
        j / radial, tf * 4, Math.min(1, tf * 4), opts.surfaceFamily || 0);
    }
  }
  if (opts.wallFootprint?.length === radial) {
    orientedContactRing(acc, ringStart, opts.wallFootprint, radial, pts[0].pos, pts[1].pos);
  }
  for (let i = 0; i < n - 1; i++) {
    const a = ringStart[i], b = ringStart[i + 1];
    for (let j = 0; j < radial; j++) acc.quad(a + j, a + j + 1, b + j + 1, b + j);
  }
  // Blunt rounded tip cap. Ring order follows N→B around +T, so the outward
  // face is ring[j] → ring[j+1] → apex. The reverse order is back-facing under
  // FrontSide and leaves conspicuous circular holes in root silhouettes.
  const last = pts[n - 1], tr = last.r;
  const apex = acc.vert(
    last.pos.x + T[n - 1].x * tr * 0.35, last.pos.y + T[n - 1].y * tr * 0.35,
    last.pos.z + T[n - 1].z * tr * 0.35, cTip, 0.5, 1, 1,
    opts.surfaceFamily || 0);
  const lr = ringStart[n - 1];
  for (let j = 0; j < radial; j++) acc.tri(lr + j, lr + j + 1, apex);
}

// Render a prepared Core SlabHull without changing any world position or face.
// The eight-corner outline has one back, one front and eight side faces. Vertices
// are deliberately duplicated per face so computeVertexNormals() preserves
// broad planar facets and the thick chipped edge in the production material.
// Every emitted triangle corresponds one-for-one to hull.triangles.
export function buildSlabHull(acc, hull, piece, cols) {
  const profile = hull.profile;
  const root = -profile.rootOverhang * piece.radius;
  const length = piece.length - root;
  const body = cols.cInner2 || cols.cInner || cols.cBase;
  const half = piece.length / 2;
  const directionLength = Math.hypot(piece.dx, piece.dy, piece.dz);
  const direction = { x: piece.dx / directionLength, y: piece.dy / directionLength,
    z: piece.dz / directionLength };
  const base = { point: { x: piece.cx - direction.x * half,
    y: piece.cy - direction.y * half, z: piece.cz - direction.z * half }, previous: null };
  const chartStations = new Map();
  const chartAt = (along) => {
    if (along <= 0) return base;
    let station = chartStations.get(along);
    if (!station) {
      station = { point: { x: base.point.x + direction.x * along,
        y: base.point.y + direction.y * along, z: base.point.z + direction.z * along },
      previous: base };
      chartStations.set(along, station);
    }
    return station;
  };
  for (let face = 0; face < 24; face++) {
    // The shallow broad-face ridges are real facets, not a painted pattern.
    // Each triangular facet owns its normals; the eight edge quads own theirs.
    const first = face < 16 ? face : 16 + (face - 16) * 2;
    const count = face < 16 ? 1 : 2;
    const local = new Map();
    const renderVertex = (source) => {
      let destination = local.get(source);
      if (destination != null) return destination;
      const corner = source % 8;
      const along = source < 16 ? hull.outline[corner][0] : hull.ridgeLocal[0];
      const across = source < 16 ? hull.outline[corner][1] : hull.ridgeLocal[1];
      const t = Math.max(0, Math.min(1, (along - root) / length));
      const band = face < 8 ? 0.18 : face < 16 ? 0.12 : 0.37;
      const colour = lerp3(cols.cBase, body, band + t * (face < 8 ? 0.68 : 0.47));
      const u = face < 16 ? (across / piece.radius + 1) * 0.5 : t * 4;
      const v = face < 16 ? t * 4 : source < 8 ? 0 : 1;
      const at = source * 3;
      destination = acc.vert(hull.vertices[at], hull.vertices[at + 1],
        hull.vertices[at + 2], colour, u, v, Math.min(1, t * 4), 1,
        chartAt(along));
      local.set(source, destination);
      return destination;
    };
    for (let triangle = first; triangle < first + count; triangle++) {
      const at = triangle * 3;
      acc.tri(renderVertex(hull.triangles[at]),
        renderVertex(hull.triangles[at + 1]),
        renderVertex(hull.triangles[at + 2]));
    }
  }
}

// A flat, thin SLAB — the reference frames' actual form language.
//
// The obsidian in docs/Inspiritation/ is not prisms or cones: it is shattered
// PLATES, long and thin, radiating inward at oblique angles and overlapping. The
// read is a broad DARK face with a razor-thin BRIGHT rim where the edge catches
// the light. Its broad face and thin edge are explicit geometry.
//
// Geometry: a tapered quad (wide at the wall, narrower at the tip), extruded by
// `thickness`, so 8 corners → 2 broad faces + 4 rim bands. Faces carry the dark
// facet tint, the rim carries the crest colour, which is what puts the highlight
// on the EDGE instead of across the face.
//
// opts: { base, dir, length, width, tipWidth, thickness, roll, cols, tilt }
export function buildSlab(acc, opts) {
  const { base, dir, length, cols } = opts;
  const w0 = opts.width;
  const w1 = opts.tipWidth == null ? w0 * 0.45 : opts.tipWidth;
  const th = (opts.thickness == null ? w0 * 0.16 : opts.thickness) / 2;
  const roll = opts.roll || 0;

  const T = new THREE.Vector3(dir.x, dir.y, dir.z).normalize();
  let N = perpendicular(T).applyAxisAngle(T, roll);
  const B = new THREE.Vector3().crossVectors(T, N).normalize();
  // a slight tilt out of the plane keeps plates from stacking as a flat fan
  if (opts.tilt) N = N.clone().addScaledVector(B, opts.tilt).normalize();

  const at = (along, across, out) => ({
    x: base.x + T.x * along + N.x * across + B.x * out,
    y: base.y + T.y * along + N.y * across + B.y * out,
    z: base.z + T.z * along + N.z * across + B.z * out,
  });

  // 8 corners: [base|tip] × [-across|+across] × [-out|+out]
  const corners = [
    at(0, -w0, -th), at(0, w0, -th), at(length, w1, -th), at(length, -w1, -th), // back face
    at(0, -w0, th), at(0, w0, th), at(length, w1, th), at(length, -w1, th),     // front face
  ];

  const face = cols.cBase;
  const body = cols.cInner || cols.cBody || cols.cBase;
  // Rim bands stay DARK: the highlight is now the Fresnel term in rimLit.js,
  // which puts it on whatever is edge-on to the eye instead of painting a fixed
  // band. Baking a bright colour here is what made rims read as grey outlines.
  const rim = face;

  // Broad faces need independent vertices: sharing the eight corner vertices
  // would force each face onto a collapsed UV line. Both faces now own a full
  // 0..1 surface, while the separate rim vertices below retain longitudinal UVs.
  const makeFace = (indices, flip = false) => indices.map((corner, i) => {
    const tip = i === 2 || i === 3;
    const c = tip ? lerp3(face, body, 0.85) : face;
    const u = (i === 1 || i === 2) ? 1 : 0;
    const vv = i >= 2 ? 1 : 0;
    const p = corners[corner];
    return acc.vert(p.x, p.y, p.z, c, flip ? 1 - u : u, vv);
  });
  const back = makeFace([0, 1, 2, 3]);
  const front = makeFace([7, 6, 5, 4], true);
  acc.quad(back[0], back[1], back[2], back[3]);
  acc.quad(front[0], front[1], front[2], front[3]);

  // rim bands — the one bright element, and thin because the slab is thin
  const rimV = [];
  for (let i = 0; i < 8; i++) {
    const p = corners[i];
    // U follows the thin perimeter; V separates the two thickness faces.
    rimV.push(acc.vert(p.x, p.y, p.z, rim, (i % 4) / 3, i < 4 ? 0 : 1));
  }
  const R = (a, b) => acc.quad(rimV[a], rimV[b], rimV[b + 4], rimV[a + 4]);
  R(1, 2); R(3, 0); R(2, 3); R(0, 1);
}
