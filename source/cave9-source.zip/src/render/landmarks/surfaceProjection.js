// Project a static landmark vertex into the same route-local coordinates used
// by the cave wall's surface shader. CaveStream builds each ring in the plane
// of pathFrameAt(seed, axialDepth); on a tilted route its world z is offset by
// the right/up vectors and cannot be used as axialDepth directly.

import { pathFrameAt } from '../../core/FlightPath.js';

const MAX_PROJECTION_STEPS = 16;
const STEP_TOLERANCE = 1e-9;
const PLANE_TOLERANCE = 1e-6;
export const SURFACE_PROJECTION_FRAME_STEP = 2;
export const MAX_SURFACE_PROJECTION_INTERVALS = 160;
export const MAX_SURFACE_PROJECTION_FRAMES = MAX_SURFACE_PROJECTION_INTERVALS + 3;

function validatePoint(point, contact) {
  if (![point?.x, point?.y, point?.z, contact].every(Number.isFinite)
    || contact < 0 || contact > 1) {
    throw new RangeError('landmark surface point/contact must be finite, contact in [0, 1]');
  }
}

function offsets(point, frame) {
  const dx = point.x - frame.center.x;
  const dy = point.y - frame.center.y;
  const dz = point.z - frame.center.z;
  return {
    right: dx * frame.right.x + dy * frame.right.y + dz * frame.right.z,
    up: dx * frame.up.x + dy * frame.up.y + dz * frame.up.z,
    plane: dx * frame.tangent.x + dy * frame.tangent.y + dz * frame.tangent.z,
  };
}

/**
 * Return { axialDepth, localRight, localUp, contact } for a world-space vertex.
 * `contact` is authored by the caller from its wall-rooted Core geometry; this
 * projection neither guesses wall proximity nor changes collision authority.
 */
export function projectLandmarkSurfacePoint(seed, point, contact = 0) {
  validatePoint(point, contact);

  // The fixed-point inverse of CaveStream's exact frame transform. Reproject
  // into the candidate frame before correcting z; for cave-scale offsets this
  // converges rapidly even where the flight path bends most strongly.
  let axialDepth = point.z;
  for (let step = 0; step < MAX_PROJECTION_STEPS; step++) {
    const frame = pathFrameAt(seed, axialDepth);
    const local = offsets(point, frame);
    const next = point.z - frame.right.z * local.right - frame.up.z * local.up;
    if (Math.abs(next - axialDepth) <= STEP_TOLERANCE) {
      axialDepth = next;
      break;
    }
    axialDepth = next;
  }

  const frame = pathFrameAt(seed, axialDepth);
  const local = offsets(point, frame);
  if (!Number.isFinite(axialDepth) || Math.abs(local.plane) > PLANE_TOLERANCE) {
    throw new RangeError('landmark point lies outside the converged cave path frame');
  }
  return { axialDepth, localRight: local.right, localUp: local.up, contact };
}

// Catmull-Rom coefficients for four exact route frames on the 2 m cave-ring
// lattice. Evaluating the cached polynomial costs no FlightPath trigonometry.
function coefficients(a, b, c, d) {
  return [b, (c - a) / 2, (2 * a - 5 * b + 4 * c - d) / 2,
    (3 * (b - c) + d - a) / 2];
}

const sample = (c, t) => ((c[3] * t + c[2]) * t + c[1]) * t + c[0];

/**
 * Bounded projection cache for one retained landmark room and seed. The owner
 * keeps this object when a RootSurface identity survives a live wall revision,
 * passes it only to changed root parts, and disposes it on room eviction.
 * Reset clears both caches even for the same seed after a new game generation.
 * This class does not yet attach attributes to any production mesh.
 */
export class LandmarkSurfaceProjector {
  constructor(seed, roomIndex) {
    this.frames = new Map();
    this.intervals = new Map();
    this.reset(seed, roomIndex);
  }

  reset(seed, roomIndex) {
    if (!Number.isInteger(seed) || !Number.isInteger(roomIndex) || roomIndex < 0) {
      throw new RangeError('surface projector requires an integer seed and room index');
    }
    this.seed = seed;
    this.roomIndex = roomIndex;
    this.frames.clear();
    this.intervals.clear();
    this.disposed = false;
    return this;
  }

  dispose() {
    this.frames.clear();
    this.intervals.clear();
    this.disposed = true;
  }

  get frameCount() { return this.frames.size; }
  get intervalCount() { return this.intervals.size; }

  _frame(z) {
    let frame = this.frames.get(z);
    if (frame) return frame;
    frame = pathFrameAt(this.seed, z);
    this.frames.set(z, frame);
    if (this.frames.size > MAX_SURFACE_PROJECTION_FRAMES) {
      this.frames.delete(this.frames.keys().next().value);
    }
    return frame;
  }

  _interval(index) {
    let interval = this.intervals.get(index);
    if (interval) return interval;
    const z = index * SURFACE_PROJECTION_FRAME_STEP;
    const a = this._frame(z - SURFACE_PROJECTION_FRAME_STEP);
    const b = this._frame(z);
    const c = this._frame(z + SURFACE_PROJECTION_FRAME_STEP);
    const d = this._frame(z + 2 * SURFACE_PROJECTION_FRAME_STEP);
    const component = (part, axis) => coefficients(
      a[part][axis], b[part][axis], c[part][axis], d[part][axis]);
    interval = [
      component('center', 'x'), component('center', 'y'),
      component('right', 'x'), component('right', 'z'),
      component('up', 'x'), component('up', 'y'), component('up', 'z'),
    ];
    this.intervals.set(index, interval);
    if (this.intervals.size > MAX_SURFACE_PROJECTION_INTERVALS) {
      this.intervals.delete(this.intervals.keys().next().value);
    }
    return interval;
  }

  project(point, contact = 0) {
    if (this.disposed) throw new Error('surface projector has been disposed');
    validatePoint(point, contact);
    // Six fixed corrections make the work predictable. The cubic frame lookup
    // remains accurate to well below a float32 axial coordinate at normal cave
    // depths; the exact independent function above is the test oracle.
    let axialDepth = point.z;
    for (let iteration = 0; iteration < 6; iteration++) {
      const index = Math.floor(axialDepth / SURFACE_PROJECTION_FRAME_STEP);
      const t = axialDepth / SURFACE_PROJECTION_FRAME_STEP - index;
      const c = this._interval(index);
      const dx = point.x - sample(c[0], t);
      const dy = point.y - sample(c[1], t);
      const dz = point.z - axialDepth;
      const rz = sample(c[3], t), uz = sample(c[6], t);
      const right = dx * sample(c[2], t) + dz * rz;
      const up = dx * sample(c[4], t) + dy * sample(c[5], t) + dz * uz;
      axialDepth = point.z - rz * right - uz * up;
    }
    const index = Math.floor(axialDepth / SURFACE_PROJECTION_FRAME_STEP);
    const t = axialDepth / SURFACE_PROJECTION_FRAME_STEP - index;
    const c = this._interval(index);
    const dx = point.x - sample(c[0], t);
    const dy = point.y - sample(c[1], t);
    const dz = point.z - axialDepth;
    return {
      axialDepth,
      localRight: dx * sample(c[2], t) + dz * sample(c[3], t),
      localUp: dx * sample(c[4], t) + dy * sample(c[5], t) + dz * sample(c[6], t),
      contact,
    };
  }
}

// A body chart unfolds its authoritative centreline into the first texture
// axis. One node is shared by every vertex of a root ring or blade station.
// Its first (wall-contact) node has no predecessor and therefore offset zero.
// The second texture axis remains whichever coordinate the fragment's actual
// cave role selects; no CPU-side role is baked into individual face vertices.
export function landmarkBodyChartOffset(projector, node, cache = new Map()) {
  if (!node) return 0;
  const known = cache.get(node);
  if (known) return known.offset;
  const local = projector.project(node.point);
  if (!node.previous) {
    const h = local.localUp / Math.max(0.001,
      Math.hypot(local.localRight, local.localUp));
    // The base role chooses the centreline's length metric. Fragment roles
    // still select the actual layer and second UV axis independently.
    const side = h > -0.485 && h < 0.525;
    cache.set(node, { local, offset: 0, side });
    return 0;
  }
  landmarkBodyChartOffset(projector, node.previous, cache);
  const prior = cache.get(node.previous);
  const selected = prior.side ? 'localUp' : 'localRight';
  const deltaSelected = local[selected] - prior.local[selected];
  const deltaAxial = local.axialDepth - prior.local.axialDepth;
  const dx = node.point.x - node.previous.point.x;
  const dy = node.point.y - node.previous.point.y;
  const dz = node.point.z - node.previous.point.z;
  const metres = Math.hypot(dx, dy, dz);
  const unfoldedAxial = Math.sqrt(Math.max(0,
    metres * metres - deltaSelected * deltaSelected));
  const offset = prior.offset + unfoldedAxial - deltaAxial;
  cache.set(node, { local, offset, side: prior.side });
  return offset;
}
