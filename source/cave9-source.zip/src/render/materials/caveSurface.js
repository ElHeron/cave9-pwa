// Cave surface array material.  This is deliberately a self-contained patch:
// Renderer owns capability detection and attribute updates, while this module
// only consumes the agreed per-vertex contract.  Keeping selection in GLSL
// blends existing layers in at most four colour-array samples per fragment.

import * as THREE from 'three';

export const CAVE_SURFACE_LAYER_COUNT = 53;
export const CAVE_SURFACE_FAMILY_BASE = Object.freeze({ branching: 32, crystal: 39, coiling: 46 });

const defaultMeans = () => Array.from({ length: CAVE_SURFACE_LAYER_COUNT }, () => new THREE.Vector3(0.18, 0.18, 0.18));

// Both shaders call these exact functions. A wall vertex and a landmark vertex
// at the same physical point therefore choose the same charts and layer weights.
// One compact, oblique field spans axial/right/up continuously. Unlike the UV
// charts, its cells cannot restart at floor/side/ceiling boundaries.
const sharedSurfaceFunctions = `
  float caveSurfaceHash(vec2 p) {
    p = fract(p * vec2(0.1031, 0.11369));
    p += dot(p, p.yx + 19.19);
    return fract((p.x + p.y) * p.x);
  }
  vec2 caveSurfaceMineralCoordinates(float axial, float localRight, float localUp) {
    return vec2(axial / 12.0 + localUp / 15.0,
      localRight / 7.0 + localUp / 11.0);
  }
  float caveSurfaceField(vec2 metres, float seed) {
    vec2 cell = floor(metres);
    vec2 blend = fract(metres);
    blend = blend * blend * (3.0 - 2.0 * blend);
    vec2 shift = vec2(seed * 0.071, seed * 0.113);
    float a = caveSurfaceHash(cell + shift);
    float b = caveSurfaceHash(cell + vec2(1.0, 0.0) + shift);
    float c = caveSurfaceHash(cell + vec2(0.0, 1.0) + shift);
    float d = caveSurfaceHash(cell + vec2(1.0, 1.0) + shift);
    return mix(mix(a, b, blend.x), mix(c, d, blend.x), blend.y);
  }
  // The projection crossfade is contained in the existing neutral strips.
  // Accents reach zero BEFORE either chart begins to mix.
  vec3 caveSurfaceRoleWeights(float h) {
    float floorWeight = 1.0 - smoothstep(-0.575, -0.555, h);
    float ceilingWeight = smoothstep(0.595, 0.615, h);
    float sideWeight = smoothstep(-0.485, -0.465, h)
      * (1.0 - smoothstep(0.505, 0.525, h));
    return vec3(floorWeight, sideWeight, ceilingWeight);
  }
  float caveSurfaceSideChart(float h) {
    return smoothstep(-0.555, -0.485, h)
      * (1.0 - smoothstep(0.525, 0.595, h));
  }
  float caveSurfaceWipe(float weight, float field) {
    // Exact endpoints avoid residual material at the physical room boundary.
    if (weight <= 0.0) return 0.0;
    if (weight >= 1.0) return 1.0;
    float width = 0.024;
    float position = mix(-width, 1.0 + width, weight);
    return smoothstep(field - width, field + width, position);
  }
  struct CaveSurfaceRecipe {
    vec4 layers;
    vec4 weights;
    vec4 charts;
    vec4 ceiling;
    int count;
  };
  CaveSurfaceRecipe caveSurfaceEmpty() {
    return CaveSurfaceRecipe(vec4(0.0), vec4(0.0), vec4(0.0), vec4(0.0), 0);
  }
  void caveSurfaceAdd(inout CaveSurfaceRecipe recipe, float layer,
      float weight, float chart, float ceiling) {
    if (weight <= 0.0) return;
    // Merging identical reads also keeps retreat/growth base layers shared.
    for (int i = 0; i < 4; i++) {
      if (i < recipe.count && recipe.layers[i] == layer && recipe.charts[i] == chart) {
        recipe.ceiling[i] += weight * ceiling;
        recipe.weights[i] += weight;
        return;
      }
    }
    recipe.layers[recipe.count] = layer;
    recipe.weights[recipe.count] = weight;
    recipe.charts[recipe.count] = chart;
    recipe.ceiling[recipe.count] = weight * ceiling;
    recipe.count += 1;
  }
  CaveSurfaceRecipe caveSurfaceMaterial(float base, bool familyMaterial,
      float h, float field, bool neutral) {
    CaveSurfaceRecipe recipe = caveSurfaceEmpty();
    vec3 roles = caveSurfaceRoleWeights(h);
    float chart = caveSurfaceSideChart(h);
    // No accent is active inside chart crossfades: exactly two base reads.
    if (neutral || chart > 0.0 && chart < 1.0) {
      caveSurfaceAdd(recipe, base, 1.0 - chart, 0.0, 0.0);
      caveSurfaceAdd(recipe, base, chart, 1.0, 0.0);
      return recipe;
    }
    float role = roles.x > 0.0 ? 1.0 : (roles.z > 0.0 ? 3.0 : 2.0);
    float roleWeight = max(roles.x, max(roles.y, roles.z));
    float threshold = role == 3.0 ? 0.84 : (role == 1.0 ? 0.82 : (familyMaterial ? 0.85 : 0.86));
    float first = smoothstep(threshold - 0.012, threshold + 0.012, field);
    float second = familyMaterial && role != 3.0
      ? smoothstep((role == 1.0 ? 0.94 : 0.95) - 0.012,
          (role == 1.0 ? 0.94 : 0.95) + 0.012, field) : 0.0;
    float accent = 0.72 * smoothstep(0.78, 0.96, field) * roleWeight * first;
    float firstLayer = base + (familyMaterial ? (role == 3.0 ? 6.0 : role) : role);
    float secondLayer = base + (role == 1.0 ? 3.0 : 5.0);
    caveSurfaceAdd(recipe, base, 1.0 - accent, chart, 0.0);
    caveSurfaceAdd(recipe, firstLayer, accent * (1.0 - second), chart,
      familyMaterial && role == 3.0 ? 1.0 : 0.0);
    caveSurfaceAdd(recipe, secondLayer, accent * second, chart, 0.0);
    return recipe;
  }
  CaveSurfaceRecipe caveSurfaceBlend(CaveSurfaceRecipe a, CaveSurfaceRecipe b, float weight) {
    CaveSurfaceRecipe recipe = caveSurfaceEmpty();
    for (int i = 0; i < 4; i++) {
      if (i < a.count) caveSurfaceAdd(recipe, a.layers[i], a.weights[i] * (1.0 - weight),
        a.charts[i], a.weights[i] > 0.0 ? a.ceiling[i] / a.weights[i] : 0.0);
      if (i < b.count) caveSurfaceAdd(recipe, b.layers[i], b.weights[i] * weight,
        b.charts[i], b.weights[i] > 0.0 ? b.ceiling[i] / b.weights[i] : 0.0);
    }
    return recipe;
  }
  float caveSurfaceFrontWeight(float axialNormal, float contact) {
    return smoothstep(0.35, 0.75, abs(axialNormal))
      * smoothstep(0.0, 0.35, contact);
  }
  CaveSurfaceRecipe caveSurfaceFrontRecipe(CaveSurfaceRecipe bodyRecipe) {
    CaveSurfaceRecipe frontRecipe = caveSurfaceEmpty();
    // The two neutral charts share a layer; merge them into one frontal read.
    // A family body has at most three distinct layers, regardless of charts.
    for (int i = 0; i < 4; i++) {
      if (i < bodyRecipe.count) caveSurfaceAdd(frontRecipe, bodyRecipe.layers[i],
        bodyRecipe.weights[i], 0.0, 0.0);
    }
    return frontRecipe;
  }
  CaveSurfaceRecipe caveSurfaceRoom(float variant, float family, float roomWeight,
      float h, float field) {
    float tunnelBase = variant * 4.0;
    float familyBase = 32.0 + clamp(family, 0.0, 2.0) * 7.0;
    // Outside the physical room use the original tunnel recipe.
    if (family < -0.5 || roomWeight <= 0.0) {
      return caveSurfaceMaterial(tunnelBase, false, h, field, false);
    }
    // Mutually exclusive phases bound the union to four slots:
    // retreat <=3, neutral swap <=4, growth <=4.
    if (roomWeight < 0.25925926) {
      float retreatWeight = smoothstep(0.0, 0.25925926, roomWeight);
      return caveSurfaceBlend(caveSurfaceMaterial(tunnelBase, false, h, field, false),
        caveSurfaceMaterial(tunnelBase, false, h, field, true), caveSurfaceWipe(retreatWeight, field));
    }
    if (roomWeight < 0.74074074) {
      float swapWeight = smoothstep(0.25925926, 0.74074074, roomWeight);
      return caveSurfaceBlend(caveSurfaceMaterial(tunnelBase, false, h, field, true),
        caveSurfaceMaterial(familyBase, true, h, field, true), caveSurfaceWipe(swapWeight, 1.0 - field));
    }
    float growWeight = smoothstep(0.74074074, 1.0, roomWeight);
    return caveSurfaceBlend(caveSurfaceMaterial(familyBase, true, h, field, true),
      caveSurfaceMaterial(familyBase, true, h, field, false), caveSurfaceWipe(growWeight, field));
  }

`;

const surfaceSamplerFunctions = (array, means) => `
  vec3 caveSurfaceRead(CaveSurfaceRecipe recipe, vec2 rightUv, vec2 sideUv,
      vec2 rightDx, vec2 rightDy, vec2 sideDx, vec2 sideDy, float macro,
      out float ceilingWeight) {
    vec3 colour = vec3(0.0);
    ceilingWeight = 0.0;
    // Four fixed slots; zero weights never issue a texture read.
    for (int i = 0; i < 4; i++) {
      if (i < recipe.count && recipe.weights[i] > 0.0) {
        bool side = recipe.charts[i] > 0.5;
        vec3 sampleColour = textureGrad(${array},
          vec3(side ? sideUv : rightUv, recipe.layers[i]),
          side ? sideDx : rightDx, side ? sideDy : rightDy).rgb;
        vec3 mean = max(${means}[int(recipe.layers[i])], vec3(0.035));
        sampleColour *= macro / max(dot(mean, vec3(0.2126, 0.7152, 0.0722)), 0.08);
        colour += sampleColour * recipe.weights[i];
        ceilingWeight += recipe.ceiling[i];
      }
    }
    return colour;
  }
`;

export function applyCaveSurface(material) {
  const uniforms = {
    uCaveSurfaceArray: { value: null },
    uCaveSurfaceStrength: { value: 1 },
    uCaveSurfaceSeed: { value: 0 },
    uCaveSurfaceMean: { value: defaultMeans() },
  };
  const previous = material.onBeforeCompile;
  material.onBeforeCompile = (shader) => {
    previous?.(shader);
    Object.assign(shader.uniforms, uniforms);
    shader.vertexShader = shader.vertexShader
      .replace('#include <common>', `#include <common>
        #ifdef CAVE_SURFACE_ARRAY
          attribute vec4 caveSurfaceLocal;
          attribute vec4 caveSurfaceState;
          // previous variant, dominant variant, next variant, region progress.
          // State remains separate because room shoulders still own its family
          // and legacy current/next transition information.
          attribute vec4 caveSurfaceMix;
          attribute float caveRoomWeight;
          varying vec4 vCaveSurfaceLocal;
          varying vec4 vCaveSurfaceState;
          flat varying vec4 vCaveSurfaceMix;
          varying float vCaveRoomWeight;
        #endif`)
      .replace('#include <begin_vertex>', `#include <begin_vertex>
        #ifdef CAVE_SURFACE_ARRAY
          vCaveSurfaceLocal = caveSurfaceLocal;
          vCaveSurfaceState = caveSurfaceState;
          vCaveSurfaceMix = caveSurfaceMix;
          vCaveRoomWeight = caveRoomWeight;
        #endif`);

    shader.fragmentShader = shader.fragmentShader
      .replace('#include <clipping_planes_pars_fragment>', `#include <clipping_planes_pars_fragment>
        #ifdef CAVE_SURFACE_ARRAY
          varying vec4 vCaveSurfaceLocal;
          varying vec4 vCaveSurfaceState;
          flat varying vec4 vCaveSurfaceMix;
          varying float vCaveRoomWeight;
          uniform highp sampler2DArray uCaveSurfaceArray;
          uniform float uCaveSurfaceStrength;
          uniform float uCaveSurfaceSeed;
          uniform vec3 uCaveSurfaceMean[${CAVE_SURFACE_LAYER_COUNT}];

          ${sharedSurfaceFunctions}
          ${surfaceSamplerFunctions('uCaveSurfaceArray', 'uCaveSurfaceMean')}
          float caveSurfaceTunnelVariant(float axial, float h, float localRight) {
            // A region always has one clearly legible main rock group (65%).
            // Its predecessor yields from 30% to 5% while its successor grows
            // from 5% to 30%. This is a geological partition, not an RGB lerp:
            // MAIN-PREVIOUS-MAIN-NEXT-MAIN keeps the two secondaries apart.
            float previousVariant = clamp(floor(vCaveSurfaceMix.x + 0.5), 0.0, 7.0);
            float mainVariant = clamp(floor(vCaveSurfaceMix.y + 0.5), 0.0, 7.0);
            float nextVariant = clamp(floor(vCaveSurfaceMix.z + 0.5), 0.0, 7.0);
            float regionProgress = clamp(vCaveSurfaceMix.w, 0.0, 1.0);
            float previousShare = mix(0.30, 0.05, regionProgress);
            float nextShare = mix(0.05, 0.30, regionProgress);
            const float mainShare = 0.65;
            // Broad, axial-stable sedimentary bands. The wave offsets their
            // borders over tens of metres without turning them into noise.
            float geologicalCoordinate = fract(axial / 72.0 + (h + 1.0) * 0.46
              + 0.115 * sin(axial * 0.052 + localRight * 0.09)
              + 0.035 * sin(axial * 0.137 - localRight * 0.21));
            float mainBand = mainShare / 3.0;
            float variant = mainVariant;
            if (geologicalCoordinate < previousShare) {
              variant = previousVariant;
            } else if (geologicalCoordinate < previousShare + mainBand) {
              variant = mainVariant;
            } else if (geologicalCoordinate < previousShare + mainBand + nextShare) {
              variant = nextVariant;
            }
            return variant;
          }
        #endif`)
      .replace('#include <color_fragment>', `#include <color_fragment>
        #ifdef CAVE_SURFACE_ARRAY
        vec3 caveSurfaceGlow = vec3(0.0);
        if (uCaveSurfaceStrength > 0.001) {
          float axial = vCaveSurfaceLocal.x;
          float localRight = vCaveSurfaceLocal.y;
          float localUp = vCaveSurfaceLocal.z;
          float h = localUp / max(0.001, length(vec2(localRight, localUp)));
          vec2 rightUv = vec2(axial / 10.0, localRight / 8.0);
          vec2 sideUv = vec2(axial / 10.0, localUp / 8.0);
          // Derivatives precede categorical variant/recipe branches.
          vec2 rightDx = dFdx(rightUv), rightDy = dFdy(rightUv);
          vec2 sideDx = dFdx(sideUv), sideDy = dFdy(sideUv);
          vec2 mineralMetres = caveSurfaceMineralCoordinates(axial, localRight, localUp);
          float field = caveSurfaceField(mineralMetres, uCaveSurfaceSeed);
          float variant = caveSurfaceTunnelVariant(axial, h, localRight);
          float family = floor(vCaveSurfaceState.w + 0.5);
          CaveSurfaceRecipe recipe = caveSurfaceRoom(variant, family, vCaveRoomWeight, h, field);
          float macro = clamp(dot(diffuseColor.rgb, vec3(0.2126, 0.7152, 0.0722)), 0.045, 0.24);
          float ceilingWeight;
          vec3 caveSurface = caveSurfaceRead(recipe, rightUv, sideUv,
            rightDx, rightDy, sideDx, sideDy, macro, ceilingWeight);
          diffuseColor.rgb = mix(diffuseColor.rgb, caveSurface, uCaveSurfaceStrength);
          // This happens while diffuseColor is still assembled, before the
          // material's tone-map/fog chunks. Family ceiling-layer weight fades
          // continuously and never reaches a neutral contact strip.
          if (ceilingWeight > 0.0) {
            float growth = smoothstep(0.06, 0.22, caveSurface.g - max(caveSurface.r, caveSurface.b));
            caveSurfaceGlow = vec3(0.07, 0.17, 0.04) * growth * growth * 0.20 * ceilingWeight;
          }
        }
        #endif`)
      .replace('#include <opaque_fragment>', `
        #ifdef CAVE_SURFACE_ARRAY
          outgoingLight = min(outgoingLight + caveSurfaceGlow, vec3(0.75));
        #endif
        #include <opaque_fragment>`);
  };
  material.needsUpdate = true;
  return uniforms;
}

// sampler2DArray is WebGL2-only. Three r160 automatically converts built-in
// materials to GLSL 300 ES on WebGL2 and supplies compatibility aliases for its
// legacy chunks. Do not force material.glslVersion=GLSL3 here: doing so removes
// the gl_FragColor alias still used by those built-in chunks.
export function setCaveSurfaceArrayEnabled(material, enabled) {
  const wasEnabled = !!material.defines?.CAVE_SURFACE_ARRAY;
  if (enabled) {
    material.defines = { ...(material.defines || {}), CAVE_SURFACE_ARRAY: 1 };
  } else {
    const { CAVE_SURFACE_ARRAY: _removed, ...defines } = material.defines || {};
    material.defines = defines;
  }
  if (wasEnabled !== !!enabled) material.needsUpdate = true;
}

// Landmark materials do not carry the dynamic tube attributes. Their family
// is fixed by material (rock=branching, crystal=crystal), while UVs and world
// position already exist in generated geometry. The bounded texture blend
// composes after caveMineral's crag/rim patch.
export function applyLandmarkSurface(material, { family = 'branching' } = {}) {
  const uniforms = {
    uLandmarkSurfaceArray: { value: null },
    uLandmarkSurfaceStrength: { value: 0 },
    uLandmarkSurfaceSeed: { value: 0 },
    uLandmarkSurfaceMean: { value: defaultMeans() },
  };
  const previous = material.onBeforeCompile;
  material.onBeforeCompile = (shader) => {
    previous?.(shader);
    Object.assign(shader.uniforms, uniforms);
    shader.vertexShader = shader.vertexShader
      .replace('#include <common>', `#include <common>
        #ifdef LANDMARK_SURFACE_ARRAY
          attribute vec4 landmarkSurfaceLocal;
          attribute float landmarkSurfaceFamily;
          attribute float landmarkBodyChartOffset;
          varying vec4 vLandmarkSurfaceLocal;
          flat varying float vLandmarkSurfaceFamily;
          varying float vLandmarkBodyChartOffset;
        #endif`)
      .replace('#include <begin_vertex>', `#include <begin_vertex>
        #ifdef LANDMARK_SURFACE_ARRAY
          vLandmarkSurfaceLocal = landmarkSurfaceLocal;
          vLandmarkSurfaceFamily = landmarkSurfaceFamily;
          vLandmarkBodyChartOffset = landmarkBodyChartOffset;
        #endif`);
    shader.fragmentShader = shader.fragmentShader
      .replace('#include <clipping_planes_pars_fragment>', `#include <clipping_planes_pars_fragment>
        #ifdef LANDMARK_SURFACE_ARRAY
          varying vec4 vLandmarkSurfaceLocal;
          flat varying float vLandmarkSurfaceFamily;
          varying float vLandmarkBodyChartOffset;
          uniform highp sampler2DArray uLandmarkSurfaceArray;
          uniform float uLandmarkSurfaceStrength;
          uniform float uLandmarkSurfaceSeed;
          uniform vec3 uLandmarkSurfaceMean[${CAVE_SURFACE_LAYER_COUNT}];
          ${sharedSurfaceFunctions}
          ${surfaceSamplerFunctions('uLandmarkSurfaceArray', 'uLandmarkSurfaceMean')}
        #endif`)
      .replace('#include <color_fragment>', `#include <color_fragment>
        #ifdef LANDMARK_SURFACE_ARRAY
        if (uLandmarkSurfaceStrength > 0.001) {
          float axial = vLandmarkSurfaceLocal.x;
          float localRight = vLandmarkSurfaceLocal.y;
          float localUp = vLandmarkSurfaceLocal.z;
          // Physical route-local derivatives exclude the unfolded body offset.
          // These and all three chart gradients precede non-uniform branches.
          vec3 physicalLocal = vec3(localRight, localUp, axial);
          vec3 faceNormal = cross(dFdx(physicalLocal), dFdy(physicalLocal));
          float axialNormal = abs(faceNormal.z) / max(length(faceNormal), 0.000001);
          float frontWeight = caveSurfaceFrontWeight(axialNormal, vLandmarkSurfaceLocal.w);
          vec2 frontUv = vec2(localRight / 10.0, localUp / 8.0);
          vec2 frontDx = dFdx(frontUv), frontDy = dFdy(frontUv);
          float h = localUp / max(0.001, length(vec2(localRight, localUp)));
          float chartAxial = axial + vLandmarkBodyChartOffset;
          vec2 rightUv = vec2(chartAxial / 10.0, localRight / 8.0);
          vec2 sideUv = vec2(chartAxial / 10.0, localUp / 8.0);
          vec2 rightDx = dFdx(rightUv), rightDy = dFdy(rightUv);
          vec2 sideDx = dFdx(sideUv), sideDy = dFdy(sideUv);
          float field = caveSurfaceField(caveSurfaceMineralCoordinates(
            axial, localRight, localUp), uLandmarkSurfaceSeed);
          CaveSurfaceRecipe recipe = caveSurfaceMaterial(
            32.0 + vLandmarkSurfaceFamily * 7.0, true, h, field, false);
          float macro = clamp(dot(diffuseColor.rgb, vec3(0.2126, 0.7152, 0.0722)), 0.045, 0.24);
          if (vLandmarkSurfaceFamily > 0.5 && vLandmarkSurfaceFamily < 1.5) {
            macro = min(macro * 3.0, 0.32);
          }
          float contactMacro = vLandmarkSurfaceFamily < 0.5 ? 0.085
            : (vLandmarkSurfaceFamily < 1.5 ? 0.055 : 0.09);
          macro = mix(contactMacro, macro, smoothstep(0.0, 0.35, vLandmarkSurfaceLocal.w));
          float ceilingWeight;
          // Full family recipes use <=3 reads; the merged frontal recipe
          // uses <=3. A partial frontal blend therefore stays within six.
          // Contact zero evaluates exactly the original E body recipe.
          vec3 landmarkSurface = vec3(0.0);
          if (frontWeight < 1.0) {
            landmarkSurface = caveSurfaceRead(recipe, rightUv, sideUv,
              rightDx, rightDy, sideDx, sideDy, macro, ceilingWeight) * (1.0 - frontWeight);
          }
          if (frontWeight > 0.0) {
            CaveSurfaceRecipe frontRecipe = caveSurfaceFrontRecipe(recipe);
            landmarkSurface += caveSurfaceRead(frontRecipe, frontUv, frontUv,
              frontDx, frontDy, frontDx, frontDy, macro, ceilingWeight) * frontWeight;
          }
          diffuseColor.rgb = mix(diffuseColor.rgb, landmarkSurface,
            uLandmarkSurfaceStrength);
        }
        #endif`);
  };
  material.needsUpdate = true;
  return uniforms;
}

export function setCaveSurfaceUniforms(uniforms, { texture = null, means, strength = 1, seed = 0 } = {}) {
  if (!uniforms) return;
  if (uniforms.uCaveSurfaceArray) uniforms.uCaveSurfaceArray.value = texture;
  if (uniforms.uLandmarkSurfaceArray) uniforms.uLandmarkSurfaceArray.value = texture;
  if (Array.isArray(means) && means.length === CAVE_SURFACE_LAYER_COUNT) {
    const values = means.map((mean) => mean?.isVector3 ? mean : new THREE.Vector3(...mean));
    if (uniforms.uCaveSurfaceMean) uniforms.uCaveSurfaceMean.value = values;
    if (uniforms.uLandmarkSurfaceMean) uniforms.uLandmarkSurfaceMean.value = values;
  }
  if (uniforms.uCaveSurfaceStrength) uniforms.uCaveSurfaceStrength.value = strength;
  if (uniforms.uLandmarkSurfaceStrength) uniforms.uLandmarkSurfaceStrength.value = strength;
  if (uniforms.uCaveSurfaceSeed) uniforms.uCaveSurfaceSeed.value = seed;
  if (uniforms.uLandmarkSurfaceSeed) uniforms.uLandmarkSurfaceSeed.value = seed;
}
