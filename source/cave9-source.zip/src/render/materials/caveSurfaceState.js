// Pure, renderer-facing state for the cave surface texture system.
//
// This module intentionally owns no Three.js objects and consumes no mutable
// cave RNG.  It can consequently be used by the renderer, visual lab and unit
// tests without changing the generated wall sequence.

import { ROOM_FADE_LEN, ROOM_LEN } from '../../core/constants.js';
import { roomShellAt } from '../../core/RoomState.js';
import { LANDMARK_TYPES, hash2, landmarkType } from '../../core/landmarks/rng.js';

export const TUNNEL_VARIANTS = Object.freeze(['v1', 'v2', 'v3', 'v4', 'v5', 'v6', 'v7', 'v8']);
export const TUNNEL_TRANSITION_LENGTH = 36;
export const TUNNEL_STRETCH_MIN = 350;
export const TUNNEL_STRETCH_MAX = 600;
// A tunnel stretch always has one visually dominant material.  The two
// neighbouring geological eras share the remaining area in a directional,
// spatially-discrete composition (never an RGB blend).
export const TUNNEL_MAIN_SHARE = 0.65;
export const TUNNEL_EDGE_SHARE = 0.05;

// Every list is deliberately symmetric.  Material selection may only use this
// table, making an impossible geological cut unrepresentable at runtime.
export const TUNNEL_VARIANT_NEIGHBOURS = Object.freeze({
  v1: Object.freeze(['v3', 'v4', 'v5', 'v6', 'v8']),
  v2: Object.freeze(['v4', 'v7']),
  v3: Object.freeze(['v1', 'v4', 'v5']),
  v4: Object.freeze(['v1', 'v2', 'v3', 'v5', 'v7']),
  v5: Object.freeze(['v1', 'v3', 'v4', 'v6', 'v8']),
  v6: Object.freeze(['v1', 'v5', 'v8']),
  v7: Object.freeze(['v2', 'v4']),
  v8: Object.freeze(['v1', 'v5', 'v6']),
});

export const FAMILY_IDS = Object.freeze({ branching: 0, crystal: 1, coiling: 2, off: -1 });
export const SURFACE_ROLES = Object.freeze(['floor', 'neutral', 'sideWall', 'ceiling']);

const STRETCH_SALT = 0x59bde27d;
const VARIANT_SALT = 0x14c846af;
const NEXT_SALT = 0x62c9ad13;
const PREVIOUS_SALT = 0x2e7865a1;
const MASK_SALT = 0x3e4c5f1b;
const clamp01 = (value) => Math.max(0, Math.min(1, value));
const smoothstep = (value) => {
  const t = clamp01(value);
  return t * t * (3 - 2 * t);
};

function variantName(value) {
  if (typeof value === 'number' && Number.isInteger(value) && value >= 1 && value <= 8) return `v${value}`;
  if (typeof value === 'string') {
    const normalized = value.toLowerCase();
    return TUNNEL_VARIANTS.includes(normalized) ? normalized : null;
  }
  return null;
}

function stretchLength(seed, index) {
  const span = TUNNEL_STRETCH_MAX - TUNNEL_STRETCH_MIN + 1;
  return TUNNEL_STRETCH_MIN + (hash2(seed | 0, (index | 0) ^ STRETCH_SALT) % span);
}

function initialVariant(seed) {
  return TUNNEL_VARIANTS[hash2(seed | 0, VARIANT_SALT) % TUNNEL_VARIANTS.length];
}

function nextVariant(seed, regionIndex, current, previous = null) {
  const neighbours = TUNNEL_VARIANT_NEIGHBOURS[current];
  // Do not immediately bounce A -> B -> A. Every ordinary stretch should
  // visibly contain three distinct geological generations, while every real
  // boundary still obeys the authored adjacency matrix.
  const candidates = neighbours.length > 1 && previous
    ? neighbours.filter((candidate) => candidate !== previous)
    : neighbours;
  return candidates[hash2(seed | 0, (regionIndex | 0) ^ NEXT_SALT) % candidates.length];
}

function initialPreviousVariant(seed, current) {
  const candidates = TUNNEL_VARIANT_NEIGHBOURS[current];
  return candidates[hash2(seed | 0, PREVIOUS_SALT) % candidates.length];
}

// Build exactly as far as a query needs, instead of caching mutable state.  At
// 20 km this visits fewer than 60 regions, which is negligible per ring and
// keeps answers independent of query order.
function stretchForDepth(seed, depth) {
  const target = Math.max(0, Number.isFinite(depth) ? depth : 0);
  let index = 0;
  let from = 0;
  let current = initialVariant(seed);
  let previous = initialPreviousVariant(seed, current);
  while (true) {
    const to = from + stretchLength(seed, index);
    const next = nextVariant(seed, index, current, previous);
    // Exact end planes belong to the following region.  The old region reaches
    // transition 1 only infinitesimally before `to`; assigning the plane to
    // the next region avoids an ambiguous double-material ring and ensures a
    // resolver walk always advances.
    if (target < to) return { index, from, to, previous, current, next };
    from = to;
    previous = current;
    current = next;
    index++;
  }
}

export function isTunnelVariantTransitionAllowed(from, to) {
  return from !== to && !!TUNNEL_VARIANT_NEIGHBOURS[from]?.includes(to);
}

// Surface-area composition for one tunnel region.  At its start the preceding
// era supplies most of the non-dominant material; at its end the following era
// does.  Clamp keeps diagnostic callers and shader-side conversions safe at
// exact region planes and outside the normal [0, 1] interval.
export function tunnelVariantSharesAt(progress) {
  const t = clamp01(Number.isFinite(progress) ? progress : 0);
  if (t === 0) return { previous: 0.30, current: TUNNEL_MAIN_SHARE, next: TUNNEL_EDGE_SHARE };
  if (t === 1) return { previous: TUNNEL_EDGE_SHARE, current: TUNNEL_MAIN_SHARE, next: 0.30 };
  const previous = 0.30 - 0.25 * t;
  const next = TUNNEL_EDGE_SHARE + 0.25 * t;
  return { previous, current: TUNNEL_MAIN_SHARE, next };
}

// CPU mirror of the shader's broad geological coordinate and categorical
// partition. Capture tooling and property tests use these helpers to measure
// real surface coverage without duplicating a second interpretation of the
// 30/65/5 contract. The shader still performs the final choice per fragment.
export function tunnelGeologicalCoordinateAt(axialDepth, localHeight, localRight) {
  const axial = Number.isFinite(axialDepth) ? axialDepth : 0;
  const h = Number.isFinite(localHeight) ? localHeight : 0;
  const right = Number.isFinite(localRight) ? localRight : 0;
  const raw = axial / 72 + (h + 1) * 0.46
    + 0.115 * Math.sin(axial * 0.052 + right * 0.09)
    + 0.035 * Math.sin(axial * 0.137 - right * 0.21);
  return raw - Math.floor(raw);
}

export function tunnelVariantBandAt(geologicalCoordinate, progress) {
  const raw = Number.isFinite(geologicalCoordinate) ? geologicalCoordinate : 0;
  const coordinate = ((raw % 1) + 1) % 1;
  const shares = tunnelVariantSharesAt(progress);
  const mainBand = shares.current / 3;
  if (coordinate < shares.previous) return 'previous';
  if (coordinate < shares.previous + mainBand) return 'current';
  if (coordinate < shares.previous + mainBand + shares.next) return 'next';
  return 'current';
}

// `transition` is 0 before the exact 36 m closing band and reaches 1 at the
// end plane.  The renderer can use it as the width of a spatial material wipe,
// not as an albedo lerp.
export function surfaceStretchAt(seed, depth, forcedVariant = null) {
  const forced = variantName(forcedVariant);
  if (forced) {
    return {
      previousVariant: forced,
      currentVariant: forced,
      nextVariant: forced,
      from: 0,
      to: Infinity,
      transition: 0,
      regionProgress: 0.5,
    };
  }
  const state = stretchForDepth(seed | 0, depth);
  const transitionFrom = state.to - TUNNEL_TRANSITION_LENGTH;
  const localDepth = Math.max(0, Number.isFinite(depth) ? depth : 0) - state.from;
  return {
    previousVariant: state.previous,
    currentVariant: state.current,
    nextVariant: state.next,
    from: state.from,
    to: state.to,
    transition: smoothstep((Math.max(0, depth) - transitionFrom) / TUNNEL_TRANSITION_LENGTH),
    regionProgress: clamp01(localDepth / (state.to - state.from)),
  };
}

// Returns -1 outside a physical room or when the shared diagnostic override
// explicitly disables landmarks.  `null` and `auto` use the landmark selector.
export function familyIdAt(seed, depth, override = null) {
  const shell = roomShellAt(depth);
  if (!shell.inside || override === 'off') return -1;
  if (override === null || override === undefined || override === 'auto') {
    return landmarkType(seed | 0, shell.index);
  }
  return Object.hasOwn(FAMILY_IDS, override) && FAMILY_IDS[override] >= 0
    ? FAMILY_IDS[override]
    : landmarkType(seed | 0, shell.index);
}

export function familyNameAt(seed, depth, override = null) {
  const id = familyIdAt(seed, depth, override);
  return id >= 0 ? LANDMARK_TYPES[id] : null;
}

// A local, geometric role resolver.  `localUp` and `localRadius` must come
// from the cave's route-local frame; global Y is intentionally absent here.
// The small axial boundary wave makes bands organic while keeping the neutral
// strips guaranteed between the warm floor, turquoise walls and green ceiling.
export function surfaceRoleAt(localUp, localRadius, axialDepth = 0, seed = 0) {
  const radius = Math.max(1e-6, Math.abs(localRadius));
  const h = localUp / radius;
  const phase = hash2(seed | 0, MASK_SALT) * 0.0001;
  const wave = Math.sin(axialDepth * (Math.PI * 2 / 13) + phase) * 0.08;
  const floor = -0.52 + wave;
  const ceiling = 0.56 + wave;
  const halfNeutral = clamp01((Math.min(1.25, Math.max(0.5, radius * 0.035)) / radius) * 0.5);
  if (h <= floor - halfNeutral) return 'floor';
  if (h < floor + halfNeutral) return 'neutral';
  if (h >= ceiling + halfNeutral) return 'ceiling';
  if (h > ceiling - halfNeutral) return 'neutral';
  return 'sideWall';
}

export function surfaceRoleIndexAt(...args) {
  return SURFACE_ROLES.indexOf(surfaceRoleAt(...args));
}

// Shared shoulder phase for tunnel -> family material composition.  Geometry
// and the broad shell weight use the same 30 m smoothstep; phase only tells a
// shader which of the documented three 10 m material stages it is in.
export function roomMaterialPhaseAt(depth) {
  const shell = roomShellAt(depth);
  if (!shell.inside) return { shell, phase: 'tunnel', blend: 0 };
  const edge = Math.min(shell.localDepth, ROOM_LEN - shell.localDepth);
  if (edge >= ROOM_FADE_LEN) return { shell, phase: 'family', blend: 1 };
  if (edge < 10) return { shell, phase: 'neutralize', blend: smoothstep(edge / 10) };
  if (edge < 20) return { shell, phase: 'swap', blend: smoothstep((edge - 10) / 10) };
  return { shell, phase: 'grow', blend: smoothstep((edge - 20) / 10) };
}

export function familyLayerNeedsSeparator(family, fromRole, toRole) {
  const pair = [fromRole, toRole].sort().join(':');
  if (pair === 'floor:sideWall' || pair === 'ceiling:sideWall') return true;
  if (fromRole === 'layerB' && toRole === 'floor') return true;
  if (fromRole === 'floor' && toRole === 'layerB') return true;
  if ((fromRole === 'layerC' && (toRole === 'sideWall' || toRole === 'ceiling'))
    || (toRole === 'layerC' && (fromRole === 'sideWall' || fromRole === 'ceiling'))) return true;
  if (family === 'branching' && pair === 'layerB:layerC') return true;
  return false;
}
