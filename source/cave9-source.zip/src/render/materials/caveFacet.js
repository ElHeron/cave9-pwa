// A fixed-cost crystalline value field for the cave wall. The stable world-cell
// key is evaluated per vertex; the fragment stage quantises the interpolated
// value. The WebGL2 surface path adds one bounded actual-face orientation cue;
// software skips it. One generated colour-detail sample is permitted only in
// the near field where it can actually be seen.

export function applyCaveFacet(material) {
  const strength = { value: 1 };
  strength.detailMap = { value: null };
  strength.detailStrength = { value: 0 };
  strength.reliefNormalMap = { value: null };
  strength.reliefHeightMap = { value: null };
  strength.reliefStrength = { value: 0 };
  const previous = material.onBeforeCompile;
  material.onBeforeCompile = (shader) => {
    if (previous) previous(shader);
    shader.uniforms.uCaveFacetStrength = strength;
    shader.uniforms.uCaveDetailMap = strength.detailMap;
    shader.uniforms.uCaveDetailStrength = strength.detailStrength;
    shader.uniforms.uCaveReliefNormalMap = strength.reliefNormalMap;
    shader.uniforms.uCaveReliefHeightMap = strength.reliefHeightMap;
    shader.uniforms.uCaveReliefStrength = strength.reliefStrength;
    shader.vertexShader = shader.vertexShader
      .replace(
        '#include <common>',
        `#include <common>
        #ifdef CAVE_FACET
          varying float vCaveFacet;
        #endif
        #if defined(CAVE_FACET) && defined(CAVE_SURFACE_ARRAY)
          varying vec3 vCaveFaceWorld;
        #endif
        #ifdef CAVE_COILING_RIM
          attribute float coilingCrest;
          varying float vCaveCoilingCrest;
        #endif
        #if defined(CAVE_DETAIL_MAPS) || defined(CAVE_RELIEF_MAPS)
          varying vec2 vCaveDetailUv;
        #endif
        #ifdef CAVE_DETAIL_MAPS
          varying float vCaveDetailFade;
        #endif
        #ifdef CAVE_RELIEF_MAPS
          varying float vCaveReliefFade;
        #endif`,
      )
      .replace(
        '#include <begin_vertex>',
        `#include <begin_vertex>
        #ifdef CAVE_COILING_RIM
          vCaveCoilingCrest = coilingCrest;
        #endif
        vec3 caveWorld = (modelMatrix * vec4(transformed, 1.0)).xyz;
        #ifdef CAVE_FACET
          vec3 caveCell = floor(abs(caveWorld) * 1.37);
          vCaveFacet = fract(dot(caveCell, vec3(0.1031, 0.11369, 0.13787)));
        #endif
        #if defined(CAVE_FACET) && defined(CAVE_SURFACE_ARRAY)
          vCaveFaceWorld = caveWorld;
        #endif
        #if defined(CAVE_DETAIL_MAPS) || defined(CAVE_RELIEF_MAPS)
          vCaveDetailUv = uv;
        #endif
        #ifdef CAVE_DETAIL_MAPS
          vCaveDetailFade = 1.0 - smoothstep(14.0, 32.0, distance(caveWorld, cameraPosition));
        #endif
        #ifdef CAVE_RELIEF_MAPS
          // Wide chambers keep their wall tens of metres from the camera. The
          // optional relief A/B therefore has its own wider fade instead of
          // inheriting the one-sample corridor-only colour-detail radius.
          vCaveReliefFade = 1.0 - smoothstep(96.0, 180.0,
            distance(caveWorld, cameraPosition));
        #endif`,
      );
    shader.fragmentShader = shader.fragmentShader
      .replace(
        '#include <clipping_planes_pars_fragment>',
        `#ifdef CAVE_FACET
          varying float vCaveFacet;
        #endif
        #if defined(CAVE_FACET) && defined(CAVE_SURFACE_ARRAY)
          varying vec3 vCaveFaceWorld;
        #endif
        #ifdef CAVE_COILING_RIM
          varying float vCaveCoilingCrest;
        #endif
        uniform float uCaveFacetStrength;
        #if defined(CAVE_DETAIL_MAPS) || defined(CAVE_RELIEF_MAPS)
          varying vec2 vCaveDetailUv;
        #endif
        #ifdef CAVE_DETAIL_MAPS
          varying float vCaveDetailFade;
          uniform sampler2D uCaveDetailMap;
          uniform float uCaveDetailStrength;
        #endif
        #ifdef CAVE_RELIEF_MAPS
          varying float vCaveReliefFade;
          uniform sampler2D uCaveReliefNormalMap;
          uniform sampler2D uCaveReliefHeightMap;
          uniform float uCaveReliefStrength;
        #endif
        #include <clipping_planes_pars_fragment>`,
      )
      .replace(
        '#include <color_fragment>',
        `#include <color_fragment>
        {
          #ifdef CAVE_FACET
            float caveWarm = max(diffuseColor.r - diffuseColor.b, 0.0);
            float facetBand = floor(vCaveFacet * 8.0) * 0.142857;
            // The former fourth-power ramp ranged from almost black to 1.5x and
            // made the fixed tube triangles overpower the chamber silhouette.
            // A bounded quadratic keeps facets legible as rock detail while the
            // authoritative wall shape remains the visual hierarchy.
            float facet2 = facetBand * facetBand;
            float facetShade = 0.38 + 0.72 * facet2;
            diffuseColor.rgb *= mix(1.0, facetShade, uCaveFacetStrength);
            #ifdef CAVE_SURFACE_ARRAY
              // WebGL2 surface path only: derivatives of the submitted world
              // triangle give one stable directional key across each face.
              // This narrow modulation costs no sampler or extra draw.
              vec3 caveFaceArea = cross(dFdx(vCaveFaceWorld), dFdy(vCaveFaceWorld));
              float caveFaceLength = inversesqrt(max(dot(caveFaceArea, caveFaceArea), 1e-10));
              float caveFaceKey = clamp(abs(dot(caveFaceArea,
                vec3(0.28, 0.82, -0.50))) * caveFaceLength, 0.0, 1.0);
              diffuseColor.rgb *= 0.84 + 0.20 * caveFaceKey;
            #endif
            diffuseColor.rgb += vec3(0.28, 0.08, 0.02) * caveWarm * 0.55;
          #endif
          #ifdef CAVE_DETAIL_MAPS
            if (uCaveDetailStrength > 0.001 && vCaveDetailFade > 0.001) {
              vec3 caveDetail = texture2D(uCaveDetailMap, vCaveDetailUv).rgb;
              vec3 caveDetailMod = vec3(0.28) + caveDetail;
              diffuseColor.rgb *= mix(vec3(1.0), caveDetailMod,
                vCaveDetailFade * uCaveDetailStrength);
            }
          #endif
          #ifdef CAVE_RELIEF_MAPS
            // Hardware beauty path. The generated tangent-space normal adds
            // directional micro-light while the height map adds crevice
            // occlusion. Both samples fade outside the visible room range;
            // software and an explicit Rock-detail-off setting compile the
            // complete block out.
            if (uCaveReliefStrength > 0.001 && vCaveReliefFade > 0.001) {
              vec3 reliefNormal = texture2D(uCaveReliefNormalMap, vCaveDetailUv).xyz * 2.0 - 1.0;
              float reliefHeight = texture2D(uCaveReliefHeightMap, vCaveDetailUv).r;
              // The generated map encodes unit normals; this fixed vector has
              // squared length 0.9976. Avoid per-fragment normalization.
              float reliefLight = clamp(dot(reliefNormal,
                vec3(-0.34, 0.42, 0.84)) * 0.54 + 0.66, 0.42, 1.18);
              float reliefOcclusion = mix(0.70, 1.12, reliefHeight);
              diffuseColor.rgb *= mix(1.0, reliefLight * reliefOcclusion,
                vCaveReliefFade * uCaveReliefStrength);
            }
          #endif
        }`,
      );
    shader.fragmentShader = shader.fragmentShader.replace(
      '#include <opaque_fragment>',
      `
      #ifdef CAVE_COILING_RIM
      {
        // C3 and corridor crests follow actual wall displacement. Modulating
        // their already shaded surface preserves relief and mineral colour.
        float caveCoilingRim = vCaveCoilingCrest * vCaveCoilingCrest;
        if (caveCoilingRim > 0.0001) {
          outgoingLight *= 1.0 + 0.35 * caveCoilingRim;
        }
      }
      #endif
      #include <opaque_fragment>`,
    );
  };
  material.needsUpdate = true;
  return strength;
}
