// caveMineral — one material patch that gives landmark geometry the surface
// qualities the reference frames have and plain geometry cannot afford.
//
// Reading the six reference images, three things carry the look that were simply
// absent, and all three are far cheaper in a shader than in vertices:
//
//   CRAG    the rock is cracked and lumpy at every scale. Doing that in geometry
//           would need millions of verts per formation; procedural noise
//           perturbing the shading normal gives it for free, and it never has to
//           be built, cached or evicted.
//   EMBERS  nearly every reference has small warm amber glows buried in the rock.
//           They are what makes the caves feel alive rather than quarried. As
//           geometry they would be lights (expensive, and three has a hard light
//           limit); as a thresholded noise term they are one line of emissive.
//   RIM     a restrained highlight on edge-facing planes. View dependent, so
//           vertex colours cannot express it at all; fog grades it with rock.
//
// It also means the geometry side only has to get SILHOUETTE right — mass, taper,
// direction — and can stay cheap and deterministic, which is what keeps the
// safety skeleton and the per-room caching workable.
//
// One patch, not three: three.js allows a single onBeforeCompile per material, so
// these have to be composed here rather than layered.
//
// The crag and ember pattern key on world position, so they remain stable under
// motion. The rim alone follows the view; none of these need simulation state.

import * as THREE from 'three';

export const MINERAL_DEFAULTS = Object.freeze({
  // crag
  cragStrength: 0.55,
  cragScale: 0.35,
  // embers
  emberColor: 0xff8b3a,
  emberStrength: 2.6,
  emberScale: 0.09,
  emberThreshold: 0.62, // higher = rarer
  // rim
  rimColor: 0xb4b6ba,
  rimPower: 4.0,
  rimStrength: 0.24,
});

// Software rasterizers cannot afford world-noise gradients and texture samples.
// Keep their cheap view-dependent edge cue, graded with the body before fog.
export function applyCaveRim(material, opts = {}) {
  const o = { ...MINERAL_DEFAULTS, ...opts };
  const rimCurve = o.rimCurve === 'linear'
    ? 'float rim = rimBase;'
    : 'float rim2 = rimBase * rimBase; float rim = rim2 * rim2;';
  const uniforms = {
    uRimColor: { value: new THREE.Color(o.rimColor) },
    uRimStrength: { value: o.rimStrength },
  };
  const previous = material.onBeforeCompile;
  material.onBeforeCompile = (shader) => {
    previous?.(shader);
    Object.assign(shader.uniforms, uniforms);
    shader.fragmentShader = shader.fragmentShader
      .replace('#include <common>', `#include <common>
      uniform vec3 uRimColor;
      uniform float uRimStrength;`)
      .replace('#include <opaque_fragment>', `{
        // Add to linear light so tone mapping and fog soften the edge with rock.
        float facing = abs(dot(normal, normalize(vViewPosition)));
        float rimBase = clamp(1.0 - facing, 0.0, 1.0);
        ${rimCurve}
        // Follow the sampled albedo: a rim cannot wash out its rock grain.
        outgoingLight += diffuseColor.rgb * uRimColor * rim * uRimStrength;
      }
      #include <opaque_fragment>`);
  };
  material.needsUpdate = true;
  return uniforms;
}

// Cheap 3D value noise.  Crag is evaluated per VERTEX with two octaves and
// interpolated; the old fragment path evaluated roughly 290 hashes per covered
// pixel, which dominated the target proxy budget.
const NOISE_GLSL = /* glsl */`
float lmHash(vec3 p){
  p = fract(p * 0.3183099 + vec3(0.71, 0.113, 0.419));
  p *= 17.0;
  return fract(p.x * p.y * p.z * (p.x + p.y + p.z));
}
float lmNoise(vec3 x){
  vec3 i = floor(x), f = fract(x);
  f = f * f * (3.0 - 2.0 * f);
  return mix(
    mix(mix(lmHash(i + vec3(0,0,0)), lmHash(i + vec3(1,0,0)), f.x),
        mix(lmHash(i + vec3(0,1,0)), lmHash(i + vec3(1,1,0)), f.x), f.y),
    mix(mix(lmHash(i + vec3(0,0,1)), lmHash(i + vec3(1,0,1)), f.x),
        mix(lmHash(i + vec3(0,1,1)), lmHash(i + vec3(1,1,1)), f.x), f.y), f.z);
}
float lmFbm2(vec3 p){
  float a = 0.5, s = 0.0;
  for (int i = 0; i < 2; i++) { s += a * lmNoise(p); p *= 2.03; a *= 0.5; }
  return s;
}`;

export function applyCaveMineral(material, opts = {}) {
  const o = { ...MINERAL_DEFAULTS, ...opts };
  const emberEnabled = o.emberEnabled !== false;
  const uniforms = {
    uCragStrength: { value: o.cragStrength },
    uCragScale: { value: o.cragScale },
    uRimColor: { value: new THREE.Color(o.rimColor) },
    uRimPower: { value: o.rimPower },
    uRimStrength: { value: o.rimStrength },
  };
  if (emberEnabled) Object.assign(uniforms, {
    uEmberColor: { value: new THREE.Color(o.emberColor) },
    uEmberStrength: { value: o.emberStrength },
    uEmberScale: { value: o.emberScale },
    uEmberThreshold: { value: o.emberThreshold },
    uEmberMask: { value: null },
  });

  material.onBeforeCompile = (shader) => {
    Object.assign(shader.uniforms, uniforms);

    // World position is what all three effects key on, so the rock stays put in
    // the world instead of swimming with the camera.
    shader.vertexShader = shader.vertexShader
      .replace('#include <common>', `#include <common>
        varying vec3 vLmWorld;
        varying vec3 vLmCrag;
        uniform float uCragScale;
        ${NOISE_GLSL}`)
      .replace(
        '#include <begin_vertex>',
        `#include <begin_vertex>
        vLmWorld = (modelMatrix * vec4(transformed, 1.0)).xyz;
        {
          vec3 wp = vLmWorld * uCragScale;
          float e = 0.6;
          vLmCrag = vec3(
            lmFbm2(wp + vec3(e,0.0,0.0)) - lmFbm2(wp - vec3(e,0.0,0.0)),
            lmFbm2(wp + vec3(0.0,e,0.0)) - lmFbm2(wp - vec3(0.0,e,0.0)),
            lmFbm2(wp + vec3(0.0,0.0,e)) - lmFbm2(wp - vec3(0.0,0.0,e)));
        }`,
      );

    shader.fragmentShader = shader.fragmentShader
      .replace(
        '#include <common>',
        `#include <common>
        varying vec3 vLmWorld;
        varying vec3 vLmCrag;
        uniform float uCragStrength, uCragScale;
        ${emberEnabled ? `uniform vec3 uEmberColor; uniform float uEmberStrength, uEmberScale, uEmberThreshold;
        uniform sampler2D uEmberMask;` : ''}
        uniform vec3 uRimColor; uniform float uRimPower, uRimStrength;
        `,
      )
      // CRAG — perturb the shading normal by the gradient of the noise field.
      // Done after the normal map so it layers on top of the baked wall relief.
      .replace(
        '#include <normal_fragment_maps>',
        `#include <normal_fragment_maps>
        {
          vec3 g = vLmCrag;
          // g is a WORLD-space gradient while normal is view space. normalMatrix
          // is vertex-stage only, so rotate the gradient with viewMatrix, which
          // three does expose to the fragment stage.
          vec3 gv = (viewMatrix * vec4(g, 0.0)).xyz;
          normal = normalize(normal - (gv - dot(gv, normal) * normal) * uCragStrength);
        }`,
      )
      // RIM — restrained directional edge light on the body. It enters before
      // opaque output, tone mapping and fog so distant silhouettes soften with
      // the same atmosphere as the rest of the formation.
      .replace(
        '#include <opaque_fragment>',
        `{
          float facing = abs(dot(normalize(normal), normalize(vViewPosition)));
          float rim = pow(clamp(1.0 - facing, 0.0, 1.0), uRimPower);
          // Surface projection has already written diffuseColor here. Keep
          // its hue and grain through the edge cue instead of adding grey.
          outgoingLight += diffuseColor.rgb * uRimColor * rim * uRimStrength;
        }
        #include <opaque_fragment>`,
      );
    if (emberEnabled) {
      // EMBERS — one baked texture sample, projected from stable world position.
      // Mesh UVs run regularly along tubes and turned the same mask into stripes;
      // the skewed projection keeps pockets spatially irregular without FBM.
      shader.fragmentShader = shader.fragmentShader.replace(
        '#include <emissivemap_fragment>',
        `#include <emissivemap_fragment>
        {
          vec2 emberUv = vec2(
            vLmWorld.x * 0.73 + vLmWorld.z * 0.19,
            vLmWorld.y * 0.67 - vLmWorld.z * 0.23) * uEmberScale;
          float baked = texture2D(uEmberMask, emberUv).r;
          float ember = smoothstep(uEmberThreshold, 1.0, baked);
          totalEmissiveRadiance += uEmberColor * ember * ember * uEmberStrength;
        }`,
      );
    }
  };

  material.needsUpdate = true;
  return uniforms;
}
