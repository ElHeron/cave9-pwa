// A vertex-only barrel warp used by the post-floor speed steps. It adds no
// render target and composes with an existing onBeforeCompile patch.
export function applySpeedWarp(material) {
  const uniform = { value: 0 };
  const previous = material.onBeforeCompile;
  material.onBeforeCompile = (shader) => {
    if (previous) previous(shader);
    shader.uniforms.uSpeedWarp = uniform;
    shader.vertexShader = shader.vertexShader
      .replace('#include <common>', '#include <common>\nuniform float uSpeedWarp;')
      .replace(
        '#include <project_vertex>',
        `#include <project_vertex>
        {
          vec2 speedNdc = gl_Position.xy / max(0.0001, gl_Position.w);
          // Near-wall vertices can sit far outside the viewport. An unbounded
          // r^2 flips and magnifies those triangles across the whole screen,
          // turning a cheap warp into catastrophic raster overdraw. Inside the
          // visible clip region this clamp is inactive.
          float speedR2 = min(dot(speedNdc, speedNdc), 2.0);
          gl_Position.xy *= 1.0 - uSpeedWarp * 0.055 * speedR2;
        }`,
      );
  };
  material.needsUpdate = true;
  return uniform;
}
