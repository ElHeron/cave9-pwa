// The single render-facing visibility contract. Difficulty owns the sight
// multiplier; this module turns it into fog planes. Brightness deliberately is
// not an input: changing display exposure must not silently alter the physical
// reaction distance promised by Difficulty.reactionWindow().

import { FOG_END } from '../core/constants.js';

export const VISIBILITY = Object.freeze({
  corridorNear: 4,
  roomNear: 10,
  roomFarScale: 0.72,
  baselineNear: 2,
});

export function visibilityAt({ sight = 1, room = 0, readability = true } = {}) {
  const t = Math.max(0, Math.min(1, Number.isFinite(room) ? room : 0));
  const sightMul = Math.max(0, Number.isFinite(sight) ? sight : 1);
  const near0 = readability ? VISIBILITY.corridorNear : VISIBILITY.baselineNear;
  return Object.freeze({
    near: near0 + (VISIBILITY.roomNear - near0) * t,
    far: FOG_END * sightMul * (1 + (VISIBILITY.roomFarScale - 1) * t),
  });
}
