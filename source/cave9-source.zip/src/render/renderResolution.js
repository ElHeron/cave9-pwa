// Performance is a deliberate internal-resolution mode even on DPR 1 screens.
// High retains the existing device-ratio cap and its original image quality.
export function effectiveRenderPixelRatio(devicePixelRatio, qualityCap) {
  const capped = Math.min(devicePixelRatio || 1, qualityCap);
  return qualityCap === 1 ? capped * 0.75 : capped;
}

export function drawingBufferSize(width, height, pixelRatio) {
  return [Math.floor(width * pixelRatio), Math.floor(height * pixelRatio)];
}
