// CameraController — first-person camera, faithful to the original
// cave9 render.c (which sits the camera AT player.pos and looks toward
// player.pos + lookAt, rolling the up-vector with ship.roll).
//
//   _original/src/render.c:147  COPY(render->cam, player->pos);   // camera = ship
//   _original/src/render.c:169  ADD2(render->target, player->pos, player->lookAt);
//
// The release has one camera contract: camera at the player, looking forward.

import * as THREE from 'three';
import { MAX_VEL_X, MAX_VEL_Y, MAX_VEL_Z } from '../core/constants.js';

const _forward = new THREE.Vector3();
const _up = new THREE.Vector3();
const _camPos = new THREE.Vector3();
const _target = new THREE.Vector3();
const _shake = new THREE.Vector3();

export class CameraController {
  constructor(camera) {
    this.camera = camera;
    this.lookAhead = 22;
    this.motion = 1.0;   // 0..1 motion intensity (reduced-motion accessibility)
    this.shakeEnabled = true;
    this._t = 0;         // bob phase accumulator
  }

  setFov(fov) {
    if (this.camera.fov !== fov) {
      this.camera.fov = fov;
      this.camera.updateProjectionMatrix();
    }
  }

  // Cockpit head-bob offset. Scales with motion-intensity so reduced-motion
  // (motion === 0) yields exactly zero — verified in tests.
  bobOffset(ship) {
    if (this.motion <= 0) return 0;
    const speedFrac = Math.min(1, Math.abs(ship.vel[2]) / MAX_VEL_Z);
    return Math.sin(this._t * 8.0) * 0.05 * this.motion * speedFrac;
  }

  // hit: 0..1 proximity/impact factor used for screen shake.
  update(ship, hit = 0) {
    this._t += 1 / 60;

    _forward.set(ship.lookAt[0], ship.lookAt[1], ship.lookAt[2]);
    if (_forward.lengthSq() < 1e-6) _forward.set(0, 0, 1);
    _forward.normalize();

    const roll = ship.roll;
    _up.set(Math.sin(roll), Math.cos(roll), 0);

    // camera position: at the player, plus the optional reduced-motion bob
    _camPos.set(ship.pos[0], ship.pos[1], ship.pos[2]);
    _camPos.y += this.bobOffset(ship);

    // screen shake (scaled by motion-intensity setting). motion === 0 disables
    // it entirely, so reduced-motion produces a deterministic, shake-free frame.
    if (this.shakeEnabled && this.motion > 0) {
      const r = ship.radius * this.motion;
      const sx = (Math.random() - 0.5);
      const sy = (Math.random() - 0.5);
      _shake.set(
        (0.18 * sx * ship.vel[0] / MAX_VEL_X
          + 0.14 * sx * (ship.lefton ? 1 : 0)
          + 0.08 * sx * ship.vel[2] / MAX_VEL_Z
          + 1.5 * sx * hit) * r,
        (0.18 * sy * ship.vel[1] / MAX_VEL_Y
          + 0.14 * sy * (ship.righton ? 1 : 0)
          + 1.5 * sy * hit) * r,
        0.08 * (Math.random() - 0.5) * ship.vel[2] / MAX_VEL_Z * r,
      );
      _camPos.add(_shake);
      // get pushed away from the wall on impact
      _camPos.x += ship.repulsion[0] * hit * ship.radius * 1.5;
      _camPos.y += ship.repulsion[1] * hit * ship.radius * 1.5;
    }

    this.camera.position.copy(_camPos);

    // look down the tunnel: at the player's nose target (pos + lookAt).
    _target.set(ship.pos[0], ship.pos[1], ship.pos[2]);
    _target.addScaledVector(_forward, this.lookAhead);
    this.camera.up.set(Math.sin(roll), Math.cos(roll), 0);
    this.camera.lookAt(_target);
  }
}
