import * as THREE from 'three';

export const SURFACE_RELIEF_ASSETS = Object.freeze({
  cave: Object.freeze({
    normal: './assets/cave-wall-normal.png',
    height: './assets/cave-wall-height.png',
  }),
  coiling: Object.freeze({
    normal: './assets/coiling-rock-normal.png',
    height: './assets/coiling-rock-height.png',
  }),
});

export function resolveSurfaceReliefProfile(profile) {
  return Object.hasOwn(SURFACE_RELIEF_ASSETS, profile) ? profile : 'cave';
}

export function configureCaveReliefTexture(texture, anisotropy = 1,
  { heightOnly = false, webgl2 = false } = {}) {
  texture.wrapS = texture.wrapT = THREE.MirroredRepeatWrapping;
  texture.colorSpace = THREE.NoColorSpace;
  // The height shader reads only .r. WebGL2 stores it in R8; WebGL1 uses RGBA.
  if (heightOnly && webgl2) {
    texture.format = THREE.RedFormat;
    texture.unpackAlignment = 1;
  }
  texture.anisotropy = Math.max(1, Math.min(2, anisotropy));
  texture.generateMipmaps = true;
  texture.needsUpdate = true;
  return texture;
}

function estimatedTextureBytes(texture) {
  const image = texture.image;
  const channels = texture.format === THREE.RedFormat ? 1 : 4;
  return (Number(image?.width) || 0) * (Number(image?.height) || 0)
    * channels * 4 / 3;
}

export class SurfaceReliefAssets {
  constructor({ loadTexture, anisotropy = 1, webgl2 = false, prewarm = () => {}, metrics }) {
    const loader = loadTexture ? null : new THREE.TextureLoader();
    this.loadTexture = loadTexture ?? ((url) => loader.loadAsync(url));
    this.anisotropy = anisotropy;
    this.webgl2 = webgl2;
    this.prewarm = prewarm;
    this.metrics = metrics;
    this.assets = new Map();
    this.promises = new Map();
  }

  get(profile) {
    return this.assets.get(resolveSurfaceReliefProfile(profile));
  }

  load(profile) {
    const resolved = resolveSurfaceReliefProfile(profile);
    if (this.assets.has(resolved)) return Promise.resolve(this.assets.get(resolved));
    if (this.promises.has(resolved)) return this.promises.get(resolved);
    const promise = this._loadPair(resolved);
    this.promises.set(resolved, promise);
    // Attach both paths: an unsuccessful load is retryable, while the caller
    // still receives the original rejection.
    promise.then(
      () => this.promises.delete(resolved),
      () => this.promises.delete(resolved),
    );
    return promise;
  }

  async _loadPair(profile) {
    const spec = SURFACE_RELIEF_ASSETS[profile];
    const settled = await Promise.allSettled([
      this.loadTexture(spec.normal), this.loadTexture(spec.height),
    ]);
    const textures = settled.filter((result) => result.status === 'fulfilled')
      .map((result) => result.value);
    if (settled.some((result) => result.status === 'rejected')) {
      for (const texture of textures) texture?.dispose?.();
      this.metrics.reliefLoadFailures++;
      throw settled.find((result) => result.status === 'rejected').reason;
    }
    const [normal, height] = textures;
    try {
      const pair = {
        normal: configureCaveReliefTexture(normal, this.anisotropy),
        height: configureCaveReliefTexture(height, this.anisotropy,
          { heightOnly: true, webgl2: this.webgl2 }),
      };
      this.prewarm(normal);
      this.prewarm(height);
      this.assets.set(profile, pair);
      this.metrics.reliefLoads++;
      this.metrics.reliefTextureBytes += estimatedTextureBytes(normal)
        + estimatedTextureBytes(height);
      return pair;
    } catch (error) {
      normal?.dispose?.();
      height?.dispose?.();
      this.metrics.reliefLoadFailures++;
      throw error;
    }
  }
}
