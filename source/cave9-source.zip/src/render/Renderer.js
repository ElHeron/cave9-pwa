// Renderer — builds and updates the Three.js scene: the dynamic cave tube,
// the ship, the head-light, fog and depth. The cave is one BufferGeometry with
// fixed topology whose attributes follow the core CaveStream's circular
// buffer in spatial order.
//
// Landmark geometry lives in ./landmarks/ — the renderer only owns the layer and
// hands it the frame's cave/player/seed.

import * as THREE from 'three';
import { effectiveRenderPixelRatio } from './renderResolution.js';
import { SurfaceReliefAssets, configureCaveReliefTexture,
  resolveSurfaceReliefProfile } from './SurfaceReliefAssets.js';
import { CameraController } from './CameraController.js';
import {
  SECTOR_COUNT, SEGMENT_COUNT, SEGMENT_LEN, FOG_END, FOV,
} from '../core/constants.js';
import { LandmarkLayer, LANDMARK_PREWARM_AHEAD_METERS } from './landmarks/LandmarkLayer.js';
import { Atmosphere, EARLY_ROOM_COLOR_WEIGHT } from './Atmosphere.js';
import { roomAt, roomShellAt } from '../core/RoomState.js';
import { COILING_MAX_RIDGE_STRENGTH } from '../core/CoilingShell.js';
import { styleAt } from '../core/Difficulty.js';
import { speedMul, SPEED_FLOOR_MUL, SPEED_REFERENCE_MUL, SPEED_STEP_START } from '../core/Difficulty.js';
import { applySpeedWarp } from './materials/speedWarp.js';
import { applyCaveFacet } from './materials/caveFacet.js';
import {
  applyCaveSurface, CAVE_SURFACE_LAYER_COUNT, setCaveSurfaceArrayEnabled,
  setCaveSurfaceUniforms,
} from './materials/caveSurface.js';
import { familyIdAt, surfaceStretchAt } from './materials/caveSurfaceState.js';

export function configureCaveTexture(texture, anisotropy = 1) {
  texture.wrapS = texture.wrapT = THREE.MirroredRepeatWrapping;
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.anisotropy = Math.max(1, Math.min(2, anisotropy));
  texture.generateMipmaps = true;
  texture.needsUpdate = true;
  return texture;
}

export { configureCaveReliefTexture };

// The authored library is transported as one ordinary PNG so startup performs
// one request/decode.  At runtime the cells are copied into a WebGL2 array
// texture: mipmaps are then generated independently per material, avoiding the
// colour bleed a conventional atlas develops at distance.
export function unpackCaveSurfacePixels(imageData, manifest) {
  const width = Number(manifest?.width);
  const height = Number(manifest?.height);
  const layers = Array.isArray(manifest?.layers) ? manifest.layers : [];
  const sourceWidth = Number(imageData?.width);
  const sourceHeight = Number(imageData?.height);
  const source = imageData?.data;
  if (!(width > 0 && height > 0) || layers.length !== Number(manifest?.layerCount)
    || !source || !(sourceWidth > 0 && sourceHeight > 0)) {
    throw new Error('invalid cave surface manifest or source pixels');
  }
  const sorted = [...layers].sort((a, b) => a.index - b.index);
  for (let index = 0; index < sorted.length; index++) {
    const layer = sorted[index];
    if (layer.index !== index || Number(layer.atlas?.width) !== width
      || Number(layer.atlas?.height) !== height) {
      throw new Error(`invalid cave surface layer ${layer.id ?? index}`);
    }
  }
  const target = new Uint8Array(width * height * 4 * sorted.length);
  const rowBytes = width * 4;
  for (const layer of sorted) {
    const x = Number(layer.atlas.x), y = Number(layer.atlas.y);
    if (x < 0 || y < 0 || x + width > sourceWidth || y + height > sourceHeight) {
      throw new Error(`cave surface layer ${layer.id} is outside the transport image`);
    }
    const layerOffset = layer.index * width * height * 4;
    for (let row = 0; row < height; row++) {
      // DataArrayTexture uploads raw rows without TextureLoader's flipY. Reverse
      // each cell here so authored PNG orientation matches ordinary textures.
      const sourceRow = y + (height - 1 - row);
      const from = (sourceRow * sourceWidth + x) * 4;
      target.set(source.subarray(from, from + rowBytes), layerOffset + row * rowBytes);
    }
  }
  return target;
}

export function configureCaveSurfaceArray(texture, anisotropy = 1) {
  texture.wrapS = texture.wrapT = THREE.RepeatWrapping;
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.magFilter = THREE.LinearFilter;
  texture.minFilter = THREE.LinearMipmapLinearFilter;
  texture.anisotropy = Math.max(1, Math.min(4, anisotropy));
  texture.generateMipmaps = true;
  texture.needsUpdate = true;
  return texture;
}

export function caveSurfaceTextureBytes(width, height, layers) {
  if (!(width > 0 && height > 0 && layers > 0)) return 0;
  return width * height * layers * 4 * 4 / 3;
}

export const SURFACE_RELIEF_REQUESTED_DEFAULT = true;

// Deterministic mineral colour baked per cave vertex. The uneven value field
// follows real ring coordinates, so it is stable in world space and turns the
// existing topology into readable crystalline facets without a fragment
// texture or dynamic light loop.
export function caveVertexColor(x, y, z, sector, seed = 0, axialZ = z) {
  const wave = 0.5 + 0.5 * Math.sin(sector * 1.73 + z * 0.083 + x * 0.19 - y * 0.13);
  const raw = Math.sin(x * 12.9898 + y * 78.233 + z * 37.719 + sector * 11.17) * 43758.5453;
  const grain = raw - Math.floor(raw);
  // Keep the wall readable without letting independent vertex grain turn each
  // production triangle into a black/bright patch. Large-scale form comes from
  // the real ring geometry; colour only supplies restrained mineral variation.
  const value = 0.05 + wave * 0.05 + grain * 0.07;
  const angle = Math.PI / 2 + (sector - 1) * Math.PI * 2 / SECTOR_COUNT;
  const coilPhase = 3 * angle - axialZ * 0.065 + (seed & 255) * 0.017;
  const coilThread = 0.5 + 0.5 * Math.cos(coilPhase);
  const coilRelief = coilThread * coilThread;
  const striation = 0.5 + 0.5 * Math.sin(z * 1.15 + sector * 0.91 + (seed & 127) * 0.13);
  // Dark mineral remains in the recessed channel; the raised thread catches a
  // cool highlight, with finer axial striation strongest between both. These
  // are vertex colours on the real wall surface, not a floating decal.
  const coilTexture = 0.72 + 0.28 * coilRelief + 0.08 * striation * (1 - coilRelief);
  const mineral = [
    value * 0.68 * coilTexture,
    value * 0.79 * (coilTexture + 0.025 * coilRelief),
    value * 0.98 * (coilTexture + 0.055 * coilRelief),
  ];
  // Sparse wall-embedded amber nests from the references. Coarse axial/sector
  // cells keep neighbouring vertices together as pockets rather than confetti;
  // the visual morph keeps the original early cave completely unchanged. This
  // is baked CPU-side into the existing colour attribute, so it adds no shader
  // texture lookup or fragment work to the narrow software-GPU budget.
  const cellZ = Math.floor(z / 12);
  const cellSector = Math.floor((((sector % SECTOR_COUNT) + SECTOR_COUNT) % SECTOR_COUNT) / 2);
  const pocketRaw = Math.sin(cellZ * 91.173 + cellSector * 37.719) * 43758.5453;
  const pocket = pocketRaw - Math.floor(pocketRaw);
  if (pocket > 0.93) {
    const hot = (0.55 + 0.45 * Math.min(1, (pocket - 0.93) / 0.07)) * styleAt(z);
    const blend = hot * (0.28 + 0.08 * grain);
    const warm = [0.38 + 0.06 * hot, 0.14 + 0.035 * hot, 0.04];
    return mineral.map((v, i) => v + (warm[i] - v) * blend);
  }
  return mineral;
}

// Visual-only emphasis for the three-start corridor coil. The wall generator
// already uses this exact phase for real geometry; this value merely lets the
// existing rim shader reveal that geometry outside the rare C3 rooms. It does
// not touch CaveStream, collision, RNG state, or generator fingerprints.
export function corridorCoilCrest(sector, seed = 0, axialZ = 0) {
  const angle = Math.PI / 2 + (sector - 1) * Math.PI * 2 / SECTOR_COUNT;
  const phase = 3 * angle - axialZ * 0.065 + (seed & 255) * 0.017;
  const thread = 0.5 + 0.5 * Math.cos(phase);
  return 0.65 * thread * thread;
}

// ---- per-frame cave-geometry rebuild gate (Phase 4C / L1) -------------------
// The cave mesh is a fixed-topology buffer in spatial order. Between ring-gens
// its geometry is byte-identical. A single new ring shifts the complete buffer
// by one row, which can be copied exactly before computing only the new tail.
//
// These pure helpers key on the CaveStream object and generation so reset and
// menu/run switches cannot reuse stale rows. The wall has no normal attribute;
// its material derives facet normals in the fragment shader.
export function caveGeomKey(cave, surfaceVariantOverride = null) {
  return {
    cave,
    generation: cave.generation,
    i: cave.i,
    capacity: cave.segs.length,
    z: cave.segs[cave.i][0][2],
    centerDepth: cave.centers?.[cave.i]?.[2],
    count: cave.count,
    ringDepth: cave._lastRingDepth,
    seed: cave.seed,
    familyOverride: cave.landmarkFamilyOverride,
    surfaceVariantOverride,
  };
}
export function caveGeomUpdateMode(prev, cave, surfaceVariantOverride = null) {
  const next = caveGeomKey(cave, surfaceVariantOverride);
  if (!prev || prev.cave !== cave || prev.generation !== next.generation
    || prev.capacity !== next.capacity || prev.seed !== next.seed
    || prev.familyOverride !== next.familyOverride
    || prev.surfaceVariantOverride !== next.surfaceVariantOverride) return 'full';
  if (prev.i === next.i && prev.z === next.z
    && prev.centerDepth === next.centerDepth
    && prev.ringDepth === next.ringDepth && prev.count === next.count) return 'skip';
  // No wrap or multi-ring advance: both require a full rebuild. The exact
  // lattice depth proves that precisely one authoritative ring was emitted.
  if (prev.count === next.capacity && next.count === next.capacity
    && next.i === prev.i + 1 && Number.isFinite(prev.ringDepth)
    && next.ringDepth === prev.ringDepth + SEGMENT_LEN
    && Number.isFinite(prev.centerDepth)
    && next.centerDepth === prev.centerDepth + SEGMENT_LEN) return 'shift';
  return 'full';
}
export function caveGeomChanged(prev, cave, surfaceVariantOverride = null) {
  return caveGeomUpdateMode(prev, cave, surfaceVariantOverride) !== 'skip';
}

// Select only the spatially ordered ring pairs that can contribute before the
// fog has become fully opaque. The live circular buffer deliberately keeps a
// much longer history than the camera can see; submitting all of it is
// especially expensive in wide rooms, where many behind-camera quads reach the
// rasterizer. Submission changes, but the authoritative 32-point surface and
// its collision topology do not.
export function caveDrawRange(cave, playerZ, fogFar, margin = 0) {
  const capacity = cave.centers.length;
  const minZ = playerZ - margin;
  const maxZ = playerZ + Math.max(0, fogFar) + margin;
  let firstRing = -1;
  let lastRing = -1;

  for (let s = 0; s < capacity; s++) {
    const buf = (cave.i + s) % capacity;
    const z = cave.centers[buf]?.[2];
    if (!Number.isFinite(z) || z < minZ || z > maxZ) continue;
    if (firstRing < 0) firstRing = s;
    lastRing = s;
  }

  if (firstRing < 0) return { start: 0, count: 0, firstPair: 0, pairCount: 0 };

  // Never submit the pair that straddles the camera plane. Its wall vertices
  // are outside the 45-degree view cone (even the minimum cave radius is much
  // wider than the near-plane footprint), yet clipping that huge quad dominates
  // software rasterizers in rooms. Start with the first wholly forward pair;
  // keep the leaving pair at the fog edge to close the visible strip.
  const firstPair = firstRing;
  const lastPair = Math.min(capacity - 2, lastRing);
  const pairCount = Math.max(0, lastPair - firstPair + 1);
  const indicesPerPair = SECTOR_COUNT * 6;
  return {
    start: firstPair * indicesPerPair,
    count: pairCount * indicesPerPair,
    firstPair,
    pairCount,
  };
}

export function cameraFarFor(fogFar) {
  return Math.max(FOG_END * 1.5, Math.max(0, fogFar) + 8);
}

export function webglRendererIdentity(gl) {
  if (!gl?.getParameter) return Object.freeze({ vendor: '', renderer: '', software: false });
  let ext = null;
  try { ext = gl.getExtension?.('WEBGL_debug_renderer_info') ?? null; } catch { /* restricted context */ }
  let vendor = '', renderer = '';
  try {
    vendor = String(gl.getParameter(ext?.UNMASKED_VENDOR_WEBGL ?? gl.VENDOR) ?? '');
    renderer = String(gl.getParameter(ext?.UNMASKED_RENDERER_WEBGL ?? gl.RENDERER) ?? '');
  } catch { /* identity is diagnostic; rendering must remain available */ }
  const software = /swiftshader|llvmpipe|software rasterizer|microsoft basic render/i
    .test(`${vendor} ${renderer}`);
  return Object.freeze({ vendor, renderer, software });
}

export class Renderer {
  constructor(canvas, opts = {}) {
    this.canvas = canvas;
    this.renderer = new THREE.WebGLRenderer({
      canvas,
      antialias: false,
      powerPreference: 'high-performance',
      preserveDrawingBuffer: !!opts.preserveDrawingBuffer,
    });
    this.renderer.setClearColor(0x000000, 1);
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.maxPixelRatio = 2;
    this.gpuIdentity = webglRendererIdentity(this.renderer.getContext());

    // Readability mode. ON ships the improved flight lighting plus
    // tone mapping; OFF reproduces the original Phase 2 look so the capture
    // harness can shoot a true before/after at the *identical* frame.
    this.readability = true;

    // Rock detail controls the deterministic geometry-derived facet field,
    // one generated near-field colour-detail sample, and the generated
    // normal/height pair on hardware. Software keeps the sampler-free fallback.
    this.rockDetail = true;
    this.rockDetailSampleActive = !this.gpuIdentity.software;
    this.surfaceArraySupported = !!(this.renderer.capabilities.isWebGL2
      && !this.gpuIdentity.software);
    this.surfaceMaterialActive = false;
    this.caveSurfaceTexture = null;
    this.caveSurfaceManifest = null;
    this.surfaceVariantOverride = null;
    this.surfaceReliefRequested = SURFACE_RELIEF_REQUESTED_DEFAULT;
    this.surfaceRelief = SURFACE_RELIEF_REQUESTED_DEFAULT && !this.gpuIdentity.software;
    this.surfaceReliefProfile = 'cave';
    this._surfaceReliefRequestSerial = 0;
    this._surfaceReliefPendingProfile = null;

    this.scene = new THREE.Scene();
    // Fog and background belong to the atmosphere, which is the only writer of
    // them (see render/Atmosphere.js). `this.fog` stays as a read alias because
    // the landmark range and the capture harness both read fog.far.
    this.atmosphere = new Atmosphere(this.scene);
    this.fog = this.atmosphere.fog;

    this.camera = new THREE.PerspectiveCamera(FOV, 1, 0.05, FOG_END * 1.5);
    this.cameraCtl = new CameraController(this.camera);

    this.brightness = 1.0;
    this.sight = 1.0; // difficulty-driven fog multiplier (grows with depth/speed)
    this.baseFov = FOV;
    this._prewarmedTextureIds = new Set();
    this._landmarkProgramsPrewarmed = false;
    this.assetMetrics = { texturePrewarms: 0, texturePrewarmFailures: 0,
      landmarkProgramPrewarms: 0, landmarkProgramPrewarmFailures: 0,
      caveProgramPrewarms: 0, caveProgramPrewarmFailures: 0,
      reliefLoads: 0, reliefLoadFailures: 0, reliefProfile: null,
      reliefTextureBytes: 0,
      surfaceArrayLoads: 0, surfaceArrayLoadFailures: 0,
      surfaceArrayTextureBytes: 0, surfaceArrayLayers: 0 };
    this.surfaceReliefAssets = new SurfaceReliefAssets({
      anisotropy: Math.min(2, this.renderer.capabilities.getMaxAnisotropy()),
      webgl2: this.renderer.capabilities.isWebGL2,
      prewarm: (texture) => this._prewarmTexture(texture),
      metrics: this.assetMetrics,
    });
    // Kept as read aliases for renderer instrumentation and existing tests.
    this._surfaceReliefAssets = this.surfaceReliefAssets.assets;
    this._surfaceReliefPromises = this.surfaceReliefAssets.promises;

    // Build order is load-bearing, not stylistic: three.js sorts the opaque
    // render list by material id, which is a global creation counter. Creating
    // the cave material before the landmark materials keeps the cave drawn first,
    // as it always has been. Changing this order shifts a handful of edge pixels.
    this._buildLights();
    this._buildCaveMesh();
    // Visible landmarks (Phase 4G / M2). Sparse deterministic lethal formations
    // in generator rooms. Core owns their shared collision capsules; this layer
    // grows only geometry covered by those capsules. The setting toggles both.
    this.landmarkLayer = new LandmarkLayer(this.scene, {
      softwareRenderer: this.gpuIdentity.software,
    });

    this.resize();
  }

  // Landmarks are on/off as one unit. Kept as a property pair rather than the
  // layer's own flag because the settings binding and the capture harness both
  // read `renderer.landmarks` as the reported state.
  get landmarks() { return this.landmarkLayer.enabled; }
  setLandmarks(on) { this.landmarkLayer.setEnabled(on); }

  _buildLights() {
    // Low ambient floor so nothing is pure black, but the deep tunnel stays
    // dark and claustrophobic.
    this.ambient = new THREE.AmbientLight(0x33384a, 0.7);
    this._corridorAmbientColor = this.ambient.color.clone();
    this._roomAmbientColor = new THREE.Color(0xe0ddd6);
    this.scene.add(this.ambient);

    // Head-light point source for the near walls around the player.
    this.headlight = new THREE.PointLight(0xfff2dd, 2.4, FOG_END, 1.2);
    this.scene.add(this.headlight);

    // Forward beam: a spotlight pointing down the tunnel so the walls
    // *ahead* (and the tunnel direction) pick up readable contours instead of
    // fading flat to black. Aimed every frame from render(). Off in baseline.
    this.forwardBeam = new THREE.SpotLight(0xffe9c8, 0, FOG_END, 0.5, 0.4, 0.9);
    this.forwardBeam.target = new THREE.Object3D();
    this.forwardBeam.target.position.set(0, 0, 20); // sane default (avoid degenerate aim)
    this.scene.add(this.forwardBeam);
    this.scene.add(this.forwardBeam.target);

    // Hemisphere fill starts cool above and near-black below in the corridor.
    // Its room profile neutralizes both poles so real landmark face normals
    // create broad light/dark planes without a view-dependent white outline.
    this.hemi = new THREE.HemisphereLight(0x6678a0, 0x05060a, 0);
    this._corridorHemiSky = this.hemi.color.clone();
    this._corridorHemiGround = this.hemi.groundColor.clone();
    this._roomHemiSky = new THREE.Color(0xb4b5b6);
    this._roomHemiGround = new THREE.Color(0x30343a);
    this.scene.add(this.hemi);

    // Directional fill defines the dark formation bodies. The corridor starts
    // with its established blue value; room lighting shifts this existing light
    // toward a restrained neutral grey instead of relying on blue edge rims.
    this.fill = new THREE.DirectionalLight(0x4060a0, 0.25);
    this.fill.position.set(0.3, 1, -0.5);
    this._corridorFillColor = this.fill.color.clone();
    this._roomFillColor = new THREE.Color(0x9ca3a8);
    this.scene.add(this.fill);

    this._applyReadabilityProfile();
  }

  // Switch between the shipped readability profile and the Phase 2 baseline.
  // Pure light/tone-mapping config — the geometry, camera and frame are
  // untouched, so a harness can capture an identical-frame before/after.
  setReadability(on) {
    this.readability = !!on;
    this.atmosphere.setReadability(on);
    this._applyReadabilityProfile();
    this.setBrightness(this.brightness);
  }

  _applyReadabilityProfile() {
    if (this.readability) {
      // Reinhard tone mapping + exposure (driven by brightness) lifts the
      // mid/near walls without an aggressive filmic toe crushing the shadows,
      // so wall contours read while the far hole still falls to the black fog.
      this.renderer.toneMapping = THREE.ReinhardToneMapping;
      this.hemi.visible = true;
      this.forwardBeam.visible = true;
    } else {
      this.renderer.toneMapping = THREE.NoToneMapping;
      this.renderer.toneMappingExposure = 1.0;
      this.hemi.visible = false;
      this.forwardBeam.visible = false;
    }
  }

  _buildCaveMesh() {
    const geo = new THREE.BufferGeometry();
    this.placeholderTex();
    this.caveGeo = geo;
    this._resizeCaveGeometry(SEGMENT_COUNT);
    this.caveMesh = new THREE.Mesh(geo, this.caveMat);
    this.caveMesh.frustumCulled = false;
    this._geomKey = null; // last rebuilt cave-geometry signature (see caveGeomKey)
    this.scene.add(this.caveMesh);
  }

  _resizeCaveGeometry(capacity) {
    if (this.caveCapacity === capacity) return;
    const verts = capacity * SECTOR_COUNT;
    this.positions = new Float32Array(verts * 3);
    this.uvs = new Float32Array(verts * 2);
    this.colors = new Float32Array(verts * 3);
    this.coilingCrests = new Float32Array(verts);
    this.caveSurfaceLocals = new Float32Array(verts * 4);
    this.caveSurfaceStates = new Float32Array(verts * 4);
    this.caveSurfaceMixes = new Float32Array(verts * 4);
    this.caveRoomWeights = new Float32Array(verts);
    this.caveGeo.setAttribute('position', new THREE.BufferAttribute(this.positions, 3));
    this.caveGeo.setAttribute('uv', new THREE.BufferAttribute(this.uvs, 2));
    this.caveGeo.setAttribute('color', new THREE.BufferAttribute(this.colors, 3));
    this.caveGeo.setAttribute('coilingCrest', new THREE.BufferAttribute(this.coilingCrests, 1));
    this.caveGeo.setAttribute('caveSurfaceLocal', new THREE.BufferAttribute(this.caveSurfaceLocals, 4));
    this.caveGeo.setAttribute('caveSurfaceState', new THREE.BufferAttribute(this.caveSurfaceStates, 4));
    this.caveGeo.setAttribute('caveSurfaceMix', new THREE.BufferAttribute(this.caveSurfaceMixes, 4));
    this.caveGeo.setAttribute('caveRoomWeight', new THREE.BufferAttribute(this.caveRoomWeights, 1));

    const idx = [];
    const at = (s, j) => s * SECTOR_COUNT + j;
    for (let s = 0; s < capacity - 1; s++) {
      for (let j = 0; j < SECTOR_COUNT; j++) {
        const j1 = (j + 1) % SECTOR_COUNT;
        const a = at(s, j), b = at(s, j1), c = at(s + 1, j), d = at(s + 1, j1);
        idx.push(a, c, b, b, c, d);
      }
    }
    this.caveGeo.setIndex(idx);
    this.caveCapacity = capacity;
    this._geomKey = null;
  }

  placeholderTex() {
    // material is created now; the real texture is swapped in by load()
    this.caveMat = new THREE.MeshBasicMaterial({
      color: 0xffffff,
      vertexColors: true,
      // CaveTopology winds the connected ring quads inward, so their front
      // faces are the surface seen from inside the tunnel.
      side: THREE.FrontSide,
    });
    this.caveMat.defines = this.gpuIdentity.software ? {} : {
      CAVE_COILING_RIM: 1,
      CAVE_FACET: 1,
    };
    this.coilingRimActive = !this.gpuIdentity.software;
    this.caveFacet = applyCaveFacet(this.caveMat);
    this.caveSurface = applyCaveSurface(this.caveMat);
    this.caveSpeedWarp = applySpeedWarp(this.caveMat);
  }

  async load() {
    if (!this._assetLoadPromise) this._assetLoadPromise = this._loadAssets();
    return this._assetLoadPromise;
  }

  async _loadCaveSurfaceArray() {
    if (!this.surfaceArraySupported) return null;
    try {
      const [response, image] = await Promise.all([
        fetch('./assets/cave-surfaces.manifest.json'),
        new THREE.ImageLoader().loadAsync('./assets/cave-surfaces-source.png'),
      ]);
      if (!response.ok) throw new Error(`surface manifest HTTP ${response.status}`);
      const manifest = await response.json();
      if (manifest?.layerCount !== CAVE_SURFACE_LAYER_COUNT
        || !Array.isArray(manifest.layers)
        || manifest.layers.length !== CAVE_SURFACE_LAYER_COUNT) {
        throw new Error(`surface manifest must contain ${CAVE_SURFACE_LAYER_COUNT} layers`);
      }
      const sourceWidth = Number(image.naturalWidth || image.width);
      const sourceHeight = Number(image.naturalHeight || image.height);
      const canvas = document.createElement('canvas');
      canvas.width = sourceWidth;
      canvas.height = sourceHeight;
      const context = canvas.getContext('2d', { willReadFrequently: true });
      if (!context) throw new Error('2D context unavailable for cave surface unpack');
      context.drawImage(image, 0, 0);
      const sourcePixels = context.getImageData(0, 0, sourceWidth, sourceHeight);
      const pixels = unpackCaveSurfacePixels(sourcePixels, manifest);
      // Drop the large transport backing store before the GPU upload. The
      // resulting array keeps only the compact 53 x 128 x 128 layer payload.
      canvas.width = canvas.height = 1;
      const texture = configureCaveSurfaceArray(new THREE.DataArrayTexture(
        pixels, Number(manifest.width), Number(manifest.height), manifest.layerCount,
      ), Math.min(4, this.renderer.capabilities.getMaxAnisotropy()));
      texture.name = 'cave-surfaces-v1';
      this.assetMetrics.surfaceArrayLoads++;
      this.assetMetrics.surfaceArrayLayers = manifest.layerCount;
      this.assetMetrics.surfaceArrayTextureBytes = caveSurfaceTextureBytes(
        manifest.width, manifest.height, manifest.layerCount);
      return { texture, manifest };
    } catch (error) {
      this.assetMetrics.surfaceArrayLoadFailures++;
      throw error;
    }
  }

  _activateCaveSurfaceArray(bundle) {
    if (!bundle?.texture?.isDataArrayTexture || !this.surfaceArraySupported) return false;
    this.caveSurfaceTexture = bundle.texture;
    this.caveSurfaceManifest = bundle.manifest;
    setCaveSurfaceUniforms(this.caveSurface, {
      texture: bundle.texture,
      means: bundle.manifest.layers.map((layer) => layer.meanLinear),
      strength: this.rockDetail ? 1 : 0,
      seed: 0,
    });
    this.landmarkLayer.applySurfaceTexture({
      texture: bundle.texture,
      manifest: bundle.manifest,
      strength: this.rockDetail ? 1 : 0,
    });
    this._applyRockDetail();
    this._prewarmTexture(bundle.texture);
    return true;
  }

  async _loadAssets() {
    const textureLoader = new THREE.TextureLoader();
    const anisotropy = Math.min(4, this.renderer.capabilities.getMaxAnisotropy());
    const [surfaceResult] = await Promise.allSettled([this._loadCaveSurfaceArray()]);
    const surfaceActive = surfaceResult.status === 'fulfilled'
      && this._activateCaveSurfaceArray(surfaceResult.value);
    if (surfaceResult.status === 'rejected') {
      console.warn('cave surface array failed to load, using legacy detail textures',
        surfaceResult.reason);
    }

    // Legacy detail textures are true fallbacks now. Loading them only when the
    // array is unavailable avoids duplicate decodes, samplers and GPU memory on
    // the production WebGL2 path.
    const [caveResult, landmarkResult] = surfaceActive
      ? [{ status: 'fulfilled', value: null }, { status: 'fulfilled', value: null }]
      : await Promise.allSettled([
        this.gpuIdentity.software
          ? Promise.resolve(null)
          : textureLoader.loadAsync('./assets/cave-wall-detail.webp'),
        this.gpuIdentity.software
          ? Promise.resolve(null)
          : textureLoader.loadAsync('./assets/landmark-rock-grain.webp'),
      ]);

    if (caveResult.status === 'fulfilled' && caveResult.value) {
      this.caveTexture = configureCaveTexture(caveResult.value, anisotropy);
      this.caveFacet.detailMap.value = this.caveTexture;
      this._applyRockDetail();
      this._prewarmTexture(this.caveTexture);
    } else if (caveResult.status === 'rejected') {
      // Texture detail is optional: vertex mineral colours and facets are the
      // complete fallback, so a failed asset never prevents gameplay.
      console.warn('cave detail texture failed to load, using vertex facets', caveResult.reason);
    }

    if (surfaceActive) {
      // Array binding above already configured both family landmark materials.
    } else if (landmarkResult.status === 'fulfilled' && landmarkResult.value) {
      this.landmarkLayer.applyTextures({ grainTex: landmarkResult.value, anisotropy });
      this._prewarmTexture(landmarkResult.value);
    } else if (landmarkResult.status === 'fulfilled') {
      this.landmarkLayer.applyTextures();
    } else {
      console.warn('landmark grain texture failed to load, using vertex colours', landmarkResult.reason);
      this.landmarkLayer.applyTextures();
    }
    this._prewarmTexture(this.landmarkLayer.emberMask);
    this._prewarmLandmarkMaterials();

    // Both fixed 512 px relief profiles are session assets, not room assets.
    // Preloading them prevents a texture upload or shader compile when a live
    // CaveStream window first enters C3. Software deliberately retains the
    // sampler-free path and never allocates these textures.
    if (this.surfaceRelief && !this.gpuIdentity.software) {
      const requestSerial = this._surfaceReliefRequestSerial;
      await Promise.allSettled([
        this._loadSurfaceRelief('cave'), this._loadSurfaceRelief('coiling'),
      ]);
      const currentPair = this._surfaceReliefAssets.get(this.surfaceReliefProfile);
      if (currentPair && this.surfaceRelief
        && requestSerial === this._surfaceReliefRequestSerial) {
        this._activateSurfaceRelief(currentPair, this.surfaceReliefProfile);
        this._prewarmCaveMaterial();
      } else if (!currentPair && requestSerial === this._surfaceReliefRequestSerial) {
        this.surfaceRelief = false;
      }
    }
  }

  _loadSurfaceRelief(profile) {
    return this.surfaceReliefAssets.load(profile);
  }

  _activateSurfaceRelief(pair, profile) {
    if (!pair?.normal?.isTexture || !pair?.height?.isTexture) return false;
    this.caveFacet.reliefNormalMap.value = pair.normal;
    this.caveFacet.reliefHeightMap.value = pair.height;
    this.caveFacet.reliefStrength.value = this.surfaceRelief ? 1 : 0;
    const hadProgram = !!this.caveMat.defines?.CAVE_RELIEF_MAPS;
    this.caveMat.defines = { ...(this.caveMat.defines ?? {}), CAVE_RELIEF_MAPS: 1 };
    if (!hadProgram) this.caveMat.needsUpdate = true;
    this.assetMetrics.reliefProfile = profile;
    return true;
  }

  setSurfaceRelief(on, profile = 'cave') {
    const requestSerial = (this._surfaceReliefRequestSerial ?? 0) + 1;
    this._surfaceReliefRequestSerial = requestSerial;
    this._surfaceReliefPendingProfile = null;
    this.surfaceReliefRequested = !!on;
    this.surfaceRelief = this.surfaceReliefRequested && !this.gpuIdentity.software;
    const requestedProfile = resolveSurfaceReliefProfile(profile);
    this.surfaceReliefProfile = requestedProfile;
    if (!this.surfaceRelief) {
      this.caveFacet.reliefStrength.value = 0;
      if (this.caveMat.defines?.CAVE_RELIEF_MAPS) {
        const { CAVE_RELIEF_MAPS: _removed, ...defines } = this.caveMat.defines;
        this.caveMat.defines = defines;
        this.caveMat.needsUpdate = true;
      }
      this.assetMetrics.reliefProfile = null;
      this._surfaceReliefActivationPromise = Promise.resolve(false);
      return this._surfaceReliefActivationPromise;
    }
    const activation = this._loadSurfaceRelief(this.surfaceReliefProfile).then((pair) => {
      // A later UI toggle/profile change wins over an older async load.
      if (!this.surfaceRelief || this.surfaceReliefProfile !== requestedProfile
        || this._surfaceReliefRequestSerial !== requestSerial) return false;
      return this._activateSurfaceRelief(pair, this.surfaceReliefProfile);
    }).catch((error) => {
      if (this._surfaceReliefRequestSerial !== requestSerial
        || !this.surfaceRelief || this.surfaceReliefProfile !== requestedProfile) return false;
      this.surfaceRelief = false;
      this.caveFacet.reliefStrength.value = 0;
      console.warn(`cave ${requestedProfile} relief maps failed to load`, error);
      return false;
    });
    this._surfaceReliefActivationPromise = activation;
    return activation;
  }

  surfaceReliefReady() {
    return this._surfaceReliefActivationPromise ?? Promise.resolve(false);
  }

  _prewarmTexture(texture) {
    if (!texture?.isTexture || this._prewarmedTextureIds.has(texture.uuid)) return false;
    try {
      this.renderer.initTexture?.(texture);
      this._prewarmedTextureIds.add(texture.uuid);
      this.assetMetrics.texturePrewarms++;
      return true;
    } catch (error) {
      this.assetMetrics.texturePrewarmFailures++;
      console.warn('texture GPU prewarm failed; normal lazy upload remains available', error);
      return false;
    }
  }

  _prewarmLandmarkMaterials() {
    if (this._landmarkProgramsPrewarmed) return false;
    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.Float32BufferAttribute([
      -1, 0, 0, 1, 0, 0, 0, 1, 0,
    ], 3));
    geometry.setAttribute('color', new THREE.Float32BufferAttribute([
      1, 1, 1, 1, 1, 1, 1, 1, 1,
    ], 3));
    geometry.setAttribute('uv', new THREE.Float32BufferAttribute([0, 0, 1, 0, 0.5, 1], 2));
    geometry.setIndex([0, 1, 2]);
    geometry.computeVertexNormals();
    const scene = new THREE.Scene();
    scene.add(new THREE.AmbientLight(0xffffff, 1));
    scene.add(new THREE.Mesh(geometry, this.landmarkLayer.rockMat));
    const crystal = new THREE.Mesh(geometry, this.landmarkLayer.crystalMat);
    crystal.position.x = 3;
    scene.add(crystal);
    try {
      this.renderer.compile(scene, this.camera);
      this._landmarkProgramsPrewarmed = true;
      this.assetMetrics.landmarkProgramPrewarms++;
      return true;
    } catch (error) {
      this.assetMetrics.landmarkProgramPrewarmFailures++;
      console.warn('landmark material prewarm failed; normal lazy compile remains available', error);
      return false;
    } finally {
      geometry.dispose();
    }
  }

  _prewarmLandmarkPrograms() {
    this.landmarkLayer.prepareHiddenPrograms((group) =>
      this.renderer.compile(group, this.camera, this.scene));
  }

  // Apply/remove the geometry-derived facet field. This is a uniform toggle;
  // geometry, fog and material program stay unchanged.
  _applyRockDetail() {
    if (this.caveFacet) {
      this.caveFacet.value = this.rockDetail && !this.gpuIdentity.software ? 1 : 0;
      this.surfaceMaterialActive = !!(this.rockDetail && this.caveSurfaceTexture
        && this.surfaceArraySupported);
      const legacyDetailActive = !!(this.rockDetail && this.caveTexture
        && !this.gpuIdentity.software && !this.surfaceMaterialActive);
      this.rockDetailSampleActive = this.surfaceMaterialActive || legacyDetailActive;
      this.caveFacet.detailStrength.value = legacyDetailActive ? 1 : 0;
      setCaveSurfaceArrayEnabled(this.caveMat, this.surfaceMaterialActive);
      setCaveSurfaceUniforms(this.caveSurface, {
        texture: this.surfaceMaterialActive ? this.caveSurfaceTexture : null,
        means: this.caveSurfaceManifest?.layers?.map((layer) => layer.meanLinear),
        strength: this.surfaceMaterialActive ? 1 : 0,
      });
      this.landmarkLayer?.applySurfaceTexture?.({
        texture: this.surfaceMaterialActive ? this.caveSurfaceTexture : null,
        manifest: this.caveSurfaceManifest,
        strength: this.surfaceMaterialActive ? 1 : 0,
      });
      if (this.caveMat) {
        const hadDetailProgram = !!this.caveMat.defines?.CAVE_DETAIL_MAPS;
        const definitions = { ...(this.caveMat.defines ?? {}) };
        if (legacyDetailActive) definitions.CAVE_DETAIL_MAPS = 1;
        else delete definitions.CAVE_DETAIL_MAPS;
        this.caveMat.defines = definitions;
        if (hadDetailProgram !== legacyDetailActive) this.caveMat.needsUpdate = true;
      }
    }
  }

  setRockDetail(on) {
    this.rockDetail = !!on;
    this._applyRockDetail();
    this.setSurfaceRelief(this.rockDetail, this.surfaceReliefProfile);
  }

  // Visual-lab/capture override only. Normal gameplay leaves this null so the
  // seed-stable 350-600 m resolver remains authoritative.
  setSurfaceVariantOverride(variant = null) {
    this.surfaceVariantOverride = variant;
    this._geomKey = null;
  }

  renderCapabilities() {
    return Object.freeze({
      gpu: { ...this.gpuIdentity },
      rockDetailRequested: !!this.rockDetail,
      rockFacetActive: !!(this.rockDetail && !this.gpuIdentity.software),
      rockFacetSoftwareFallback: !!(this.rockDetail && this.gpuIdentity.software),
      rockDetailSampleActive: !!this.rockDetailSampleActive,
      surfaceMaterialActive: !!this.surfaceMaterialActive,
      surfaceArraySupported: !!this.surfaceArraySupported,
      surfaceArrayLayers: this.assetMetrics.surfaceArrayLayers || 0,
      surfaceArrayTextureBytes: this.assetMetrics.surfaceArrayTextureBytes || 0,
      rockDetailSoftwareFallback: !!(this.rockDetail && this.gpuIdentity.software),
      surfaceReliefRequested: !!this.surfaceReliefRequested,
      surfaceReliefActive: !!this.surfaceRelief,
      surfaceReliefProfile: this.surfaceRelief ? this.assetMetrics.reliefProfile : null,
      surfaceReliefSoftwareFallback: !!(this.surfaceReliefRequested && this.gpuIdentity.software),
      landmarkMineralActive: !this.landmarkLayer.softwareRenderer,
      landmarkRimActive: true,
      landmarkSoftwareFallback: this.landmarkLayer.softwareRenderer,
      landmarkLightingModel: this.landmarkLayer.softwareRenderer ? 'lambert' : 'standard',
      coilingRimActive: !!this.coilingRimActive,
      coilingRimSoftwareFallback: false,
    });
  }

  _syncCoilingRim(cave) {
    if (!this.gpuIdentity.software) {
      this.coilingRimActive = true;
      return;
    }
    const active = !!cave?.coilingStrengths?.some((value) => Number(value) > 0);
    if (active === this.coilingRimActive) return;
    const definitions = { ...(this.caveMat.defines ?? {}) };
    if (active) definitions.CAVE_COILING_RIM = 1;
    else delete definitions.CAVE_COILING_RIM;
    this.caveMat.defines = definitions;
    this.caveMat.needsUpdate = true;
    this.coilingRimActive = active;
  }

  _syncSurfaceReliefProfile(cave) {
    if (!this.surfaceRelief || this.gpuIdentity.software) return;
    const coiling = !!cave?.coilingStrengths?.some((value) => Number(value) > 0);
    const profile = coiling ? 'coiling' : 'cave';
    if (this._surfaceReliefPendingProfile
      && this._surfaceReliefPendingProfile !== profile) {
      this._surfaceReliefRequestSerial = (this._surfaceReliefRequestSerial ?? 0) + 1;
      this._surfaceReliefPendingProfile = null;
    }
    if (this.assetMetrics.reliefProfile === profile) return;
    if (this._surfaceReliefPendingProfile === profile) return;
    const requestSerial = (this._surfaceReliefRequestSerial ?? 0) + 1;
    this._surfaceReliefRequestSerial = requestSerial;
    this._surfaceReliefPendingProfile = null;
    const pair = this._surfaceReliefAssets.get(profile);
    if (pair) {
      this.surfaceReliefProfile = profile;
      this._activateSurfaceRelief(pair, profile);
      return;
    }
    // This only occurs when the player enabled detail after boot. The ordinary
    // default has both profiles preloaded above.
    this._surfaceReliefPendingProfile = profile;
    this._surfaceReliefActivationPromise = this._loadSurfaceRelief(profile).then((loaded) => {
      if (this._surfaceReliefRequestSerial !== requestSerial || !this.surfaceRelief) return false;
      this._surfaceReliefPendingProfile = null;
      this.surfaceReliefProfile = profile;
      return this._activateSurfaceRelief(loaded, profile);
    }).catch((error) => {
      if (this._surfaceReliefRequestSerial !== requestSerial || !this.surfaceRelief) return false;
      this._surfaceReliefPendingProfile = null;
      console.warn(`cave ${profile} relief maps failed to load`, error);
      return false;
    });
  }

  _prewarmCaveMaterial() {
    try {
      this.renderer.compile(this.scene, this.camera);
      this.assetMetrics.caveProgramPrewarms++;
      return true;
    } catch (error) {
      this.assetMetrics.caveProgramPrewarmFailures++;
      console.warn('cave relief program prewarm failed; normal lazy compile remains available', error);
      return false;
    }
  }

  setBrightness(b) {
    this.brightness = b;
    if (this.readability) {
      this._applyRoomLighting(this.atmosphere.roomT,
        this._roomPresence ?? this.atmosphere.roomT);
    } else {
      // Phase 2 baseline.
      this.ambient.intensity = 0.7 * b;
      this.ambient.color.copy(this._corridorAmbientColor);
      this.headlight.intensity = 2.4 * b;
      this.hemi.intensity = 0;
      this.hemi.color.copy(this._corridorHemiSky);
      this.hemi.groundColor.copy(this._corridorHemiGround);
      this.fill.intensity = 0.25;
      this.fill.color.copy(this._corridorFillColor);
    }
    this.atmosphere.setBrightness(b);
  }

  // Room light keeps nearby mineral as a shaped dark figure against lighter
  // depth. A small physical-room share reaches the existing directional fill
  // before the style morph, so early crystal facets do not vanish into black.
  // This only changes lights/tone mapping; the visible, colliding geometry is
  // untouched. At t=0 every value is the established corridor profile.
  _applyRoomLighting(t = 0, presence = t) {
    const room = Math.max(0, Math.min(1, t));
    const physicalRoom = Math.max(0, Math.min(1, presence));
    const fillRoom = Math.max(room, 0.28 * physicalRoom);
    const shapeRoom = Math.max(room, 0.60 * physicalRoom);
    const b = this.brightness;
    this.renderer.toneMappingExposure = (1.0 + b) * (1 - 0.25 * room);
    this.ambient.intensity = b * (0.5 + 0.9 * fillRoom);
    this.ambient.color.copy(this._corridorAmbientColor).lerp(this._roomAmbientColor, fillRoom);
    this.headlight.intensity = 3.0 * b * (1 - 0.48 * room);
    this.forwardBeam.intensity = 6.5 * b * (1 - 0.52 * room);
    this.hemi.intensity = b * (0.9 + 0.30 * shapeRoom);
    this.hemi.color.copy(this._corridorHemiSky).lerp(this._roomHemiSky, shapeRoom);
    this.hemi.groundColor.copy(this._corridorHemiGround)
      .lerp(this._roomHemiGround, shapeRoom);
    this.fill.intensity = 0.25 + 0.18 * fillRoom;
    this.fill.color.copy(this._corridorFillColor).lerp(this._roomFillColor, fillRoom);
    // The cave wall uses baked vertex shading, so its room value shift is one
    // uniform multiply rather than five per-pixel lights.
    this.caveMat.color.setRGB(
      1 - 0.55 * room,
      1 - 0.50 * room,
      1 - 0.42 * room,
    );
  }

  // Difficulty-driven draw distance. Sight grows with depth/speed so the player
  // keeps a constant reaction window (see Difficulty.js / BALANCE.md).
  setSight(mul) {
    this.atmosphere.setSight(mul);
    this._syncCameraFar();
  }

  _syncCameraFar() {
    const far = cameraFarFor(this.fog.far);
    if (Math.abs(this.camera.far - far) < 1e-3) return;
    this.camera.far = far;
    this.camera.updateProjectionMatrix();
  }


  setFov(fov) { this.baseFov = fov; this.cameraCtl.setFov(fov); }
  setMotion(m) { this.cameraCtl.motion = m; this.cameraCtl.shakeEnabled = m > 0.01; }
  setQuality(maxPR) { this.maxPixelRatio = maxPR; this.resize(); }
  resize() {
    const w = window.innerWidth, h = window.innerHeight;
    const pr = effectiveRenderPixelRatio(window.devicePixelRatio, this.maxPixelRatio);
    this.renderer.setPixelRatio(pr);
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
  }

  _updateCaveGeometry(cave) {
    // One emitted ring moves every spatially ordered row left by one. Reuse
    // those exact Float32 bytes and compute only the new tail ring. Reset,
    // variant changes, multi-ring advances and head wrap rebuild every row.
    this._resizeCaveGeometry(cave.segs.length);
    const updateMode = caveGeomUpdateMode(this._geomKey, cave, this.surfaceVariantOverride);
    if (updateMode === 'skip') return;

    const pos = this.positions;
    const uvs = this.uvs;
    const colors = this.colors;
    const coilingCrests = this.coilingCrests;
    const surfaceLocals = this.caveSurfaceLocals;
    const surfaceStates = this.caveSurfaceStates;
    const surfaceMixes = this.caveSurfaceMixes;
    const roomWeights = this.caveRoomWeights;
    const segs = cave.segs;
    const capacity = segs.length;
    const firstRing = updateMode === 'shift' ? capacity - 1 : 0;
    if (updateMode === 'shift') {
      for (const [attribute, components] of [
        [pos, 3], [uvs, 2], [colors, 3], [coilingCrests, 1],
        [surfaceLocals, 4], [surfaceStates, 4], [surfaceMixes, 4], [roomWeights, 1],
      ]) attribute.copyWithin(0, SECTOR_COUNT * components);
    }
    let p = firstRing * SECTOR_COUNT * 3;
    let u = firstRing * SECTOR_COUNT * 2;
    let c = firstRing * SECTOR_COUNT * 3;
    let crest = firstRing * SECTOR_COUNT;
    let local = firstRing * SECTOR_COUNT * 4;
    let state = firstRing * SECTOR_COUNT * 4;
    let mix = firstRing * SECTOR_COUNT * 4;
    let room = firstRing * SECTOR_COUNT;
    for (let s = firstRing; s < capacity; s++) {
      const buf = (cave.i + s) % capacity;
      const ring = segs[buf];
      const centre = cave.centers[buf];
      const frame = cave.frames[buf];
      const axialDepth = centre[2];
      const stretch = surfaceStretchAt(cave.seed, axialDepth, this.surfaceVariantOverride);
      const variantA = Math.max(0, Number(stretch.currentVariant.slice(1)) - 1);
      const variantB = Math.max(0, Number(stretch.nextVariant.slice(1)) - 1);
      const variantPrevious = Math.max(0, Number((stretch.previousVariant
        ?? stretch.currentVariant).slice(1)) - 1);
      const regionProgress = Number.isFinite(stretch.regionProgress)
        ? Math.max(0, Math.min(1, stretch.regionProgress)) : 0;
      const family = familyIdAt(cave.seed, axialDepth, cave.landmarkFamilyOverride);
      const roomWeight = family >= 0 ? roomShellAt(axialDepth).weight : 0;
      const sectorOffset = (cave.ringAngleOffsets?.[buf] || 0) * SECTOR_COUNT / (Math.PI * 2);
      for (let j = 0; j < SECTOR_COUNT; j++) {
        const v = ring[j];
        // C3 may rotate the sampling lattice to keep one vertex column on its
        // travelling crest. Material coordinates follow the physical angle,
        // not the column index, while corridor rows retain their exact values.
        const physicalSector = j + sectorOffset;
        pos[p++] = v[0];
        pos[p++] = v[1];
        pos[p++] = v[2];
        // u wraps around the tube, v anchored to world-z so the rock doesn't swim
        uvs[u++] = physicalSector / SECTOR_COUNT * 4;
        uvs[u++] = v[2] * 0.06;
        const mineral = caveVertexColor(v[0], v[1], v[2], physicalSector, cave.seed, axialDepth);
        colors[c++] = mineral[0];
        colors[c++] = mineral[1];
        colors[c++] = mineral[2];
        // C3 accents follow the actual local wall displacement after its safety
        // clamp. A ring-wide amplitude also lit the untouched opposite wall.
        const familyCrest = (cave.coilingInsets?.[buf]?.[j] || 0) / COILING_MAX_RIDGE_STRENGTH;
        const corridorCrest = corridorCoilCrest(physicalSector, cave.seed, axialDepth);
        const legacyCrestPhase = Math.min(1, Math.max(0, (roomWeight - 0.12) / 0.68));
        const legacyCrestWeight = family === 2
          ? 1 - legacyCrestPhase * legacyCrestPhase * (3 - 2 * legacyCrestPhase)
          : 1;
        coilingCrests[crest++] = Math.min(1,
          Math.max(0, familyCrest, corridorCrest * legacyCrestWeight));
        const dx = v[0] - centre[0], dy = v[1] - centre[1], dz = v[2] - centre[2];
        const localRight = dx * frame.right.x + dy * frame.right.y + dz * frame.right.z;
        const localUp = dx * frame.up.x + dy * frame.up.y + dz * frame.up.z;
        surfaceLocals[local++] = axialDepth;
        surfaceLocals[local++] = localRight;
        surfaceLocals[local++] = localUp;
        surfaceLocals[local++] = Math.max(1e-6, Math.hypot(localRight, localUp));
        surfaceStates[state++] = variantA;
        surfaceStates[state++] = variantB;
        surfaceStates[state++] = stretch.transition;
        surfaceStates[state++] = family;
        surfaceMixes[mix++] = variantPrevious;
        surfaceMixes[mix++] = variantA;
        surfaceMixes[mix++] = variantB;
        surfaceMixes[mix++] = regionProgress;
        roomWeights[room++] = roomWeight;
      }
    }
    setCaveSurfaceUniforms(this.caveSurface, {
      texture: this.surfaceMaterialActive ? this.caveSurfaceTexture : null,
      means: this.caveSurfaceManifest?.layers?.map((layer) => layer.meanLinear),
      strength: this.surfaceMaterialActive ? 1 : 0,
      seed: cave.seed,
    });
    this._geomKey = caveGeomKey(cave, this.surfaceVariantOverride);
    this.caveGeo.attributes.position.needsUpdate = true;
    this.caveGeo.attributes.uv.needsUpdate = true;
    this.caveGeo.attributes.color.needsUpdate = true;
    this.caveGeo.attributes.coilingCrest.needsUpdate = true;
    this.caveGeo.attributes.caveSurfaceLocal.needsUpdate = true;
    this.caveGeo.attributes.caveSurfaceState.needsUpdate = true;
    this.caveGeo.attributes.caveSurfaceMix.needsUpdate = true;
    this.caveGeo.attributes.caveRoomWeight.needsUpdate = true;
    // NOTE: computeBoundingSphere() intentionally removed (Phase 4C / L1).
    // caveMesh.frustumCulled === false and nothing raycasts the cave, so the
    // bounding sphere was never read — it was pure dead per-frame cost.
  }

  _updateCaveDrawRange(cave, playerZ) {
    const range = caveDrawRange(cave, playerZ, this.fog.far);
    this.caveGeo.setDrawRange(range.start, range.count);
  }

  // hit: 0..1 wall-proximity for shake + danger tint.
  // warnOverride: optional 0..1 warning level for the headlight/beam tint. When
  // null the renderer uses the reactive score.warnLevel (unchanged behaviour).
  // The app passes the predictive-augmented finalWarn here (Phase 4F / M1) so the
  // forward glow leads with the audio warning; this is render-only and never feeds
  // the kill test or the score.
  render(game, hit = 0, warnOverride = null) {
    // Two independent things multiplied: WHERE (is this stretch a chamber) and
    // HOW FAR ALONG (has the look travelled from the original toward the
    // reference — see Difficulty.styleAt). Early rooms retain corridor fog
    // planes while physical-room presence colours the distant air.
    const pl = game.player;
    const roomPresence = roomAt(pl.pos[2]).t;
    const roomStyle = roomPresence * styleAt(pl.pos[2] - pl.start);
    this._roomPresence = roomPresence;
    this.atmosphere.setRoom(roomStyle,
      Math.max(roomStyle, EARLY_ROOM_COLOR_WEIGHT * roomPresence));
    this._syncCameraFar();
    if (this.readability) this._applyRoomLighting(roomStyle, roomPresence);
    this._syncCoilingRim(game.cave);
    this._syncSurfaceReliefProfile(game.cave);
    this._updateCaveGeometry(game.cave);
    this._updateCaveDrawRange(game.cave, pl.pos[2]);
    const depth = game.player.pos[2] - game.player.start;
    const fx = depth < SPEED_STEP_START || this.cameraCtl.motion <= 0.01 ? 0
      : Math.max(0, Math.min(1, (speedMul(depth) - SPEED_FLOOR_MUL) / (SPEED_REFERENCE_MUL - SPEED_FLOOR_MUL)))
        * this.cameraCtl.motion;
    this.speedFx = fx;
    this.caveSpeedWarp.value = fx;
    this.landmarkLayer.setSpeedFx(fx);
    this.landmarkLayer.update(game.cave, game.player.pos[2], this.fog.far, game.seed,
      game.landmarkCache, game.landmarkFamilyOverride,
      Math.min(game.cave.len(), this.fog.far + LANDMARK_PREWARM_AHEAD_METERS));
    this._prewarmLandmarkPrograms();
    // head-light rides just ahead of the ship, tinting red near the wall
    const p = game.player;
    this.headlight.position.set(p.pos[0], p.pos[1], p.pos[2] + 1.5);
    const warn = warnOverride != null ? warnOverride : (game.score.warnLevel || 0);
    this.headlight.color.setRGB(1, 1 - 0.55 * warn, 0.87 - 0.7 * warn);

    // Aim the forward beam down the tunnel (player.pos + lookAt).
    this._aimBeam(p, warn);

    this.cameraCtl.update(game.player, hit);
    this.renderer.render(this.scene, this.camera);
  }

  // Tooling view: isolate one authoritative composition and orbit it in its
  // route-local cross-section. The cave is hidden only for this extra draw; the
  // gameplay scene and camera contract remain unchanged.
  renderOrbitPose(comp, angle = 0) {
    if (!comp?.frame) return false;
    const f = comp.frame;
    const a = Number.isFinite(angle) ? angle : 0;
    const lo = new THREE.Vector3(Infinity, Infinity, Infinity);
    const hi = new THREE.Vector3(-Infinity, -Infinity, -Infinity);
    for (const piece of comp.pieces) {
      const half = piece.length / 2;
      for (const sign of [-1, 1]) {
        const x = piece.cx + piece.dx * half * sign;
        const y = piece.cy + piece.dy * half * sign;
        const z = piece.cz + piece.dz * half * sign;
        lo.x = Math.min(lo.x, x - piece.radius); lo.y = Math.min(lo.y, y - piece.radius); lo.z = Math.min(lo.z, z - piece.radius);
        hi.x = Math.max(hi.x, x + piece.radius); hi.y = Math.max(hi.y, y + piece.radius); hi.z = Math.max(hi.z, z + piece.radius);
      }
    }
    const target = lo.clone().add(hi).multiplyScalar(0.5);
    let bound = 1;
    for (const piece of comp.pieces) {
      const half = piece.length / 2;
      for (const sign of [-1, 1]) {
        const endpoint = new THREE.Vector3(
          piece.cx + piece.dx * half * sign,
          piece.cy + piece.dy * half * sign,
          piece.cz + piece.dz * half * sign,
        );
        bound = Math.max(bound, endpoint.distanceTo(target) + piece.radius);
      }
    }
    const halfFov = THREE.MathUtils.degToRad(this.camera.fov * 0.5);
    const distance = Math.max(18, bound / Math.sin(halfFov) * 1.08);
    const ca = Math.cos(a), sa = Math.sin(a);
    this.camera.position.set(
      target.x + f.right.x * ca * distance + f.up.x * sa * distance,
      target.y + f.right.y * ca * distance + f.up.y * sa * distance,
      target.z + f.right.z * ca * distance + f.up.z * sa * distance,
    );
    this.camera.up.set(f.tangent.x, f.tangent.y, f.tangent.z);
    this.camera.lookAt(target);
    const caveVisible = this.caveMesh.visible;
    const sceneFog = this.scene.fog;
    const cameraFar = this.camera.far;
    const lightPosition = this.headlight.position.clone();
    const lightDistance = this.headlight.distance;
    this.caveMesh.visible = false;
    this.scene.fog = null;
    this.camera.far = distance + bound * 1.25;
    this.camera.updateProjectionMatrix();
    this.headlight.position.copy(this.camera.position);
    this.headlight.distance = distance + bound * 2;
    this.renderer.render(this.scene, this.camera);
    this.caveMesh.visible = caveVisible;
    this.scene.fog = sceneFog;
    this.camera.far = cameraFar;
    this.camera.updateProjectionMatrix();
    this.headlight.position.copy(lightPosition);
    this.headlight.distance = lightDistance;
    return true;
  }

  // Aim the forward beam down the tunnel from the player position.
  _aimBeam(p, warn = 0) {
    if (!this.readability) return;
    const lx = p.lookAt[0], ly = p.lookAt[1], lz = p.lookAt[2] || 1;
    this.forwardBeam.position.set(p.pos[0], p.pos[1], p.pos[2]);
    this.forwardBeam.target.position.set(
      p.pos[0] + lx * 20, p.pos[1] + ly * 20, p.pos[2] + lz * 20);
    this.forwardBeam.target.updateMatrixWorld();
    this.forwardBeam.color.setRGB(1, 1 - 0.45 * warn, 0.78 - 0.6 * warn);
  }

  // a quiet idle spin of the menu background using a parked game
  renderIdle(game) {
    // Two independent things multiplied: WHERE (is this stretch a chamber) and
    // HOW FAR ALONG (has the look travelled from the original toward the
    // reference — see Difficulty.styleAt). Early rooms retain corridor fog
    // planes while physical-room presence colours the distant air.
    const pl = game.player;
    const roomPresence = roomAt(pl.pos[2]).t;
    const roomStyle = roomPresence * styleAt(pl.pos[2] - pl.start);
    this._roomPresence = roomPresence;
    this.atmosphere.setRoom(roomStyle,
      Math.max(roomStyle, EARLY_ROOM_COLOR_WEIGHT * roomPresence));
    if (this.readability) this._applyRoomLighting(roomStyle, roomPresence);
    this._syncCoilingRim(game.cave);
    this._syncSurfaceReliefProfile(game.cave);
    this._updateCaveGeometry(game.cave);
    this._updateCaveDrawRange(game.cave, pl.pos[2]);
    this.landmarkLayer.update(game.cave, game.player.pos[2], this.fog.far, game.seed,
      game.landmarkCache, game.landmarkFamilyOverride,
      Math.min(game.cave.len(), this.fog.far + LANDMARK_PREWARM_AHEAD_METERS));
    this._prewarmLandmarkPrograms();
    this.headlight.position.set(
      game.player.pos[0], game.player.pos[1], game.player.pos[2] + 1.5);
    this._aimBeam(game.player, 0);
    this.cameraCtl.update(game.player, 0);
    this.renderer.render(this.scene, this.camera);
  }
}
