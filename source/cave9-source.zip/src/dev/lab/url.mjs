import { normalizeVisualScenario } from '../scenario/schema.mjs';

const DEFAULT_BASE = 'http://localhost/';
const boolParam = (params, name) => {
  if (!params.has(name)) return undefined;
  return !['0', 'false', 'off', 'no'].includes((params.get(name) ?? '').toLowerCase());
};

export function parseScenarioUrl(input = globalThis.location?.href ?? DEFAULT_BASE) {
  const url = input instanceof URL ? input : new URL(String(input), DEFAULT_BASE);
  const p = url.searchParams;
  return normalizeVisualScenario({
    name: p.get('name') ?? undefined,
    seed: p.get('seed') ?? undefined,
    mode: p.get('mode') ?? undefined,
    distance: p.get('distance') ?? undefined,
    steps: p.get('steps') ?? undefined,
    family: p.get('family') ?? undefined,
    camera: p.get('camera') ?? undefined,
    orthographicAxis: p.get('orthoAxis') ?? undefined,
    renderPass: p.get('renderPass') ?? undefined,
    orbitDegrees: p.get('orbit') ?? undefined,
    orbitScope: p.get('orbitScope') ?? undefined,
    placement: p.get('placement') ?? (boolParam(p, 'place') ? 'place' : undefined),
    control: p.get('control') ?? undefined,
    paused: boolParam(p, 'paused'),
    viewport: {
      width: p.get('width') ?? undefined,
      height: p.get('height') ?? undefined,
      dpr: p.get('dpr') ?? undefined,
    },
    settings: {
      readability: boolParam(p, 'readability'),
      rockDetail: boolParam(p, 'rockDetail'),
      surfaceRelief: boolParam(p, 'surfaceRelief'),
      landmarks: boolParam(p, 'landmarks'),
      cave: boolParam(p, 'cave'),
      wireframe: boolParam(p, 'wireframe'),
      landmarkMesh: boolParam(p, 'landmarkMesh'),
      collisionCapsules: boolParam(p, 'collisionCapsules'),
      booleanTube: boolParam(p, 'booleanTube'),
      playerHull: boolParam(p, 'playerHull'),
      frames: boolParam(p, 'frames'),
      fog: boolParam(p, 'fog'),
      material: boolParam(p, 'material'),
      light: boolParam(p, 'light'),
      brightness: p.get('brightness') ?? undefined,
      fov: p.get('fov') ?? undefined,
      motion: p.get('motion') ?? undefined,
    },
  });
}

const setBool = (params, name, value) => params.set(name, value ? '1' : '0');

export function serializeScenarioUrl(
  input,
  base = globalThis.location?.href ?? DEFAULT_BASE,
) {
  const scenario = normalizeVisualScenario(input);
  const url = base instanceof URL ? new URL(base.href) : new URL(String(base), DEFAULT_BASE);
  const p = url.searchParams;
  p.set('visualLab', '1');
  p.delete('lab');
  p.set('name', scenario.name);
  p.set('seed', String(scenario.seed));
  p.set('mode', String(scenario.mode));
  p.set('distance', String(scenario.distance));
  p.set('steps', String(scenario.steps));
  p.set('family', scenario.family);
  p.set('camera', scenario.camera);
  p.set('orthoAxis', scenario.orthographicAxis);
  p.set('renderPass', scenario.renderPass);
  p.set('orbit', String(scenario.orbitDegrees));
  p.set('orbitScope', scenario.orbitScope);
  p.set('placement', scenario.placement);
  p.set('control', scenario.control);
  setBool(p, 'paused', scenario.paused);
  p.set('width', String(scenario.viewport.width));
  p.set('height', String(scenario.viewport.height));
  p.set('dpr', String(scenario.viewport.dpr));
  setBool(p, 'readability', scenario.settings.readability);
  setBool(p, 'rockDetail', scenario.settings.rockDetail);
  setBool(p, 'surfaceRelief', scenario.settings.surfaceRelief);
  setBool(p, 'landmarks', scenario.settings.landmarks);
  for (const name of ['cave', 'wireframe', 'landmarkMesh', 'collisionCapsules',
    'booleanTube', 'playerHull', 'frames', 'fog', 'material', 'light']) {
    setBool(p, name, scenario.settings[name]);
  }
  p.set('brightness', String(scenario.settings.brightness));
  p.set('fov', String(scenario.settings.fov));
  p.set('motion', String(scenario.settings.motion));
  p.delete('place');
  return url.href;
}
