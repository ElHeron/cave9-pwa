import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';

const CAVE_LAYERS = new Set(['cave', 'wireframe', 'landmarkMesh', 'collisionCapsules',
  'booleanTube', 'playerHull', 'frames', 'fog', 'material', 'light']);

// Fixed world-space lighting for geometry review. These values never follow
// gameplay warning, room depth or the orbit camera, so matched captures share
// one documented light rig. Production geometry and normals are unchanged.
export const VISUAL_CLAY_LIGHT_RIG = Object.freeze({
  ambient: { color: 0xffffff, intensity: 0.85 },
  key: { color: 0xffffff, intensity: 2.0, position: [12, 18, 26] },
  fill: { color: 0xffffff, intensity: 0.9, position: [-16, -8, -12] },
  material: { color: 0x92979b, roughness: 1, metalness: 0 },
  background: 0x292c30,
});

function disposeChildren(group) {
  while (group.children.length) {
    const child = group.children.pop();
    child.geometry?.dispose?.();
    child.material?.dispose?.();
  }
}

function addSegments(group, points, color, opacity = 0.8) {
  if (!points.length) return;
  const geometry = new THREE.BufferGeometry().setFromPoints(points);
  const material = new THREE.LineBasicMaterial({ color, transparent: opacity < 1, opacity,
    depthWrite: false, toneMapped: false });
  group.add(new THREE.LineSegments(geometry, material));
}

export class VisualDebug3d {
  constructor(renderer) {
    this.r = renderer;
    this.scene = renderer.scene;
    this._originalRenderState = {
      caveMaterial: renderer.caveMesh.material,
      caveVisible: renderer.caveMesh.visible,
      landmarkVisible: renderer.landmarkLayer.group.visible,
      fog: renderer.scene.fog,
      background: renderer.scene.background,
      lights: new Map([renderer.ambient, renderer.headlight, renderer.forwardBeam,
        renderer.hemi, renderer.fill].map((light) => [light, light.visible])),
    };
    this._disposed = false;
    this.layers = {
      cave: true, wireframe: false, landmarkMesh: true, collisionCapsules: false,
      booleanTube: false, playerHull: false, frames: false, fog: true, material: true, light: true,
    };
    this.group = new THREE.Group();
    this.group.name = 'visual-lab-debug-layers';
    this.scene.add(this.group);
    this.tubeGroup = new THREE.Group();
    this.frameGroup = new THREE.Group();
    this.capsuleGroup = new THREE.Group();
    this.group.add(this.tubeGroup, this.frameGroup, this.capsuleGroup);
    this.wireMaterial = new THREE.MeshBasicMaterial({ color: 0x75d7ff, wireframe: true,
      transparent: true, opacity: 0.55, depthWrite: false, toneMapped: false });
    this.wireMesh = new THREE.Mesh(renderer.caveGeo, this.wireMaterial);
    this.wireMesh.frustumCulled = false;
    this.wireMesh.visible = false;
    this.group.add(this.wireMesh);
    this.playerMaterial = new THREE.MeshBasicMaterial({ color: 0xffd34d, wireframe: true,
      transparent: true, opacity: 0.9, depthWrite: false, toneMapped: false });
    this.playerHull = new THREE.Mesh(new THREE.SphereGeometry(1, 16, 10), this.playerMaterial);
    this.playerHull.visible = false;
    this.group.add(this.playerHull);
    this.flatMaterial = new THREE.MeshNormalMaterial({ flatShading: true, side: THREE.FrontSide });
    this.neutralLandmarkMaterial = new THREE.MeshBasicMaterial({ color: 0x777b82,
      side: THREE.FrontSide, toneMapped: false });
    this.clayMaterial = new THREE.MeshStandardMaterial({
      ...VISUAL_CLAY_LIGHT_RIG.material, side: THREE.FrontSide, toneMapped: false,
    });
    // CaveGeometry has positions but no vertex-normal attribute. Fragment
    // derivatives recover its actual triangle normals for directional light.
    this.clayCaveMaterial = new THREE.MeshStandardMaterial({
      ...VISUAL_CLAY_LIGHT_RIG.material, side: THREE.FrontSide,
      flatShading: true, toneMapped: false,
    });
    this.clayRig = new THREE.Group();
    this.clayRig.name = 'visual-lab-fixed-clay-light-rig';
    const ambient = VISUAL_CLAY_LIGHT_RIG.ambient;
    const key = VISUAL_CLAY_LIGHT_RIG.key;
    const fill = VISUAL_CLAY_LIGHT_RIG.fill;
    this.clayRig.add(new THREE.AmbientLight(ambient.color, ambient.intensity));
    for (const spec of [key, fill]) {
      const light = new THREE.DirectionalLight(spec.color, spec.intensity);
      light.position.fromArray(spec.position);
      this.clayRig.add(light);
    }
    this.clayRig.visible = false;
    this.scene.add(this.clayRig);
    this.silhouetteMaterial = new THREE.MeshBasicMaterial({ color: 0x000000,
      side: THREE.FrontSide, toneMapped: false });
    this._beautyBackground = this.scene.background;
    this._silhouetteBackground = new THREE.Color(0xffffff);
    this._clayBackground = new THREE.Color(VISUAL_CLAY_LIGHT_RIG.background);
    this.renderPass = 'beauty';
    this.freeCamera = renderer.camera.clone();
    this.orthoCamera = new THREE.OrthographicCamera(-8, 8, 8, -8, 0.05, 1000);
    this.freeControls = new OrbitControls(this.freeCamera, renderer.canvas);
    this.orthoControls = new OrbitControls(this.orthoCamera, renderer.canvas);
    this._onFreeChange = () => {
      if (this.cameraMode === 'free') this.r.renderer.render(this.scene, this.freeCamera);
    };
    this._onOrthoChange = () => {
      if (this.cameraMode === 'orthographic') this.r.renderer.render(this.scene, this.orthoCamera);
    };
    this.freeControls.addEventListener('change', this._onFreeChange);
    this.orthoControls.addEventListener('change', this._onOrthoChange);
    this.freeControls.enabled = false;
    this.orthoControls.enabled = false;
    this.cameraMode = 'hero';
    this._cameraNeedsSync = true;
    this._caveKey = '';
    this._capsuleKey = '';
    this._orbitDrawRanges = [];
  }

  resetCamera() { this._cameraNeedsSync = true; }

  get activeCamera() {
    if (this.cameraMode === 'free') return this.freeCamera;
    if (this.cameraMode === 'orthographic') return this.orthoCamera;
    return this.r.camera;
  }

  getActiveCamera() { return this.activeCamera; }

  setRenderPass(pass = 'beauty') {
    if (!['beauty', 'neutral', 'clay', 'silhouette'].includes(pass)) {
      throw new RangeError(`Unsupported visual render pass "${pass}"`);
    }
    this.renderPass = pass;
    this._applyRenderPass();
    return this.renderPass;
  }

  setLayer(name, enabled) {
    if (!CAVE_LAYERS.has(name)) return false;
    this.layers[name] = !!enabled;
    const r = this.r;
    if (name === 'cave') r.caveMesh.visible = !!enabled;
    if (name === 'wireframe') this.wireMesh.visible = !!enabled;
    if (name === 'landmarkMesh') r.landmarkLayer.group.visible = !!enabled;
    if (name === 'fog') r.scene.fog = enabled ? r.atmosphere.fog : null;
    if (name === 'material') r.caveMesh.material = enabled ? r.caveMat : this.flatMaterial;
    if (name === 'light') {
      for (const light of [r.ambient, r.headlight, r.forwardBeam, r.hemi, r.fill]) light.visible = !!enabled;
    }
    if (!enabled && name === 'collisionCapsules') disposeChildren(this.capsuleGroup);
    if (!enabled && name === 'booleanTube') disposeChildren(this.tubeGroup);
    if (!enabled && name === 'frames') disposeChildren(this.frameGroup);
    if (enabled && name === 'collisionCapsules') this._capsuleKey = '';
    if (enabled && (name === 'booleanTube' || name === 'frames')) this._caveKey = '';
    this._applyRenderPass();
    return true;
  }

  update(game, compositions = game.landmarkCompositions) {
    this.wireMesh.visible = this.layers.wireframe;
    this.playerHull.visible = this.layers.playerHull;
    this.playerHull.position.fromArray(game.player.pos);
    this.playerHull.scale.setScalar(game.player.radius);
    const caveKey = `${game.cave.i}:${game.cave.segs.length}:${game.cave.cursorDepth}`;
    if (caveKey !== this._caveKey) {
      this._caveKey = caveKey;
      if (this.layers.booleanTube) this._rebuildTube(game.cave);
      if (this.layers.frames) this._rebuildFrames(game.cave);
    }
    const capsuleKey = compositions
      .map((comp) => `${comp.k}:${comp.surfaceRevision}:${comp.collisionPieces?.length || 0}`).join('|');
    if (this.layers.collisionCapsules && capsuleKey !== this._capsuleKey) {
      this._capsuleKey = capsuleKey;
      this._rebuildCapsules(compositions);
    }
    this._applyRenderPass();
  }

  clearOrbitPieceScope() {
    const ranges = this._orbitDrawRanges.splice(0);
    let restoreError = null;
    for (const { geometry, start, count } of ranges) {
      try { geometry.setDrawRange(start, count); }
      catch (error) { restoreError ??= error; }
    }
    if (restoreError) throw restoreError;
  }

  // A Crystal evidence orbit intentionally inspects one of its three separate
  // axial irises. The camera already fits one authoritative bank; the
  // other two banks must not leak in from beyond that fit and be clipped at an
  // image edge. Slabs are emitted in piece/gid order at a fixed index cost, so a
  // draw range isolates real production triangles without cloning, scaling or
  // inventing any geometry. The original range is restored before every Hero
  // render and on disposal.
  setOrbitPieceScope(composition, pieces) {
    this.clearOrbitPieceScope();
    if (composition?.typeName !== 'crystal' || !composition.pieces?.length || !pieces?.length) {
      return { applied: false, meshCount: 0, pieceCount: 0 };
    }
    const gids = pieces.map((piece) => piece.gid).sort((a, b) => a - b);
    if (gids.some((gid, index) => !Number.isInteger(gid)
      || (index > 0 && gid !== gids[index - 1] + 1))) {
      return { applied: false, meshCount: 0, pieceCount: 0 };
    }
    let meshCount = 0, completed = false;
    try {
      const suffix = `:${composition.k}:${composition.typeName}`;
      for (const entry of this.r.landmarkLayer?.built?.values?.() || []) {
        if (!entry.group.visible || !entry.roomKey?.endsWith(suffix)) continue;
        entry.group.traverse((object) => {
          const geometry = object.geometry;
          const indexCount = geometry?.getIndex?.()?.count;
          if (!object.isMesh || !(indexCount > 0)) return;
          const indicesPerPiece = indexCount / composition.pieces.length;
          if (!Number.isInteger(indicesPerPiece)) return;
          this._orbitDrawRanges.push({ geometry,
            start: geometry.drawRange.start, count: geometry.drawRange.count });
          geometry.setDrawRange(gids[0] * indicesPerPiece, gids.length * indicesPerPiece);
          meshCount++;
        });
      }
      completed = true;
      return { applied: meshCount > 0, meshCount, pieceCount: gids.length,
        firstGid: gids[0], lastGid: gids[gids.length - 1] };
    } finally {
      if (!completed) this.clearOrbitPieceScope();
    }
  }

  _applyRenderPass() {
    const beauty = this.renderPass === 'beauty';
    const clay = this.renderPass === 'clay';
    const silhouette = this.renderPass === 'silhouette';
    for (const room of this.r.landmarkLayer?.group?.children || []) for (const mesh of room.children || []) {
      if (!mesh.isMesh) continue;
      if (!mesh.userData.visualBeautyMaterial) mesh.userData.visualBeautyMaterial = mesh.material;
      mesh.material = beauty ? mesh.userData.visualBeautyMaterial
        : silhouette ? this.silhouetteMaterial
          : clay ? this.clayMaterial : this.neutralLandmarkMaterial;
    }
    this.r.caveMesh.material = clay ? this.clayCaveMaterial
      : beauty && this.layers.material ? this.r.caveMat : this.flatMaterial;
    this.r.caveMesh.visible = silhouette ? false : this.layers.cave;
    this.scene.background = silhouette ? this._silhouetteBackground
      : clay ? this._clayBackground : this._beautyBackground;
    this.scene.fog = beauty && this.layers.fog ? this.r.atmosphere.fog : null;
    for (const light of [this.r.ambient, this.r.headlight, this.r.forwardBeam, this.r.hemi, this.r.fill]) {
      light.visible = beauty && this.layers.light;
    }
    this.clayRig.visible = clay;
  }

  _rebuildTube(cave) {
    disposeChildren(this.tubeGroup);
    const points = [];
    for (let i = 0; i < cave.frames.length; i += 4) {
      const frame = cave.frames[i], radius = cave.innerRadii[i];
      if (!frame || !(radius > 0)) continue;
      for (let j = 0; j < 32; j++) {
        for (const k of [j, (j + 1) % 32]) {
          const angle = k / 32 * Math.PI * 2;
          points.push(new THREE.Vector3(
            frame.center.x + frame.right.x * Math.cos(angle) * radius + frame.up.x * Math.sin(angle) * radius,
            frame.center.y + frame.right.y * Math.cos(angle) * radius + frame.up.y * Math.sin(angle) * radius,
            frame.center.z + frame.right.z * Math.cos(angle) * radius + frame.up.z * Math.sin(angle) * radius,
          ));
        }
      }
    }
    addSegments(this.tubeGroup, points, 0x44ff99, 0.72);
  }

  _rebuildFrames(cave) {
    disposeChildren(this.frameGroup);
    const axes = [
      ['right', 0xff5577], ['up', 0x66ff88], ['tangent', 0x66aaff],
    ];
    for (const [name, color] of axes) {
      const points = [];
      for (let i = 0; i < cave.frames.length; i += 8) {
        const frame = cave.frames[i];
        if (!frame) continue;
        points.push(new THREE.Vector3(frame.center.x, frame.center.y, frame.center.z));
        points.push(new THREE.Vector3(frame.center.x + frame[name].x * 2,
          frame.center.y + frame[name].y * 2, frame.center.z + frame[name].z * 2));
      }
      addSegments(this.frameGroup, points, color);
    }
  }

  _rebuildCapsules(compositions) {
    disposeChildren(this.capsuleGroup);
    const fromY = new THREE.Vector3(0, 1, 0);
    for (const comp of compositions || []) for (const piece of comp.collisionPieces || comp.pieces || []) {
      const material = new THREE.MeshBasicMaterial({
        color: piece.collisionOnly ? 0xff4f9a : 0xffa23d, wireframe: true,
        transparent: true, opacity: 0.7, depthWrite: false, toneMapped: false,
      });
      const geometry = new THREE.CapsuleGeometry(piece.radius, piece.length, 4, 8);
      const mesh = new THREE.Mesh(geometry, material);
      mesh.position.set(piece.cx, piece.cy, piece.cz);
      const direction = new THREE.Vector3(piece.dx, piece.dy, piece.dz).normalize();
      mesh.quaternion.setFromUnitVectors(fromY, direction);
      this.capsuleGroup.add(mesh);
    }
  }

  _orthographicFit(composition, frame, axis, aspect) {
    const vertices = [];
    for (const entry of this.r.landmarkLayer?.built?.values?.() || []) {
      if (!entry.group.visible || !entry.roomKey?.endsWith(`:${composition.k}:${composition.typeName}`)) continue;
      entry.group.updateMatrixWorld(true);
      entry.group.traverse((object) => {
        const position = object.geometry?.getAttribute?.('position');
        if (!object.isMesh || !position) return;
        for (let i = 0; i < position.count; i++) {
          vertices.push(new THREE.Vector3(position.getX(i), position.getY(i), position.getZ(i))
            .applyMatrix4(object.matrixWorld));
        }
      });
    }
    if (!vertices.length) return null;
    const right = new THREE.Vector3(frame.right.x, frame.right.y, frame.right.z).normalize();
    const up = new THREE.Vector3(frame.up.x, frame.up.y, frame.up.z).normalize();
    const tangent = new THREE.Vector3(frame.tangent.x, frame.tangent.y, frame.tangent.z).normalize();
    const view = axis === 'side' ? right.clone().multiplyScalar(-1)
      : axis === 'top' ? up.clone().multiplyScalar(-1) : tangent;
    const screenRight = axis === 'side' ? tangent : right;
    const screenUp = axis === 'top' ? tangent : up;
    const bounds = { r0: Infinity, r1: -Infinity, u0: Infinity, u1: -Infinity, d0: Infinity, d1: -Infinity };
    for (const vertex of vertices) {
      const r = vertex.dot(screenRight), u = vertex.dot(screenUp), d = vertex.dot(view);
      bounds.r0 = Math.min(bounds.r0, r); bounds.r1 = Math.max(bounds.r1, r);
      bounds.u0 = Math.min(bounds.u0, u); bounds.u1 = Math.max(bounds.u1, u);
      bounds.d0 = Math.min(bounds.d0, d); bounds.d1 = Math.max(bounds.d1, d);
    }
    const midR = (bounds.r0 + bounds.r1) / 2;
    const midU = (bounds.u0 + bounds.u1) / 2;
    const midD = (bounds.d0 + bounds.d1) / 2;
    const target = screenRight.clone().multiplyScalar(midR)
      .add(screenUp.clone().multiplyScalar(midU)).add(view.clone().multiplyScalar(midD));
    const halfHeight = Math.max(4, (bounds.u1 - bounds.u0) * 0.56,
      (bounds.r1 - bounds.r0) / Math.max(0.1, aspect) * 0.56);
    const distance = Math.max(40, bounds.d1 - bounds.d0 + 24);
    return { target, view, screenUp, halfHeight, distance, vertexCount: vertices.length };
  }

  presentCamera(mode, game, { axis = 'front', focus = null, frame = null } = {}) {
    this.freeControls.enabled = mode === 'free';
    this.orthoControls.enabled = mode === 'orthographic';
    if (mode !== 'free' && mode !== 'orthographic') {
      this.cameraMode = mode;
      return null;
    }
    const hero = this.r.camera;
    const camera = mode === 'free' ? this.freeCamera : this.orthoCamera;
    const controls = mode === 'free' ? this.freeControls : this.orthoControls;
    const width = this.r.canvas.clientWidth || this.r.canvas.width || 1;
    const height = this.r.canvas.clientHeight || this.r.canvas.height || 1;
    const orthoFit = mode === 'orthographic' && focus && frame
      ? this._orthographicFit(focus, frame, axis, width / height) : null;
    if (orthoFit) {
      camera.position.copy(orthoFit.target).addScaledVector(orthoFit.view, -orthoFit.distance);
      camera.up.copy(orthoFit.screenUp);
      controls.target.copy(orthoFit.target);
      camera.lookAt(orthoFit.target);
      this._orthoHalfHeight = orthoFit.halfHeight;
      this._orthoVertexCount = orthoFit.vertexCount;
      this._cameraNeedsSync = false;
    } else if (this._cameraNeedsSync || this.cameraMode !== mode) {
      camera.position.copy(hero.position);
      camera.quaternion.copy(hero.quaternion);
      camera.up.copy(hero.up);
      const look = new THREE.Vector3(...game.player.lookAt).normalize();
      controls.target.fromArray(game.player.pos).addScaledVector(look, 22);
      this._cameraNeedsSync = false;
    }
    if (camera.isPerspectiveCamera) {
      camera.aspect = width / height;
      camera.fov = hero.fov;
    } else {
      const half = this._orthoHalfHeight ?? (focus ? 20 : 8);
      camera.left = -half * width / height; camera.right = half * width / height;
      camera.top = half; camera.bottom = -half;
    }
    camera.far = Math.max(1000, hero.far);
    camera.updateProjectionMatrix();
    controls.update();
    this.r.renderer.render(this.scene, camera);
    this.cameraMode = mode;
    return {
      requested: mode, active: mode, supported: true,
      projection: camera.isOrthographicCamera ? 'orthographic' : 'perspective',
      axis: camera.isOrthographicCamera ? axis : null,
      fittedVertexCount: camera.isOrthographicCamera ? this._orthoVertexCount ?? 0 : null,
      halfHeight: camera.isOrthographicCamera ? this._orthoHalfHeight ?? null : null,
      position: camera.position.toArray(), target: controls.target.toArray(),
    };
  }

  dispose() {
    if (this._disposed) return;
    this._disposed = true;
    this.clearOrbitPieceScope();
    for (const room of this.r.landmarkLayer?.group?.children || []) for (const mesh of room.children || []) {
      if (!mesh.isMesh || !mesh.userData.visualBeautyMaterial) continue;
      mesh.material = mesh.userData.visualBeautyMaterial;
      delete mesh.userData.visualBeautyMaterial;
    }
    this.freeControls.removeEventListener('change', this._onFreeChange);
    this.orthoControls.removeEventListener('change', this._onOrthoChange);
    this.freeControls.dispose();
    this.orthoControls.dispose();
    const original = this._originalRenderState;
    this.r.caveMesh.material = original.caveMaterial;
    this.r.caveMesh.visible = original.caveVisible;
    this.r.landmarkLayer.group.visible = original.landmarkVisible;
    this.r.scene.fog = original.fog;
    this.r.scene.background = original.background;
    for (const [light, visible] of original.lights) light.visible = visible;
    this.scene.remove(this.group);
    this.scene.remove(this.clayRig);
    disposeChildren(this.tubeGroup); disposeChildren(this.frameGroup); disposeChildren(this.capsuleGroup);
    this.playerHull.geometry.dispose(); this.playerMaterial.dispose();
    this.wireMaterial.dispose(); this.flatMaterial.dispose();
    this.neutralLandmarkMaterial.dispose(); this.clayMaterial.dispose();
    this.clayCaveMaterial.dispose();
    this.silhouetteMaterial.dispose();
  }
}

export const VISUAL_DEBUG_LAYERS = Object.freeze([...CAVE_LAYERS]);
