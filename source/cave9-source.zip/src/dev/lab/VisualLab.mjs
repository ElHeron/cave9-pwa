import * as THREE from 'three';
import { createVisualDevApi } from '../scenario/VisualScenarioRunner.mjs';
import { normalizeVisualScenario } from '../scenario/schema.mjs';
import { parseScenarioUrl, serializeScenarioUrl } from './url.mjs';
import { VisualDebug3d, VISUAL_DEBUG_LAYERS } from './VisualDebug3d.mjs';
import {
  surfaceStretchAt,
  tunnelVariantSharesAt,
} from '../../render/materials/caveSurfaceState.js';
import {
  buildCaveAtlas,
  inspectDepthSector,
  inspectWorldPoint,
  renderCaveAtlasFragment,
} from '../atlas/index.js';

const HOST_ID = 'cave9-visual-lab';
const mounted = new WeakMap();

const markup = `
  <style>
    :host { all: initial; color-scheme: dark; }
    .lab { position: fixed; z-index: 2147483647; top: 12px; right: 12px; width: 440px;
      max-height: calc(100vh - 24px); overflow: auto;
      box-sizing: border-box; padding: 12px; border: 1px solid #516079; border-radius: 9px;
      background: rgba(8, 11, 17, .94); color: #e8edf5; box-shadow: 0 8px 28px #000a;
      font: 12px/1.35 ui-monospace, SFMono-Regular, Consolas, monospace; }
    h2 { margin: 0 0 10px; font: 600 14px/1.2 system-ui, sans-serif; letter-spacing: .04em; }
    .grid { display: grid; grid-template-columns: 88px 1fr; gap: 6px 8px; align-items: center; }
    label { color: #b9c5d6; }
    input, select, button { box-sizing: border-box; min-width: 0; border: 1px solid #46546a;
      border-radius: 4px; background: #141b27; color: #f4f7fb; font: inherit; }
    input, select { width: 100%; padding: 5px 6px; }
    input[type=checkbox] { width: auto; justify-self: start; accent-color: #79a8ff; }
    .actions { display: grid; grid-template-columns: repeat(4, 1fr); gap: 5px; margin: 10px 0; }
    button { padding: 6px 4px; cursor: pointer; }
    button:hover { border-color: #79a8ff; }
    .layers { display: grid; grid-template-columns: repeat(5, 1fr); gap: 5px; }
    .layers label { display: grid; justify-items: center; gap: 3px; padding: 5px 2px;
      border: 1px solid #303b4d; border-radius: 4px; }
    pre { max-height: 170px; margin: 10px 0 0; padding: 7px; overflow: auto;
      border-radius: 4px; background: #070a0f; color: #a9c7f7; white-space: pre-wrap; }
    details { margin-top: 10px; border-top: 1px solid #303b4d; padding-top: 8px; }
    summary { cursor: pointer; color: #cbd7e7; }
    #atlas { margin-top: 7px; color: #b9d6ff; }
    #atlas .cave-atlas-header h2 { margin: 0; font-size: 12px; }
    #atlas .cave-atlas-header p, #atlas figcaption { margin: 2px 0; font-size: 9px; color: #8ea2bc; }
    #atlas figure { margin: 8px 0; }
    #atlas svg { display: block; width: 100%; height: auto; background: #070a0f; }
    #atlas [data-depth] { cursor: crosshair; }
    #atlas [data-depth]:hover { filter: brightness(1.5); }
    #atlas .atlas-selected { stroke: #fff; stroke-width: 1.4px; filter: brightness(1.8); }
  </style>
  <section class="lab" aria-label="Cave9 Visual Lab">
    <h2>Visual Lab · V1</h2>
    <div class="grid">
      <label for="seed">Seed</label><input id="seed" type="number" step="1">
      <label for="distance">Distance</label><input id="distance" type="number" min="0" max="1000000" step="10">
      <label for="surfaceVariant">Tunnel surface</label><select id="surfaceVariant"><option value="">Auto</option><option value="v1">V1</option><option value="v2">V2</option><option value="v3">V3</option><option value="v4">V4</option><option value="v5">V5</option><option value="v6">V6</option><option value="v7">V7</option><option value="v8">V8</option></select>
      <label for="family">Family</label><select id="family"><option value="auto">Auto</option><option value="branching">Branching</option><option value="crystal">Crystal</option><option value="coiling">Coiling</option></select>
      <label for="camera">Camera</label><select id="camera"><option value="hero">Hero</option><option value="orbit">Formation orbit</option><option value="free">Free</option><option value="orthographic">Orthographic</option></select>
      <label for="orthoAxis">Ortho axis</label><select id="orthoAxis"><option value="front">Front</option><option value="side">Side</option><option value="top">Top</option></select>
      <label for="renderPass">Render pass</label><select id="renderPass"><option value="beauty">Beauty</option><option value="neutral">Neutral</option><option value="clay">Lit clay (wall + form)</option><option value="silhouette">Silhouette</option></select>
      <label for="orbit">Orbit °</label><input id="orbit" type="number" step="15">
      <label for="orbitScope">Orbit scope</label><select id="orbitScope"><option value="detail-bank">Crystal bank detail</option><option value="complete-composition">Complete composition</option></select>
      <label for="placement">Placement</label><select id="placement"><option value="fly">Fly</option><option value="place">Place</option></select>
      <label for="control">Control</label><select id="control"><option value="autopilot">Autopilot</option><option value="neutral">Neutral</option></select>
    </div>
    <div class="actions">
      <button id="pause" type="button">Resume</button>
      <button id="step" type="button">Step</button>
      <button id="reset" type="button">Reset</button>
      <button id="url" type="button">Copy URL</button>
    </div>
    <div class="layers">
      <label>Landmarks<input id="landmarks" type="checkbox"></label>
      <label>Rock detail<input id="rockDetail" type="checkbox"></label>
      <label>Normal + height<input id="surfaceRelief" type="checkbox"></label>
      <label>Readability<input id="readability" type="checkbox"></label>
      <label>Cave<input id="cave" type="checkbox"></label>
      <label>Wire<input id="wireframe" type="checkbox"></label>
      <label>LM mesh<input id="landmarkMesh" type="checkbox"></label>
      <label>Capsules<input id="collisionCapsules" type="checkbox"></label>
      <label>Bool tube<input id="booleanTube" type="checkbox"></label>
      <label>Player<input id="playerHull" type="checkbox"></label>
      <label>Frames<input id="frames" type="checkbox"></label>
      <label>Fog<input id="fog" type="checkbox"></label>
      <label>Material<input id="material" type="checkbox"></label>
      <label>Light<input id="light" type="checkbox"></label>
    </div>
    <pre id="status" aria-live="polite"></pre>
    <details open><summary>3D → 2D cave atlas</summary><div id="atlas"></div></details>
  </section>`;

function fields(shadow) {
  return Object.fromEntries([
    'seed', 'distance', 'surfaceVariant', 'family', 'camera', 'orthoAxis', 'renderPass', 'orbit', 'orbitScope', 'placement', 'control',
    'pause', 'step', 'reset', 'url', 'landmarks', 'rockDetail', 'surfaceRelief', 'readability',
    ...VISUAL_DEBUG_LAYERS, 'status', 'atlas',
  ].map((id) => [id, shadow.getElementById(id)]));
}

function scenarioFromFields(current, ui, paused) {
  return normalizeVisualScenario({
    ...current,
    seed: ui.seed.value,
    distance: ui.distance.value,
    family: ui.family.value,
    camera: ui.camera.value,
    orthographicAxis: ui.orthoAxis.value,
    renderPass: ui.renderPass.value,
    orbitDegrees: ui.orbit.value,
    orbitScope: ui.orbitScope.value,
    placement: ui.placement.value,
    control: ui.control.value,
    paused,
    settings: {
      ...current.settings,
      landmarks: ui.landmarks.checked,
      rockDetail: ui.rockDetail.checked,
      surfaceRelief: ui.surfaceRelief.checked,
      readability: ui.readability.checked,
      ...Object.fromEntries(VISUAL_DEBUG_LAYERS.map((name) => [name, ui[name].checked])),
    },
  });
}

// External capture/performance drivers call visual.step many times without
// showing the inspector. Keep their public result and error path identical to
// the runner while avoiding an expensive SVG rebuild for every simulation step.
export function createVisualLabStepBridge(api, { captureMode, renderStatus,
  renderAtlas, lastAtlasFrame }) {
  return (count = 1) => {
    const result = api.step(count);
    if (!captureMode) {
      renderStatus();
      if (api.runner.frame - lastAtlasFrame() >= 6) renderAtlas();
    }
    return result;
  };
}

/**
 * Dynamically mounted by the composition root only when the visualLab query
 * parameter is present; normal player sessions never load this module.
 */
export async function mountVisualLab({
  app = globalThis.__cave9,
  scenario = null,
  document: doc = globalThis.document,
  window: win = globalThis.window,
  host = null,
} = {}) {
  if (!app) throw new Error('mountVisualLab requires the Cave9 app');
  if (!doc?.body) throw new Error('mountVisualLab requires a document body');

  const existingHost = host ?? doc.getElementById(HOST_ID);
  if (existingHost && mounted.has(existingHost)) return mounted.get(existingHost);
  const target = existingHost ?? doc.createElement('div');
  if (!target.id) target.id = HOST_ID;
  if (!target.isConnected) doc.body.append(target);
  const shadow = target.shadowRoot ?? target.attachShadow({ mode: 'open' });
  shadow.innerHTML = markup;
  const ui = fields(shadow);
  const api = createVisualDevApi(app);
  api.runner.dev3d = new VisualDebug3d(app.renderer);
  const initial = normalizeVisualScenario(scenario ?? parseScenarioUrl(win?.location?.href));
  api.loadScenario(initial);

  let disposed = false;
  let raf = null;
  let atlas = null;
  let selection = null;
  let lastAtlasFrame = -1;
  const marker = new THREE.Mesh(
    new THREE.SphereGeometry(0.22, 12, 8),
    new THREE.MeshBasicMaterial({ color: 0xfff06a, depthTest: false, depthWrite: false, toneMapped: false }),
  );
  marker.name = 'visual-lab-selection';
  marker.renderOrder = 10000;
  marker.visible = false;
  app.renderer?.scene?.add(marker);
  const raycaster = new THREE.Raycaster();
  const pointer = new THREE.Vector2();
  const renderStatus = () => {
    const state = api.inspect();
    const s = state.scenario;
    const tunnelSurface = s
      ? surfaceStretchAt(s.seed, state.distance, ui.surfaceVariant.value || null)
      : null;
    if (s) {
      ui.seed.value = String(s.seed);
      ui.distance.value = String(s.distance);
      ui.family.value = s.family;
      ui.camera.value = s.camera;
      ui.orthoAxis.value = s.orthographicAxis;
      ui.renderPass.value = s.renderPass;
      ui.orbit.value = String(s.orbitDegrees);
      ui.orbitScope.value = s.orbitScope;
      ui.placement.value = s.placement;
      ui.control.value = s.control;
      ui.landmarks.checked = state.layers.landmarks;
      ui.rockDetail.checked = state.layers.rockDetail;
      ui.surfaceRelief.checked = state.layers.surfaceRelief;
      ui.readability.checked = state.layers.readability;
      for (const name of VISUAL_DEBUG_LAYERS) ui[name].checked = state.layers[name];
    }
    ui.pause.textContent = state.paused ? 'Resume' : 'Pause';
    ui.status.textContent = JSON.stringify({
      frame: state.frame,
      phase: state.phase,
      distance: state.distance,
      warning: state.warning?.final,
      clearance: state.player?.clearance,
      positioning: state.positioning,
      camera: state.camera,
      viewport: state.viewport,
      renderer: {
        capabilities: app.renderer?.renderCapabilities?.() ?? null,
        drawCalls: app.renderer?.renderer?.info?.render?.calls ?? null,
        programs: app.renderer?.renderer?.info?.programs?.length ?? null,
      },
      tunnelSurface: tunnelSurface ? {
        previous: tunnelSurface.previousVariant,
        main: tunnelSurface.currentVariant,
        next: tunnelSurface.nextVariant,
        progress: tunnelSurface.regionProgress,
        shares: tunnelVariantSharesAt(tunnelSurface.regionProgress),
        from: tunnelSurface.from,
        to: tunnelSurface.to,
      } : null,
      errorStatus: state.errorStatus,
      errors: state.errors,
      selection,
    }, null, 2);
    return state;
  };

  const markSelection = (next, present = true) => {
    selection = next;
    const world = next?.world ?? next?.surfacePoint ?? next?.atlasPoint;
    marker.visible = Array.isArray(world);
    if (marker.visible) {
      marker.position.fromArray(world);
      const activeCamera = api.runner.dev3d?.getActiveCamera?.() ?? app.renderer.camera;
      const towardCamera = new THREE.Vector3().copy(activeCamera.position).sub(marker.position);
      if (towardCamera.lengthSq() > 1e-9) marker.position.addScaledVector(towardCamera.normalize(), 0.12);
    }
    for (const cell of ui.atlas.querySelectorAll('.atlas-selected')) cell.classList.remove('atlas-selected');
    if (next && atlas) {
      const fraction = Number(next.displaySectorFraction);
      const sector = Number.isFinite(fraction)
        ? ((Math.floor(fraction + 1e-9) % 32) + 32) % 32
        : next.displaySector;
      let best = null, gap = Infinity;
      for (const cell of ui.atlas.querySelectorAll(`.atlas-unwrapped-cell[data-sector="${sector}"]`)) {
        const nextGap = Math.abs(Number(cell.dataset.depth) - next.depth);
        if (nextGap < gap) { best = cell; gap = nextGap; }
      }
      best?.classList.add('atlas-selected');
    }
    if (present) {
      api.pause();
      api.step(0);
    }
    renderStatus();
    return next;
  };

  const renderAtlas = () => {
    try {
      atlas = buildCaveAtlas({
        cave: api.runner.game.cave,
        seed: api.runner.game.seed,
        landmarks: api.runner.visibleCompositions(),
      });
      ui.atlas.innerHTML = renderCaveAtlasFragment(atlas, {
        centerline: { width: 640, height: 230 },
        longitudinal: { width: 640, height: 230 },
        crossSections: { width: 640, cellHeight: 90 },
        unwrapped: { width: 640, rowHeight: 3 },
      });
      ui.atlas.removeAttribute('data-error');
      lastAtlasFrame = api.runner.frame;
      if (selection && (selection.depth < atlas.depthRange[0] || selection.depth > atlas.depthRange[1])) {
        selection = { expired: true, reason: 'selected depth left the live cave buffer' };
        marker.visible = false;
      } else if (selection) markSelection(selection, false);
      return atlas;
    } catch (error) {
      atlas = null;
      ui.atlas.dataset.error = 'true';
      ui.atlas.textContent = `Atlas unavailable: ${error?.message || error}`;
      return null;
    }
  };

  const refresh = () => { renderStatus(); renderAtlas(); };

  const tick = () => {
    if (disposed) return;
    if (!api.runner.paused) {
      api.step(1);
      renderStatus();
      // Rebuilding thousands of SVG cells at 60 Hz would hide the behaviour we
      // are trying to inspect. Ten-Hz refresh keeps selection tied to the live
      // circular buffer while leaving the renderer responsive.
      if (api.runner.frame - lastAtlasFrame >= 6) renderAtlas();
    }
    raf = win.requestAnimationFrame(tick);
  };

  const reload = () => api.loadScenario({
    ...scenarioFromFields(api.inspect().scenario, ui, api.runner.paused),
    steps: 0,
  });
  ui.pause.addEventListener('click', () => {
    if (api.runner.paused) api.resume(); else api.pause();
    renderStatus();
  });
  ui.step.addEventListener('click', () => { api.step(1); refresh(); });
  ui.reset.addEventListener('click', () => { reload(); refresh(); });
  for (const layer of ['landmarks', 'rockDetail', 'surfaceRelief', 'readability', ...VISUAL_DEBUG_LAYERS]) {
    ui[layer].addEventListener('change', () => {
      api.setLayer(layer, ui[layer].checked);
      refresh();
    });
  }
  for (const name of ['family', 'camera', 'orthoAxis', 'renderPass', 'orbit', 'orbitScope']) {
    ui[name].addEventListener('change', () => { reload(); refresh(); });
  }
  ui.surfaceVariant.addEventListener('change', () => {
    app.renderer?.setSurfaceVariantOverride?.(ui.surfaceVariant.value || null);
    reload();
    refresh();
  });
  ui.atlas.addEventListener('click', (event) => {
    const targetCell = event.target?.closest?.('[data-depth]');
    if (!targetCell || targetCell.dataset.sector === undefined) return;
    // A running CaveStream recycles its ring buffer. Rebuild immediately so
    // both the selected SVG cell and SurfaceQuery refer to one atomic snapshot.
    renderAtlas();
    if (!atlas) return;
    const depth = Number(targetCell.dataset.depth);
    const sector = Number(targetCell.dataset.sector ?? 0);
    if (!Number.isFinite(depth) || !Number.isInteger(sector)) return;
    markSelection(inspectDepthSector(atlas, depth, sector));
  });
  const pickFromCanvas = (event) => {
    if (event.button !== 0 || api.inspect().camera?.active === 'orbit') return;
    renderAtlas();
    const activeCamera = api.runner.dev3d?.getActiveCamera?.() ?? app.renderer?.camera;
    if (!atlas || !activeCamera || !app.renderer?.caveMesh) return;
    const rect = app.canvas.getBoundingClientRect();
    pointer.set(
      (event.clientX - rect.left) / rect.width * 2 - 1,
      -((event.clientY - rect.top) / rect.height) * 2 + 1,
    );
    app.renderer.scene.updateMatrixWorld(true);
    raycaster.setFromCamera(pointer, activeCamera);
    const caveMaterial = app.renderer.caveMesh.material;
    const originalSide = caveMaterial.side;
    caveMaterial.side = THREE.DoubleSide;
    const hit = raycaster.intersectObject(app.renderer.caveMesh, false)[0];
    caveMaterial.side = originalSide;
    let world = hit?.point ?? null;
    // Some Three.js versions retain a stale bounding sphere for this dynamic
    // BufferGeometry. Fall back to the same authoritative ring triangles the
    // renderer submits; this is still the real cave surface, not route math.
    if (!world) {
      const candidate = new THREE.Vector3();
      let nearest = Infinity;
      for (let i = 0; i < atlas.rings.length - 1; i++) for (let j = 0; j < 32; j++) {
        const next = (j + 1) % 32;
        const lo0 = new THREE.Vector3(...atlas.rings[i].sectors[j].world);
        const lo1 = new THREE.Vector3(...atlas.rings[i].sectors[next].world);
        const hi0 = new THREE.Vector3(...atlas.rings[i + 1].sectors[j].world);
        const hi1 = new THREE.Vector3(...atlas.rings[i + 1].sectors[next].world);
        for (const triangle of [[lo0, hi0, lo1], [lo1, hi0, hi1]]) {
          const point = raycaster.ray.intersectTriangle(...triangle, false, candidate);
          if (!point) continue;
          const distance = raycaster.ray.origin.distanceTo(point);
          if (distance < nearest) { nearest = distance; world = point.clone(); }
        }
      }
    }
    if (world) markSelection({ selectionOrigin: 'canvas', ...inspectWorldPoint(atlas, world.toArray()) });
    else {
      selection = { selectionOrigin: 'canvas', miss: true, reason: 'pointer ray did not hit the submitted cave wall' };
      renderStatus();
    }
  };
  app.canvas?.addEventListener('pointerdown', pickFromCanvas);
  ui.url.addEventListener('click', async () => {
    const current = scenarioFromFields(api.inspect().scenario, ui, api.runner.paused);
    const url = serializeScenarioUrl(current, win.location.href);
    win.history?.replaceState?.(null, '', url);
    try {
      await win.navigator?.clipboard?.writeText?.(url);
      ui.url.textContent = 'Copied';
    } catch {
      ui.url.textContent = 'URL set';
    }
    win.setTimeout(() => { ui.url.textContent = 'Copy URL'; }, 900);
  });

  const captureMode = new URL(win.location.href).searchParams.get('capture') === '1';
  const controllerStep = createVisualLabStepBridge(api, {
    captureMode, renderStatus, renderAtlas, lastAtlasFrame: () => lastAtlasFrame,
  });
  const controller = Object.freeze({
    ...api,
    loadScenario: (nextScenario) => {
      const result = api.loadScenario(nextScenario);
      refresh();
      return result;
    },
    step: controllerStep,
    setLayer: (name, visible) => {
      const result = api.setLayer(name, visible);
      refresh();
      return result;
    },
    pause: () => {
      const result = api.pause();
      renderStatus();
      return result;
    },
    resume: () => {
      const result = api.resume();
      renderStatus();
      return result;
    },
    reset: () => {
      const result = api.reset();
      refresh();
      return result;
    },
    inspect: (depth, sector) => {
      if (depth === undefined) return api.inspect();
      renderAtlas();
      if (!atlas) throw new Error('Cave atlas is not available');
      return markSelection(inspectDepthSector(atlas, Number(depth), Number(sector ?? 0)));
    },
    element: target,
    url: () => serializeScenarioUrl(
      scenarioFromFields(api.inspect().scenario, ui, api.runner.paused), win.location.href),
    dispose: () => {
      disposed = true;
      if (raf !== null) win.cancelAnimationFrame(raf);
      mounted.delete(target);
      app.canvas?.removeEventListener('pointerdown', pickFromCanvas);
      app.renderer?.scene?.remove(marker);
      marker.geometry.dispose();
      marker.material.dispose();
      api.runner.dispose();
      target.remove();
    },
  });
  mounted.set(target, controller);
  renderStatus();
  renderAtlas();
  raf = win.requestAnimationFrame(tick);
  return controller;
}
