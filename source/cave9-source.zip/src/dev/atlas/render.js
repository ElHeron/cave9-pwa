// Dependency-free SVG/HTML-fragment rendering for the cave atlas data model.

const SVG_NS = 'http://www.w3.org/2000/svg';

const esc = (value) => String(value)
  .replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;')
  .replaceAll('"', '&quot;').replaceAll("'", '&#39;');
const n = (value) => Number(value.toFixed(3));
const clamp = (value, lo, hi) => Math.max(lo, Math.min(hi, value));

function extent(values, padding = 0.08) {
  let lo = Math.min(...values), hi = Math.max(...values);
  if (lo === hi) { lo -= 1; hi += 1; }
  const pad = (hi - lo) * padding;
  return [lo - pad, hi + pad];
}

function scale(domain, range) {
  const den = domain[1] - domain[0] || 1;
  return (value) => range[0] + (value - domain[0]) / den * (range[1] - range[0]);
}

function path(points, x, y) {
  return points.map((point, index) => `${index ? 'L' : 'M'}${n(x(point))},${n(y(point))}`).join(' ');
}

function svg(title, width, height, body, className) {
  return `<svg xmlns="${SVG_NS}" class="${className}" role="img" aria-label="${esc(title)}" ` +
    `viewBox="0 0 ${width} ${height}"><title>${esc(title)}</title>${body}</svg>`;
}

function panelTitle(label, x, y) {
  return `<text x="${x}" y="${y}" font-size="12" fill="currentColor">${esc(label)}</text>`;
}

function landmarkLines(atlas, x, y, coordinate) {
  return atlas.landmarks.map((piece) => {
    const a = piece.endpoints.a, b = piece.endpoints.b;
    return `<line class="atlas-landmark atlas-landmark-${esc(piece.shape)}" ` +
      `x1="${n(x(a[2]))}" y1="${n(y(a[coordinate]))}" x2="${n(x(b[2]))}" y2="${n(y(b[coordinate]))}" ` +
      `stroke="currentColor" stroke-width="${n(Math.max(1, piece.radius))}" opacity=".7" ` +
      `data-room="${esc(piece.room)}" data-piece="${piece.pieceIndex}"/>`;
  }).join('');
}

export function renderCenterlineSvg(atlas, { width = 960, height = 300 } = {}) {
  const margin = { left: 44, right: 16, top: 28, bottom: 22 };
  const gap = 30;
  const rowHeight = (height - margin.top - margin.bottom - gap) / 2;
  const x = scale(atlas.depthRange, [margin.left, width - margin.right]);
  const plots = [
    { label: 'Top · world X', points: atlas.centerline.top, coordinate: 0, top: margin.top },
    { label: 'Side · world Y', points: atlas.centerline.side, coordinate: 1, top: margin.top + rowHeight + gap },
  ];
  let body = '';
  for (const plot of plots) {
    const yr = extent(plot.points.map((point) => point.value));
    const y = scale(yr, [plot.top + rowHeight, plot.top]);
    body += panelTitle(plot.label, margin.left, plot.top - 9);
    body += `<line x1="${margin.left}" y1="${n(y(0))}" x2="${width - margin.right}" y2="${n(y(0))}" ` +
      'stroke="currentColor" opacity=".18"/>';
    body += `<path class="atlas-centerline atlas-centerline-${plot.coordinate ? 'side' : 'top'}" ` +
      `d="${path(plot.points, (p) => x(p.depth), (p) => y(p.value))}" fill="none" ` +
      'stroke="currentColor" stroke-width="1.75"/>';
    body += landmarkLines(atlas, x, y, plot.coordinate);
  }
  return svg('Cave route centreline, top and side', width, height, body, 'cave-atlas-centerline');
}

export function renderLongitudinalSvg(atlas, { width = 960, height = 300 } = {}) {
  const margin = { left: 44, right: 16, top: 28, bottom: 22 };
  const gap = 30;
  const rowHeight = (height - margin.top - margin.bottom - gap) / 2;
  const x = scale(atlas.depthRange, [margin.left, width - margin.right]);
  const plots = [
    { label: 'Route-local Right section', points: atlas.longitudinal.right, axis: 'right', top: margin.top },
    { label: 'Route-local Up section', points: atlas.longitudinal.up, axis: 'up', top: margin.top + rowHeight + gap },
  ];
  let body = '';
  for (const plot of plots) {
    const values = plot.points.flatMap((point) => [point.negative.local[plot.axis], point.positive.local[plot.axis]]);
    const y = scale(extent(values), [plot.top + rowHeight, plot.top]);
    const polygon = [
      ...plot.points.map((point) => ({ depth: point.depth, value: point.positive.local[plot.axis] })),
      ...[...plot.points].reverse().map((point) => ({ depth: point.depth, value: point.negative.local[plot.axis] })),
    ];
    body += panelTitle(plot.label, margin.left, plot.top - 9);
    body += `<path class="atlas-wall-section atlas-wall-section-${plot.axis}" ` +
      `d="${path(polygon, (p) => x(p.depth), (p) => y(p.value))} Z" ` +
      'fill="currentColor" fill-opacity=".09" stroke="currentColor" stroke-width="1.25"/>';
  }
  return svg('Actual cave wall, route-local longitudinal sections', width, height, body,
    'cave-atlas-longitudinal');
}

export function renderCrossSectionsSvg(atlas, { width = 960, cellHeight = 112 } = {}) {
  const cells = atlas.crossSections.length;
  const columns = Math.max(1, Math.min(10, cells));
  const rows = Math.ceil(cells / columns);
  const cellWidth = width / columns;
  const height = rows * cellHeight;
  const allRadius = atlas.crossSections.flatMap((section) => section.points.map((point) => point.radius));
  const maxRadius = Math.max(...allRadius, 1);
  let body = '';
  atlas.crossSections.forEach((section, index) => {
    const column = index % columns, row = Math.floor(index / columns);
    const cx = column * cellWidth + cellWidth / 2;
    const cy = row * cellHeight + cellHeight / 2 + 8;
    const factor = Math.min(cellWidth * 0.38, cellHeight * 0.34) / maxRadius;
    const d = section.points.map((point, pointIndex) => {
      const x = cx + point.local.right * factor;
      const y = cy - point.local.up * factor;
      return `${pointIndex ? 'L' : 'M'}${n(x)},${n(y)}`;
    }).join(' ') + ' Z';
    body += `<g class="atlas-cross-section" data-depth="${n(section.depth)}" ` +
      `data-reasons="${esc(section.reasons.join(','))}">`;
    body += `<path d="${d}" fill="currentColor" fill-opacity=".08" stroke="currentColor" stroke-width="1"/>`;
    body += `<line x1="${n(cx)}" y1="${n(cy)}" x2="${n(cx + 9)}" y2="${n(cy)}" ` +
      'stroke="currentColor" stroke-width="1.5"/>';
    body += `<text x="${n(cx)}" y="${row * cellHeight + 13}" text-anchor="middle" ` +
      `font-size="9" fill="currentColor">${n(section.depth)} m</text></g>`;
  });
  return svg('Cave cross-section strips at regular intervals and extrema', width, height, body,
    'cave-atlas-cross-sections');
}

export function renderUnwrappedSvg(atlas, { width = 960, rowHeight = 4 } = {}) {
  const margin = { left: 48, right: 12, top: 24, bottom: 22 };
  const plotWidth = width - margin.left - margin.right;
  const height = Math.max(100, margin.top + margin.bottom + atlas.unwrapped.rows.length * rowHeight);
  const plotHeight = height - margin.top - margin.bottom;
  const cellWidth = plotWidth / atlas.sectorCount;
  const radii = atlas.unwrapped.rows.flatMap((row) => row.points.map((point) => point.radius));
  const range = extent(radii, 0);
  const yDepth = scale(atlas.depthRange, [margin.top, margin.top + plotHeight]);
  let body = panelTitle('Unwrapped wall · depth × 32 mesh columns', margin.left, 14);
  atlas.unwrapped.rows.forEach((row, rowIndex) => {
    const previousDepth = atlas.unwrapped.rows[rowIndex - 1]?.depth;
    const nextDepth = atlas.unwrapped.rows[rowIndex + 1]?.depth;
    const upperDepth = previousDepth == null
      ? atlas.depthRange[0]
      : (previousDepth + row.depth) / 2;
    const lowerDepth = nextDepth == null
      ? atlas.depthRange[1]
      : (row.depth + nextDepth) / 2;
    const y = yDepth(upperDepth);
    const h = yDepth(lowerDepth) - y + 0.2;
    row.points.forEach((point, displaySector) => {
      const t = clamp((point.radius - range[0]) / (range[1] - range[0] || 1), 0, 1);
      const light = 20 + t * 62;
      body += `<rect class="atlas-unwrapped-cell" x="${n(margin.left + displaySector * cellWidth)}" ` +
        `y="${n(y)}" width="${n(cellWidth + 0.2)}" height="${n(h)}" ` +
        `fill="hsl(${n(198 - t * 164)} 72% ${n(light)}%)" data-depth="${n(row.depth)}" ` +
        `data-sector="${displaySector}" data-original-sector="${point.originalSector}"/>`;
    });
  });
  for (const piece of atlas.landmarks) {
    const x = margin.left + piece.displaySector / atlas.sectorCount * plotWidth;
    const y = yDepth(piece.depth);
    body += `<circle class="atlas-unwrapped-landmark" cx="${n(x)}" cy="${n(y)}" r="2.5" ` +
      `fill="currentColor" data-room="${esc(piece.room)}" data-piece="${piece.pieceIndex}"/>`;
  }
  body += `<line class="atlas-seam atlas-seam-start" x1="${margin.left}" y1="${margin.top}" ` +
    `x2="${margin.left}" y2="${height - margin.bottom}" stroke="currentColor" stroke-width="1.5"/>`;
  body += `<line class="atlas-seam atlas-seam-cyclic" x1="${width - margin.right}" y1="${margin.top}" ` +
    `x2="${width - margin.right}" y2="${height - margin.bottom}" stroke="currentColor" stroke-width="1.5"/>`;
  body += `<text x="${margin.left}" y="${height - 7}" font-size="9" fill="currentColor">First-ring +Right column</text>`;
  body += `<text x="${width - margin.right}" y="${height - 7}" text-anchor="end" font-size="9" ` +
    'fill="currentColor">Same column (cyclic)</text>';
  return svg('Unwrapped cave wall with a cyclic first-ring route-right mesh column', width, height, body, 'cave-atlas-unwrapped');
}

/** A DOM-free fragment the Visual Lab can assign to `container.innerHTML`. */
export function renderCaveAtlasFragment(atlas, options = {}) {
  const title = options.title || `Cave atlas${atlas.seed == null ? '' : ` · seed ${atlas.seed}`}`;
  return `<section class="cave-atlas" data-atlas-version="${atlas.version}" ` +
    `data-seed="${esc(atlas.seed ?? '')}" data-seam-sector="${atlas.unwrapped.seam.originalSector}">` +
    `<header class="cave-atlas-header"><h2>${esc(title)}</h2>` +
    `<p>${n(atlas.depthRange[0])}–${n(atlas.depthRange[1])} m · ${atlas.rings.length} rings · ` +
    `${atlas.sectorCount} sectors</p></header>` +
    `<figure>${renderCenterlineSvg(atlas, options.centerline)}<figcaption>Route centreline</figcaption></figure>` +
    `<figure>${renderLongitudinalSvg(atlas, options.longitudinal)}<figcaption>Actual wall sections</figcaption></figure>` +
    `<figure>${renderCrossSectionsSvg(atlas, options.crossSections)}<figcaption>Cross-section strip</figcaption></figure>` +
    `<figure>${renderUnwrappedSvg(atlas, options.unwrapped)}<figcaption>Unwrapped wall</figcaption></figure>` +
    '</section>';
}
