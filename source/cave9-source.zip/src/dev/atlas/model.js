// Deterministic, read-only 3D -> 2D cave atlas model.
//
// The atlas never invents geometry. Its only inputs are live CaveStream rings,
// their FlightPath frames and optional Landmark compositions. Interpolated
// points lie on the longitudinal edges of the actual wall mesh.

import { SECTOR_COUNT, SHIP_RADIUS } from '../../core/constants.js';
import { closestTrianglePoint, queryNearestSurface } from '../../core/SurfaceQuery.js';

const TAU = Math.PI * 2;
const SOURCE = Symbol('cave-atlas-source');

const mod = (n, m) => ((n % m) + m) % m;
const lerp = (a, b, t) => a + (b - a) * t;
const finite = (n, label) => {
  if (!Number.isFinite(n)) throw new TypeError(`${label} must be finite`);
  return n;
};

function copyPoint(p) {
  return [finite(p[0], 'point x'), finite(p[1], 'point y'), finite(p[2], 'point z')];
}

function copyVector(v, label) {
  if (!v) throw new TypeError(`missing ${label}`);
  return {
    x: finite(v.x, `${label}.x`),
    y: finite(v.y, `${label}.y`),
    z: finite(v.z, `${label}.z`),
  };
}

function copyFrame(frame) {
  return {
    center: copyVector(frame.center, 'frame.center'),
    tangent: copyVector(frame.tangent, 'frame.tangent'),
    right: copyVector(frame.right, 'frame.right'),
    up: copyVector(frame.up, 'frame.up'),
  };
}

function project(frame, point) {
  const dx = point[0] - frame.center.x;
  const dy = point[1] - frame.center.y;
  const dz = point[2] - frame.center.z;
  return {
    right: dx * frame.right.x + dy * frame.right.y + dz * frame.right.z,
    up: dx * frame.up.x + dy * frame.up.y + dz * frame.up.z,
    tangent: dx * frame.tangent.x + dy * frame.tangent.y + dz * frame.tangent.z,
  };
}

function normalize(v) {
  const length = Math.hypot(v.x, v.y, v.z) || 1;
  return { x: v.x / length, y: v.y / length, z: v.z / length };
}

function interpolateFrame(a, b, t) {
  const vector = (name) => normalize({
    x: lerp(a[name].x, b[name].x, t),
    y: lerp(a[name].y, b[name].y, t),
    z: lerp(a[name].z, b[name].z, t),
  });
  return {
    center: {
      x: lerp(a.center.x, b.center.x, t),
      y: lerp(a.center.y, b.center.y, t),
      z: lerp(a.center.z, b.center.z, t),
    },
    tangent: vector('tangent'),
    right: vector('right'),
    up: vector('up'),
  };
}

function angularDistance(a, b) {
  return Math.abs(Math.atan2(Math.sin(a - b), Math.cos(a - b)));
}

function rawRings(cave) {
  if (!cave || !Array.isArray(cave.segs) || !Array.isArray(cave.centers) ||
      !Array.isArray(cave.frames)) {
    throw new TypeError('buildCaveAtlas requires a CaveStream-compatible cave');
  }
  const rings = [];
  for (let bufferIndex = 0; bufferIndex < cave.segs.length; bufferIndex++) {
    const frameSource = cave.frames[bufferIndex];
    const centerSource = cave.centers[bufferIndex];
    const wall = cave.segs[bufferIndex];
    if (!frameSource || !centerSource || !Number.isFinite(centerSource[2])) continue;
    if (!Array.isArray(wall) || wall.length !== SECTOR_COUNT) {
      throw new RangeError(`ring ${bufferIndex} must contain exactly ${SECTOR_COUNT} sectors`);
    }
    const frame = copyFrame(frameSource);
    const center = copyPoint(centerSource);
    const sectors = wall.map((sourcePoint, originalSector) => {
      const world = copyPoint(sourcePoint);
      const local = project(frame, world);
      return {
        originalSector,
        world,
        local,
        radius: Math.hypot(local.right, local.up),
        angle: Math.atan2(local.up, local.right),
      };
    });
    const protectedRadius = Number(cave.innerRadii?.[bufferIndex]) || 0;
    rings.push({
      bufferIndex, depth: center[2], center, frame, sectors,
      clearance: { protectedRadius },
    });
  }
  rings.sort((a, b) => a.depth - b.depth || a.bufferIndex - b.bufferIndex);
  if (rings.length < 2) throw new RangeError('the cave atlas needs at least two framed rings');
  for (let i = 1; i < rings.length; i++) {
    if (!(rings[i].depth > rings[i - 1].depth)) {
      throw new RangeError('framed cave ring depths must be unique');
    }
  }
  // Clearance is measured against the same submitted wall triangles as
  // SurfaceQuery/collision. A vertex-radius minimum is not authoritative: the
  // polygon chord and the interior between two rings can both be closer.
  for (const ring of rings) ring.clearance = triangleClearanceAt(rings, ring.depth);
  return rings;
}

function nearestDirectionSector(ring, targetAngle) {
  let best = 0;
  let gap = Infinity;
  for (const sector of ring.sectors) {
    const next = angularDistance(sector.angle, targetAngle);
    if (next < gap) { gap = next; best = sector.originalSector; }
  }
  return best;
}

function bracket(rings, depth) {
  if (depth <= rings[0].depth) return { lo: 0, hi: 0, t: 0 };
  const last = rings.length - 1;
  if (depth >= rings[last].depth) return { lo: last, hi: last, t: 0 };
  let low = 0, high = last;
  while (low + 1 < high) {
    const mid = (low + high) >> 1;
    if (rings[mid].depth <= depth) low = mid;
    else high = mid;
  }
  return {
    lo: low,
    hi: high,
    t: (depth - rings[low].depth) / (rings[high].depth - rings[low].depth),
  };
}

function triangleClearanceAt(rings, depth) {
  let { lo, hi, t } = bracket(rings, depth);
  if (lo === hi) {
    if (hi < rings.length - 1) { hi++; t = 0; }
    else { lo--; t = 1; }
  }
  const frame = interpolateFrame(rings[lo].frame, rings[hi].frame, t);
  const centre = [frame.center.x, frame.center.y, frame.center.z];
  let wall = Infinity;
  for (let sector = 0; sector < SECTOR_COUNT; sector++) {
    const next = mod(sector + 1, SECTOR_COUNT);
    const lo0 = rings[lo].sectors[sector].world;
    const lo1 = rings[lo].sectors[next].world;
    const hi0 = rings[hi].sectors[sector].world;
    const hi1 = rings[hi].sectors[next].world;
    wall = Math.min(wall,
      closestTrianglePoint(centre, lo0, hi0, lo1).distance,
      closestTrianglePoint(centre, lo1, hi0, hi1).distance);
  }
  const protectedRadius = lerp(
    rings[lo].clearance.protectedRadius,
    rings[hi].clearance.protectedRadius,
    t,
  );
  return {
    wall,
    playerHull: wall - SHIP_RADIUS,
    protectedRadius,
    booleanReserve: wall - protectedRadius,
  };
}

function sampleAt(rings, depth, originalSector) {
  const { lo, hi, t } = bracket(rings, depth);
  const a = rings[lo], b = rings[hi];
  const pa = a.sectors[originalSector].world;
  const pb = b.sectors[originalSector].world;
  const world = hi === lo ? pa.slice() : [
    lerp(pa[0], pb[0], t), lerp(pa[1], pb[1], t), lerp(pa[2], pb[2], t),
  ];
  const frame = hi === lo ? a.frame : interpolateFrame(a.frame, b.frame, t);
  const local = project(frame, world);
  return {
    depth: lerp(a.depth, b.depth, t),
    originalSector,
    world,
    local,
    radius: Math.hypot(local.right, local.up),
    angle: Math.atan2(local.up, local.right),
    source: {
      lowerRing: lo,
      upperRing: hi,
      lowerBufferIndex: a.bufferIndex,
      upperBufferIndex: b.bufferIndex,
      t,
    },
  };
}

function sectionSeries(rings, positiveAngle, negativeAngle) {
  return rings.map((ring) => ({
    depth: ring.depth,
    bufferIndex: ring.bufferIndex,
    // C3's mesh columns can rotate with its crest. A directional section must
    // reselect the nearest actual vertex on each ring, not follow one column.
    positive: ring.sectors[nearestDirectionSector(ring, positiveAngle)],
    negative: ring.sectors[nearestDirectionSector(ring, negativeAngle)],
  }));
}

function addSelection(map, depth, reason) {
  const key = Number(depth).toPrecision(15);
  const entry = map.get(key) || { depth, reasons: [] };
  if (!entry.reasons.includes(reason)) entry.reasons.push(reason);
  map.set(key, entry);
}

function extremaSelections(rings, sections) {
  const metrics = [
    ['top', (r) => r.center[0]],
    ['side', (r) => r.center[1]],
    ['right-span', (_r, i) => sections.right[i].positive.local.right - sections.right[i].negative.local.right],
    ['up-span', (_r, i) => sections.up[i].positive.local.up - sections.up[i].negative.local.up],
    ['wall-clearance', (r) => r.clearance.wall],
    ['player-clearance', (r) => r.clearance.playerHull],
    ['boolean-reserve', (r) => r.clearance.booleanReserve],
  ];
  const result = [];
  for (const [name, value] of metrics) {
    let min = 0, max = 0;
    for (let i = 1; i < rings.length; i++) {
      if (value(rings[i], i) < value(rings[min], min)) min = i;
      if (value(rings[i], i) > value(rings[max], max)) max = i;
    }
    result.push([rings[min].depth, `${name}-min`], [rings[max].depth, `${name}-max`]);
  }
  return result;
}

function buildCrossSections(rings, sections, spacing) {
  if (!(spacing > 0) || !Number.isFinite(spacing)) {
    throw new RangeError('crossSectionSpacing must be a positive finite number');
  }
  const selected = new Map();
  const minDepth = rings[0].depth;
  const maxDepth = rings.at(-1).depth;
  addSelection(selected, minDepth, 'start');
  addSelection(selected, maxDepth, 'end');
  const firstGrid = Math.ceil((minDepth - 1e-9) / spacing) * spacing;
  for (let depth = firstGrid; depth <= maxDepth + 1e-9; depth += spacing) {
    addSelection(selected, Math.min(depth, maxDepth), 'grid');
  }
  for (const [depth, reason] of extremaSelections(rings, sections)) addSelection(selected, depth, reason);

  return [...selected.values()].sort((a, b) => a.depth - b.depth).map(({ depth, reasons }) => ({
    depth,
    reasons,
    clearance: triangleClearanceAt(rings, depth),
    points: Array.from({ length: SECTOR_COUNT }, (_, originalSector) =>
      sampleAt(rings, depth, originalSector)),
  }));
}

function unwrappedDepths(rings, spacing = 2) {
  const min = rings[0].depth, max = rings.at(-1).depth;
  const depths = [min];
  // A partial tail would contradict the advertised fixed-depth grid. The live
  // CaveStream already ends on its two metre lattice; compatible synthetic or
  // clipped sources stop at the last complete atlas row instead.
  for (let depth = min + spacing; depth <= max + 1e-9; depth += spacing) depths.push(depth);
  return depths;
}

function pieceEndpoints(piece) {
  const half = piece.length / 2;
  return {
    a: [piece.cx - piece.dx * half, piece.cy - piece.dy * half, piece.cz - piece.dz * half],
    b: [piece.cx + piece.dx * half, piece.cy + piece.dy * half, piece.cz + piece.dz * half],
  };
}

function closestRouteDepth(rings, point) {
  let best = { distance: Infinity, depth: rings[0].depth, segment: 0, t: 0 };
  for (let i = 0; i < rings.length - 1; i++) {
    const a = rings[i].center, b = rings[i + 1].center;
    const dx = b[0] - a[0], dy = b[1] - a[1], dz = b[2] - a[2];
    const den = dx * dx + dy * dy + dz * dz || 1;
    const t = Math.max(0, Math.min(1,
      ((point[0] - a[0]) * dx + (point[1] - a[1]) * dy + (point[2] - a[2]) * dz) / den));
    const q = [a[0] + dx * t, a[1] + dy * t, a[2] + dz * t];
    const distance = Math.hypot(point[0] - q[0], point[1] - q[1], point[2] - q[2]);
    if (distance < best.distance) {
      best = { distance, depth: lerp(rings[i].depth, rings[i + 1].depth, t), segment: i, t };
    }
  }
  return best;
}

// Inverse of sampleAt for the atlas grid: project onto every real longitudinal
// wall edge, not merely the route centreline. This preserves depth on curved or
// helical tubes where a wall point's closest route-centre parameter is shifted
// by the tube radius.
function closestWallEdge(rings, point, sectorOrder) {
  let best = null;
  for (let displaySector = 0; displaySector < sectorOrder.length; displaySector++) {
    const originalSector = sectorOrder[displaySector];
    for (let i = 0; i < rings.length - 1; i++) {
      const a = rings[i].sectors[originalSector].world;
      const b = rings[i + 1].sectors[originalSector].world;
      const dx = b[0] - a[0], dy = b[1] - a[1], dz = b[2] - a[2];
      const den = dx * dx + dy * dy + dz * dz || 1;
      const t = Math.max(0, Math.min(1,
        ((point[0] - a[0]) * dx + (point[1] - a[1]) * dy + (point[2] - a[2]) * dz) / den));
      const world = [a[0] + dx * t, a[1] + dy * t, a[2] + dz * t];
      const distance = Math.hypot(point[0] - world[0], point[1] - world[1], point[2] - world[2]);
      if (!best || distance < best.distance) {
        best = {
          displaySector,
          originalSector,
          distance,
          world,
          depth: lerp(rings[i].depth, rings[i + 1].depth, t),
          source: {
            lowerRing: i,
            upperRing: i + 1,
            lowerBufferIndex: rings[i].bufferIndex,
            upperBufferIndex: rings[i + 1].bufferIndex,
            t,
          },
        };
      }
    }
  }
  return best;
}

function barycentric(point, a, b, c) {
  const v0 = [b[0] - a[0], b[1] - a[1], b[2] - a[2]];
  const v1 = [c[0] - a[0], c[1] - a[1], c[2] - a[2]];
  const v2 = [point[0] - a[0], point[1] - a[1], point[2] - a[2]];
  const d00 = v0[0] ** 2 + v0[1] ** 2 + v0[2] ** 2;
  const d01 = v0[0] * v1[0] + v0[1] * v1[1] + v0[2] * v1[2];
  const d11 = v1[0] ** 2 + v1[1] ** 2 + v1[2] ** 2;
  const d20 = v2[0] * v0[0] + v2[1] * v0[1] + v2[2] * v0[2];
  const d21 = v2[0] * v1[0] + v2[1] * v1[1] + v2[2] * v1[2];
  const denominator = d00 * d11 - d01 * d01;
  if (Math.abs(denominator) < 1e-12) return [1, 0, 0];
  const v = (d11 * d20 - d01 * d21) / denominator;
  const w = (d00 * d21 - d01 * d20) / denominator;
  return [1 - v - w, v, w];
}

// Exact inverse over the same two wall triangles used by SurfaceQuery and the
// renderer. The returned sector fraction identifies a position inside one of
// the 32 unwrapped cells; displaySector remains the nearest discrete column.
function closestWallTriangle(rings, point, sectorOrder) {
  const displayOf = new Map(sectorOrder.map((original, display) => [original, display]));
  let best = null;
  for (let i = 0; i < rings.length - 1; i++) {
    for (let originalSector = 0; originalSector < SECTOR_COUNT; originalSector++) {
      const nextSector = mod(originalSector + 1, SECTOR_COUNT);
      const lo0 = rings[i].sectors[originalSector].world;
      const lo1 = rings[i].sectors[nextSector].world;
      const hi0 = rings[i + 1].sectors[originalSector].world;
      const hi1 = rings[i + 1].sectors[nextSector].world;
      for (const [vertices, angularWeight, depthWeight, triangle] of [
        [[lo0, hi0, lo1], (weights) => weights[2], (weights) => weights[1], 0],
        [[lo1, hi0, hi1], (weights) => weights[0] + weights[2],
          (weights) => weights[1] + weights[2], 1],
      ]) {
        const q = closestTrianglePoint(point, ...vertices);
        if (best && q.distance >= best.distance) continue;
        const world = [q.qx, q.qy, q.qz];
        const weights = barycentric(world, ...vertices);
        const cellStart = displayOf.get(originalSector);
        const sectorFraction = mod(cellStart + angularWeight(weights), SECTOR_COUNT);
        const t = Math.max(0, Math.min(1, depthWeight(weights)));
        best = {
          displaySector: mod(Math.round(sectorFraction), SECTOR_COUNT),
          displaySectorFraction: sectorFraction,
          originalSector: sectorOrder[mod(Math.round(sectorFraction), SECTOR_COUNT)],
          cellOriginalSector: originalSector,
          distance: q.distance,
          world,
          depth: lerp(rings[i].depth, rings[i + 1].depth, t),
          source: {
            lowerRing: i, upperRing: i + 1,
            lowerBufferIndex: rings[i].bufferIndex,
            upperBufferIndex: rings[i + 1].bufferIndex,
            triangle, t, barycentric: weights,
          },
        };
      }
    }
  }
  return best;
}

function normalizeLandmarks(rings, compositions, seamSector) {
  const out = [];
  for (const composition of compositions || []) {
    if (!composition) continue;
    for (let pieceIndex = 0; pieceIndex < (composition.pieces || []).length; pieceIndex++) {
      const piece = composition.pieces[pieceIndex];
      const endpoints = pieceEndpoints(piece);
      const centre = [piece.cx, piece.cy, piece.cz];
      const route = closestRouteDepth(rings, centre);
      const sampledFrame = interpolateFrame(
        rings[route.segment].frame, rings[Math.min(route.segment + 1, rings.length - 1)].frame, route.t);
      const local = project(sampledFrame, centre);
      const angle = mod(Math.atan2(local.up, local.right), TAU);
      const nearestSector = nearestDirectionSector(rings[0], angle);
      out.push({
        room: composition.k,
        type: composition.typeName,
        pieceIndex,
        shape: piece.shape,
        role: piece.role || null,
        centre,
        endpoints,
        radius: piece.radius,
        length: piece.length,
        depth: route.depth,
        angle,
        displaySector: mod(nearestSector - seamSector, SECTOR_COUNT),
      });
    }
  }
  return out;
}

/**
 * Build a serialisable atlas from a live CaveStream-compatible object.
 * `landmarks` must be real `compositionAt`/`landmarksInView` results.
 */
export function buildCaveAtlas({
  cave,
  seed = cave?.seed ?? null,
  landmarks = [],
  crossSectionSpacing = 10,
} = {}) {
  const rings = rawRings(cave);
  const seamSector = nearestDirectionSector(rings[0], 0);
  const sectorOrder = Array.from({ length: SECTOR_COUNT }, (_, i) => mod(seamSector + i, SECTOR_COUNT));
  const directions = {
    scope: 'first-ring',
    right: seamSector,
    up: nearestDirectionSector(rings[0], Math.PI / 2),
    left: nearestDirectionSector(rings[0], Math.PI),
    down: nearestDirectionSector(rings[0], -Math.PI / 2),
  };
  const sections = {
    right: sectionSeries(rings, 0, Math.PI),
    up: sectionSeries(rings, Math.PI / 2, -Math.PI / 2),
  };
  const unwrapped = {
    seam: { axis: 'route-frame-right', anchor: 'first-ring',
      follows: 'vertex-column', originalSector: seamSector },
    sectorOrder,
    depthStep: 2,
    rows: unwrappedDepths(rings, 2).map((depth) => {
      const points = sectorOrder.map((originalSector, displaySector) => ({
        ...sampleAt(rings, depth, originalSector), displaySector,
      }));
      return {
        depth,
        points,
        // Duplicate the seam point as a boundary vertex. Cells remain exactly 32.
        boundaryPoints: [...points, { ...points[0], displaySector: SECTOR_COUNT, cyclicDuplicate: true }],
      };
    }),
  };
  const atlas = {
    kind: 'cave-atlas',
    version: 1,
    seed,
    sectorCount: SECTOR_COUNT,
    depthRange: [rings[0].depth, rings.at(-1).depth],
    rings,
    centerline: {
      top: rings.map((ring) => ({ depth: ring.depth, value: ring.center[0], bufferIndex: ring.bufferIndex })),
      side: rings.map((ring) => ({ depth: ring.depth, value: ring.center[1], bufferIndex: ring.bufferIndex })),
    },
    directions,
    longitudinal: sections,
    crossSections: buildCrossSections(rings, sections, crossSectionSpacing),
    unwrapped,
    landmarks: normalizeLandmarks(rings, landmarks, seamSector),
  };
  Object.defineProperty(atlas, SOURCE, { value: { cave, compositions: landmarks }, enumerable: false });
  return atlas;
}

function sourceFor(atlas) {
  const source = atlas?.[SOURCE];
  if (!source) throw new TypeError('inspection requires an atlas returned by buildCaveAtlas');
  return source;
}

function surfaceSummary(query) {
  return {
    kind: query.nearest?.kind || null,
    ringIndex: query.ringIndex,
    surfaceDistance: query.nearest?.surfaceDistance ?? null,
    hullClearance: query.nearest?.hullClearance ?? null,
    point: query.nearest ? [query.nearest.qx, query.nearest.qy, query.nearest.qz] : null,
    leftClear: query.leftClear,
    rightClear: query.rightClear,
    landmark: query.landmark ? {
      shape: query.landmark.piece?.shape || null,
      role: query.landmark.piece?.role || null,
      surfaceDistance: query.landmark.surfaceDistance,
    } : null,
  };
}

/** Map atlas depth/display-sector coordinates to an actual wall-edge point. */
export function inspectDepthSector(atlas, depth, displaySector) {
  const source = sourceFor(atlas);
  finite(depth, 'depth');
  finite(displaySector, 'displaySector');
  const column = mod(Math.round(displaySector), atlas.sectorCount);
  const originalSector = atlas.unwrapped.sectorOrder[column];
  const point = sampleAt(atlas.rings, depth, originalSector);
  const query = queryNearestSurface(source.cave, point.world, 0, source.compositions);
  return {
    ...point,
    displaySector: column,
    seam: column === 0,
    surface: surfaceSummary(query),
  };
}

/** Map a world point back to its nearest route depth and cyclic atlas sector. */
export function inspectWorldPoint(atlas, point) {
  const source = sourceFor(atlas);
  const requested = copyPoint(point);
  const query = queryNearestSurface(source.cave, requested, 0, source.compositions);
  const surface = query.wall ?? query.nearest;
  const target = surface
    ? [surface.qx, surface.qy, surface.qz]
    : requested;
  const best = closestWallTriangle(atlas.rings, target, atlas.unwrapped.sectorOrder)
    ?? closestWallEdge(atlas.rings, target, atlas.unwrapped.sectorOrder);
  return {
    requested,
    surfacePoint: target,
    depth: best.depth,
    displaySector: best.displaySector,
    displaySectorFraction: best.displaySectorFraction ?? best.displaySector,
    originalSector: best.originalSector,
    atlasPoint: best.world,
    atlasPointDistance: best.distance,
    seam: best.displaySector === 0,
    source: best.source,
    surface: surfaceSummary(query),
  };
}
