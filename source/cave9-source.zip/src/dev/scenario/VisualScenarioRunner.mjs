import { Game, RunPhase } from '../../core/Game.js';
import { computeWarn } from '../../core/WarnState.js';
import { shipHit } from '../../core/CollisionSystem.js';
import { placeAt } from '../../app/CaptureHarness.js';
import { pathFrameAt } from '../../core/FlightPath.js';
import { VISUAL_CLAY_LIGHT_RIG } from '../lab/VisualDebug3d.mjs';
import {
  VisualSnapshotV1,
  normalizeVisualScenario,
} from './schema.mjs';

const MAX_FLIGHT_STEPS = 200000;
const SUPPORTED_LAYERS = Object.freeze([
  'landmarks', 'rockDetail', 'surfaceRelief', 'readability', 'cave', 'wireframe', 'landmarkMesh',
  'collisionCapsules', 'booleanTube', 'playerHull', 'frames', 'fog', 'material', 'light',
]);

const round = (value, digits = 6) => Number.isFinite(value) ? +value.toFixed(digits) : null;
const clone3 = (values) => values.map((value) => round(value));

const hiddenState = (element) => element?.classList?.contains?.('hidden');
const restoreHiddenState = (element, hidden) => {
  if (hidden !== undefined) element?.classList?.toggle?.('hidden', hidden);
};
const audioParamValue = (param) => Number.isFinite(param?.value) ? param.value : null;
const setAudioParam = (param, value, now = 0) => {
  if (!param || value === null) return;
  if (typeof param.setValueAtTime === 'function') param.setValueAtTime(value, now);
  else param.value = value;
};

function unit3(value) {
  const length = Math.hypot(value.x, value.y, value.z) || 1;
  return { x: value.x / length, y: value.y / length, z: value.z / length };
}

function cross3(a, b) {
  return unit3({
    x: a.y * b.z - a.z * b.y,
    y: a.z * b.x - a.x * b.z,
    z: a.x * b.y - a.y * b.x,
  });
}

// Crystal plates deliberately face the approach camera. A pure cross-section
// orbit therefore sees mostly their thin edges. This tilted, still orthonormal
// camera rig keeps a substantial route-tangent component at all six 60-degree
// evidence poses (0.78 at 0/180, 0.39 at the other four) without changing or
// scaling the rendered geometry.
export function crystalOrbitFrame(frame) {
  if (!frame?.right || !frame?.up || !frame?.tangent) return frame;
  const tangent = unit3(frame.tangent);
  const radial = unit3(frame.right);
  const up = unit3(frame.up);
  const axialWeight = 0.78;
  const radialWeight = Math.sqrt(1 - axialWeight * axialWeight);
  const right = unit3({
    x: tangent.x * axialWeight + radial.x * radialWeight,
    y: tangent.y * axialWeight + radial.y * radialWeight,
    z: tangent.z * axialWeight + radial.z * radialWeight,
  });
  return { ...frame, right, up, tangent: cross3(right, up),
    orbitRig: 'crystal-oblique-v1', orbitAxialWeight: axialWeight };
}

/**
 * Deterministic visual-scenario driver. With an app it uses the application's
 * real game, renderer and warning path. Without one it remains a useful
 * headless driver over the real Game and CaptureHarness placement code.
 */
export class VisualScenarioRunner {
  constructor({ app = null, game = null } = {}) {
    this.app = app;
    this.game = game ?? app?.game ?? new Game();
    this.scenario = null;
    this.paused = true;
    this.frame = 0;
    this.lastWarn = null;
    this.layers = Object.fromEntries(SUPPORTED_LAYERS.map((name) => [name,
      !['wireframe', 'collisionCapsules', 'booleanTube', 'playerHull', 'frames'].includes(name)]));
    this.cameraState = { requested: 'hero', active: 'hero', supported: true };
    this.dev3d = null;
    this._appControl = null;
    this.runtimeErrors = [];
    this._runtimeErrorKeys = new Set();
    this._runtimeErrorSequence = 0;
    this._runtimeSources = null;
  }

  clearRuntimeErrors() {
    this.runtimeErrors.length = 0;
    this._runtimeErrorKeys.clear();
    this._runtimeErrorSequence = 0;
    return [];
  }

  recordRuntimeError(type, error = null, details = {}) {
    const message = error instanceof Error ? error.message
      : typeof error === 'string' ? error
        : error?.message ? String(error.message) : String(details.message ?? type ?? 'runtime error');
    const entry = {
      sequence: ++this._runtimeErrorSequence,
      frame: this.frame,
      type: String(type || 'runtime-error'),
      message,
      source: details.source == null ? null : String(details.source),
      path: details.path == null ? null : String(details.path),
      value: details.value == null ? null : String(details.value),
      fatal: !!details.fatal,
    };
    const key = String(details.dedupeKey ??
      `${entry.type}:${entry.source ?? ''}:${entry.path ?? ''}:${entry.message}`);
    if (this._runtimeErrorKeys.has(key)) {
      return this.runtimeErrors.find((item) => item.dedupeKey === key) ?? null;
    }
    this._runtimeErrorKeys.add(key);
    entry.dedupeKey = key;
    this.runtimeErrors.push(Object.freeze(entry));
    return entry;
  }

  loadScenario(input = {}) {
    const scenario = normalizeVisualScenario(input);
    this.clearRuntimeErrors();
    this.scenario = scenario;
    this.paused = scenario.paused;
    this.frame = 0;
    this.cameraState = { requested: scenario.camera, active: 'hero',
      supported: scenario.camera === 'hero' };

    this._takeAppControl();
    try {
      this.game.start({
      mode: scenario.mode,
      seed: scenario.seed,
      // `off` must reach CaveStream before prime so a naturally selected C3
      // room cannot retain its surface-resident shell in the control capture.
      family: scenario.family,
      });
      this.dev3d?.resetCamera();
      this.dev3d?.setRenderPass?.(scenario.renderPass);
      for (const layer of SUPPORTED_LAYERS) this.setLayer(layer, scenario.settings[layer], false);
      this._applyRenderSettings(scenario.settings);

      if (scenario.placement === 'place') {
        placeAt(this.game, scenario.distance);
      } else {
        this._flyTo(scenario.distance);
      }
      this._advance(scenario.steps);
      this._present();
      return this.inspect();
    } catch (error) {
      this.recordRuntimeError('runtime-exception', error, { source: 'loadScenario', fatal: true });
      throw error;
    }
  }

  reset() {
    if (!this.scenario) throw new Error('No visual scenario loaded');
    return this.loadScenario({ ...this.scenario, steps: 0 });
  }

  pause() {
    this.paused = true;
    if (this.scenario) this.scenario.paused = true;
    return this.inspect();
  }

  resume() {
    this.paused = false;
    if (this.scenario) this.scenario.paused = false;
    return this.inspect();
  }

  step(count = 1) {
    if (!this.scenario) throw new Error('No visual scenario loaded');
    const requested = Math.max(0, Math.min(10000, Math.trunc(Number(count) || 0)));
    try {
      const advanced = this._advance(requested);
      this.scenario.steps += advanced;
      this._present();
      return { advanced, ...this.inspect() };
    } catch (error) {
      this.recordRuntimeError('runtime-exception', error, { source: 'step', fatal: true });
      throw error;
    }
  }

  setLayer(name, enabled, present = true) {
    if (!SUPPORTED_LAYERS.includes(name)) {
      throw new RangeError(`Unsupported visual layer "${name}"; supported: ${SUPPORTED_LAYERS.join(', ')}`);
    }
    const on = !!enabled;
    this.layers[name] = on;
    const renderer = this.app?.renderer;
    if (name === 'landmarks') {
      this.game.landmarksEnabled = on;
      if (!on) this.game.landmarkCompositions = [];
      renderer?.setLandmarks?.(on);
    } else if (name === 'rockDetail') {
      renderer?.setRockDetail?.(on);
    } else if (name === 'surfaceRelief') {
      renderer?.setSurfaceRelief?.(on, this.scenario?.family === 'coiling' ? 'coiling' : 'cave');
    } else if (name === 'readability') {
      renderer?.setReadability?.(on);
    } else {
      this.dev3d?.setLayer(name, on);
    }
    if (this.scenario) this.scenario.settings[name] = on;
    if (present && this.scenario) this._present();
    return this.inspect();
  }

  inspect() {
    if (!this.scenario) return {
      version: VisualSnapshotV1,
      loaded: false,
      errors: this.runtimeErrors.map((entry) => ({ ...entry })),
      errorStatus: this.runtimeErrors.length ? 'error' : 'ok',
      supportedLayers: [...SUPPORTED_LAYERS],
    };
    const p = this.game.player;
    const warning = this.lastWarn ?? computeWarn(this.game);
    const actualDistance = p.pos[2] - p.start;
    const frame = pathFrameAt(this.game.seed, Math.max(0, actualDistance));
    const tangentDot = p.lookAt[0] * frame.tangent.x
      + p.lookAt[1] * frame.tangent.y + p.lookAt[2] * frame.tangent.z;
    const canvas = this.app?.canvas ?? this.app?.renderer?.canvas;
    const renderer = this.app?.renderer?.renderer;
    const actualViewport = {
      width: Number(canvas?.width) || null,
      height: Number(canvas?.height) || null,
      dpr: round(renderer?.getPixelRatio?.() ?? globalThis.devicePixelRatio ?? 1, 3),
    };
    const requestedViewport = { ...this.scenario.viewport };
    const viewportMatches = actualViewport.width === requestedViewport.width * requestedViewport.dpr
      && actualViewport.height === requestedViewport.height * requestedViewport.dpr
      && actualViewport.dpr === requestedViewport.dpr;
    const difficulty = this.game.difficulty();
    this._recordNonFiniteValues({
      actualDistance,
      player: { position: p.pos, velocity: p.vel, lookAt: p.lookAt, roll: p.roll,
        clearance: p.dist === Number.MAX_VALUE ? null : p.dist },
      route: { tangentDot },
      time: this.game.time,
      score: { value: this.game.scoreValue(), distance: this.game.score.distance,
        warnLevel: this.game.score.warnLevel },
      warning,
      difficulty,
      camera: this.cameraState,
    });
    if (this.game.phase === RunPhase.DEAD) {
      this.recordRuntimeError('crash', 'game entered the dead phase', {
        source: 'simulation', fatal: true, dedupeKey: 'simulation-crash',
      });
    }
    this._recordWebglContextState();
    return {
      version: VisualSnapshotV1,
      loaded: true,
      scenario: normalizeVisualScenario(this.scenario),
      frame: this.frame,
      paused: this.paused,
      phase: this.game.phase,
      distance: round(actualDistance, 3),
      positioning: {
        requestedDistance: round(this.scenario.distance, 3),
        actualDistance: round(actualDistance, 3),
        method: this.scenario.placement,
        placed: this.scenario.placement === 'place',
        flown: this.scenario.placement === 'fly',
        reached: actualDistance + 1e-6 >= this.scenario.distance,
        crashed: this.game.phase === RunPhase.DEAD,
      },
      family: {
        requested: this.scenario.family,
        active: [...new Set(this._visibleCompositions().map((comp) => comp.typeName))],
      },
      camera: { ...this.cameraState },
      renderPass: { requested: this.scenario.renderPass,
        active: this.dev3d?.renderPass ?? 'beauty', supported: !!this.dev3d,
        lightRig: this.dev3d?.renderPass === 'clay' ? VISUAL_CLAY_LIGHT_RIG : null },
      viewport: { requested: requestedViewport, actual: actualViewport, matches: viewportMatches },
      route: { tangentDot: round(tangentDot, 6) },
      time: round(this.game.time),
      player: {
        position: clone3(p.pos),
        velocity: clone3(p.vel),
        lookAt: clone3(p.lookAt),
        roll: round(p.roll),
        clearance: p.dist === Number.MAX_VALUE ? null : round(Math.max(0, p.dist)),
        left: !!p.lefton,
        right: !!p.righton,
      },
      score: {
        value: this.game.scoreValue(),
        distance: round(this.game.score.distance, 3),
        warnLevel: round(this.game.score.warnLevel, 6),
      },
      warning: {
        reactive: round(warning.reactive),
        predictive: round(warning.predictive),
        final: round(warning.final),
        pan: round(warning.pan),
        leadDist: round(warning.leadDist),
      },
      difficulty,
      renderCapabilities: this.app?.renderer?.renderCapabilities?.() ?? null,
      layers: { ...this.layers },
      errors: this.runtimeErrors.map((entry) => ({ ...entry })),
      errorStatus: this.runtimeErrors.length ? 'error' : 'ok',
      supportedLayers: [...SUPPORTED_LAYERS],
    };
  }

  snapshot({ includeImage = true } = {}) {
    const state = this.inspect();
    const canvas = this.app?.canvas ?? this.app?.renderer?.canvas;
    let image = null;
    if (includeImage && canvas?.toDataURL) {
      try {
        image = {
          mimeType: 'image/png',
          width: Number(canvas.width) || 0,
          height: Number(canvas.height) || 0,
          dataUrl: canvas.toDataURL('image/png'),
        };
      } catch (error) {
        this.recordRuntimeError('snapshot-error', error, { source: 'canvas.toDataURL' });
      }
    }
    return { ...state, version: VisualSnapshotV1, image,
      errors: this.runtimeErrors.map((entry) => ({ ...entry })),
      errorStatus: this.runtimeErrors.length ? 'error' : 'ok' };
  }

  _recordNonFiniteValues(value, path = 'snapshot') {
    if (typeof value === 'number') {
      if (!Number.isFinite(value)) this.recordRuntimeError('non-finite', `non-finite value at ${path}`, {
        source: 'snapshot-validation', path, value,
      });
      return;
    }
    if (!value || typeof value !== 'object') return;
    if (Array.isArray(value)) {
      value.forEach((item, index) => this._recordNonFiniteValues(item, `${path}[${index}]`));
      return;
    }
    for (const [key, item] of Object.entries(value)) {
      this._recordNonFiniteValues(item, `${path}.${key}`);
    }
  }

  _recordWebglContextState() {
    try {
      const renderer = this.app?.renderer;
      if (!renderer) return;
      const webglRenderer = renderer.renderer;
      if (!webglRenderer?.getContext) {
        this.recordRuntimeError('webgl-context-missing', 'renderer has no WebGL context provider', {
          source: 'webgl', fatal: true, dedupeKey: 'webgl-context-missing',
        });
        return;
      }
      const gl = webglRenderer.getContext();
      if (!gl) {
        this.recordRuntimeError('webgl-context-missing', 'renderer returned no WebGL context', {
          source: 'webgl', fatal: true, dedupeKey: 'webgl-context-missing',
        });
        return;
      }
      if (gl?.isContextLost?.()) this.recordRuntimeError('webgl-context-lost', 'WebGL context is lost', {
        source: 'webgl', fatal: true, dedupeKey: 'webgl-context-lost',
      });
      if (typeof gl.getError === 'function') {
        const code = gl.getError();
        const noError = Number.isFinite(gl.NO_ERROR) ? gl.NO_ERROR : 0;
        if (code !== noError) this.recordRuntimeError('webgl-error', `WebGL error ${code}`, {
          source: 'webgl.getError', value: code, fatal: false, dedupeKey: `webgl-error:${code}`,
        });
      }
    } catch (error) {
      this.recordRuntimeError('webgl-inspection-error', error, { source: 'webgl' });
    }
  }

  _takeAppControl() {
    if (!this.app) return;
    if (!this._appControl) {
      const renderer = this.app.renderer;
      const input = this.app.input;
      const audio = this.app.audio;
      const menu = this.app.menu;
      this._appControl = {
        state: this.app.state,
        externalFrameDriver: !!this.app.externalFrameDriver,
        held: this.app._held,
        input: input ? { enabled: !!input.enabled, left: !!input.left, right: !!input.right } : null,
        audio: audio ? {
          thrustActive: !!audio._thrustSrc,
          thrustGain: audioParamValue(audio._thrustGain?.gain),
          proximityGain: audioParamValue(audio._proxGain?.gain),
          proximityFrequency: audioParamValue(audio._proxOsc?.frequency),
          proximityPan: audioParamValue(audio._proxPan?.pan),
        } : null,
        menu: menu ? {
          current: menu.current,
          overlayHidden: hiddenState(menu.overlay),
          flightHidden: hiddenState(menu.flightOverlay),
          touchHidden: hiddenState(menu.touch),
        } : null,
        reducedMotion: globalThis.document?.body?.classList?.contains?.('reduced-motion'),
        renderer: renderer ? {
          landmarks: renderer.landmarks,
          rockDetail: renderer.rockDetail,
          surfaceReliefRequested: renderer.surfaceReliefRequested,
          surfaceReliefProfile: renderer.surfaceReliefProfile,
          readability: renderer.readability,
          brightness: renderer.brightness,
          sight: renderer.sight,
          fov: renderer.baseFov ?? renderer.camera?.fov,
          motion: renderer.cameraCtl?.motion,
          shakeEnabled: renderer.cameraCtl?.shakeEnabled,
          cameraTime: renderer.cameraCtl?._t,
        } : null,
      };
    }
    this._bindRuntimeErrorSources();
    this.app.useExternalFrameDriver?.();
    if (this.app.AppState?.CAPTURE) this.app.state = this.app.AppState.CAPTURE;
    this.app.input?.setEnabled?.(false);
    this.app.audio?.stopLoops?.();
    this.app.menu?.hideOverlay?.();
    this.app.menu?.setFlightOverlayVisible?.(true);
    this.app.menu?.setTouchVisible?.(false);
  }

  _bindRuntimeErrorSources() {
    if (this._runtimeSources || !this.app) return;
    const canvas = this.app.canvas ?? this.app.renderer?.canvas;
    const win = canvas?.ownerDocument?.defaultView ?? globalThis.window;
    const onError = (event) => this.recordRuntimeError('browser-error', event?.error ?? event?.message, {
      source: event?.filename ?? 'window.error', fatal: false,
    });
    const onRejection = (event) => this.recordRuntimeError('unhandled-rejection', event?.reason, {
      source: 'window.unhandledrejection', fatal: false,
    });
    const onContextLost = (event) => {
      event?.preventDefault?.();
      this.recordRuntimeError('webgl-context-lost', event?.statusMessage || 'WebGL context is lost', {
        source: 'canvas.webglcontextlost', fatal: true, dedupeKey: 'webgl-context-lost',
      });
    };
    const onContextCreationError = (event) => this.recordRuntimeError(
      'webgl-context-creation-error', event?.statusMessage || 'WebGL context creation failed', {
        source: 'canvas.webglcontextcreationerror', fatal: true,
      });
    win?.addEventListener?.('error', onError);
    win?.addEventListener?.('unhandledrejection', onRejection);
    canvas?.addEventListener?.('webglcontextlost', onContextLost);
    canvas?.addEventListener?.('webglcontextcreationerror', onContextCreationError);
    this._runtimeSources = { win, canvas, onError, onRejection, onContextLost, onContextCreationError };
  }

  _unbindRuntimeErrorSources() {
    const source = this._runtimeSources;
    if (!source) return;
    source.win?.removeEventListener?.('error', source.onError);
    source.win?.removeEventListener?.('unhandledrejection', source.onRejection);
    source.canvas?.removeEventListener?.('webglcontextlost', source.onContextLost);
    source.canvas?.removeEventListener?.('webglcontextcreationerror', source.onContextCreationError);
    this._runtimeSources = null;
  }

  _applyRenderSettings(settings) {
    const renderer = this.app?.renderer;
    renderer?.setBrightness?.(settings.brightness);
    renderer?.setFov?.(settings.fov);
    renderer?.setMotion?.(settings.motion);
    this.app?.setReducedMotion?.(settings.motion);
    if (renderer?.cameraCtl) {
      renderer.cameraCtl.shakeEnabled = false;
      renderer.cameraCtl._t = 0;
    }
  }

  _control() {
    if (this.scenario.control === 'autopilot') this.game.autopilot();
    else this.game.player.lefton = this.game.player.righton = false;
  }

  _flyTo(distance) {
    let guard = 0;
    while (this.game.player.pos[2] - this.game.player.start < distance
      && this.game.phase === RunPhase.RUNNING && guard < MAX_FLIGHT_STEPS) {
      this._control();
      this.game.step();
      this.frame++;
      guard++;
    }
  }

  _advance(count) {
    let advanced = 0;
    while (advanced < count && this.game.phase === RunPhase.RUNNING) {
      this._control();
      const crashed = this.game.step();
      advanced++;
      this.frame++;
      if (crashed) break;
    }
    return advanced;
  }

  _present() {
    const session = this.app?.session;
    this.lastWarn = session?.trackWarn?.(this.game) ?? computeWarn(this.game);
    const renderer = this.app?.renderer;
    if (!renderer) return;
    const visibleCompositions = this._visibleCompositions();
    this.dev3d?.clearOrbitPieceScope?.();
    this.dev3d?.update(this.game, visibleCompositions);
    renderer.setSight?.(this.game.difficulty().sightMul);
    const hit = shipHit(this.game.player);
    renderer.render?.(this.game, hit, this.lastWarn.final);
    // Renderer.render may lazily build a newly visible landmark room. Apply the
    // dev-only pass once more and redraw Hero so the captured frame cannot show
    // production materials while claiming a neutral or silhouette pass.
    this.dev3d?.update(this.game, visibleCompositions);
    if (this.dev3d && this.dev3d.renderPass !== 'beauty') {
      renderer.renderer?.render?.(renderer.scene, renderer.camera);
    }
    const requestedCamera = this.scenario?.camera ?? 'hero';
    let orbit = null;
    const focusComp = visibleCompositions.reduce((best, value) => !best
      || Math.abs(value.z - this.scenario.distance) < Math.abs(best.z - this.scenario.distance)
      ? value : best, null);
    if (requestedCamera === 'free' || requestedCamera === 'orthographic') {
      const focusFrame = focusComp
        ? pathFrameAt(this.game.seed, Math.max(0, focusComp.z - this.game.player.start)) : null;
      this.cameraState = this.dev3d?.presentCamera(requestedCamera, this.game, {
        axis: this.scenario.orthographicAxis, focus: focusComp, frame: focusFrame,
      })
        ?? { requested: requestedCamera, active: 'hero', supported: false };
    } else if (requestedCamera === 'orbit') {
      const comp = focusComp;
      const orbitComp = comp ? this._orbitComposition(comp) : null;
      const pieceScope = orbitComp?.orbitScope === 'detail-bank'
        ? this.dev3d?.setOrbitPieceScope?.(comp, orbitComp.pieces) : null;
      let orbitRendered = false;
      try {
        orbitRendered = !!(orbitComp && renderer.renderOrbitPose?.(
          orbitComp, this.scenario.orbitDegrees * Math.PI / 180));
      } finally {
        // A successful scope remains leased to the frozen capture frame. Every
        // next presentation clears it before Hero; failed/throwing renders must
        // restore immediately so normal rendering can never inherit the crop.
        if (!orbitRendered) this.dev3d?.clearOrbitPieceScope?.();
      }
      if (orbitRendered) {
        orbit = { comp: orbitComp, angle: this.scenario.orbitDegrees * Math.PI / 180 };
        this.cameraState = { requested: requestedCamera, active: 'orbit', supported: true,
          scope: orbitComp.orbitScope ?? 'complete-composition',
          isolation: 'landmark-only',
          pieceCount: orbitComp.pieces.length,
          rig: orbitComp.orbitRig ?? 'route-cross-section',
          axialViewComponent: orbitComp.orbitAxialWeight == null ? null
            : round(Math.abs(Math.cos(orbit.angle)) * orbitComp.orbitAxialWeight),
          pieceScope: pieceScope ?? { applied: false, meshCount: 0,
            pieceCount: orbitComp.pieces.length } };
      } else {
        this.cameraState = { requested: requestedCamera, active: 'hero', supported: false };
      }
    } else {
      this.cameraState = {
        requested: requestedCamera,
        active: 'hero',
        supported: requestedCamera === 'hero',
      };
    }
    this.app.debug?.update?.(this.game, this.lastWarn);
    this.app.holdCaptureFrame?.(this.game, hit, this.lastWarn.final, orbit);
  }

  _visibleCompositions() {
    if (!this.game.landmarksEnabled) return [];
    const range = this.app?.renderer?.fog?.far ?? 110;
    return this.game.landmarkCache?.landmarksInView?.(
      this.game.cave, this.game.player.pos[2], range, this.game.seed, range,
      this.game.landmarkFamilyOverride,
    ) ?? this.game.landmarkCompositions;
  }

  _orbitComposition(comp) {
    if (!comp?.pieces?.length) return comp;
    // Crystal's three widely separated radial irises become sub-pixel when one
    // camera fits their full axial span, so Orbit documents the nearest bank.
    // Branching claws are one connected braid with axial wall spines; cropping
    // a bank clips those shared spines and is not an honest topology view.
    if (comp.typeName === 'crystal' && this.scenario?.orbitScope === 'complete-composition') {
      const frame = crystalOrbitFrame(comp.frame);
      return { ...comp, frame, orbitScope: 'complete-composition',
        orbitRig: frame.orbitRig, orbitAxialWeight: frame.orbitAxialWeight };
    }
    const key = comp.typeName === 'crystal' ? 'bank' : null;
    if (!key || !comp.pieces.some((piece) => Number.isInteger(piece[key]))) return comp;
    const groups = new Map();
    for (const piece of comp.pieces) {
      const value = piece[key];
      if (!Number.isInteger(value)) continue;
      if (!groups.has(value)) groups.set(value, []);
      groups.get(value).push(piece);
    }
    const targetDepth = this.scenario?.distance ?? comp.z;
    const nearest = [...groups.values()].reduce((best, pieces) => {
      const depth = pieces.reduce((sum, piece) => sum + piece.cz, 0) / pieces.length;
      return !best || Math.abs(depth - targetDepth) < Math.abs(best.depth - targetDepth)
        ? { pieces, depth } : best;
    }, null);
    if (!nearest) return comp;
    const bankFrame = crystalOrbitFrame(pathFrameAt(this.game.seed, Math.max(0, nearest.depth)));
    return { ...comp, pieces: nearest.pieces, collisionPieces: nearest.pieces,
      frame: bankFrame, orbitScope: 'detail-bank',
      orbitRig: bankFrame.orbitRig, orbitAxialWeight: bankFrame.orbitAxialWeight };
  }

  visibleCompositions() { return this._visibleCompositions(); }

  dispose() {
    this.dev3d?.dispose?.();
    this.dev3d = null;
    this._unbindRuntimeErrorSources();
    if (!this.app || !this._appControl) return;
    const original = this._appControl;
    const renderer = this.app.renderer;
    if (renderer && original.renderer) {
      if (original.renderer.landmarks !== undefined) renderer.setLandmarks?.(original.renderer.landmarks);
      if (original.renderer.readability !== undefined) renderer.setReadability?.(original.renderer.readability);
      if (original.renderer.rockDetail !== undefined) renderer.setRockDetail?.(original.renderer.rockDetail);
      if (original.renderer.surfaceReliefRequested !== undefined) renderer.setSurfaceRelief?.(
        original.renderer.surfaceReliefRequested, original.renderer.surfaceReliefProfile);
      if (original.renderer.brightness !== undefined) renderer.setBrightness?.(original.renderer.brightness);
      if (original.renderer.fov !== undefined) renderer.setFov?.(original.renderer.fov);
      if (original.renderer.motion !== undefined) renderer.setMotion?.(original.renderer.motion);
      if (original.renderer.sight !== undefined) renderer.setSight?.(original.renderer.sight);
      if (renderer.cameraCtl) {
        if (original.renderer.shakeEnabled !== undefined) {
          renderer.cameraCtl.shakeEnabled = original.renderer.shakeEnabled;
        }
        if (original.renderer.cameraTime !== undefined) renderer.cameraCtl._t = original.renderer.cameraTime;
      }
    }
    const input = this.app.input;
    if (input && original.input) {
      input.setEnabled?.(original.input.enabled);
      input.left = original.input.left;
      input.right = original.input.right;
    }
    const audio = this.app.audio;
    if (audio && original.audio) {
      const now = audio.ctx?.currentTime ?? 0;
      if (original.audio.thrustActive) audio.thrust?.(true);
      setAudioParam(audio._thrustGain?.gain, original.audio.thrustGain, now);
      setAudioParam(audio._proxGain?.gain, original.audio.proximityGain, now);
      setAudioParam(audio._proxOsc?.frequency, original.audio.proximityFrequency, now);
      setAudioParam(audio._proxPan?.pan, original.audio.proximityPan, now);
    }
    const menu = this.app.menu;
    if (menu && original.menu) {
      menu.current = original.menu.current;
      restoreHiddenState(menu.overlay, original.menu.overlayHidden);
      restoreHiddenState(menu.flightOverlay, original.menu.flightHidden);
      restoreHiddenState(menu.touch, original.menu.touchHidden);
    }
    if (original.renderer?.motion !== undefined && typeof this.app.setReducedMotion === 'function') {
      this.app.setReducedMotion(original.renderer.motion);
    } else if (original.reducedMotion !== undefined && typeof this.app.setReducedMotion === 'function') {
      this.app.setReducedMotion(original.reducedMotion ? 0 : 1);
    }
    if (original.reducedMotion !== undefined) {
      // Preserve an intentionally custom/inconsistent body class too; the app
      // API above restores the semantic setting, this restores the exact DOM.
      globalThis.document?.body?.classList?.toggle?.('reduced-motion', original.reducedMotion);
    }
    this.app._held = original.held;
    this.app.state = original.state;
    if (!original.externalFrameDriver) this.app.releaseExternalFrameDriver?.();
    this._appControl = null;
  }
}

export function createVisualDevApi(app, options = {}) {
  const runner = new VisualScenarioRunner({ app, ...options });
  return Object.freeze({
    loadScenario: (scenario) => runner.loadScenario(scenario),
    step: (count) => runner.step(count),
    setLayer: (name, enabled) => runner.setLayer(name, enabled),
    inspect: () => runner.inspect(),
    snapshot: (snapshotOptions) => runner.snapshot(snapshotOptions),
    pause: () => runner.pause(),
    resume: () => runner.resume(),
    reset: () => runner.reset(),
    recordRuntimeError: (type, error, details) => runner.recordRuntimeError(type, error, details),
    clearRuntimeErrors: () => runner.clearRuntimeErrors(),
    runner,
  });
}
