export const VisualScenarioV1 = 'VisualScenarioV1';
export const VisualSnapshotV1 = 'VisualSnapshotV1';

export const DEFAULT_VISUAL_SCENARIO = Object.freeze({
  version: VisualScenarioV1,
  name: 'visual-lab',
  seed: 424242,
  mode: 2,
  distance: 0,
  steps: 0,
  family: 'auto',
  camera: 'hero',
  orthographicAxis: 'front',
  renderPass: 'beauty',
  orbitDegrees: 0,
  orbitScope: 'detail-bank',
  placement: 'fly',
  control: 'autopilot',
  paused: true,
  viewport: Object.freeze({ width: 1280, height: 720, dpr: 1 }),
  settings: Object.freeze({
    readability: true,
    rockDetail: true,
    surfaceRelief: true,
    landmarks: true,
    cave: true,
    wireframe: false,
    landmarkMesh: true,
    collisionCapsules: false,
    booleanTube: false,
    playerHull: false,
    frames: false,
    fog: true,
    material: true,
    light: true,
    brightness: 1,
    fov: 45,
    motion: 0,
  }),
});

const finite = (value, fallback, min = -Infinity, max = Infinity) => {
  const number = Number(value);
  return Number.isFinite(number) ? Math.max(min, Math.min(max, number)) : fallback;
};

const boolean = (value, fallback) => {
  if (value === undefined || value === null || value === '') return fallback;
  if (typeof value === 'string') {
    if (['0', 'false', 'off', 'no'].includes(value.toLowerCase())) return false;
    if (['1', 'true', 'on', 'yes'].includes(value.toLowerCase())) return true;
  }
  return !!value;
};

const integerSeed = (value) => {
  const seed = finite(value, DEFAULT_VISUAL_SCENARIO.seed, -2147483648, 2147483647) | 0;
  return seed === 0 ? 1 : seed;
};

const oneOf = (value, allowed, fallback) => allowed.includes(value) ? value : fallback;

/**
 * Return a detached, JSON-safe VisualScenarioV1. Unknown keys are deliberately
 * discarded so a copied lab URL cannot smuggle application state into a run.
 */
export function normalizeVisualScenario(input = {}) {
  if (input === null || typeof input !== 'object' || Array.isArray(input)) {
    throw new TypeError('VisualScenarioV1 must be an object');
  }
  if (input.version !== undefined && input.version !== VisualScenarioV1) {
    throw new TypeError(`Unsupported visual scenario version: ${input.version}`);
  }

  const defaults = DEFAULT_VISUAL_SCENARIO;
  const suppliedSettings = input.settings && typeof input.settings === 'object'
    ? input.settings : {};
  const placement = input.placement === 'place' || input.place === true ? 'place' : 'fly';
  const control = input.control === 'neutral' ? 'neutral' : 'autopilot';
  const family = oneOf(input.family, ['auto', 'off', 'branching', 'crystal', 'coiling'], defaults.family);

  return {
    version: VisualScenarioV1,
    name: String(input.name ?? defaults.name).slice(0, 80),
    seed: integerSeed(input.seed),
    mode: finite(input.mode, defaults.mode, 1, 2) === 1 ? 1 : 2,
    distance: finite(input.distance, defaults.distance, 0, 1000000),
    steps: Math.trunc(finite(input.steps, defaults.steps, 0, 1000000)),
    family,
    camera: oneOf(input.camera, ['hero', 'orbit', 'free', 'orthographic'], defaults.camera),
    orthographicAxis: oneOf(input.orthographicAxis, ['front', 'side', 'top'], defaults.orthographicAxis),
    renderPass: oneOf(input.renderPass, ['beauty', 'neutral', 'clay', 'silhouette'], defaults.renderPass),
    orbitDegrees: finite(input.orbitDegrees, defaults.orbitDegrees, -36000, 36000),
    orbitScope: oneOf(input.orbitScope, ['detail-bank', 'complete-composition'], defaults.orbitScope),
    placement,
    control,
    paused: boolean(input.paused, defaults.paused),
    viewport: {
      width: Math.trunc(finite(input.viewport?.width, defaults.viewport.width, 320, 7680)),
      height: Math.trunc(finite(input.viewport?.height, defaults.viewport.height, 180, 4320)),
      dpr: finite(input.viewport?.dpr, defaults.viewport.dpr, 0.5, 4),
    },
    settings: {
      readability: boolean(suppliedSettings.readability, defaults.settings.readability),
      rockDetail: boolean(suppliedSettings.rockDetail, defaults.settings.rockDetail),
      surfaceRelief: boolean(suppliedSettings.surfaceRelief, defaults.settings.surfaceRelief),
      // `off` is an explicit evidence/control state, not a fourth procedural
      // family. Preserve it in the scenario/snapshot while disabling both
      // visible and lethal landmark authority for the run.
      landmarks: family === 'off' ? false
        : boolean(suppliedSettings.landmarks, defaults.settings.landmarks),
      cave: boolean(suppliedSettings.cave, defaults.settings.cave),
      wireframe: boolean(suppliedSettings.wireframe, defaults.settings.wireframe),
      landmarkMesh: boolean(suppliedSettings.landmarkMesh, defaults.settings.landmarkMesh),
      collisionCapsules: boolean(suppliedSettings.collisionCapsules, defaults.settings.collisionCapsules),
      booleanTube: boolean(suppliedSettings.booleanTube, defaults.settings.booleanTube),
      playerHull: boolean(suppliedSettings.playerHull, defaults.settings.playerHull),
      frames: boolean(suppliedSettings.frames, defaults.settings.frames),
      fog: boolean(suppliedSettings.fog, defaults.settings.fog),
      material: boolean(suppliedSettings.material, defaults.settings.material),
      light: boolean(suppliedSettings.light, defaults.settings.light),
      brightness: finite(suppliedSettings.brightness, defaults.settings.brightness, 0.1, 2),
      fov: finite(suppliedSettings.fov, defaults.settings.fov, 45, 110),
      motion: finite(suppliedSettings.motion, defaults.settings.motion, 0, 1),
    },
  };
}

export function assertVisualSnapshot(snapshot) {
  if (!snapshot || snapshot.version !== VisualSnapshotV1) {
    throw new TypeError('Expected a VisualSnapshotV1');
  }
  return snapshot;
}
