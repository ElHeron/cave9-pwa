// SaveSystem — a defensive localStorage boundary. Values loaded from storage are
// untrusted: a prior version, devtools, or a blocked browser must never make the
// game fail to start. Historical keys remain readable; ranked.v1 keys carry
// the complete rule profile and never reinterpret an old scalar best.

import { seedFromString } from '../core/RNG.js';
import { DAILY_RULES, isNormalizedRunRules } from '../core/RunRules.js';

const PREFIX = 'cave9.';
export const SAVE_FORMAT_VERSION = 2;

const DANGEROUS_KEYS = new Set(['__proto__', 'constructor', 'prototype']);
const DAILY_KEY = /^\d{4}-\d{2}-\d{2}$/;

function isRecord(value) {
  if (value === null || typeof value !== 'object' || Array.isArray(value)) return false;
  const prototype = Object.getPrototypeOf(value);
  return prototype === Object.prototype || prototype === null;
}

function read(key, fallback) {
  try {
    const raw = localStorage.getItem(PREFIX + key);
    return raw == null ? fallback : JSON.parse(raw);
  } catch {
    return fallback;
  }
}

function write(key, value) {
  try {
    localStorage.setItem(PREFIX + key, JSON.stringify(value));
    return true;
  } catch {
    return false;
  }
}

function markVersion() { write('storageVersion', SAVE_FORMAT_VERSION); }

function writeCurrent(key, value) {
  const saved = write(key, value);
  if (saved) markVersion();
  return saved;
}

function score(value) { return Number.isSafeInteger(value) && value >= 0 ? value : 0; }
function validScore(value) { return Number.isSafeInteger(value) && value >= 0; }
function mode(value) { return value === 1 || value === 2 ? value : null; }

function seed(value) {
  // Seeds are signed 32-bit values in the core. Do not use bitwise coercion
  // here: it silently wraps huge numbers into unrelated personal records.
  return Number.isSafeInteger(value) && value >= -0x80000000 && value <= 0x7fffffff ? value : null;
}

function dailyKey(value) { return typeof value === 'string' && DAILY_KEY.test(value) ? value : null; }
function rankedDay(value) {
  const day = dailyKey(value);
  if (!day) return null;
  const date = new Date(`${day}T00:00:00Z`);
  return Number.isFinite(date.getTime()) && date.toISOString().slice(0, 10) === day ? day : null;
}

function safeMap(value, valueIsValid) {
  if (!isRecord(value)) return Object.create(null);
  const out = Object.create(null);
  for (const key of Object.keys(value)) {
    if (!DANGEROUS_KEYS.has(key) && valueIsValid(key, value[key])) out[key] = value[key];
  }
  return out;
}

function repairedMap(storageKey, valueIsValid) {
  const raw = read(storageKey, null);
  const normalized = safeMap(raw, valueIsValid);
  if (raw !== null && (!isRecord(raw) || Object.keys(raw).some((key) =>
    !Object.prototype.hasOwnProperty.call(normalized, key) || raw[key] !== normalized[key]))) {
    writeCurrent(storageKey, normalized);
  }
  return normalized;
}

function seedBestMap(storageKey = 'seedBest') {
  return repairedMap(storageKey, (key, value) => {
    const normalizedSeed = seed(Number(key));
    return normalizedSeed !== null && String(normalizedSeed) === key && validScore(value);
  });
}

function unlockMap() {
  return repairedMap('unlocks', (key, value) => key.length > 0 && typeof value === 'boolean');
}

function rankedContext(context) {
  if (!context || (context.daily !== true && context.daily !== false)) return null;
  const normalizedSeed = seed(context.seed);
  if (normalizedSeed === null || normalizedSeed === 0 || !isNormalizedRunRules(context.rules)) return null;
  if (context.daily) {
    const day = rankedDay(context.dailyKey);
    if (!day || seedFromString(day) !== normalizedSeed || context.rules.key !== DAILY_RULES.key) return null;
  } else if (context.dailyKey !== null) {
    return null;
  }
  const kind = context.daily ? 'daily' : 'free';
  const profile = context.rules.key;
  return { kind, profile, seed: normalizedSeed, day: context.dailyKey };
}

function rankedBestKey(identity) { return `ranked.v1.best.${identity.kind}.${identity.profile}`; }
function rankedSeedKey(identity) { return `ranked.v1.seedBest.${identity.kind}.${identity.profile}`; }
function rankedDailyKey(identity) { return `ranked.v1.daily.${identity.day}.${identity.profile}`; }

export const SaveSystem = {
  available() {
    try {
      const key = PREFIX + '__test';
      localStorage.setItem(key, '1');
      localStorage.removeItem(key);
      return true;
    } catch {
      return false;
    }
  },

  // The marker tracks the storage layout; an existing v1 value stays
  // observable until a successful write upgrades it to v2.
  formatVersion() {
    const version = read('storageVersion', 0);
    return Number.isSafeInteger(version) && version >= 0 && version <= SAVE_FORMAT_VERSION ? version : 0;
  },

  // Ranked records use the frozen context supplied at run start. The old
  // getBest/getSeedBest/getDailyBest API remains available for historical data.
  getRunBest(context) {
    const identity = rankedContext(context);
    return identity ? score(read(rankedBestKey(identity), 0)) : 0;
  },
  setRunBest(context, value) {
    const identity = rankedContext(context);
    if (!identity || !validScore(value) || value <= this.getRunBest(context)) return false;
    writeCurrent(rankedBestKey(identity), value);
    return true;
  },
  getRunSeedBest(context) {
    const identity = rankedContext(context);
    return identity ? score(seedBestMap(rankedSeedKey(identity))[String(identity.seed)]) : 0;
  },
  setRunSeedBest(context, value) {
    const identity = rankedContext(context);
    if (!identity || !validScore(value)) return false;
    const records = seedBestMap(rankedSeedKey(identity));
    const key = String(identity.seed);
    if (value <= score(records[key])) return false;
    records[key] = value;
    const keys = Object.keys(records);
    if (keys.length > 50) delete records[keys[0]];
    writeCurrent(rankedSeedKey(identity), records);
    return true;
  },
  getRunDailyBest(context) {
    const identity = rankedContext(context);
    return identity?.kind === 'daily' ? score(read(rankedDailyKey(identity), 0)) : 0;
  },
  setRunDailyBest(context, value) {
    const identity = rankedContext(context);
    if (identity?.kind !== 'daily' || !validScore(value) || value <= this.getRunDailyBest(context)) return false;
    writeCurrent(rankedDailyKey(identity), value);
    return true;
  },
  recordRun(context, value) {
    return {
      newBest: this.setRunBest(context, value),
      newSeedBest: this.setRunSeedBest(context, value),
      newDailyBest: this.setRunDailyBest(context, value),
    };
  },

  // Best score is tracked per control mode (1-button vs 2-button).
  getBest(controlMode = 2) {
    const normalizedMode = mode(controlMode);
    return normalizedMode === null ? 0 : score(read(`best.${normalizedMode}`, 0));
  },
  setBest(controlMode, value) {
    const normalizedMode = mode(controlMode);
    if (normalizedMode === null || !validScore(value)) return false;
    const current = this.getBest(normalizedMode);
    if (value > current) {
      writeCurrent(`best.${normalizedMode}`, value);
      return true;
    }
    return false;
  },
  bestOverall() { return Math.max(this.getBest(1), this.getBest(2)); },

  getSettings() {
    const value = read('settings', null);
    return isRecord(value) ? value : null;
  },
  setSettings(value) { return isRecord(value) && writeCurrent('settings', value); },

  getUnlocks() { return unlockMap(); },
  setUnlock(key, value = true) {
    if (typeof key !== 'string' || key.length === 0 || DANGEROUS_KEYS.has(key) || typeof value !== 'boolean') return false;
    const unlocks = unlockMap();
    unlocks[key] = value;
    return writeCurrent('unlocks', unlocks);
  },

  getLastSeed() { return seed(read('lastSeed', null)); },
  setLastSeed(value) {
    const normalizedSeed = seed(value);
    return normalizedSeed !== null && writeCurrent('lastSeed', normalizedSeed);
  },

  // ---- daily challenge (local, backend-free) ----------------------------
  getDailyBest(key) {
    const normalizedKey = dailyKey(key);
    return normalizedKey === null ? 0 : score(read(`daily.${normalizedKey}`, 0));
  },
  setDailyBest(key, value) {
    const normalizedKey = dailyKey(key);
    if (normalizedKey === null || !validScore(value)) return false;
    const current = this.getDailyBest(normalizedKey);
    if (value > current) {
      writeCurrent(`daily.${normalizedKey}`, value);
      return true;
    }
    return false;
  },

  // Best score for an arbitrary seed. Keep a bounded, null-prototype map so
  // corrupted data and prototype-shaped keys cannot escape this boundary.
  getSeedBest(value) {
    const normalizedSeed = seed(value);
    if (normalizedSeed === null) return 0;
    return score(seedBestMap()[String(normalizedSeed)]);
  },
  setSeedBest(value, best) {
    const normalizedSeed = seed(value);
    if (normalizedSeed === null || !validScore(best)) return false;
    const records = seedBestMap();
    const key = String(normalizedSeed);
    if (best <= score(records[key])) return false;
    records[key] = best;
    const keys = Object.keys(records);
    if (keys.length > 50) delete records[keys[0]];
    writeCurrent('seedBest', records);
    // Keep the legacy return contract: true means this score beat the loaded
    // record, even when a blocked backend cannot persist it.
    return true;
  },
};
