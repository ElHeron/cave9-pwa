import { Capacitor } from '@capacitor/core';
import packageInfo from '../../package.json' with { type: 'json' };

export const PUBLIC_GAME_URL = 'https://elheron.github.io/cave9-pwa/';
export const isNativeApp = () => Capacitor.isNativePlatform();
export const shareBaseUrl = (pageUrl, native = isNativeApp()) => native ? PUBLIC_GAME_URL : pageUrl;
export const sourceDownloadUrl = (native = isNativeApp()) => native
  ? `https://github.com/ElHeron/cave9-pwa/releases/download/android-v${packageInfo.version}/cave9-${packageInfo.version}-source.zip`
  : './source/cave9-source.zip';

export async function bindNativeListeners({ onPause, onBack }, { native = isNativeApp(), api } = {}) {
  if (!native) return [];
  const App = api ?? (await import('@capacitor/app')).App;
  return Promise.all([
    App.addListener('pause', onPause),
    App.addListener('backButton', () => { void onBack(() => App.exitApp()); }),
  ]);
}

export async function writeGameClipboard(text) {
  if (isNativeApp()) {
    const { Clipboard } = await import('@capacitor/clipboard');
    await Clipboard.write({ string: text });
  } else await navigator.clipboard.writeText(text);
}
