// AudioSystem — WebAudio. Uses the original cave9 samples (thrust/hit/crash,
// see LICENSE_NOTES) when they decode, with synth fallbacks so the game is
// never silent. A continuous "proximity" tone rises as you near a wall.
//
// Browsers block audio until a user gesture: call resume() from the first tap.
//
// This system takes a warning LEVEL and a stereo PAN and plays them; deciding
// what those should be is core/WarnState.js's job (directionalPan moved there
// with the rest of the warning model).

export class AudioSystem {
  constructor() {
    this.ctx = null;
    this.enabled = true;
    this.volume = 0.7;
    this.buffers = {};
    this.ready = false;
    this._thrustGain = null;
    this._thrustSrc = null;
    this._proxOsc = null;
    this._proxGain = null;
    this._proxPan = null;
  }

  _ensureContext() {
    if (this.ctx) return;
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    this.ctx = new AC();
    this.master = this.ctx.createGain();
    this.master.gain.value = this.enabled ? this.volume : 0;
    this.master.connect(this.ctx.destination);
  }

  async load() {
    this._ensureContext();
    if (!this.ctx) return;
    const names = { thrust: 'thrust.wav', hit: 'hit.wav', crash: 'crash.wav' };
    await Promise.all(Object.entries(names).map(async ([key, file]) => {
      try {
        const res = await fetch('./assets/' + file);
        const arr = await res.arrayBuffer();
        this.buffers[key] = await this.ctx.decodeAudioData(arr);
      } catch {
        this.buffers[key] = null; // fall back to synth
      }
    }));
    this.ready = true;
  }

  resume() {
    this._ensureContext();
    if (this.ctx && this.ctx.state === 'suspended') this.ctx.resume();
  }

  setEnabled(v) {
    this.enabled = v;
    if (this.master) this.master.gain.value = v ? this.volume : 0;
  }
  setVolume(v) {
    this.volume = v;
    if (this.master) this.master.gain.value = this.enabled ? v : 0;
  }

  // ---- gameplay sounds -------------------------------------------------

  _startProximity() {
    if (!this.ctx || this._proxOsc) return;
    this._proxOsc = this.ctx.createOscillator();
    this._proxGain = this.ctx.createGain();
    this._proxOsc.type = 'sawtooth';
    this._proxOsc.frequency.value = 200;
    this._proxGain.gain.value = 0;
    // Stereo-pan the warning so the player hears which wall is close. The panner
    // sits AFTER the gain and BEFORE the master, so mute/volume (on the master)
    // still govern audibility. Feature-detected: if StereoPannerNode is missing
    // we fall back to the original mono chain (no error, just no panning).
    if (typeof this.ctx.createStereoPanner === 'function') {
      this._proxPan = this.ctx.createStereoPanner();
      this._proxOsc.connect(this._proxGain).connect(this._proxPan).connect(this.master);
    } else {
      this._proxPan = null;
      this._proxOsc.connect(this._proxGain).connect(this.master);
    }
    this._proxOsc.start();
  }

  // level: 0..1 wall proximity (drives the warning tone).
  // pan: −1..1 stereo direction of the nearest wall (see directionalPan). Purely
  // additive — it changes where the warning is heard, not whether it plays.
  proximity(level, pan = 0) {
    if (!this.ctx || !this.enabled) return;
    this._startProximity();
    const now = this.ctx.currentTime;
    const g = level > 0.45 ? (level - 0.45) * 0.5 : 0;
    this._proxGain.gain.setTargetAtTime(g, now, 0.05);
    this._proxOsc.frequency.setTargetAtTime(180 + level * 520, now, 0.05);
    if (this._proxPan) {
      const p = Math.max(-1, Math.min(1, pan || 0));
      this._proxPan.pan.setTargetAtTime(p, now, 0.08);
    }
  }

  // intensity: 0..1 thrust amount (loops the thrust sample)
  thrust(active) {
    if (!this.ctx || !this.enabled) return;
    const now = this.ctx.currentTime;
    if (active && !this._thrustSrc) {
      this._thrustGain = this.ctx.createGain();
      this._thrustGain.gain.value = 0;
      this._thrustGain.connect(this.master);
      if (this.buffers.thrust) {
        const s = this.ctx.createBufferSource();
        s.buffer = this.buffers.thrust;
        s.loop = true;
        s.connect(this._thrustGain);
        s.start();
        this._thrustSrc = s;
      } else {
        const o = this.ctx.createOscillator();
        o.type = 'triangle';
        o.frequency.value = 90;
        o.connect(this._thrustGain);
        o.start();
        this._thrustSrc = o;
      }
    }
    if (this._thrustGain) {
      this._thrustGain.gain.setTargetAtTime(active ? 0.35 : 0, now, 0.03);
    }
  }

  crash() {
    if (!this.ctx || !this.enabled) return;
    this.stopLoops();
    this._playBuffer('crash', 0.9) || this._noiseBurst();
  }

  blip(freq = 660) {
    if (!this.ctx || !this.enabled) return;
    const now = this.ctx.currentTime;
    const o = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    o.type = 'square';
    o.frequency.value = freq;
    g.gain.setValueAtTime(0.0, now);
    g.gain.linearRampToValueAtTime(0.2, now + 0.01);
    g.gain.exponentialRampToValueAtTime(0.001, now + 0.12);
    o.connect(g).connect(this.master);
    o.start(now);
    o.stop(now + 0.13);
  }

  _playBuffer(key, gain = 1) {
    if (!this.ctx || !this.buffers[key]) return false;
    const s = this.ctx.createBufferSource();
    const g = this.ctx.createGain();
    g.gain.value = gain;
    s.buffer = this.buffers[key];
    s.connect(g).connect(this.master);
    s.start();
    return true;
  }

  _noiseBurst() {
    const ctx = this.ctx;
    const len = Math.floor(ctx.sampleRate * 0.4);
    const buf = ctx.createBuffer(1, len, ctx.sampleRate);
    const data = buf.getChannelData(0);
    for (let i = 0; i < len; i++) data[i] = (Math.random() * 2 - 1) * (1 - i / len);
    const s = ctx.createBufferSource();
    const g = ctx.createGain();
    g.gain.value = 0.6;
    s.buffer = buf;
    s.connect(g).connect(this.master);
    s.start();
  }

  stopLoops() {
    const now = this.ctx ? this.ctx.currentTime : 0;
    if (this._thrustGain) this._thrustGain.gain.setTargetAtTime(0, now, 0.02);
    if (this._thrustSrc) {
      try { this._thrustSrc.stop(now + 0.1); } catch {}
      this._thrustSrc = null;
      this._thrustGain = null;
    }
    if (this._proxGain) this._proxGain.gain.setTargetAtTime(0, now, 0.05);
  }
}
