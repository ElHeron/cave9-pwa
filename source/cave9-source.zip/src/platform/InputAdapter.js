// InputAdapter — unifies keyboard, gamepad and touch into two thruster flags
// (`left`, `right`) plus a couple of UI actions (pause, confirm). The game loop
// reads `.left` / `.right`; menus get `onPause` / `onConfirm` callbacks.

import { ONE_BUTTON } from '../core/constants.js';

// Pure resolver: combine raw left/right intents into the final thruster flags,
// applying invert (swap L/R) and the one-button collapse. Unit-tested so the
// "invert changes input direction" and "one-button collapses" rules are proven
// without any DOM/window. `which` of L/R refers to physical inputs.
export function resolveThrust({ l, r, up = false, mode, invertX = false, diagonalPhase = 0 }) {
  let left = !!l;
  let right = !!r;
  if (invertX) { const t = left; left = right; right = t; }
  if (up) {
    if (left !== right && (diagonalPhase & 1) === 0) {
      // Up + one side cannot be represented by one of the four binary
      // thruster states. Alternate BOTH / SIDE at the fixed-step rate so the
      // held keys produce a stable diagonal average without changing physics.
      left = right = true;
    } else if (!left && !right) {
      left = right = true;
    }
  }
  if (mode === ONE_BUTTON) {
    const any = left || right;
    left = right = any;
  }
  return { left, right };
}

// The camera looks along +Z, so screen-left is produced by the right actuator
// and screen-right by the left actuator. Keep that projection correction at
// the platform boundary; core physics, autopilot and replay bits remain stable.
// 'mirror' deliberately reverses the corrected screen mapping.
export function touchMapping(hand) {
  return hand === 'mirror' ? { left: 'L', right: 'R' } : { left: 'R', right: 'L' };
}

export class InputAdapter {
  constructor(opts = {}) {
    this.left = false;
    this.right = false;
    this.enabled = false;       // only steer the ship while a run is active
    this.mode = 2;
    this.touchHand = 'split';
    this.invertX = false;

    this.onPause = opts.onPause || (() => {});
    this.onConfirm = opts.onConfirm || (() => {});

    this._keys = new Set();
    this._pressedSinceStep = new Set();
    this._touchL = false;
    this._touchR = false;
    this._touchPressedL = false;
    this._touchPressedR = false;
    this._padState = { l: false, r: false, up: false };
    this._padPauseLatch = false;
    this._padConfirmLatch = false;
    this._touchBinding = null;
    this._diagonalPhase = 0;
    this._diagonalSignature = '';
    this._diagonalActive = false;

    this._bindKeyboard();
  }

  setEnabled(v) {
    this.enabled = v;
    if (!v) {
      this.left = this.right = false;
      this._pressedSinceStep.clear();
      this._keys.clear();
      this._touchPressedL = this._touchPressedR = false;
      this._touchL = this._touchR = false;
      this._diagonalPhase = 0;
      this._diagonalSignature = '';
      this._diagonalActive = false;
    }
  }
  setMode(m) { this.mode = m; }
  setTouchHand(h) {
    if (this.touchHand === h) return;
    this.touchHand = h;
    this._touchL = this._touchR = false;
    this._touchPressedL = this._touchPressedR = false;
  }
  setInvertX(v) { this.invertX = !!v; }

  _bindKeyboard() {
    window.addEventListener('keydown', (e) => {
      if (e.repeat) return;
      const k = e.code;
      if (this.enabled && /^(?:Arrow(?:Left|Right|Up|Down)|Key[WASD]|Space)$/.test(k)) e.preventDefault?.();
      if (k === 'Escape' || k === 'KeyP') { this.onPause(); return; }
      if (k === 'Enter' || k === 'Space') {
        // Space also thrusts, but Enter is a pure confirm
        if (k === 'Enter') {
          // Focused controls already have native Enter behaviour. A global
          // confirm here would start a run as well as activating the control.
          const target = e.target ?? globalThis.document?.activeElement;
          const interactive = target?.closest?.('button, input, select, textarea, a, [role="button"], [contenteditable="true"]')
            || /^(BUTTON|INPUT|SELECT|TEXTAREA|A)$/.test(target?.tagName ?? '')
            || target?.isContentEditable;
          if (!interactive) this.onConfirm(e);
          return;
        }
      }
      if (this.enabled) {
        this._keys.add(k);
        this._pressedSinceStep.add(k);
      }
    });
    window.addEventListener('keyup', (e) => {
      if (this.enabled && /^(?:Arrow(?:Left|Right|Up|Down)|Key[WASD]|Space)$/.test(e.code)) e.preventDefault?.();
      this._keys.delete(e.code);
    });
    window.addEventListener('blur', () => {
      this._keys.clear();
      this._pressedSinceStep.clear();
      this._touchL = this._touchR = false;
      this._touchPressedL = this._touchPressedR = false;
      this._diagonalPhase = 0;
      this._diagonalSignature = '';
      this._diagonalActive = false;
      this.left = this.right = false;
    });
  }

  // Bind each physical zone once. Mapping is read at press time, so changing
  // layout never accumulates listeners or leaves an old mapping active.
  bindTouch(leftEl, rightEl) {
    if (this._touchBinding?.leftEl === leftEl && this._touchBinding?.rightEl === rightEl) return;
    this._touchBinding?.remove();
    const listeners = [];
    const add = (el, type, fn, options) => {
      el.addEventListener(type, fn, options);
      listeners.push(() => el.removeEventListener(type, fn, options));
    };
    const press = (zone, v) => {
      const map = touchMapping(this.touchHand);
      const which = map.left === zone ? 'L' : 'R';
      if (which === 'L') {
        if (v && !this._touchL && this.enabled) this._touchPressedL = true;
        this._touchL = v && this.enabled;
      } else {
        if (v && !this._touchR && this.enabled) this._touchPressedR = true;
        this._touchR = v && this.enabled;
      }
    };
    for (const [el, zone] of [[leftEl, 'L'], [rightEl, 'R']]) {
      add(el, 'touchstart', (e) => { e.preventDefault(); press(zone, true); }, { passive: false });
      add(el, 'touchend', (e) => { e.preventDefault(); press(zone, false); }, { passive: false });
      add(el, 'touchcancel', () => press(zone, false));
      // also support mouse for desktop testing of the touch UI
      add(el, 'mousedown', (e) => { e.preventDefault(); press(zone, true); });
      add(el, 'mouseup', () => press(zone, false));
      add(el, 'mouseleave', () => press(zone, false));
    }
    this._touchBinding = { leftEl, rightEl, remove: () => listeners.forEach((remove) => remove()) };
  }

  rebindTouch(leftEl, rightEl) {
    this._touchL = this._touchR = false;
    this._touchPressedL = this._touchPressedR = false;
    this.bindTouch(leftEl, rightEl);
  }

  _pollGamepad() {
    const pads = globalThis.navigator?.getGamepads?.() ?? [];
    let l = false, r = false, up = false, pause = false, confirm = false;
    const wasEnabled = this.enabled;
    for (const pad of pads) {
      if (!pad) continue;
      const ax = pad.axes[0] || 0;
      if (ax < -0.35) r = true;
      if (ax > 0.35) l = true;
      // shoulder/trigger buttons
      if (pad.buttons[4]?.pressed || pad.buttons[6]?.pressed) r = true;
      if (pad.buttons[5]?.pressed || pad.buttons[7]?.pressed) l = true;
      if (pad.buttons[0]?.pressed) { up = true; confirm = true; } // A / cross
      if (pad.buttons[9]?.pressed) pause = true;  // Start
    }
    if (pause && !this._padPauseLatch) { this._padPauseLatch = true; this.onPause(); }
    if (!pause) this._padPauseLatch = false;
    if (confirm && !this._padConfirmLatch && !wasEnabled) this.onConfirm();
    this._padConfirmLatch = confirm;
    return { l, r, up };
  }

  _keyboardState(includeLatched = false) {
    const K = includeLatched
      ? new Set([...this._keys, ...this._pressedSinceStep])
      : this._keys;
    // Screen direction is the inverse of the actuator name in the +Z camera.
    let r = K.has('ArrowLeft') || K.has('KeyA');
    let l = K.has('ArrowRight') || K.has('KeyD');
    const up = K.has('Space') || K.has('ArrowUp') || K.has('KeyW');
    return { l, r, up };
  }

  // Called once per animation frame.
  update() {
    this._padState = this._pollGamepad();
    if (!this.enabled) {
      this.left = this.right = false;
      this._pressedSinceStep.clear();
      this._touchPressedL = this._touchPressedR = false;
      return;
    }
    this._resolveCurrent(true);
  }

  _resolveCurrent(includeLatched) {
    const kb = this._keyboardState(includeLatched);
    const pad = this._padState;
    const rawLeft = kb.l || pad.l || this._touchL || (includeLatched && this._touchPressedL);
    const rawRight = kb.r || pad.r || this._touchR || (includeLatched && this._touchPressedR);
    const up = kb.up || pad.up;
    const signature = up && rawLeft !== rawRight && this.mode !== ONE_BUTTON
      ? `${rawLeft ? 'L' : 'R'}:${this.invertX ? 1 : 0}`
      : '';
    if (signature !== this._diagonalSignature) this._diagonalPhase = 0;
    this._diagonalSignature = signature;
    this._diagonalActive = !!signature;
    const { left, right } = resolveThrust({
      l: rawLeft,
      r: rawRight,
      up,
      mode: this.mode,
      invertX: this.invertX,
      diagonalPhase: this._diagonalPhase,
    });
    this.left = left;
    this.right = right;
  }

  // Called by the fixed-step loop. A tap that began and ended between display
  // samples reaches exactly one simulation step; held controls remain active
  // across every catch-up step after a long frame.
  sampleStep() {
    const state = { left: this.left, right: this.right };
    this._pressedSinceStep.clear();
    this._touchPressedL = this._touchPressedR = false;
    if (this._diagonalActive) this._diagonalPhase ^= 1;
    this._resolveCurrent(false);
    return state;
  }
}

export function isTouchDevice() {
  return (('ontouchstart' in window) || (navigator.maxTouchPoints > 0));
}
