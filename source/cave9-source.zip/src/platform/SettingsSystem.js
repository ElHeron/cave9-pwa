// SettingsSystem — typed, persisted user settings plus a schema the menu uses
// to auto-build the settings UI. Every persisted value is treated as untrusted
// and coerced/clamped against the schema before it reaches the runtime.

import { SaveSystem } from './SaveSystem.js';
import { ONE_BUTTON, TWO_BUTTONS } from '../core/constants.js';

export const SETTINGS_SCHEMA = [
  {
    key: 'controlMode', label: 'Control scheme', kind: 'choice',
    choices: [
      { value: TWO_BUTTONS, label: 'Two thrusters' },
      { value: ONE_BUTTON, label: 'One button (easier)' },
    ],
    section: 'Gameplay',
  },
  { key: 'sensitivity', label: 'Thruster sensitivity', kind: 'range', min: 0.6, max: 1.6, step: 0.05, fmt: 'x', section: 'Gameplay' },
  { key: 'invertX', label: 'Invert thrusters (L/R)', kind: 'toggle', section: 'Gameplay' },
  { key: 'brightness', label: 'Brightness', kind: 'range', min: 0.6, max: 1.5, step: 0.05, fmt: 'x', section: 'Display' },
  { key: 'fov', label: 'Field of view', kind: 'range', min: 35, max: 75, step: 1, fmt: '°', section: 'Display' },
  { key: 'motion', label: 'Motion / shake', kind: 'range', min: 0, max: 1, step: 0.05, fmt: '%', section: 'Display' },
  { key: 'quality', label: 'Render quality', kind: 'choice',
    choices: [
      { value: 1, label: 'Performance' },
      { value: 2, label: 'High' },
    ], section: 'Display' },
  { key: 'rockDetail', label: 'Rock surface detail', kind: 'toggle', section: 'Display' },
  { key: 'landmarks', label: 'Obstacle formations', kind: 'toggle', section: 'Gameplay' },
  { key: 'sound', label: 'Sound effects', kind: 'toggle', section: 'Audio' },
  { key: 'volume', label: 'Volume', kind: 'range', min: 0, max: 1, step: 0.05, fmt: '%', section: 'Audio' },
  { key: 'touchHand', label: 'Touch layout', kind: 'choice',
    choices: [
      { value: 'split', label: 'Left / Right' },
      { value: 'mirror', label: 'Right / Left (mirrored)' },
    ], section: 'Touch' },
];

export const DEFAULTS = {
  controlMode: TWO_BUTTONS,
  sensitivity: 1.0,
  invertX: false,
  brightness: 1.0,
  fov: 50,
  motion: 1.0,
  quality: 2,
  rockDetail: true,
  landmarks: true,
  sound: true,
  volume: 0.7,
  touchHand: 'split',
  helpSeen: false, // persisted onboarding state; deliberately absent from the menu schema
};

const FIELD_BY_KEY = Object.fromEntries(SETTINGS_SCHEMA.map((f) => [f.key, f]));

// Coerce a single value to a valid one for its field. Out-of-range ranges are
// clamped; unknown choices and non-finite ranges fall back to the default;
// toggles become real booleans. Pure — unit-tested in test/settings.test.js.
export function clampSetting(key, value, fallback = DEFAULTS[key]) {
  if (key === 'helpSeen') return value === true;
  const field = FIELD_BY_KEY[key];
  if (!field) return value; // unknown key: leave as-is
  if (field.kind === 'range') {
    const n = typeof value === 'number' ? value : parseFloat(value);
    if (!Number.isFinite(n)) return fallback;
    return Math.min(field.max, Math.max(field.min, n));
  }
  if (field.kind === 'toggle') {
    if (typeof value === 'boolean') return value;
    // Retain the historic 0/1 DOM coercion, but reject strings such as "false".
    if (value === 1) return true;
    if (value === 0 || value === '') return false;
    return fallback;
  }
  if (field.kind === 'choice') {
    const valid = field.choices.map((c) => c.value);
    // numbers may arrive as strings from the DOM
    const coerced = typeof valid[0] === 'number' ? Number(value) : value;
    return valid.includes(coerced) ? coerced : fallback;
  }
  return value;
}

// Coerce a whole settings object: every known key is clamped, defaults fill the
// gaps, and unknown keys are dropped.
export function coerceSettings(raw = {}) {
  const source = raw !== null && typeof raw === 'object' && !Array.isArray(raw) ? raw : {};
  const out = {};
  for (const key of Object.keys(DEFAULTS)) {
    const v = Object.prototype.hasOwnProperty.call(source, key) ? source[key] : DEFAULTS[key];
    out[key] = clampSetting(key, v);
  }
  return out;
}

export class SettingsSystem {
  constructor({ prefersReducedMotion } = {}) {
    const stored = SaveSystem.getSettings();
    const hasSavedMotion = stored !== null && Object.prototype.hasOwnProperty.call(stored, 'motion');
    const preferReduced = prefersReducedMotion ?? globalThis.matchMedia?.('(prefers-reduced-motion: reduce)')?.matches ?? false;
    this.values = coerceSettings(hasSavedMotion ? stored : { ...stored, motion: preferReduced ? 0 : DEFAULTS.motion });
    this.listeners = new Set();
    // Repair malformed or partial data when storage is available. A blocked
    // backend simply declines the write, leaving the in-memory defaults usable.
    SaveSystem.setSettings(this.values);
  }

  get(key) { return this.values[key]; }

  set(key, value) {
    const v = clampSetting(key, value);
    this.values[key] = v;
    SaveSystem.setSettings(this.values);
    this.emit(key, v);
    return v;
  }

  reset() {
    this.values = { ...DEFAULTS };
    SaveSystem.setSettings(this.values);
    for (const k of Object.keys(this.values)) this.emit(k, this.values[k]);
  }

  onChange(fn) { this.listeners.add(fn); return () => this.listeners.delete(fn); }
  emit(key, value) { for (const fn of this.listeners) fn(key, value); }
}
